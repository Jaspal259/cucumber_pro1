// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-005-fedex-fed.js');

// period of service
const Ouk103P003PosDcDependantPensioner = function Ouk103P003PosDcDependantPensioner() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk103P003PosDcDependantPensioner';
  this.data.periodOfServiceTestDescription = 'For ouk-103';

  this.data.planType = 'DC';
  this.data.typeLabel = commonConstants.dcTypeLabel;
  this.data.posStatusValueAsNumber = 6;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
};
module.exports = Ouk103P003PosDcDependantPensioner;
