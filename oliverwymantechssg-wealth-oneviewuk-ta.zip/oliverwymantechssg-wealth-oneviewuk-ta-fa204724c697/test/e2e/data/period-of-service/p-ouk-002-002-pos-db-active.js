// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// period of service
const Ouk002P002PosDbDeferred = function Ouk002P002PosDbDeferred() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk002P002PosDbDeferred';
  this.data.periodOfServiceTestDescription = 'For ouk-2';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '108390'
  this.data.alternativeName = 'FIYOJWX CEN';
};
module.exports = Ouk002P002PosDbDeferred;
