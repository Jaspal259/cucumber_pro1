// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// period of service
const Ouk212P001PosPensioner = function Ouk212P001PosPensioner() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk212P001PosPensioner';
  this.data.periodOfServiceTestDescription = 'ouk-212 - pensioner';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '998'

  this.data.planType = 'Pensioner';
  this.data.typeLabel = commonConstants.pensionerTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = new Date('2002-02-01');
  this.data.nrdValue = new Date('2028-03-17');
  this.data.trdValue = new Date('2028-03-17');
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = true;
  this.data.pensionStartDateValue = new Date('0000-00-00');
  this.data.pensionNumberValue = 'OVT/000029';
  this.data.amountLabel = 'GROSS PENSION';
  this.data.amountDateLabel = 'A YEAR';
  this.data.amountValue = '£9,999,999.99';
};
module.exports = Ouk212P001PosPensioner;
