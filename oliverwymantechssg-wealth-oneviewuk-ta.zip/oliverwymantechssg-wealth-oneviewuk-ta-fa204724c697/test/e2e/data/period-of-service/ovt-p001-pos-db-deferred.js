// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/ovt-db-scheme.js');

// period of service
const OvtP001PosDbDeferred = function OvtP001PosDbDeferred() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'OvtP001PosDbDeferred';
  this.data.periodOfServiceTestDescription = 'DB deferred period of service for test participant 001';

  this.data.periodOfServicePrimaryKey = '01dac5e043dd17d53d0ce6fe785e2838'; // hashed version of '17160'

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 4;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = '30/08/1994';
  this.data.nrdValue = '04/08/2027';
  this.data.trdValue = '04/08/2027';
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.dateOfExitValue = '12/06/1998';
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = false;
  this.data.amountDate = '12/06/1998';
};
module.exports = OvtP001PosDbDeferred;
