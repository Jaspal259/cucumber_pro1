// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-004-all-card-visibility-disabled.js');

// period of service
const Ouk100PosPensioner = function Ouk100PosPensioner() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk100PosPensioner';
  this.data.periodOfServiceTestDescription = 'DC pensioner period of service for test participant - ouk-100';

  this.data.planType = 'Pensioner';
  this.data.typeLabel = commonConstants.pensionerTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = new Date('2002-02-01');
  this.data.nrdValue = new Date('2028-03-17');
  this.data.trdValue = new Date('2028-03-17');
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = true;
  this.data.pensionStartDateValue = new Date('2016-07-01');
  this.data.pensionNumberValue = 'OVT/000029';
  this.data.amountLabelDc = 'GROSS PENSION';
  this.data.amountDateLabel = 'A YEAR';
};
module.exports = Ouk100PosPensioner;
