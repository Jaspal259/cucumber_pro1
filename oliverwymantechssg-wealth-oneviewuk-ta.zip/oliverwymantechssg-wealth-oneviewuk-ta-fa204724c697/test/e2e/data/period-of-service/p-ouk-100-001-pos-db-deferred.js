// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-004-all-card-visibility-disabled.js');

// period of service
const Ouk100PosDbDeferred = function Ouk100PosDbDeferred() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk100PosDbDeferred';
  this.data.periodOfServiceTestDescription = 'DB deferred period of service for test participant - ouk-100';

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 4;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = new Date('2002-02-01');
  this.data.nrdValue = new Date('2028-03-17');
  this.data.trdValue = new Date('2028-03-17');
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = false;
};
module.exports = Ouk100PosDbDeferred;
