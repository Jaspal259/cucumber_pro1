// load common
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-009-whitbread-whi.js');

// period of service
const Ouk100P006PosDcActive = function Ouk100P006PosDcActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk100PosDcActive';
  this.data.periodOfServiceTestDescription = 'DC active period of service for test participant - ouk-100';

  this.data.planType = 'DC';
  this.data.typeLabel = commonConstants.dbTypeLabel;
};
module.exports = Ouk100P006PosDcActive;
