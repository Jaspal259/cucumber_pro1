// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-009-whitbread-whi.js');

// period of service
const Ouk100PosDcActive = function Ouk100PosDcActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk100PosDcActive';
  this.data.periodOfServiceTestDescription = 'DC active period of service for test participant - ouk-100';
  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '1126090'
  this.data.planType = 'DC';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.memberReference = 'STL5058';
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.posLastStatusChangeDate = new Date('1996-10-01');
  this.data.dateJoinedSchemeValue = new Date('1996-09-01');
};
module.exports = Ouk100PosDcActive;
