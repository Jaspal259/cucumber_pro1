// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/ovt-dc-scheme.js');

// period of service
const OvtP001PosDcActive = function OvtP001PosDcActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'OvtP001PosDcActive';
  this.data.periodOfServiceTestDescription = 'DC active period of service for test participant 001';

  this.data.periodOfServicePrimaryKey = '1d41bc8a111bba770a3d34d3aa301b92'; // hashed version of '17150'
  this.data.alternativeName = 'Andy Demo';

  this.data.planType = 'DC';
  this.data.typeLabel = commonConstants.dcTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = '01/06/2002';
  this.data.nrdValue = '04/08/2023';
  this.data.trdValue = '04/08/2021';
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = true;
  this.data.amountLabelDc = 'TOTAL FUND VALUE';
};
module.exports = OvtP001PosDcActive;
