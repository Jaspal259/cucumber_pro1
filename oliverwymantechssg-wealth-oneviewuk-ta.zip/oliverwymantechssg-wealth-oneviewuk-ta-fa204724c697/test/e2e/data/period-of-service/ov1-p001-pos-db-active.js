// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/ov1-db-scheme.js');

// period of service
const ov1P001PosDbActive = function ov1P001PosDbActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'ov1P001PosDbActive';
  this.data.periodOfServiceTestDescription = 'DB active period of service for OV1 TE client test participant 001';

  this.data.periodOfServicePrimaryKey = '2a7fcde6c6197d30b1e1ca55cd5e9457'; // hashed version of '17150'

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = '01/02/2002';
  this.data.nrdValue = '04/08/2023';
  this.data.trdValue = '04/08/2023';
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = false;
  this.data.amountDate = '06/04/2012';
};
module.exports = ov1P001PosDbActive;
