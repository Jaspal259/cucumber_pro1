// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/ovt-pensioner-scheme.js');

// period of service
const OvtP001PosPensioner = function OvtP001PosPensioner() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'OvtP001PosPensioner';
  this.data.periodOfServiceTestDescription = 'DC pensioner period of service for test participant 001';

  this.data.periodOfServicePrimaryKey = '6cbb5524c39e6bebfba8576cb5a9f5be'; // hashed version of '920'

  this.data.planType = 'Pensioner';
  this.data.typeLabel = commonConstants.pensionerTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = '01/02/2002';
  this.data.nrdValue = '17/03/2028';
  this.data.trdValue = '17/03/2028';
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = true;
  this.data.pensionStartDateValue = '30/04/2001';
  this.data.pensionNumberValue = 'OVT/000029';
  this.data.amountLabelDc = 'GROSS PENSION';
  this.data.amountDateLabel = 'A YEAR';
  this.data.amountValue = '£11,263.08';
};
module.exports = OvtP001PosPensioner;
