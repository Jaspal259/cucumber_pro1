// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// period of service
const Ouk100PosDbActive = function Ouk100PosDbActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.alternativeName = '';

  this.data.periodOfServiceTestId = 'Ouk100PosDbActive';
  this.data.periodOfServiceTestDescription = 'DB active period of service for test participant - ouk-100';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '5550'

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.posLastStatusChangeDate = new Date('1994-10-03');
  this.data.dateJoinedSchemeValue = new Date('1994-10-03');
};
module.exports = Ouk100PosDbActive;
