// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// period of service
const Ouk214PosPensioner = function Ouk214PosPensioner() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk214PosPensioner';
  this.data.periodOfServiceTestDescription = 'For ouk-214';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '104990'

  this.data.planType = 'Pensioner';
  this.data.typeLabel = commonConstants.pensionerTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.pensionStartDateValue = new Date('1999-09-04');
  this.data.pensionNumberValue = 'CEN/000064';
  this.data.amountLabelDc = 'GROSS PENSION';
  this.data.amountValue = '£10000000.00';     // expecting actual figure to be above this
  this.data.amountDateLabel = 'A YEAR';
};
module.exports = Ouk214PosPensioner;
