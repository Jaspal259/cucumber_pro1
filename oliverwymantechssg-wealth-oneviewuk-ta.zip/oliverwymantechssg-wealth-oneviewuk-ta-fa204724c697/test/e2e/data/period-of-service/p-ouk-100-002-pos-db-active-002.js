// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-008-centrica-cmp.js');

// period of service
const Ouk100PosDbActive = function Ouk100PosDbActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.alternativeName = '';

  this.data.periodOfServiceTestId = 'Ouk100PosDbActive';
  this.data.periodOfServiceTestDescription = 'DB active period of service for test participant - ouk-100';

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.posLastStatusChangeDate = new Date('2011-01-01');
  this.data.dateJoinedSchemeValue = new Date('2011-01-01');
};
module.exports = Ouk100PosDbActive;
