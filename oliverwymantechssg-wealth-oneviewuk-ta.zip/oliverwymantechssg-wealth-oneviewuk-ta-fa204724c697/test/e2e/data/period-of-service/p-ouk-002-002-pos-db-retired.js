// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-010-centrica-cfs.js');

// period of service
const Ouk002P002PosDbRetired = function Ouk002P002PosDbRetired() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk002P002PosDbRetired';
  this.data.periodOfServiceTestDescription = 'For ouk-2';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '200500'
  this.data.alternativeName = '';
};
module.exports = Ouk002P002PosDbRetired;
