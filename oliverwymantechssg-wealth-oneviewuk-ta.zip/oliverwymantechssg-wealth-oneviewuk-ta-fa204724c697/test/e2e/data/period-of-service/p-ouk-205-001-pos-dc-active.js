// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/ovt-dc-scheme.js');

// period of service
const Ouk205P001PosDcActive = function Ouk205P001PosDcActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk205P001PosDcActive';
  this.data.periodOfServiceTestDescription = 'DC active period of service for test participant - ouk-205';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '17150'

  this.data.planType = 'DC';
  this.data.typeLabel = commonConstants.dcTypeLabel;
  this.data.posStatusValueAsNumber = 1;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
  this.data.isDateJoinedSchemeRecordedInMidas = true;
  this.data.dateJoinedSchemeValue = new Date('2002-02-01');
  this.data.nrdValue = new Date('2028-03-17');
  this.data.trdValue = new Date('2028-03-17');
  this.data.isDateOfExitRecordedInMidas = true;
  this.data.isNrdRecordedInMidas = true;
  this.data.isTrdRecordedInMidas = true;
};
module.exports = Ouk205P001PosDcActive;
