// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// load data definitions
const PosDefinition = require('../_definitions/period-of-service-definition.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// period of service
const Ouk108P001PosDcActive = function Ouk108P001PosDcActive() {
  // private variables

  // exposed properties
  this.data = new PosDefinition();
  this.scheme = new Scheme();

  this.data.periodOfServiceTestId = 'Ouk108P001PosDcActive';
  this.data.periodOfServiceTestDescription = 'For ouk-108';

  this.data.periodOfServicePrimaryKey = '17c9f9ff5fb935fc69446151f418b700'; // hashed version of '20700'

  this.data.planType = 'DB';
  this.data.typeLabel = commonConstants.dbTypeLabel;
  this.data.posStatusValueAsNumber = 4;
  this.data.posStatusValue = commonTests.getParticipantStatusFromNumber(this.data.posStatusValueAsNumber);
};
module.exports = Ouk108P001PosDcActive;
