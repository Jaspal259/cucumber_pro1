// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');

// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/ov1-client.js');

// load period(s) of service
const PosDcActive = require('../period-of-service/ov1-p001-pos-dc-active.js');
const PosDcDeferred = require('../period-of-service/ov1-p001-pos-dc-deferred.js');
const PosDbActive = require('../period-of-service/ov1-p001-pos-db-active.js');
const PosDbDeferred = require('../period-of-service/ov1-p001-pos-db-deferred.js');
const PosPensioner = require('../period-of-service/ov1-p001-pos-pensioner.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// participant
const ov1Participant001 = function ov1Participant001() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcActive = new PosDcActive();
  this.posDcDeferred = new PosDcDeferred();
  this.posDbActive = new PosDbActive();
  this.posDbDeferred = new PosDbDeferred();
  this.posPensioner = new PosPensioner();

  this.client = new Client();
  this.posDcActive = new PosDcActive();
  this.posDcDeferred = new PosDcDeferred();
  this.posDbActive = new PosDbActive();
  this.posDbDeferred = new PosDbDeferred();
  this.posPensioner = new PosPensioner();

  this.data.participantTestId = 'ov1Participant001';
  this.data.participantTestDescription = 'TE OV1 client participant';

  this.data.userFirstName = 'NRBJNB';
  this.data.userInitials = 'N';
  this.data.userSurname = 'QIKGWXNNYUQTK';

  this.data.defaultUserId = () => {
    const ov3Environment = commonTests.getOv3Environment();

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        return '50313342';
      case commonConstants.appEnvironmentEnum.uat:
        return '50424165';
      case commonConstants.appEnvironmentEnum.staging:
        return '56408933';
      case commonConstants.appEnvironmentEnum.prod:
        return '50991983';
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
    }
  };

  this.data.nino = 'OV346336D';
  this.data.dateOfBirth = '04/08/1963';
  this.data.userId = 'TA19_gd4gd';          // was mercerdemo

  this.data.passcode = () => {
    const ov3Environment = commonTests.getOv3Environment();

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        return 'Bf5_fgsKct';
      case commonConstants.appEnvironmentEnum.uat:
        return 'Bg_4djVC4s';
      case commonConstants.appEnvironmentEnum.staging:
        return 'Hy3_vg67DgA';
      case commonConstants.appEnvironmentEnum.prod:
        return 'B5_fsd8JwVuj';
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
    }
  };

  this.data.emailAddress = 'daniel.freeman@mercer.com';

  this.data.mainPeriodOfService = this.posDcActive;
  this.data.numberOfPeriodsOfService = 5;
  this.data.numberOfDcPos = 2;
  this.data.numberOfDbPos = 2;
  this.data.numberOfPensionerPos = 1;
  this.data.overseasIndicator = 'N';
};
module.exports = ov1Participant001;
