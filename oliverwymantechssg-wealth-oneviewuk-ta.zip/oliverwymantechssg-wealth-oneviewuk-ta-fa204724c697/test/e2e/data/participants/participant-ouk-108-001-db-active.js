// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-centrica.js');

// load period(s) of service
const PosDbDeferred = require('../period-of-service/p-ouk-108-001-pos-db-active.js');

// participant
const participantOuk456P001 = function participantOuk456P001() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDbDeferred = new PosDbDeferred();

  this.data.participantTestId = 'participantOuk456P001';
  this.data.participantTestDescription = 'for ouk-100';

  this.data.nino = 'JK274505B';
  this.data.userId = 'CENDEFNODOE';
  this.data.passcode = () => 'OV3Password!';
};
module.exports = participantOuk456P001;
