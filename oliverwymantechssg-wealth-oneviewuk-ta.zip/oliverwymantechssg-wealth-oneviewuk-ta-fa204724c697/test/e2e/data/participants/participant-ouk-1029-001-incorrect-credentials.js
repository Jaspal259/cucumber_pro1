// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/ov1-client.js');

// participant
const participantOuk1029P001 = function participantOuk1029P001() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();

  this.data.participantTestId = 'participantOuk1029P001';
  this.data.participantTestDescription = 'For ouk-1029';

  this.data.userId = 'incorrectCredentials';
  this.data.passcode = () => 'WrongPwd123*';
};
module.exports = participantOuk1029P001;
