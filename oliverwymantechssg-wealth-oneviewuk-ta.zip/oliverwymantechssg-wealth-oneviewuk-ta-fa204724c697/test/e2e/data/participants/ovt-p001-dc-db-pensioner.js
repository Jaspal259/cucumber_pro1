// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');

// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/ovtdemo-client.js');

// load period(s) of service
const PosDcActive = require('../period-of-service/ovt-p001-pos-dc-active.js');
const PosDcDeferred = require('../period-of-service/ovt-p001-pos-dc-deferred.js');
const PosDbActive = require('../period-of-service/ovt-p001-pos-db-active.js');
const PosDbDeferred = require('../period-of-service/ovt-p001-pos-db-deferred.js');
const PosPensioner = require('../period-of-service/ovt-p001-pos-pensioner.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// participant
const ovtParticipant001 = function ovtParticipant001() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcActive = new PosDcActive();
  this.posDcDeferred = new PosDcDeferred();
  this.posDbActive = new PosDbActive();
  this.posDbDeferred = new PosDbDeferred();
  this.posPensioner = new PosPensioner();

  this.data.participantTestId = 'ovtParticipant001';
  this.data.participantTestDescription = 'OVT participant - 1 DC active POS, 1 DB active POS, 1 Pensioner POS';

  this.data.userFirstName = 'A';
  this.data.userSurname = 'Demonstration';
  this.data.defaultUserId = () => {
    const ov3Environment = commonTests.getOv3Environment();

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
      case commonConstants.appEnvironmentEnum.uat:
      case commonConstants.appEnvironmentEnum.staging:
      case commonConstants.appEnvironmentEnum.prod:
        return 'clientdemo';
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
    }
  };

  this.data.nino = 'OV123456D';
  this.data.dateOfBirth = '04/08/1963';
  this.data.userId = 'mercerdemo';

  this.data.passcode = () => {
    const ov3Environment = commonTests.getOv3Environment();

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
      case commonConstants.appEnvironmentEnum.uat:
      case commonConstants.appEnvironmentEnum.staging:
      case commonConstants.appEnvironmentEnum.prod:
        return 'Oneview2019*';

      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
    }
  };

  this.data.emailAddress = 'mercerdemo@mercer.com'; // dummy e-mail address - will never check email account for TE

  this.data.mainPeriodOfService = this.posDcActive;
  this.data.numberOfPeriodsOfService = 5;
  this.data.numberOfDcPos = 2;
  this.data.numberOfDbPos = 2;
  this.data.numberOfPensionerPos = 1;
  this.data.overseasIndicator = 'N';
};
module.exports = ovtParticipant001;
