// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-whitbread.js');

// load period(s) of service
const PosDcActive01 = require('../period-of-service/p-ouk-100-003-pos-dc-active-001.js');
const PosDcActive02 = require('../period-of-service/p-ouk-100-003-pos-dc-active-002.js');

// participant
const participantOuk100P003 = function participantOuk100P003() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcActive01 = new PosDcActive01();
  this.posDcActive02 = new PosDcActive02();

  this.data.participantTestId = 'participantOuk100P003';
  this.data.participantTestDescription = 'for ouk-100';

  this.data.userFirstName = 'Tepjh';
  this.data.userSurname = 'Zepkqffh';
  this.data.nino = 'NR564684B';
  this.data.userId = 'OV3DUP05';
  this.data.passcode = () => 'OV3Password!';

  this.data.numberOfPeriodsOfService = 2;
  this.data.numberOfDcPos = 2;
  this.data.numberOfDbPos = 0;
  this.data.numberOfPensionerPos = 0;
};
module.exports = participantOuk100P003;
