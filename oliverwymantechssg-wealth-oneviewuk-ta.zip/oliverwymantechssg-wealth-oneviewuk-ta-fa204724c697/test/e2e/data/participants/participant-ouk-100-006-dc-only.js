// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-fedex.js');

// load period(s) of service
const PosDcActive01 = require('../period-of-service/p-ouk-100-006-pos-dc-active-001.js');

// participant
const participantOuk100P006 = function participantOuk100P006() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcActive01 = new PosDcActive01();

  this.data.participantTestId = 'participantOuk100P006';
  this.data.participantTestDescription = 'for ouk-100';

  this.data.nino = 'JA626312B';
  this.data.userId = 'OV3DCD01';
  this.data.passcode = () => 'OV3Password!';
};
module.exports = participantOuk100P006;
