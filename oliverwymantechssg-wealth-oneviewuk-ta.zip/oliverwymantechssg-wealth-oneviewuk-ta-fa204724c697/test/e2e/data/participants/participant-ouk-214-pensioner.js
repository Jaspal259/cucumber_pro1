// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-centrica.js');

// load period(s) of service
const PosPensioner = require('../period-of-service/p-ouk-214-pos-pensioner.js');

// load scheme(s)
const Scheme = require('../schemes/scheme-006-centrica-cen.js');

// participant
const participantOuk002P003 = function participantOuk002P003() {
  // private variables
  this.scheme = new Scheme();

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posPensioner = new PosPensioner();
  // needs pensioner participant with multiple POS
  // where [ALTERNATE NAME] is held and is different
  this.data.participantTestId = 'participantOuk002P003';
  this.data.participantTestDescription = 'participant for ouk-2 - ';

  this.data.userFirstName = 'ZEPYJWYP BVS';
  this.data.userSurname = 'BPBXRJFZ';
  this.data.nino = 'ZB174229B';
  this.data.userId = 'OV3CEN02';
  this.data.passcode = () => 'Oneview247*';

  // this.data.mainPeriodOfService = this.posDbActive;
  this.data.numberOfPeriodsOfService = 2;
  this.data.numberOfPensionerPos = 2;
};
module.exports = participantOuk002P003;
