// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-outage-client.js');

// load period(s) of service
const PosDcActive = require('../period-of-service/ovt-p001-pos-dc-active.js');
const PosDcDeferred = require('../period-of-service/ovt-p001-pos-dc-deferred.js');
const PosDbActive = require('../period-of-service/ovt-p001-pos-db-active.js');
const PosDbDeferred = require('../period-of-service/ovt-p001-pos-db-deferred.js');
const PosPensioner = require('../period-of-service/ovt-p001-pos-pensioner.js');

// participant
const participantOuk1420P001 = function participantOuk1420P001() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcActive = new PosDcActive();
  this.posDcDeferred = new PosDcDeferred();
  this.posDbActive = new PosDbActive();
  this.posDbDeferred = new PosDbDeferred();
  this.posPensioner = new PosPensioner();

  this.data.participantTestId = 'participantOuk1420P001';
  this.data.participantTestDescription = 'OVT participant - for ouk-1420';

  this.data.userFirstName = 'A';
  this.data.userSurname = 'Demonstration';
  this.data.nino = 'OV123456D';
  this.data.userId = 'mercerdemo';
  this.data.passcode = () => 'Oneview321%';

  this.data.mainPeriodOfService = this.posDcActive;
  this.data.numberOfPeriodsOfService = 5;
  this.data.numberOfDcPos = 2;
  this.data.numberOfDbPos = 2;
  this.data.numberOfPensionerPos = 1;
  this.data.overseasIndicator = 'N';
};
module.exports = participantOuk1420P001;
