// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-centrica.js');

// load period(s) of service
const PosDbActive01 = require('../period-of-service/p-ouk-100-002-pos-db-active-001.js');
const PosDbActive02 = require('../period-of-service/p-ouk-100-002-pos-db-active-002.js');

// participant
const participantOuk100P002 = function participantOuk100P002() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDbActive01 = new PosDbActive01();
  this.posDbActive02 = new PosDbActive02();

  this.data.participantTestId = 'participantOuk100P002';
  this.data.participantTestDescription = 'for ouk-100';

  this.data.userFirstName = 'Zerlqjq';
  this.data.userSurname = 'Wikenw';
  this.data.nino = 'JA020038C';
  this.data.userId = 'OV3DUP011';
  this.data.passcode = () => 'OV3DUP011*';

  this.data.numberOfPeriodsOfService = 2;
  this.data.numberOfDcPos = 0;
  this.data.numberOfDbPos = 2;
  this.data.numberOfPensionerPos = 0;

  this.data.mainPeriodOfService = this.posDbActive02;
  this.data.overseasIndicator = 'NULL';
};
module.exports = participantOuk100P002;
