// load data definitions
const ParticipantDefinition = require('../_definitions/participant-definition.js');

// load client
const Client = require('../clients/client-fedex.js');

// load period(s) of service
const PosDcDependantPensioner = require('../period-of-service/p-ouk-103-003-pos-dc-dependant-pensioner.js');

// participant
const participantOuk103P003 = function participantOuk103P003() {
  // private variables

  // exposed properties
  this.data = new ParticipantDefinition();
  this.client = new Client();
  this.posDcDependantPensioner = new PosDcDependantPensioner();

  this.data.participantTestId = 'participantOuk103P003';
  this.data.participantTestDescription = 'OVT participant - for ouk-103';

  this.data.nino = 'YP927376A';
  this.data.userId = 'FEDTEST41';
  this.data.passcode = () => 'Oneview246*';
};
module.exports = participantOuk103P003;
