// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const ClientWhitbread = function ClientWhitbread() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'WHITBREAD';
  this.data.clientNameValue = 'WHITBREAD';
  this.data.isProductLogoUploaded = true;                  // default
  this.data.isClientLogoUploaded = true;                   // default
};
module.exports = ClientWhitbread;
