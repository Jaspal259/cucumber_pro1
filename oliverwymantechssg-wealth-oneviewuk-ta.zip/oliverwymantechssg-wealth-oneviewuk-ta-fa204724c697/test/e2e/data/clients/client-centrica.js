// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const ClientOvtDemo = function ClientOvtDemo() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'CENTRICA';
  this.data.clientNameValue = 'Wayne Enterprises';
  this.data.isProductLogoUploaded = false;                  // default
  this.data.isClientLogoUploaded = false;                   // default
};
module.exports = ClientOvtDemo;
