// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const OvtdemoClient = function OvtdemoClient() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'OVTDEMO';
  this.data.clientNameValue = 'Wayne Enterprises';
  this.data.isProductLogoUploaded = true;                  // default
  this.data.isClientLogoUploaded = true;                   // default
};
module.exports = OvtdemoClient;
