// NOTE this client is a partial client set up permanently in outage by Darren Vincent (may only be in QA currently)

// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const ClientOutageClient = function ClientOutageClient() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'OUTAGECLIENT';
  this.data.clientNameValue = 'to be defined';
  this.data.isProductLogoUploaded = true;                  // default
  this.data.isClientLogoUploaded = true;                   // default
};
module.exports = ClientOutageClient;
