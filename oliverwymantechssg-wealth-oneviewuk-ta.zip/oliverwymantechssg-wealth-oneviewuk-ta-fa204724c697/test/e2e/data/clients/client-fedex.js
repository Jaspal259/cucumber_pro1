// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const ClientOvtDemo = function ClientOvtDemo() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'FedEx';
  this.data.clientNameValue = 'FedEx';
  this.data.isProductLogoUploaded = true;                  // default
  this.data.isClientLogoUploaded = true;                   // default
};
module.exports = ClientOvtDemo;
