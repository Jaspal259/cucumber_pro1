// load data definitions
const ClientDefinition = require('../_definitions/client-definition.js');

// scheme
const Ov1Client = function Ov1Client() {
  // private variables

  // exposed properties
  this.data = new ClientDefinition();

  this.data.clientCode = 'OV1';
  this.data.clientNameValue = 'OV1 Test Automation only';
  this.data.isProductLogoUploaded = true;                  // default
  this.data.isClientLogoUploaded = true;                   // default
};
module.exports = Ov1Client;
