// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeCen = function SchemeCen() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeCen';
  this.data.schemeTestDescription = 'CEN scheme';

  this.data.midasSchemeCode = 'CENL';
  this.data.longSchemeNameValue = 'Centrica Engineers Pension Scheme is long enoughhhhhhhhhhhhh';
  this.data.isDateOfExitEnabledForPlan = true;
};
module.exports = SchemeCen;
