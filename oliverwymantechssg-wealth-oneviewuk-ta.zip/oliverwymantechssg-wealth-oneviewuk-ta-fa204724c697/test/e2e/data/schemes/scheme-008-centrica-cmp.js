// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeCmp = function SchemeCmp() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeCmp';
  this.data.schemeTestDescription = 'CMP scheme';

  this.data.midasSchemeCode = 'CMPL';
  this.data.longSchemeNameValue = '';
};
module.exports = SchemeCmp;
