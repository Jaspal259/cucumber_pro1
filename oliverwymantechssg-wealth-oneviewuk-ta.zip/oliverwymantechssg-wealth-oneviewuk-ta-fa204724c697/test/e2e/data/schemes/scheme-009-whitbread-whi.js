// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeWhi = function SchemeWhi() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeWhi';
  this.data.schemeTestDescription = 'WHI scheme';
  this.data.longSchemeNameValue = 'WHITBREAD GROUP PENSION FUND';
  this.data.midasSchemeCode = 'WHIL';
  this.data.isDateJoinedSchemeEnabledForPlan = false;
  this.data.isDateOfExitEnabledForPlan = false;
  this.data.isPensionStartDateEnabled = true;
  this.data.isPlanTypeDescriptionDefined = true;
};
module.exports = SchemeWhi;
