// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeCei = function SchemeCei() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeCei';
  this.data.schemeTestDescription = 'CEI scheme';

  this.data.midasSchemeCode = 'CEIL';
  this.data.longSchemeNameValue = '';
};
module.exports = SchemeCei;
