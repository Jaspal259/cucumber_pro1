// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const Ov1DcScheme = function Ov1DcScheme() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'Ov1DcScheme';
  this.data.schemeTestDescription = 'OV1 TE-only scheme';

  this.data.midasSchemeCode = 'f760717fff567b448034bce68c4fe24b'; // hashed version of 'OV1L'
  this.data.longSchemeNameValue = 'OVT Demo & Pension Plan';
  this.data.isDateJoinedSchemeEnabledForPlan = true;
  this.data.isDateOfExitEnabledForPlan = true;
  this.data.isPensionStartDateEnabled = true;
  this.data.isPlanTypeDescriptionDefined = true;
  this.data.isDcDashboardCardVisibilityEnabled = true;
  this.data.isDbDashboardCardVisibilityEnabled = true;
  this.data.isPensionerDashboardCardVisibilityEnabled = true;
};
module.exports = Ov1DcScheme;
