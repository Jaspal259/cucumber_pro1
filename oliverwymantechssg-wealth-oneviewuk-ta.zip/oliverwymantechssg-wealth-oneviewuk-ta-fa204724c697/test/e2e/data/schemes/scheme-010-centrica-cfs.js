// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeNoSchemeName = function SchemeNoSchemeName() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeNoSchemeName';
  this.data.schemeTestDescription = 'CFS scheme';

  this.data.midasSchemeCode = 'CFSL';
  this.data.longSchemeNameValue = '';
};
module.exports = SchemeNoSchemeName;
