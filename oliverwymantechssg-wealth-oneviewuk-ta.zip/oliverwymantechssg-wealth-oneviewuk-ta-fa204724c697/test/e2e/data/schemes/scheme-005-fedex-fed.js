// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const SchemeFed = function SchemeFed() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'SchemeFed';
  this.data.schemeTestDescription = 'FED scheme';

  this.data.midasSchemeCode = 'FEDL';
  this.data.isDateOfExitEnabledForPlan = true;
};
module.exports = SchemeFed;
