// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const Scheme002CcDisplayItemsDisabled = function Scheme002CcDisplayItemsDisabled() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'Scheme002CcDisplayItemsDisabled';
  this.data.schemeTestDescription = 'Scheme 002 - Trd disabled, Nrd enabled, '
    + 'DJP disabled, DOE disabled, Pension Start Date disabled';

  this.data.midasSchemeCode = 'CENL';
  this.data.longSchemeNameValue = 'Centrica Engineers Pension Scheme';
  this.data.isDateJoinedSchemeEnabledForPlan = false;
  this.data.isDateOfExitEnabledForPlan = false;
  this.data.isPensionStartDateEnabled = false;
  this.data.isPensionNumberEnabled = false;
  this.data.isPlanTypeDescriptionDefined = true;
  this.data.isDcDashboardCardVisibilityEnabled = true;
  this.data.isDbDashboardCardVisibilityEnabled = true;
  this.data.isPensionerDashboardCardVisibilityEnabled = true;
};
module.exports = Scheme002CcDisplayItemsDisabled;
