// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const OvtDbScheme = function OvtDbScheme() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'OvtDbScheme';
  this.data.schemeTestDescription = 'OVT scheme';

  this.data.midasSchemeCode = '9a3aa74a76b955568d6f9259ea382956'; // hashed version of 'OVTL'
  this.data.longSchemeNameValue = 'OVT Demo Plan';
  this.data.isDateJoinedSchemeEnabledForPlan = true;
  this.data.isDateOfExitEnabledForPlan = true;
  this.data.isPensionStartDateEnabled = true;
  this.data.isPlanTypeDescriptionDefined = true;
  this.data.isDcDashboardCardVisibilityEnabled = true;
  this.data.isDbDashboardCardVisibilityEnabled = true;
  this.data.isPensionerDashboardCardVisibilityEnabled = true;
};
module.exports = OvtDbScheme;
