// load data definitions
const SchemeDefinition = require('../_definitions/scheme-definition.js');

// scheme
const Scheme004AllCardVisibilityDisabled = function Scheme004AllCardVisibilityDisabled() {
  // private variables

  // exposed properties
  this.data = new SchemeDefinition();

  this.data.schemeTestId = 'Scheme004AllCardVisibilityDisabled';
  this.data.schemeTestDescription = 'scheme - all dashboard card visibility disabled';

  this.data.midasSchemeCode = 'OVTL';
  this.data.longSchemeNameValue = 'OVT Demo & Pension Plan';
  this.data.isDateJoinedSchemeEnabledForPlan = true;
  this.data.isDateOfExitEnabledForPlan = true;
  this.data.isPensionStartDateEnabled = true;
  this.data.isPlanTypeDescriptionDefined = true;
  this.data.isDcDashboardCardVisibilityEnabled = false;
  this.data.isDbDashboardCardVisibilityEnabled = false;
  this.data.isPensionerDashboardCardVisibilityEnabled = false;
};
module.exports = Scheme004AllCardVisibilityDisabled;
