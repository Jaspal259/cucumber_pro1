// definition
const clientDefinition = function clientDefinition() {
  // THIS FUNCTION ONLY DEFINES DATA STRUCTURE

  // private variables

  // exposed properties
  this.clientCode = 'define';
  this.clientNameValue = 'define';
  this.isProductLogoUploaded = true;                  // default
  this.isClientLogoUploaded = true;                   // default
};
module.exports = clientDefinition;
