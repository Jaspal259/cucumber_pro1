// definition
const schemeDefinition = function schemeDefinition() {
  // THIS FUNCTION ONLY DEFINES DATA STRUCTURE

  // private variables

  // exposed properties
  this.schemeTestId = 'define';
  this.schemeTestDescription = 'define';

  this.midasSchemeCode = 'define';
  this.longSchemeNameValue = 'define';
  this.isDateJoinedSchemeEnabledForPlan = 'define';   // same as DJP - date joined plan
  this.isDateOfExitEnabledForPlan = 'define';
  this.isPensionStartDateEnabled = 'define';
  this.isPensionNumberEnabled = true;
  this.isPlanTypeDescriptionDefined = 'define';
  this.isDcDashboardCardVisibilityEnabled = 'define';
  this.isDbDashboardCardVisibilityEnabled = 'define';
  this.isPensionerDashboardCardVisibilityEnabled = 'define';
};
module.exports = schemeDefinition;
