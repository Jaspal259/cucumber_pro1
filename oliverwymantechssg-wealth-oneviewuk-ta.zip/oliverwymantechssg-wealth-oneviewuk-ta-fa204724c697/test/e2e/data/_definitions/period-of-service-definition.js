// load common
const CommonConstants = require('../../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// definition
const periodOfServiceDefinition = function periodOfServiceDefinition() {
  // THIS FUNCTION ONLY DEFINES DATA STRUCTURE

  // private variables

  // exposed properties
  this.periodOfServiceTestId = 'define';
  this.periodOfServiceTestDescription = 'define';

  // this is used in the url of the POS page e.g. 17160 in /wealth-snapshot/OVTL/17160
  this.periodOfServicePrimaryKey = 'define';

  this.planType = 'define';
  this.typeLabel = 'define';
  this.memberReference = 'define';
  this.forenames = 'define';
  this.surname = 'define';
  this.alternativeName = 'define';
  this.alternativeGreeting = 'define';
  this.posStatusLabel = commonConstants.posStatusLabel;
  this.posStatusValueAsNumber = 'define';
  this.posStatusValue = 'define';
  this.posLastStatusChangeDate = 'define';  // not on OV3 or MIDAS - used for sorting - from SM_STATUS_DETAILS_H table
  this.dateJoinedSchemeLabel = 'Date Joined';  // same as DJP - date joined plan
  this.isDateJoinedSchemeRecordedInMidas = 'define';
  this.dateJoinedSchemeValue = 'define';
  this.nrdValue = 'define';
  this.trdValue = 'define';
  this.dateOfExitLabel = 'DATE OF EXIT';
  this.dateOfExitValue = 'define';
  this.isDateOfExitRecordedInMidas = 'define';
  this.retirementDateLabel = 'RETIREMENT DATE';
  this.isNrdRecordedInMidas = 'define';
  this.isTrdRecordedInMidas = 'define';
  this.pensionStartDateLabel = 'PENSION START DATE';
  this.pensionStartDateValue = 'define';
  this.pensionNumberLabel = 'PENSION NUMBER';
  this.pensionNumberValue = 'define';
  this.amountLabelDc = 'TOTAL FUND VALUE';
  this.amountLabelDb = 'PENSION BENEFIT';
  this.amountDateLabel = 'define';
  this.amountDate = 'define';
  this.amountValue = 'define';   // note we probably can't check amount value as this will continually update

  // detail Aggregated Benefits View cards
  this.dcTotalFundValue = 'define';
  this.dcTotalFundDate = new Date('2007-07-27');

  this.transferValueLabel = 'TRANSFER VALUE';
  this.transferValue = 'define';

  this.retirementBenefitValue = 'define';
};
module.exports = periodOfServiceDefinition;
