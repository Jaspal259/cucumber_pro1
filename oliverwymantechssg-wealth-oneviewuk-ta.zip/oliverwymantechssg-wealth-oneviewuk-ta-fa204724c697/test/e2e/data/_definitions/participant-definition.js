// definition
const participantDefinition = function participantDefinition() {
  // private variables

  // exposed properties
  this.participantTestId = 'define';
  this.participantTestDescription = 'define';
  this.userProfileContentEnabled = 'define';

  // note the user identification data should come from the main period of service
  // for the moment we can leave this data within our QA participant object
  // but we may need to do move these to the POS objects
  this.userFirstName = 'define';
  this.userInitials = 'define';
  this.userSurname = 'define';
  this.defaultUserId = () => 'define';
  this.nino = 'define';
  this.dateOfBirth = 'define';
  this.userId = 'define';
  this.passcode = () => 'define';
  this.emailAddress = 'define';

  this.mainPeriodOfService = 'define';
  this.numberOfPeriodsOfService = 'define';
  this.numberOfDcPos = 'define';
  this.numberOfDbPos = 'define';
  this.numberOfPensionerPos = 'define';
};
module.exports = participantDefinition;
