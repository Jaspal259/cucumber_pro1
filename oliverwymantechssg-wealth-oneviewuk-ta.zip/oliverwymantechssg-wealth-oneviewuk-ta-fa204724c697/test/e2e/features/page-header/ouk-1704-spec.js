// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();

const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

const dcPlanSummaryPage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);

const dbPlanSummaryPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);

const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-1704${commonConstants.bddScenarioPrefix}`;

async function loadPlanPage(cardInstance, planType) {
  if (planType === 'DC') {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromDashboard(dashboardPage, dcPlanSummaryPage, cardInstance);
  }

  if (planType === 'DB') {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromDashboard(dashboardPage, dbPlanSummaryPage, cardInstance);
  }

  if (planType === 'PIP') {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromDashboard(
      dashboardPage, pensionerPlanSummaryPage, cardInstance);
  }
}

function loadPlanPageThenClickHome(cardInstance, planType) {
  it(`THEN redirect [PARTICIPANT] to [DASHBOARD] (${planType})`, async () => {
    await loadPlanPage(cardInstance, planType);
    await commonTests.clickCommonHeaderLink(
      dashboardPage.header, dashboardPage.header.commonHeaderLinkEnum.home, true);
    await dashboardTests.checkDashboardPageLoadsWithCards(dashboardPage, standardParticipant);
  });
}

describe(`${scenarioPrefix}Home navigation`, () => {
  /* GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
       WHEN the [HOME LINK] is selected */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  loadPlanPageThenClickHome(0, 'DC');
  loadPlanPageThenClickHome(0, 'DB');
  loadPlanPageThenClickHome(0, 'PIP');

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
