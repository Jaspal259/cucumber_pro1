// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load test(s)
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-205${commonConstants.bddScenarioPrefix}`;

/*
   QA note - employer select page is not being implemented for MMP so the following scenarios are not
   tested for MMP in ouk-205:

   - Feature display (authenticated)
   - Employer select page

   and new scenario added by QA:

   - Authenticated, logo uploaded
 */

describe(`${scenarioPrefix}Authenticated, logo uploaded`, () => {
  /*
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    AND a logo has been uploaded for the [CLIENT]
    WHEN they view the [PAGE HEADER]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  it('THEN show [CLIENT LOGO] from CMS', async () => {
    expect(standardParticipant.client.data.isClientLogoUploaded === true);
    expect(dashboardPage.header.clientLogo.isPresent()).toBe(true);
    await checkers.containingImage(dashboardPage.header.clientLogoImage, '/files/pages/');
    await checkers.containingImage(dashboardPage.header.clientLogoImage, 'logo');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
