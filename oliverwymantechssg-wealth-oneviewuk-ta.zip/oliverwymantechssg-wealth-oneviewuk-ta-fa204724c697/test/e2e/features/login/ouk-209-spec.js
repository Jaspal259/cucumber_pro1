// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
// really n/a as this is an early test just to check existence of 'create account' link - doesn't do anything yet
// but need participant to set client for page URL
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const LoginTests = require('../_common/authentication-login.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const RegistrationPage = require('../../page-objects/authentication-registration.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const loginPage = new LoginPage(standardParticipant);
const registrationPage = new RegistrationPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-209${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Access`, () => {
  /*
    GIVEN that the Participant has not yet registered
    AND they wish to create an account
    WHEN they view the [Login page]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN show [CREATE ACCOUNT BUTTON] (now [REGISTER BUTTON])', async () => {
    await commonTests.clickElement(loginPage.loginFormUnselectedTab);
    expect(loginPage.registerButton.isEnabled()).toBe(true);
    await checkers.isMercerOsButtonSelected(loginPage.registerButton);
  });

  it('AND [CREATE ACCOUNT DESCRIPTION] from CMS', async () => {
    await checkers.exactText(loginPage.registerButton, 'Register');
  });

  it('AND the Participant navigates to registration page (WHEN they select the [CREATE ACCOUNT BUTTON])',
    async () => {
      await commonTests.clickElement(loginPage.registerButton);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(registrationPage, true);
    });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
