// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcEarningsHistory = require('../../page-objects/dc-earnings-history.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po');

// load participant(s)
const ParticipantOuk2218P001
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');
const ParticipantOuk2218P002
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');
const ParticipantOuk2218P003
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DcEarningHistoryTests = require('../_common/dc-earnings-history.spec.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participantOuk2218P001 = new ParticipantOuk2218P001();
const participantOuk2218P002 = new ParticipantOuk2218P002();
const participantOuk2218P003 = new ParticipantOuk2218P003();
const dcEarningHistoryTests = new DcEarningHistoryTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();

// tests
const scenarioPrefix = `OUK-2218${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Earnings history visibility`, () => {
  /*
    GIVEN the member has navigated to the DC plan summary page
    AND DC earnings history is enabled
    WHEN the DC plan summary page loads
   */

  const participant = participantOuk2218P001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);
  const dcEarningsHistoryPage = new DcEarningsHistory(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  it('THEN show DC earnings history link \n', async () => {
    await checkers.anyText(dcEarningsHistoryPage.planHeader.earningsHistoryLink);
    expect(dcEarningsHistoryPage.planHeader.earningsHistoryLink.getTagName()).toBe('a');
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

xdescribe(`${scenarioPrefix}Earnings history entry`, () => {
  /*
    GIVEN the DC earnings history link is available
    WHEN the member selects the DC earnings history link
   */

  const participant = participantOuk2218P001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);
  const dcEarningsHistoryPage = new DcEarningsHistory(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dcEarningHistoryTests.browseToDcEarningsHistoryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, dcEarningsHistoryPage, participant, 0);
  });

  it('THEN redirect member to the DC earnings history page in same browser window ', () => {
    expect(browser.getCurrentUrl()).toEqual(dcEarningsHistoryPage.url);
  });

  afterAll(async () => {
    await commonTests.logOut(dcEarningsHistoryPage, loginPage);
  });
});

/* Scenario will fail as id's need to add for dropdown items. */
function remunerationListsScenario(participant) {
  xdescribe(`${scenarioPrefix}Remuneration lists`, () => {
    /*
  GIVEN the member has navigated to the DC earnings history page
  AND DC remuneration types have been defined for the plan
  AND the member has DC remuneration history for the remuneration types defined for the Plan
  WHEN the page loads
 */

    const loginPage = new LoginPage(participant);
    const dashboardPage = new DashboardPage(participant);
    const dcPlanSummaryPage = new DcPlanSummaryPage(
      participant,
      participant.posDcActive.scheme.data.midasSchemeCode,
      participant.posDcActive.data.periodOfServicePrimaryKey);
    const dcEarningsHistoryPage = new DcEarningsHistory(
      participant,
      participant.posDcActive.scheme.data.midasSchemeCode,
      participant.posDcActive.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await dcEarningHistoryTests.browseToDcEarningsHistoryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, dcEarningsHistoryPage, participant, 0);
    });

    it('THEN show all available remuneration TYPES AND show links for each remuneration type'
    + ' AND show the remuneration history from their record for the Plan POS', async () => {
      const columnCount = await dcEarningsHistoryPage.getCountOfDataTableHeaderColumns();

      switch (participant) {
        case participantOuk2218P001:
          if (columnCount < 2) {
            await dcEarningHistoryTests.showAnnualEarningsDetails(dcEarningsHistoryPage);
          } else {
            await commonTests.clickElement(dcEarningsHistoryPage.earningHistorySalaryTypeDropdown);
            await commonTests.clickElement(dcEarningsHistoryPage.annualEarningsLink);
            await dcEarningHistoryTests.showAnnualEarningsDetails(dcEarningsHistoryPage);
          }
          break;

        case participantOuk2218P002:
          if (columnCount < 2) {
            await dcEarningHistoryTests.showPensionableSalaryDetails(dcEarningsHistoryPage);
            await dcEarningHistoryTests.showBonusDetails(dcEarningsHistoryPage);
          } else {
            await commonTests.clickElement(dcEarningsHistoryPage.earningHistorySalaryTypeDropdown);
            await commonTests.clickElement(dcEarningsHistoryPage.pensionableSalaryLink);
            await dcEarningHistoryTests.showPensionableSalaryDetails(dcEarningsHistoryPage);
            await commonTests.clickElement(dcEarningsHistoryPage.earningHistorySalaryTypeDropdown);
            await commonTests.clickElement(dcEarningsHistoryPage.grossEarningsLink);
            await dcEarningHistoryTests.showBonusDetails(dcEarningsHistoryPage);
          }
          break;

        case participantOuk2218P003:
          if (columnCount < 2) {
            await dcEarningHistoryTests.showAnnualEarningsDetails(dcEarningsHistoryPage);
            await dcEarningHistoryTests.showBonusDetails(dcEarningsHistoryPage);
          } else {
            await commonTests.clickElement(dcEarningsHistoryPage.earningHistorySalaryTypeDropdown);
            await commonTests.clickElement(dcEarningsHistoryPage.annualEarningsLink);
            await dcEarningHistoryTests.showAnnualEarningsDetails(dcEarningsHistoryPage);
            await commonTests.clickElement(dcEarningsHistoryPage.earningHistorySalaryTypeDropdown);
            await commonTests.clickElement(dcEarningsHistoryPage.grossEarningsLink);
            await dcEarningHistoryTests.showBonusDetails(dcEarningsHistoryPage);
          }
          break;

        default:
          throw new Error(`Does not support dbServiceInstance === ${participant}`);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dcEarningsHistoryPage, loginPage);
    });
  });
}

remunerationListsScenario(participantOuk2218P001);
remunerationListsScenario(participantOuk2218P002);
remunerationListsScenario(participantOuk2218P003);
