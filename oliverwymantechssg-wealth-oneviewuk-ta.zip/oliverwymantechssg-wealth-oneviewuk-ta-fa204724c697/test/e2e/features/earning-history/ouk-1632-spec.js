// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DbEarningsHistoryPage = require('../../page-objects/db-earnings-history.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbEarningsHistoryTests = require('../_common/db-earnings-history.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbEarningsHistoryTests = new DbEarningsHistoryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPageActive = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbEarningsHistoryPageActive = new DbEarningsHistoryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryPageDeferred = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
const dbEarningsHistoryPageDeferred = new DbEarningsHistoryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-1632${commonConstants.bddScenarioPrefix}`;
const until = protractor.ExpectedConditions;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dbEarningsHistoryTests.browseToDbEarningsHistoryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageActive, dbEarningsHistoryPageActive, standardParticipant, 0);
  } else {
    await dbEarningsHistoryTests.browseToDbEarningsHistoryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageDeferred, dbEarningsHistoryPageDeferred, standardParticipant, 1);
  }
}

function runEarningHistoryEntry(dbEarningsHistoryPage, participantStatus) {
  describe(`${scenarioPrefix}Earnings history entry - ${participantStatus}`, () => {
    /*
     GIVEN the DB earnings history link is available
     WHEN the member selects the DB earnings history link
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    it('THEN redirect member to the DB earnings history page in same browser window', async () => {
      await commonTests.checkPageLoadsAndContainsStandardElements(dbEarningsHistoryPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dbEarningsHistoryPage, loginPage);
    });
  });
}

runEarningHistoryEntry(dbEarningsHistoryPageActive, 'active');
runEarningHistoryEntry(dbEarningsHistoryPageDeferred, 'deferred');

function runRemunerationLists(dbEarningsHistoryPage, participantStatus) {
  describe(`${scenarioPrefix}Remuneration lists - ${participantStatus}`, () => {
    /*
      GIVEN the member has navigated to the DB earnings history page
      AND DB remuneration types have been defined for the plan
      AND the member has DB remuneration history for the remuneration types defined for the Plan
      WHEN the page loads
     */

    const checkSalaryDataTable = async () => {
      await browser.wait(until.visibilityOf(dbEarningsHistoryPage.dbEarningsTableHeaderRow),
        commonConstants.briefBrowserWaitDelay, 'DB earnings table header row not shown');
      await checkers.containingTextIgnoreCase(dbEarningsHistoryPage.getDataTableHeaderByIndex(0),
        'Date');
      await checkers.containingTextIgnoreCase(dbEarningsHistoryPage.getDataTableHeaderByIndex(1),
        'Amount');

      const rows = await dbEarningsHistoryPage.getDataTableRows();
      const rowsCount = await rows.length;
      expect(rowsCount).not.toBe(0, 'Missing data in salary data table');

      if (rowsCount > 3) {
        const middle = Math.ceil(rowsCount / 2);
        const last = rowsCount - 1;
        await checkers.anyUkDateOrNA(dbEarningsHistoryPage.getDataTableDateElementByIndex(0));
        await checkers.anyGbp(dbEarningsHistoryPage.getDataTableAmountElementByIndex(0));
        await checkers.anyUkDateOrNA(dbEarningsHistoryPage.getDataTableDateElementByIndex(middle));
        await checkers.anyGbp(dbEarningsHistoryPage.getDataTableAmountElementByIndex(middle));
        await checkers.anyUkDateOrNA(dbEarningsHistoryPage.getDataTableDateElementByIndex(last));
        await checkers.anyGbp(dbEarningsHistoryPage.getDataTableAmountElementByIndex(last));
      } else {
        for (let i = 0; i < rowsCount; i += 1) {
          await checkers.anyUkDateOrNA(dbEarningsHistoryPage.getDataTableDateElementByIndex(i));
          await checkers.anyGbp(dbEarningsHistoryPage.getDataTableAmountElementByIndex(i));
        }
      }
    };

    beforeAll(async () => {
      await login(participantStatus);
    });

    it('THEN show all available remuneration TYPES AND show links for each remuneration type'
      + ' AND show the remuneration history from their record for the Plan POS', async () => {
      // tabs or dropdown shown for salary types?
      const tabsCount = await dbEarningsHistoryPage.salariesTabs.count();

      if (tabsCount > 0) {
        // tabs
        for (let i = 0; i < tabsCount; i += 1) {
          const tab = await dbEarningsHistoryPage.salariesTab(i);
          await checkers.anyText(tab);
          await commonTests.clickElement(tab);
          await checkSalaryDataTable();
        }
      } else if (tabsCount === 0) {
        await checkSalaryDataTable();
      } else {
        // dropdown
        await checkers.containingTextIgnoreCase(dbEarningsHistoryPage.dropdownLabel, 'select');
        await checkers.anyUkYear(dbEarningsHistoryPage.dropdownSelectionValue);
        await commonTests.clickElement(dbEarningsHistoryPage.dropdownSelection);
        const optionsCount = await dbEarningsHistoryPage.dropdownOptions.count();

        // sanity check
        expect(optionsCount).toBeLessThan(101);

        for (let i = 0; i < optionsCount; i += 1) {
          await checkers.anyText(dbEarningsHistoryPage.dropdownOption(i));
        }

        await checkSalaryDataTable();
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dbEarningsHistoryPage, loginPage);
    });
  });
}

runRemunerationLists(dbEarningsHistoryPageActive, 'active');
runRemunerationLists(dbEarningsHistoryPageDeferred, 'deferred');
