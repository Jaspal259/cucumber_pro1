// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const LoginTests = require('../_common/authentication-login.spec.js');
const ForgotUserCredentialTests = require('../_common/authentication-forgot-user-credential.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const ForgotUserCredentialPage = require('../../page-objects/authentication-forgot-user-credential.po');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const forgotUserCredentialTests = new ForgotUserCredentialTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const forgotUserCredentialPage = new ForgotUserCredentialPage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-1579${commonConstants.bddScenarioPrefix}`;

async function browseToForgotUserIdPage() {
  await commonTests.clickElement(loginPage.forgotUserIdLink);
  await commonTests.checkUnauthPageLoadsAndContainsStandardElements(forgotUserCredentialPage, false);
  expect(browser.getCurrentUrl()).toContain(forgotUserCredentialPage.forgotUserIdUrl);
}

describe(`${scenarioPrefix}User navigates to Forgot User ID page + Participant verifies their identity`, () => {
  /*
    User navigates to Forgot Passcode page
    -----------------------------------------------------
    GIVEN the Participant is viewing the client login page
    WHEN they select the Forgot User ID link

    Participant verifies their identity
    -----------------------------------------------------
    GIVEN the Participant is viewing the Forgot User ID page
    WHEN they submit a valid default <User ID> and <e-mail address>
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: User navigates to Forgot User ID page
  it('THEN redirect Participant to Forgot User ID page', async () => {
    await browseToForgotUserIdPage();
  });

  // scenario: TE-added tests
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check page elements all present (includes OUK-6213)`,
    async () => {
    // check page elements all present
      if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
        await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdLabel, 'AUTHENTICATION');
      }

      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdHeaderLabel(global.deviceType),
        'Forgot');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardHeader, 'User ID');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'default User ID');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'e-mail address ');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'verify');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'account');
      await forgotUserCredentialTests.checkElementsOnPageCommonToForgotUserIdAndForgotPasscode(
        forgotUserCredentialPage);
    });

  // scenario: Participant verifies their identity
  it('THEN return Participant to login page', async () => {
    await forgotUserCredentialTests.checkValidUserIdAndEmailCanBeEntered(
      forgotUserCredentialPage, loginPage, standardParticipant);
  });

  it('AND show confirmation message', async () => {
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'e-mail');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'reset');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'online');
  });

  // NOTE TE cannot automate the Gherkin phrases
  //    AND <send forgotten User ID email> to e-mail address held for the participant
  //    AND update Participant event history

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

// TODO: re-enable once bug 9043 fixed
xdescribe(`${scenarioPrefix}Participant provides invalid credentials`, () => {
  /*
    GIVEN the Participant is viewing the Forgot User ID page
    WHEN the Participant navigates away from one of the <credential fields>
    AND the <credentials> provided do not meet the <required format>
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN display field error validation against each failed field (user ID)', async () => {
    await browseToForgotUserIdPage();
    await forgotUserCredentialTests.checkBlankUserIdRejected(forgotUserCredentialPage);
  });

  it('THEN display field error validation against each failed field (email address)', async () => {
    await forgotUserCredentialTests.checkSetOfInvalidEmailsRejected(forgotUserCredentialPage);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Participant selects forgot User ID link`, () => {
  /*
    GIVEN the Participant is viewing the Forgot User ID page
    WHEN they select the Forgot User ID link
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN display Contact Us notification message', async () => {
    await browseToForgotUserIdPage();
    await commonTests.clickElement(forgotUserCredentialPage.forgotUserIdLink);
    await browser.wait(
      until.visibilityOf(forgotUserCredentialPage.forgotUserIdPopUp),
      commonConstants.shortBrowserWaitDelay,
      'Contact Us notification message pop-up not shown');
    await checkers.anyText(forgotUserCredentialPage.forgotUserIdPopUp);
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdPopUpTitle, 'Forgot');
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdPopUpTitle, 'User ID');
    await checkers.anyTextOf20CharsPlus(forgotUserCredentialPage.forgotUserIdPopUpDescription);
  });

  // scenario: TE-added test
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND notification disappears when clicking elsewhere`,
    async () => {
      await commonTests.clickElement(forgotUserCredentialPage.mercerCardHeader);
      await browser.wait(
        until.invisibilityOf(forgotUserCredentialPage.forgotUserIdPopUp),
        commonConstants.shortBrowserWaitDelay,
        'Contact Us notification message pop-up still shown');
      expect(forgotUserCredentialPage.forgotUserIdPopUp.isPresent()).toBe(false);
      expect(forgotUserCredentialPage.forgotUserIdPopUpTitle.isPresent()).toBe(false);
      expect(forgotUserCredentialPage.forgotUserIdPopUpDescription.isPresent()).toBe(false);
    });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Participant selects Cancel`, () => {
  /*
    GIVEN the Participant is viewing the Forgot User ID page
    WHEN they select Cancel
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN return Participant to Login Page', async () => {
    await browseToForgotUserIdPage();
    await forgotUserCredentialTests.checkCancel(forgotUserCredentialPage, loginPage);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
