// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const loginTests = new LoginTests();

// tests
const scenarioPrefix = `OUK-3078${commonConstants.bddScenarioPrefix}`;

const invalidUserIdToken
  = `${browser.params.ov3RootUrl}${standardParticipant.client.data.clientCode}`
  + '/reset-userid?token=454a5960aa9642c88ac4f9268fa0f955ed27fc041fb342d385a7b815f31565df';
const invalidPasscodeToken
  = `${browser.params.ov3RootUrl}${standardParticipant.client.data.clientCode}`
  + '/reset-passcode?token=b8157768e63447d7893499633f9fd589665e04de2870453dbb50d898b07766e5';

function runInvalidTokenScenario(token, tokenDescription) {
  describe(`${scenarioPrefix}Invalid token (${tokenDescription} : ${token})`, () => {
    /*
      GIVEN the Participant has received a forgotten credential email
      GIVEN the Participant is <ineligible> to reset their credentials online
      WHEN the Participant selects the forgotten link in the email
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${tokenDescription}`);
      await browser.get(token);
    });

    it('THEN direct Participant to client login page', async () => {
      await loginPage.cookiePolicy.agreeCookiePolicy(true);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
    });

    it('AND show invalid token message (red toast)', async () => {
      await checkers.containingTextIgnoreCase(loginPage.toast.message, 'unable');
      await checkers.containingTextIgnoreCase(loginPage.toast.message, 'reset');
    });

    // scenario: TE-added tests
    it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check page elements all present`, async () => {
      await commonTests.clickElement(loginPage.toast.closeIcon);
      await loginTests.checkPageElements(loginPage);
    });

    afterAll(async () => {
      await commonTests.clearBrowserCacheAndCookies();
    });
  });
}

runInvalidTokenScenario(invalidUserIdToken, 'invalidUserIdToken');
runInvalidTokenScenario(invalidPasscodeToken, 'invalidPasscodeToken');
