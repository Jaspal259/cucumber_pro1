// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const RegistrationPage = require('../../page-objects/authentication-registration.po.js');
const LoginPage = require('../../page-objects/authentication-login.po.js');
const UsefulInfoTermsOfUsePage = require('../../page-objects/useful-info-terms-of-use.po.js');

// Load tests
const LoginTests = require('../_common/authentication-login.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const registrationPage = new RegistrationPage(standardParticipant);
const usefulInfoTermsOfUsePage = new UsefulInfoTermsOfUsePage(standardParticipant);

// other
const stepOneOnlyText = ' (step 1 only)';

// tests
const scenarioPrefix = `OUK-5048${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Participant already registered`, () => {
  /*
    GIVEN the Participant has previously registered to use OneView
    WHEN they submit valid User ID, National Insurance Number and DOB
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN return Participant to login screen', async () => {
    await commonTests.clickElement(loginPage.loginFormUnselectedTab);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);

    await commonTests.clickElement(loginPage.registerButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(registrationPage, true);
    const userId = standardParticipant.data.defaultUserId();
    await registrationPage.defaultUserIdInput.sendKeys(userId);
    await registrationPage.niNumberInput.sendKeys(standardParticipant.data.nino);
    await registrationPage.dateOfBirthInputText.sendKeys(standardParticipant.data.dateOfBirth);

    await commonTests.clickElement(registrationPage.continueButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  });

  it('AND show previously registered alert message', async () => {
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'already registered');
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Cancel whilst verifying account details`
  + ` + Cancel modal + Cancel modal, continue, cancel${stepOneOnlyText}`, () => {
  /*
    Cancel whilst verifying account details
    -----------------------------------------------------------
    GIVEN the Participant is registering to use OneView
    AND they have provided details in at least one of the [registration steps]
    WHEN they select cancel (decline on COU)

    Cancel modal, cancel
    -----------------------------------------------------------
    GIVEN view is Cancel modal
    WHEN the Participant selects cancel

    Cancel modal, continue
    -----------------------------------------------------------
    GIVEN the view is Cancel modal
    WHEN the Participant selects continue
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: Cancel whilst verifying account details
  it('THEN show cancel modal AND enable continue (primary button) AND enable cancel'
    + ' (Cancel modal, cancel) THEN dismiss cancel modal'
    + ' + AND return Participant to the view prior to selecting cancel', async () => {
    await commonTests.clickElement(loginPage.loginFormUnselectedTab);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);

    await commonTests.clickElement(loginPage.registerButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(registrationPage, true);
    const userId = standardParticipant.data.defaultUserId();
    await registrationPage.defaultUserIdInput.sendKeys(userId);
    await registrationPage.niNumberInput.sendKeys(standardParticipant.data.nino);
    await registrationPage.dateOfBirthInputText.sendKeys(standardParticipant.data.dateOfBirth);

    await unsavedChangesModalTests.cancelCancelUnsavedChanges(
      registrationPage,
      registrationPage.cancelButton,
      registrationPage.unsavedChangesModal,
      registrationPage.url);
  });

  // scenario: Cancel modal, cancel
  // 'THEN dismiss cancel modal' phrase included above
  // 'AND return Participant to the view prior to selecting cancel' phrase included above

  it('AND retain any details provided', async () => {
    const userId = standardParticipant.data.defaultUserId();
    await checkers.inputContainingText(registrationPage.defaultUserIdInput, userId);
    await checkers.inputContainingText(registrationPage.niNumberInput, standardParticipant.data.nino);
    await checkers.inputContainingText(registrationPage.dateOfBirthInputText, standardParticipant.data.dateOfBirth);
  });

  // scenario: Cancel modal, continue
  it('THEN dismiss cancel modal ... AND return Participant to OneView client login page', async () => {
    const userId = standardParticipant.data.defaultUserId();
    await registrationPage.defaultUserIdInput.sendKeys(userId);
    await registrationPage.niNumberInput.sendKeys(standardParticipant.data.nino);
    await registrationPage.dateOfBirthInputText.sendKeys(standardParticipant.data.dateOfBirth);

    await unsavedChangesModalTests.confirmCancelUnsavedChanges(
      registrationPage.cancelButton,
      registrationPage.unsavedChangesModal,
      registrationPage.url,
      loginPage,
      false);
  });

  it('AND show cancel message notification', async () => {
    await checkers.anyTextOf20CharsPlus(loginPage.toast.message);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Cancel through navigating away, no edits`, () => {
  /*
    GIVEN the Participant is registering to use OneView
    AND they have not provided details in the verify details step (step 1)
    WHEN the Participant attempts to navigate away
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN navigate Participant to page selected', async () => {
    await commonTests.clickElement(loginPage.loginFormUnselectedTab);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
    await commonTests.clickElement(loginPage.registerButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(registrationPage, true);
    await checkers.anyText(registrationPage.footer.termsOfUseLink);
    await commonTests.clickElement(registrationPage.footer.termsOfUseLink);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(usefulInfoTermsOfUsePage, false);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
