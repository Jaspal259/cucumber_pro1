// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec.js');
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const dashboardTests = new DashboardTests();

// as long as all participants use the same client we can just 1 participant to create the pages for all participants
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-1638${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Login card`, () => {
  /*
    GIVEN the Participant has previously registered
    AND they have navigated to the client login page
    AND the OneView status for at least one period of service is Eligible
    WHEN the client login page loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN enable updates to User ID and Passcode fields', () => {
    expect(loginPage.userIdInput.isEnabled()).toBe(true);
    expect(loginPage.passcodeInput.isEnabled()).toBe(true);
  });

  it('AND show Login button in active state as primary button', async () => {
    await checkers.containingTextIgnoreCase(loginPage.loginBtn, 'Log In');
    await checkers.isMercerOsButtonSelected(loginPage.loginBtn);
  });

  // scenario: TE-added tests
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check page elements all present`, async () => {
    await loginTests.checkPageElements(loginPage);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

async function enterUserIdAndPasscode(userId, passcode) {
  await loginPage.userIdInput.sendKeys(userId);
  await loginPage.passcodeInput.sendKeys(passcode);
  await commonTests.clickElement(loginPage.loginBtn);
}

function runBlankLoginDetailsScenario(userId, passcode) {
  describe(`${scenarioPrefix}Blank Login details (userId: '${userId}', passcode: '${passcode}')`, () => {
    /*
      GIVEN the Participant has previously registered
      AND they have navigated to the client login page
      AND the OneView status for at least one period of service is Eligible
      WHEN they submit <blank login details>
     */

    const userIdError = 'Your user ID is required';
    const passcodeError = 'Your passcode is required';
    const credentialsInvalidError = 'invalid';

    beforeAll(async () => {
      await loginTests.checkLoginPageLoads(loginPage);
    });

    it('THEN [retain login details]'
      + ' AND show [missing field validation error]'
      + ' AND show error notification message', async () => {
      await enterUserIdAndPasscode(userId, passcode);
      await checkers.inputContainingText(loginPage.userIdInput, userId);
      await checkers.inputContainingText(loginPage.passcodeInput, passcode);
      await checkers.anyTextOf20CharsPlus(loginPage.toast.message);

      if (userId === '' && passcode === '') {
        await checkers.containingTextIgnoreCase(loginPage.userIdRequiredErrorText, userIdError);
        await checkers.containingTextIgnoreCase(loginPage.passcodeRequiredErrorText, passcodeError);
        await checkers.containingTextIgnoreCase(loginPage.toast.message, credentialsInvalidError);
      } else if (passcode === '') {
        expect(loginPage.userIdRequiredErrorText.isPresent()).toBe(false);
        await checkers.containingTextIgnoreCase(loginPage.passcodeRequiredErrorText, passcodeError);
        await checkers.containingTextIgnoreCase(loginPage.toast.message, credentialsInvalidError);
      } else {
        await checkers.containingTextIgnoreCase(loginPage.userIdRequiredErrorText, userIdError);
        expect(loginPage.passcodeRequiredErrorText.isPresent()).toBe(false);
        await checkers.containingTextIgnoreCase(loginPage.toast.message, credentialsInvalidError);
      }
    });

    afterAll(async () => {
      await commonTests.clearBrowserCacheAndCookies();
    });
  });
}

runBlankLoginDetailsScenario('', '');
runBlankLoginDetailsScenario('abcd', '');
runBlankLoginDetailsScenario('', '123444');

function enterCredentialsAndCheckCredentialsDiscarded(userId, passcode) {
  it('THEN discard login details entered', async () => {
    await enterUserIdAndPasscode(userId, passcode);
    await checkers.inputNoText(loginPage.userIdInput);
    await checkers.inputNoText(loginPage.passcodeInput);
  });
}

function checkLoginFails(userId, passcode) {
  enterCredentialsAndCheckCredentialsDiscarded(userId, passcode);

  it('AND show an invalid login notification message', async () => {
    await checkers.containingTextIgnoreCase(loginPage.loginFormContent, 'User ID');
    await checkers.containingTextIgnoreCase(loginPage.loginFormContent, 'Passcode');
    await checkers.containingTextIgnoreCase(loginPage.loginFormContent, 'invalid');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'User ID');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'Passcode');
  });
}

describe(`${scenarioPrefix}Invalid User ID`, () => {
  /*
    GIVEN the Participant has previously registered
    AND they have navigated to the client login page
    AND the OneView status for at least one period of service is Eligible
    WHEN they submit an invalid User ID
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  checkLoginFails('xyz 123 asd rty', 'mercer123_');

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Invalid Passcode + Successful login, alternate User ID`, () => {
  /*
    Invalid Passcode
    -----------------------------------------------------------
    GIVEN their Participant account status is Active
    WHEN they submit a valid User ID
    BUT the Passcode is invalid

    Successful login, alternate User ID
    -----------------------------------------------------------
    GIVEN their Participant account status is Active
    AND they are not required to accept the conditions of use
    AND this is not the first time they have accessed OneView 3.0
    AND they have an alternate User ID
    AND their passcode has not expired
    WHEN they login using their valid alternate User ID and Passcode
   */

  // NOTE scenarios combined as 2nd will ensure standard participant account will not lockup as a result of the first

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: Invalid Passcode
  checkLoginFails(standardParticipant.data.userId, '****');

  it('AND show an invalid login notification message', async () => {
    await checkers.anyTextOf20CharsPlus(loginPage.toast.message);
  });

  // scenario: Successful login, alternate User ID
  it('THEN they should be directed to the OneView Dashboard page', async () => {
    // standard login
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
