// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const RegistrationPage = require('../../page-objects/authentication-registration.po');
const ForgotUserCredentialPage = require('../../page-objects/authentication-forgot-user-credential.po');
const DashboardPage = require('../../page-objects/dashboard.po');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po');
const ViewProfilePage = require('../../page-objects/view-profile.po.js');
const DbPlanMaterialsPage = require('../../page-objects/db-plan-materials.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const registrationPage = new RegistrationPage(standardParticipant);
const forgotUserCredentialPage = new ForgotUserCredentialPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const viewProfilePage = new ViewProfilePage(standardParticipant);
const dbPlanSummaryPage = new DbPlanSummaryPage(standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanMaterialsPage = new DbPlanMaterialsPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-4063${commonConstants.bddScenarioPrefix}`;

function checkBookmarkedPageLoads(bookmarkedNonAuthPageDescription, bookmarkedNonAuthPage, bookmarkedNonAuthPageUrl) {
  describe(`${scenarioPrefix}Bookmarked login page (${bookmarkedNonAuthPageDescription})`, () => {
    /*
      GIVEN Participant is not logged in
      AND the Participant has bookmarked a <non-authenticated page>
      WHEN bookmark selected
  */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(
        `${scenarioPrefix}${bookmarkedNonAuthPageDescription}`);
    });

    it('THEN redirect Participant to bookmarked page', async () => {
      await browser.get(bookmarkedNonAuthPageUrl);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(bookmarkedNonAuthPage, true);
    });

    afterAll(async () => {
      await commonTests.clearBrowserCacheAndCookies();
    });
  });
}

checkBookmarkedPageLoads('login page', loginPage, loginPage.url);
checkBookmarkedPageLoads('registration page', registrationPage, registrationPage.url);
checkBookmarkedPageLoads('forgot user ID page', forgotUserCredentialPage, forgotUserCredentialPage.forgotUserIdUrl);

describe(`${scenarioPrefix}Bookmarked login page (forgot user ID page)`, () => {
  /*
    GIVEN Participant is logged in
    AND the Participant has a <non-authenticated site page> bookmarked
    WHEN bookmark selected
  */

  beforeAll(async () => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  it('THEN redirect Participant to dashboard page', async () => {
    await browser.get(forgotUserCredentialPage.forgotUserIdUrl);
    await dashboardTests.checkDashboardPageLoadsWithCards(dashboardPage, standardParticipant);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

function checkBookmarkedPageWithinSiteLoads(bookmarkedAuthPageDescription, bookmarkedAuthPage) {
  describe(`${scenarioPrefix}Bookmarked page within site (${bookmarkedAuthPageDescription})`, () => {
    /*
      GIVEN Participant is logged in
      AND the Participant has an <authenticated site page> bookmarked
      WHEN bookmark selected
     */

    beforeAll(async () => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
    });

    it('THEN redirect Participant to bookmarked page', async () => {
      await browser.get(bookmarkedAuthPage.url);
      await commonTests.checkPageLoadsAndContainsStandardElements(bookmarkedAuthPage);
    });

    afterAll(async () => {
      await commonTests.logOut(bookmarkedAuthPage, loginPage);
    });
  });
}

checkBookmarkedPageWithinSiteLoads('dashboard', dashboardPage);
checkBookmarkedPageWithinSiteLoads('DB plan summary', dbPlanSummaryPage);
checkBookmarkedPageWithinSiteLoads('Pensioner plan summary', pensionerPlanSummaryPage);
checkBookmarkedPageWithinSiteLoads('DB plan materials', dbPlanMaterialsPage);
checkBookmarkedPageWithinSiteLoads('view profile', viewProfilePage);

describe(`${scenarioPrefix}Bookmarked page out of site (view profile)`, () => {
  /*
      GIVEN Participant is not logged in
      AND has an <authenticated site page> bookmarked
      WHEN bookmark selected
  */

  beforeAll(async () => {
    // ensure participant logged out - necessary for reliable Jenkins run
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
    await commonTests.logOut(dashboardPage, loginPage);
  });

  it('THEN redirect Participant to bookmarked page', async () => {
    await browser.get(viewProfilePage.url);
    expect(browser.getCurrentUrl()).toEqual(loginPage.url);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
