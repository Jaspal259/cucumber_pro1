// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
// really n/a for this test but required for client
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const LoginTests = require('../_common/authentication-login.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const loginPage = new LoginPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-198${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Max articles to display + Card content`, () => {
  /*
    Max articles to display
    ---------------------------------------
    GIVEN that the Participant is on the [LOGIN PAGE]
    WHEN they view the [LOGIN PAGE]

    Card content
    ---------------------------------------
    GIVEN that the Participant is on the [LOGIN PAGE]
    WHEN they are viewing a [LOGIN ARTICLE]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: Max articles to display
  it('THEN directly above the skinny footer, show 3 articles '
    + 'i.e. [LOGIN ARTICLE 1], [LOGIN ARTICLE 2], [LOGIN ARTICLE 3]', async () => {
    const articleCount = await loginPage.allArticles.count();
    expect(articleCount).toBe(3);
  });

  // scenario: Card content
  it('THEN show [LOGIN ARTICLE HEADLINE] from CMS', async () => {
    await checkers.containingTextIgnoreCase(loginPage.article0.headline, 'Register');
    await checkers.containingTextIgnoreCase(loginPage.article1.headline, 'Forgot');
    await checkers.containingTextIgnoreCase(loginPage.article2.headline, 'Safe');
  });

  it('AND [LOGIN ARTICLE MEDIA] from CMS', async () => {
    await checkers.containingImage(loginPage.article0.icon, '/files/articles/');
    await checkers.containingImage(loginPage.article1.icon, '/files/articles/');
    await checkers.containingImage(loginPage.article2.icon, '/files/articles/');
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND [ARTICLE DESCRIPTION] from CMS`, async () => {
    await checkers.anyTextOf20CharsPlus(loginPage.article0.articleDesc);
    await checkers.anyTextOf20CharsPlus(loginPage.article1.articleDesc);
    await checkers.anyTextOf20CharsPlus(loginPage.article2.articleDesc);
  });

  it('AND [LOGIN CTA DESC] from CMS', async () => {
    await checkers.containingTextIgnoreCase(loginPage.article0.callToAction, 'READ MORE');
    await checkers.containingTextIgnoreCase(loginPage.article1.callToAction, 'READ MORE');
    await checkers.containingTextIgnoreCase(loginPage.article2.callToAction, 'READ MORE');
  });

  it('AND [LOGIN CTA]', async () => {
    await checkers.containingLink(loginPage.article0.callToAction,
      `/${standardParticipant.client.data.clientCode}/articles`);
    await checkers.containingLink(loginPage.article1.callToAction,
      `/${standardParticipant.client.data.clientCode}/articles`);
    await checkers.containingLink(loginPage.article2.callToAction,
      `/${standardParticipant.client.data.clientCode}/articles`);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
