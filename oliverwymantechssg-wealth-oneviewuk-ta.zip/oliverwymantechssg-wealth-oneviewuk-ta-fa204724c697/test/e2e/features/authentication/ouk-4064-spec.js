// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');

// load participant(s)
const ParticipantCentrica
  = require('../../data/participants/participant-ouk-214-pensioner.js');
const ParticipantFedex
  = require('../../data/participants/participant-ouk-103-003-dc-dependant-pensioner.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const participantCentrica = new ParticipantCentrica();
const participantFedex = new ParticipantFedex();

// other
const ov3Environment = commonTests.getOv3Environment();
let areClientLoginPagesSetUp;

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
    areClientLoginPagesSetUp = true;
    break;
  case commonConstants.appEnvironmentEnum.prod:
    // TODO: remove once Centrica and FedEx client login pages set up and working
    areClientLoginPagesSetUp = false;
    break;
  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
}

// tests
const scenarioPrefix = `OUK-4064${commonConstants.bddScenarioPrefix}`;

function runClientVanityEmail(participant) {
  describe(`${scenarioPrefix}Client Vanity url (${participant.client.data.clientCode})`, () => {
    /*
     GIVEN Client has <vanity URL>
     WHEN the Participant attempts to access the client <vanity URL>
     */

    const loginPage = new LoginPage(participant);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(
        `${scenarioPrefix}${participant.client.data.clientCode}`);
      await loginTests.checkLoginPageLoads(loginPage);
    });

    it(`THEN redirect Participant to Client domain
        AND display client login page`, async () => {
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
      await loginTests.checkPageElements(loginPage);
    });

    afterAll(async () => {
      await commonTests.clearBrowserCacheAndCookies();
    });
  });
}

if (areClientLoginPagesSetUp) {
  runClientVanityEmail(participantCentrica);
  runClientVanityEmail(participantFedex);
}
