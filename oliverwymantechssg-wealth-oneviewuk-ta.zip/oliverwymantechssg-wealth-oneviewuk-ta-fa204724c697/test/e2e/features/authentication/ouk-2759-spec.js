// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const RegistrationPage = require('../../page-objects/authentication-registration.po.js');
const LoginPage = require('../../page-objects/authentication-login.po.js');

// Load tests
const LoginTests = require('../_common/authentication-login.spec.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const registrationPage = new RegistrationPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-2759${commonConstants.bddScenarioPrefix}`;

// other
const until = protractor.ExpectedConditions;

describe(`${scenarioPrefix}Login page + Register view`, () => {
  /*
    Login page
    ------------------------------------------
    GIVEN the Participant has their default User ID
    AND they have not registered to access OneView
    AND Participant account status is Active
    AND the OneView status for at least one period of service is Eligible
    GIVEN the Participant has navigated to the client login page
    WHEN they select the Register link

    Register view
    ------------------------------------------
    GIVEN the Participant has their default User ID
    AND they have not registered to access OneView
    AND Participant account status is Active
    AND the OneView status for at least one period of service is Eligible
    GIVEN view is Register view
    WHEN they select the Register button
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: Login page
  it('THEN switch view to Register view', async () => {
    await loginTests.checkPageElements(loginPage);
    await commonTests.clickElement(loginPage.loginFormUnselectedTab);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
    await checkers.containingTextIgnoreCase(loginPage.loginFormSelectedTab, loginPage.loginFormRegisterTabText);
    await checkers.containingTextIgnoreCase(loginPage.loginFormUnselectedTab, loginPage.loginFormLoginTabText);
  });

  // scenario: TE-added tests
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check login page elements all present`, async () => {
    await checkers.containingTextIgnoreCase(loginPage.registerHeading, 'Register');

    // this next line tests ouk-7306
    await checkers.anyTextOf20CharsPlus(loginPage.registerDescription);

    await checkers.containingTextIgnoreCase(loginPage.registerButton, 'Register');
  });

  // scenario: Register view
  it('THEN redirect Participant to registration flow step 1', async () => {
    await commonTests.clickElement(loginPage.registerButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(registrationPage, true);
  });

  // scenario: TE-added tests
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check registration page elements all present`
    + ' (includes OUK-6213)', async () => {
    // top of page
    await checkers.containingTextIgnoreCase(registrationPage.registrationHeaderLabel(global.deviceType),
      'Registration');

    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        // top of page

        await checkers.containingTextIgnoreCase(registrationPage.registrationLabel, 'AUTHENTICATION');
        await checkers.containingTextIgnoreCase(registrationPage.helpAndContactUsLink, 'Help & Contacts');

        // stepper

        expect(registrationPage.mercerStepperBarDesktop.isDisplayed()).toBe(true);


        // note need to specifically wait for icons to load as these load after main page
        await browser.wait(until.visibilityOf(registrationPage.registrationStepIconDesktop(0)),
          commonConstants.briefBrowserWaitDelay,
          'No registration step icon for \'Verify Your Identity\' shown');

        await checkers.containingTextIgnoreCase(registrationPage.registrationStepNumberDesktop(0), '1');
        await checkers.containingImage(registrationPage.registrationStepIconDesktop(0),
          commonConstants.checkImageSource);
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepTitleDesktop(0),
          'Verify Your Identity');

        await browser.wait(until.visibilityOf(registrationPage.registrationStepIconDesktop(1)),
          commonConstants.briefBrowserWaitDelay,
          'No registration step icon for \'Terms of Use\' shown');

        await checkers.containingTextIgnoreCase(registrationPage.registrationStepNumberDesktop(1), '2');
        await checkers.containingImage(registrationPage.registrationStepIconDesktop(1),
          commonConstants.checkImageSource);
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepTitleDesktop(1),
          'Terms of Use');


        await browser.wait(until.visibilityOf(registrationPage.registrationStepIconDesktop(2)),
          commonConstants.briefBrowserWaitDelay,
          'No registration step icon for \'Contact Details\' shown');

        await checkers.containingTextIgnoreCase(registrationPage.registrationStepNumberDesktop(2), '3');
        await checkers.containingImage(registrationPage.registrationStepIconDesktop(2),
          commonConstants.checkImageSource);
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepTitleDesktop(2),
          'Contact Details');


        await browser.wait(until.visibilityOf(registrationPage.registrationStepIconDesktop(3)),
          commonConstants.briefBrowserWaitDelay,
          'No registration step icon for \'Account\' shown');

        await checkers.containingTextIgnoreCase(registrationPage.registrationStepNumberDesktop(3), '4');
        await checkers.containingImage(registrationPage.registrationStepIconDesktop(3),
          commonConstants.checkImageSource);
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepTitleDesktop(3),
          'Account');

        // registration card content
        expect(registrationPage.registrationStepImage.getAttribute('style')).toContain('registr');
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepHeading, 'Verify Your Identity');
        await checkers.anyTextOf20CharsPlus(registrationPage.registrationStepDescription);

        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // stepper
        await checkers.containingTextIgnoreCase(registrationPage.registrationStepTitleMobile,
          'Verify Your Identity');
        break;

      default:
        throw new Error(
          `The deviceType '${global.deviceType}' is not supported.`
          + ' Please ensure no tests are switched off using xdescribe.');
    }

    // registration card content

    // note need to specifically wait for icons to load as these load after main page
    await browser.wait(until.visibilityOf(registrationPage.defaultUserIdIcon),
      commonConstants.briefBrowserWaitDelay,
      'No default user icon shown');

    await checkers.containingImage(registrationPage.defaultUserIdIcon, commonConstants.personImageSource);
    await checkers.containingTextIgnoreCase(registrationPage.defaultUserIdLabel, 'Default User ID');
    await checkers.inputNoText(registrationPage.defaultUserIdInput);
    expect(registrationPage.forgotDefaultUserIdLink(global.deviceType).getAttribute('mercer-popup')).toBe(null);

    await browser.wait(until.visibilityOf(registrationPage.niNumberIcon),
      commonConstants.briefBrowserWaitDelay,
      'No NI number icon shown');
    await checkers.containingImage(registrationPage.niNumberIcon, commonConstants.folderSharedImageSource);
    await checkers.containingTextIgnoreCase(registrationPage.niNumberLabel, 'National Insurance Number');
    await checkers.inputNoText(registrationPage.niNumberInput);

    await browser.wait(until.visibilityOf(registrationPage.dateOfBirthIcon),
      commonConstants.briefBrowserWaitDelay,
      'No date of birth icon shown');
    await checkers.containingImage(registrationPage.dateOfBirthIcon, commonConstants.dateRangeImageSource);
    await checkers.containingTextIgnoreCase(registrationPage.dateOfBirthLabel, 'Date of Birth');
    await checkers.containingTextIgnoreCase(registrationPage.dateOfBirthLabel, 'dd/mm/yyyy');
    expect(registrationPage.dateOfBirthInputDatePicker.isPresent()).toBe(true);
    await checkers.inputNoText(registrationPage.dateOfBirthInputText);

    // footer - includes test for OUK-6213 - note will check false and 2 once 6213 finished by Dev
    expect(registrationPage.backButton.isPresent()).toBe(true);
    const buttonCount = await registrationPage.getFooterButtons.count();
    expect(buttonCount).toBe(3);

    // footer - rest of test
    await checkers.containingTextIgnoreCase(registrationPage.cancelButton, 'Cancel');
    await checkers.isMercerOsButtonUnselected(registrationPage.cancelButton);
    expect(registrationPage.cancelButton.isEnabled()).toBe(true);
    await checkers.containingTextIgnoreCase(registrationPage.continueButton, 'Continue');
    await checkers.isMercerOsButtonSelected(registrationPage.continueButton);
    expect(registrationPage.continueButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
