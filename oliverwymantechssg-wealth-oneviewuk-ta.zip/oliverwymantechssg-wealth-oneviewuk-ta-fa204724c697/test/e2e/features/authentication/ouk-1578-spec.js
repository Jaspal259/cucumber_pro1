// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const LoginTests = require('../_common/authentication-login.spec.js');
const ForgotUserCredentialTests = require('../_common/authentication-forgot-user-credential.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const ForgotUserCredentialPage = require('../../page-objects/authentication-forgot-user-credential.po');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const forgotUserCredentialTests = new ForgotUserCredentialTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const forgotUserCredentialPage = new ForgotUserCredentialPage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-1578${commonConstants.bddScenarioPrefix}`;

async function browseToForgotPasscodePage() {
  await commonTests.clickElement(loginPage.forgotPasscodeLink);
  await commonTests.checkUnauthPageLoadsAndContainsStandardElements(forgotUserCredentialPage, false);
  expect(browser.getCurrentUrl()).toContain(forgotUserCredentialPage.forgotPasscodeUrl);
}

describe(`${scenarioPrefix}User navigates to Forgot Passcode page + Participant verifies their identity`, () => {
  /*
    User navigates to Forgot Passcode page
    -----------------------------------------------------
    GIVEN the Participant is viewing the client login page
    WHEN they select the Forgot Passcode link

    Participant verifies their identity
    -----------------------------------------------------
    GIVEN the Participant is viewing the Forgot Passcode page
    WHEN they submit a valid <User ID> and <e-mail address>
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // scenario: User navigates to Forgot Passcode page
  it('THEN redirect Participant to Forgot Passcode page', async () => {
    await browseToForgotPasscodePage();
  });

  // scenario: TE-added tests
  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check page elements all present (includes OUK-6213)`,
    async () => {
    // check page elements all present
      if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
        await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotPasscodeLabel,
          'AUTHENTICATION');
      }

      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotPasscodeHeaderLabel(global.deviceType),
        'Forgot');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardHeader, 'Forgot');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardHeader, 'passcode');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'User ID');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'e-mail');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'account.');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, 'reset');
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.mercerCardContent, '24 hours');

      await forgotUserCredentialTests.checkElementsOnPageCommonToForgotUserIdAndForgotPasscode(
        forgotUserCredentialPage);
    });

  // scenario: Participant verifies their identity
  it('THEN return Participant to login page', async () => {
    await forgotUserCredentialTests.checkValidUserIdAndEmailCanBeEntered(
      forgotUserCredentialPage, loginPage, standardParticipant);
  });

  it('AND show confirmation message', async () => {
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'e-mail');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'passcode');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'reset');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'online');
  });

  // NOTE TE cannot automate the Gherkin phrases
  //    AND <send forgotten Passcode email> to e-mail address held for the participant
  //    AND update Participant event history

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

// TODO: re-enable once bug 9043 fixed
xdescribe(`${scenarioPrefix}Participant provides invalid credentials`, () => {
  /*
    GIVEN the Participant is viewing the Forgot Passcode page
    WHEN the Participant navigates away from one of the <credential input fields>
    AND the <credentials> provided do not meet the <required format>
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN display field error validation against each failed field (user ID)', async () => {
    await browseToForgotPasscodePage();
    await forgotUserCredentialTests.checkBlankUserIdRejected(forgotUserCredentialPage);
  });

  it('THEN display field error validation against each failed field (email address)', async () => {
    await forgotUserCredentialTests.checkSetOfInvalidEmailsRejected(forgotUserCredentialPage);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Participant selects forgot User ID link (from forgot passcode page)`, () => {
  /*
    GIVEN the Participant is viewing the Forgot Passcode page
    WHEN they select the Forgot User ID link
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN redirect Participant to Forgot User ID page', async () => {
    await browseToForgotPasscodePage();
    const userIdLinkWait = commonConstants.mediumShortBrowserWaitDelay;
    await browser.wait(
      until.elementToBeClickable(forgotUserCredentialPage.forgotUserIdLink),
      userIdLinkWait,
      `Link to forgot user ID page is not displayed / not clickable (waited ${userIdLinkWait}ms)`);
    await commonTests.clickElement(forgotUserCredentialPage.forgotUserIdLink);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(
      forgotUserCredentialPage, false);
    expect(browser.getCurrentUrl()).toContain(forgotUserCredentialPage.forgotUserIdUrl);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Participant selects Cancel`, () => {
  /*
    GIVEN the Participant is viewing the Forgot Passcode page
    WHEN they select Cancel
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN return Participant to Login Page', async () => {
    await browseToForgotPasscodePage();
    await forgotUserCredentialTests.checkCancel(forgotUserCredentialPage, loginPage);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
