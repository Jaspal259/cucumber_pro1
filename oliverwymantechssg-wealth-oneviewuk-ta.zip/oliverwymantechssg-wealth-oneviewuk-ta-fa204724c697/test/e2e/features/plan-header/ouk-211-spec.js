// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// note can use just 1 participant object as all set to use same participant file
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-211${commonConstants.bddScenarioPrefix}`;

async function login(dbServiceInstance, dbPlanSummaryPage) {
  await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
    loginPage, dashboardPage, dbPlanSummaryPage, standardParticipant, dbServiceInstance);
}

function runAmalgamatedScenarios(planDesignAndStatus, dbServiceInstance, pos, schemeCode, primaryKey) {
  describe(`${scenarioPrefix}Display feature + Card Content`
  + ` + Multiple periods of service [POS] (${planDesignAndStatus})`, () => {
    /*
      Display feature
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DB Plan Summary] Page
      WHEN they view the DB Plan Summary Page

      Card Content
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DB Plan Summary] Page
      WHEN they view the [DB PLAN HEADER]

      Multiple periods of service [POS]
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DB Plan Summary] Page
      AND the Member has multiple [POS]
      WHEN the Member views [DB PLAN HEADER]
     */

    const dbPlanSummaryPage = new DbPlanSummaryPage(
      standardParticipant,
      schemeCode,
      primaryKey);
    const planHeader = dbPlanSummaryPage.planHeader;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planDesignAndStatus}`);
      await login(dbServiceInstance, dbPlanSummaryPage);
    });

    // Display feature
    it('(Display feature) THEN show [DB PLAN HEADER] beneath [Page Header]', async () => {
      await commonTests.clickExpandMoreButtonIfMobile(planHeader.mobileExpandMore);
      expect(dbPlanSummaryPage.planHeader.planHeader.isDisplayed()).toBe(true);
    });

    // Card Content
    it('(Card Content) THEN show the [DB PLAN DESCRIPTION] (OUK-101)', async () => {
      await checkers.containingTextIgnoreCase(planHeader.typeLabel, pos.data.typeLabel);
    });

    planHeaderTests.verifyCardContentScenario(planHeader, pos);

    // Multiple periods of service [POS]
    it('(Multiple POS) THEN show [CARD CONTENT] relevant to [POS] selected from Dashboard', async () => {
      await planHeaderTests.checkCardContentIsRelevantToPos(planHeader, pos);
    });

    afterAll(async () => {
      await commonTests.logOut(dbPlanSummaryPage, loginPage);
    });
  });
}

runAmalgamatedScenarios('DB active', 0, standardParticipant.posDbActive,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);

runAmalgamatedScenarios('DB deferred', 1, standardParticipant.posDbDeferred,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
