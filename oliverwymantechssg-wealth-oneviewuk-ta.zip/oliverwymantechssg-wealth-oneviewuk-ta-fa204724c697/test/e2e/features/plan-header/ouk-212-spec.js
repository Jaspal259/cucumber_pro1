// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();
const pos = standardParticipant.posPensioner;
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  pos.scheme.data.midasSchemeCode,
  pos.data.periodOfServicePrimaryKey);
const planHeader = pensionerPlanSummaryPage.planHeader;

// tests
const scenarioPrefix = `OUK-212${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Display feature + Card Content`, () => {
  /*
   Display feature
   -------------------------------------------------------------
   GIVEN that the Pensioner is on the [PIP Plan Summary] Page
   WHEN they view the PIP Plan Summary Page

   Card Content
   -------------------------------------------------------------
   GIVEN that the Pensioner is on the [PIP Plan Summary] Page
   WHEN they view the [PIP PLAN HEADER]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage,
      standardParticipant, 0);
  });

  // Display feature
  it('(Display feature) THEN show [PIP PLAN HEADER]', async () => {
    await commonTests.clickExpandMoreButtonIfMobile(planHeader.mobileExpandMore);
    expect(pensionerPlanSummaryPage.planHeader.planHeader.isDisplayed()).toBe(true);
  });

  // Card Content
  it('(Card Content) THEN show the [PIP PLAN DESCRIPTION] (OUK-101)', async () => {
    await checkers.containingTextIgnoreCase(planHeader.typeLabel, pos.data.typeLabel);
  });

  planHeaderTests.checkPlanName(planHeader, pos);

  it(`(Card Content) ${commonConstants.bddAdditionalCheckAddedByTe} AND [MEMBER REFERENCE]`, async () => {
    await checkers.containingTextIgnoreCase(planHeader.memberReferenceLabel, 'CLIENT');
    await checkers.containingTextIgnoreCase(planHeader.memberReferenceValue, 'TEST558635');
  });

  it('(Card Content) AND [PENSION NUMBER] (OUK-107)', async () => {
    await checkers.containingTextIgnoreCase(planHeader.pensionNumberLabel, pos.data.pensionNumberLabel);
    await checkers.containingTextIgnoreCase(planHeader.pensionNumberValue, pos.data.pensionNumberValue);
  });

  it('(Card Content) AND [PENSION START DATE] (OUK-124)', async () => {
    await checkers.containingTextIgnoreCase(planHeader.pensionStartDateLabel, pos.data.pensionStartDateLabel);
    await checkers.exactUkDate(planHeader.pensionStartDateValue, pos.data.pensionStartDateValue);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});
