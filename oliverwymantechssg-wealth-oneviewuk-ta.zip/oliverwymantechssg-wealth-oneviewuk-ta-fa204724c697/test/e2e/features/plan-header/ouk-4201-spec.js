/*
  note this was originally coded as ouk-1192 but has now been transferred and updated into 4201
 */

// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const LoginTests = require('../_common/authentication-login.spec.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginTests = new LoginTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dcPlanSummaryPage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);


// tests
const scenarioPrefix = `OUK-4201${commonConstants.bddScenarioPrefix}`;

async function checkProductLogoIsShown(page) {
  // note cannot test location but can check existence and image used
  await checkers.containingImage(page.productLogo.standardMercerLogoImage, 'logo');
}

describe(`${scenarioPrefix}Login page, has logo [originally from ouk-1192] + Plan summary page, has logo`, () => {
  /*
    Login page, has logo [originally from ouk-1192]
    -----------------------------------------------------------
    GIVEN that the [PARTICIPANT] has navigated to the Login Page
    AND the [PRODUCT LOGO] is available
    WHEN the Login page loads

    Plan summary page, has logo
    -----------------------------------------------------------
    GIVEN that the Participant is viewing a [PLAN SUMMARY PAGE]
    AND the [PRODUCT LOGO] is available
    WHEN the [PLAN HEADER] loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  // Login page, has logo [originally from ouk-1192]
  it('(Login page, has logo [originally from ouk-1192]) THEN show [PRODUCT LOGO]', async () => {
    // note cannot test location but can check existence and image used
    await checkProductLogoIsShown(loginPage);
  });

  // Plan summary page, has logo
  it('(Plan summary page, has logo) THEN show [PRODUCT LOGO] (DC)', async () => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, 0);
    await checkProductLogoIsShown(dcPlanSummaryPage);
  });

  it('(Plan summary page, has logo) THEN show [PRODUCT LOGO] (DB)', async () => {
    await commonTests.clickElement(dcPlanSummaryPage.header.commonHeaderBarMercerLogo);
    await dashboardTests.checkDashboardPageLoadsWithCards(dashboardPage, standardParticipant);
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromDashboard(
      dashboardPage, dbPlanSummaryPage, 0);
    await checkProductLogoIsShown(dbPlanSummaryPage);
  });

  it('(Plan summary page, has logo) THEN show [PRODUCT LOGO] (pensioner)', async () => {
    await commonTests.clickElement(dbPlanSummaryPage.header.commonHeaderBarMercerLogo);
    await dashboardTests.checkDashboardPageLoadsWithCards(dashboardPage, standardParticipant);
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromDashboard(
      dashboardPage, pensionerPlanSummaryPage, 0);
    await checkProductLogoIsShown(pensionerPlanSummaryPage);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});
