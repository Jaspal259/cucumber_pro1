// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// note can use just 1 participant object as all set to use same participant file
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);


// tests
const scenarioPrefix = `OUK-210${commonConstants.bddScenarioPrefix}`;

async function login(dcServiceInstance, dcPlanSummaryPage) {
  await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
    loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, dcServiceInstance);
}

function runAmalgamatedScenarios(planDesignAndStatus, dcServiceInstance, pos, schemeCode, primaryKey) {
  describe(`${scenarioPrefix}Display feature + Card Content`
  + ` + Multiple periods of service [POS] (${planDesignAndStatus})`, () => {
    /*
      Display feature
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DC Plan Summary] Page
      WHEN they view the DC Plan Summary Page

      Card Content
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DC Plan Summary] Page
      WHEN they view the [DC PLAN HEADER]

      Multiple periods of service [POS]
      ---------------------------------------------------------------
      GIVEN that the Member is on the [DC Plan Summary] Page
      AND the Member has multiple [POS]
      WHEN the Member views [DC PLAN HEADER]
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      schemeCode,
      primaryKey);
    const planHeader = dcPlanSummaryPage.planHeader;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planDesignAndStatus}`);
      await login(dcServiceInstance, dcPlanSummaryPage);
    });

    // Display feature
    it('(Display feature) THEN show [DC PLAN HEADER] beneath [Page Header]', async () => {
      await commonTests.clickExpandMoreButtonIfMobile(planHeader.mobileExpandMore);
      expect(dcPlanSummaryPage.planHeader.planHeader.isDisplayed()).toBe(true);
    });

    // Card Content
    it('(Card Content) THEN show the [DC PLAN DESCRIPTION] (OUK-101)', async () => {
      await checkers.containingTextIgnoreCase(planHeader.typeLabel, pos.data.typeLabel);
    });

    planHeaderTests.verifyCardContentScenario(planHeader, pos);

    // Multiple periods of service [POS]
    it('(Multiple POS) THEN show [CARD CONTENT] relevant to [POS] selected from Dashboard', async () => {
      await planHeaderTests.checkCardContentIsRelevantToPos(planHeader, pos);
    });

    afterAll(async () => {
      await commonTests.logOut(dcPlanSummaryPage, loginPage);
    });
  });
}

runAmalgamatedScenarios('DC active', 0, standardParticipant.posDcActive,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);

runAmalgamatedScenarios('DC deferred', 1, standardParticipant.posDcDeferred,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey);
