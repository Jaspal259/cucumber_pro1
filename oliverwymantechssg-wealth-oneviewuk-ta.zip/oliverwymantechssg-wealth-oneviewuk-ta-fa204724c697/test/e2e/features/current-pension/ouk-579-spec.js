// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const pos = standardParticipant.posPensioner;
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  pos.scheme.data.midasSchemeCode,
  pos.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-579${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Card display + Gross pension card`, () => {
  /*
    Card display
    -------------------------------------------------------
    GIVEN that the Pensioner is viewing the PIP Summary Page
    WHEN PIP Summary page loads

    Gross pension card
    -------------------------------------------------------
    GIVEN that the Pensioner is viewing the PIP Summary Page
    WHEN [GROSS PENSION CARD] loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, 0);
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}Check number of snapshot cards`, async () => {
    const cardCount = await pensionerPlanSummaryPage.getSnapshotCardCount();
    expect(cardCount).toBe(3);
  });

  // Card display
  it('(Card display) THEN show 3 cards in the following order [GROSS PENSION CARD]', () => {
    expect(pensionerPlanSummaryPage.grossPensionCard.isDisplayed()).toBe(true);
  });

  it('AND [GROSS YTD CARD]', () => {
    expect(pensionerPlanSummaryPage.grossYtdCard.isDisplayed()).toBe(true);
  });

  it('AND [TAX YTD CARD]', () => {
    expect(pensionerPlanSummaryPage.taxYtdCard.isDisplayed()).toBe(true);
  });

  // Gross pension card
  it('(Gross pension card) THEN show [GROSS PENSION CARD DESC]', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossPensionDesc, 'Gross Pension');
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND show [GROSS PENSION CARD ICON]`, async () => {
    await checkers.anyImage(pensionerPlanSummaryPage.grossPensionIcon);
  });

  it('AND [GROSS PENSION] to 2dp', async () => {
    await checkers.anyGbp(pensionerPlanSummaryPage.grossPensionAmount);
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossPensionAmountTerm, 'a year');
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND show [GROSS PENSION CTA]`, async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossPenAction, 'View Breakdown');
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Gross YTD + Payment frequency gross amount label (payment frequency = MONTHLY)`, () => {
  /*
    GIVEN that the Pensioner is viewing the PIP Summary Page
    WHEN [GROSS YTD CARD] loads
   */

  /*
    Extra JIRA test info:

    #Next Pay Date in 2.0 is in format dd Month yyyy but this is inconsistent with the rest of the site
    #Payment frequency gross amount label is conditional based on the payment frequency - see below
   */

  /*
      Extra JIRA test info:

      Examples:
      |PAYMENT FREQUENCY  |PAYMENT FREQUENCY GROSS LABEL
      |Weekly             |Weekly Gross Pay
      |Monthly            |Monthly Gross Pay
      |Annual             |Annual Gross Pay
      |Quarterly          |Quarterly Gross Pay
      |Half Yearly        |Biannual Gross Pay
      |Lunar              |Lunar Gross Pay
      #see comments for service decodes
     */

  // *** QA note - for automation there is one amalgamated scenario for 'Gross YTD' and
  // 'Payment frequency gross amount label' ***

  beforeAll(async () => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, 0);
  });

  it('THEN show [GROSS YTD CARD DESC]', async () => {
    expect(pensionerPlanSummaryPage.grossYtdCard.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossYtdDesc, 'Gross');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossYtdDesc, 'Year-to-Date');
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND show [GROSS YTD CARD ICON]`, async () => {
    await checkers.anyImage(pensionerPlanSummaryPage.grossYtdIcon);
  });

  it('AND [GROSS YTD] to 2dp', async () => {
    await checkers.anyGbp(pensionerPlanSummaryPage.grossYtdAmount);
  });

  it('AND show [PAYMENT FREQUENCY GROSS LABEL] based on [PAYMENT FREQUENCY]', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossYtdPayFreqLabel, 'MONTHLY');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossYtdPayFreqLabel, 'GROSS');
  });

  it('AND [PAYMENT FREQUENCY GROSS AMOUNT] to 2dp', async () => {
    await checkers.anyGbp(pensionerPlanSummaryPage.grossYtdFreqAmount);
  });

  it('AND [NEXT PAY DATE] format dd/mm/yyyy', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossYtdNextPayDateLabel, 'NEXT PAY DATE');
    await checkers.anyUkDate(pensionerPlanSummaryPage.grossYtdNextPayDateValue);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Tax YTD + Tax YTD learn more`, () => {
  /*
    Tax YTD
    -------------------------------------------------------
    GIVEN that the Pensioner is viewing the PIP Summary Page
    WHEN the [TAX YTD CARD] loads

    Tax YTD learn more
    -------------------------------------------------------
    GIVEN that the Pensioner is viewing the PIP Summary Page
    AND the Pensioner is viewing the [TAX YTD CARD]
    WHEN they select the [TAX YTD VIEW MORE LINK]
   */

  beforeAll(async () => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, 0);
  });

  // Tax YTD
  it('(Tax YTD) THEN show [TAX YTD CARD DESC]', async () => {
    expect(pensionerPlanSummaryPage.taxYtdCard.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdDesc, 'Tax');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdDesc, 'Year-to-Date');
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND show [TAX YTD CARD ICON]`, async () => {
    await checkers.anyImage(pensionerPlanSummaryPage.taxYtdIcon);
  });

  it('AND [TAX YTD] to 2dp', async () => {
    await checkers.anyGbp(pensionerPlanSummaryPage.taxYtdAmount);
  });

  it('AND [TAX CODEBASIS]', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdTaxCodeBasisLabel, 'TAX CODE/BASIS');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdTaxCodeBasisValue, 'S525L/0');
  });

  it('AND [TAX OFFICE REF]', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdTaxOfficeRefLabel, 'OFFICE REFERENCE');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdTaxOfficeRefValue, 'AA00000');
  });

  it('AND [TAX YTD VIEW MORE LINK]', async () => {
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxYtdAction, 'View Tax Office Address');
  });

  // Tax YTD learn more
  it('THEN show [TAX OFFICE DISTRICT ADDRESS]', async () => {
    await commonTests.clickElement(pensionerPlanSummaryPage.taxYtdAction);
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalHeader, 'Tax Office');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalHeader, 'Address');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalContent, 'Office District');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalContent, '581');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalContent, 'Tax Office District');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalContent, 'Pay As You Earn');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.taxModalContent, 'HM Revenue & Customs');

    const taxModalContinue = pensionerPlanSummaryPage.taxModalContinue(global.deviceType);
    await checkers.anyText(taxModalContinue);

    // check modal can be closed
    await commonTests.clickElement(taxModalContinue);
    expect(pensionerPlanSummaryPage.taxModalHeader.isPresent()).toBe(false);
    expect(pensionerPlanSummaryPage.taxModalContent.isPresent()).toBe(false);
    expect(taxModalContinue.isPresent()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});
