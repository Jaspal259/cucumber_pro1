// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');
const CurrentPensionTests = require('../_common/pensioner-current-pension.spec');
const TooltipTests = require('../_common/tooltips.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const CurrentPensionPage = require('../../page-objects/pensioner-current-pension.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const currentPensionTests = new CurrentPensionTests();
const tooltipTests = new TooltipTests();
const planHeaderTests = new PlanHeaderTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const currentPensionPage = new CurrentPensionPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

async function loginAndBrowseToCurrentPensionPage() {
  await currentPensionTests.browseToCurrentPensionPageViaPipPlanSummaryPage(
    loginPage, dashboardPage, pensionerPlanSummaryPage, currentPensionPage, standardParticipant, 0);
}

async function checkTableData() {
  const recordCount = await currentPensionPage.getPensionElementCount();

  if (recordCount === 1) {
    await currentPensionTests.checkPensionerData(currentPensionPage, 0);
  } else if (recordCount === 2) {
    await currentPensionTests.checkPensionerData(currentPensionPage, 0);
    await currentPensionTests.checkPensionerData(currentPensionPage, 1);
  } else if (recordCount > 2) {
    const lastRow = recordCount - 1;
    const midRow = Math.round(lastRow / 2);
    await currentPensionTests.checkPensionerData(currentPensionPage, 0);
    await currentPensionTests.checkPensionerData(currentPensionPage, midRow);
    await currentPensionTests.checkPensionerData(currentPensionPage, lastRow);
  } else {
    fail('No pensioner data found');
  }
}

async function checkTooltip(elementIndex) {
  // no. of tooltips checked is counted (0 or 1)
  let tooltipCount = 0;
  let tooltip = currentPensionPage.tooltips.firstRightTooltip;
  const iconPresent = await browser.isElementPresent(currentPensionPage.getElementNameHelpIcon(elementIndex));

  if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
    tooltip = currentPensionPage.tooltips.tooltipText;
  }

  if (iconPresent) {
    // only check for tooltip if icon there - icon dependant on Midas data (see bug 6772)
    await tooltipTests.checkTooltipIsElementWithAnyText(
      currentPensionPage.getElementNameHelpIcon(elementIndex),
      currentPensionPage.getCurrentAmount(elementIndex),
      tooltip
    );

    tooltipCount = 1;
  }

  return tooltipCount;
}

async function incrementTooltipCountIfTipDisplayed(tooltipCount, tooltipIndex) {
  const isTipDisplayed = await checkTooltip(tooltipIndex);   // note checkTooltip returns 1 if displayed, 0 otherwise
  return tooltipCount + isTipDisplayed;
}

async function checkInfoTooltips() {
  // no. of tooltips checked is counted (0 or >0)
  let tooltipCount = 0;
  const recordCount = await currentPensionPage.getPensionElementCount();

  if (recordCount === 1) {
    tooltipCount = await checkTooltip(0);
  } else if (recordCount === 2) {
    tooltipCount = await incrementTooltipCountIfTipDisplayed(tooltipCount, 0);
    tooltipCount = await incrementTooltipCountIfTipDisplayed(tooltipCount, 1);
  } else if (recordCount > 2) {
    const lastRow = recordCount - 1;
    const midRow = Math.round(lastRow / 2);

    tooltipCount = await incrementTooltipCountIfTipDisplayed(tooltipCount, 0);
    tooltipCount = await incrementTooltipCountIfTipDisplayed(tooltipCount, midRow);
    tooltipCount = await incrementTooltipCountIfTipDisplayed(tooltipCount, lastRow);
  } else {
    fail('No pensioner data found');
  }

  if (tooltipCount === 0) {
    fail('No tooltips (info text) found');
  }

  return tooltipCount;
}

async function checkHeaderInfoIcon(index, deviceType) {
  const tooltip = currentPensionPage.tooltips.topTooltip;
  const icon = currentPensionPage.getHeaderInfoIcon(index, deviceType);
  await checkers.containingImage(icon, commonConstants.infoImageSource);
  await tooltipTests.checkTooltipIsElementWithAnyText(
    icon,
    currentPensionPage.getHeaderName(index, deviceType),
    tooltip
  );
}

// tests
const scenarioPrefix = `OUK-1663${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Pension breakdown visibility`, () => {
  /*
    GIVEN Pension breakdown is enabled
    AND Gross Pension > 0
    AND at least 1 inclusive pension element is available
    WHEN the Pensioner navigates to the PIP Summary page
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, 0);
  });

  it('THEN enable "Pension Breakdown" feature in current pension card', async () => {
    expect(pensionerPlanSummaryPage.grossPensionCard.isDisplayed()).toBe(true);
    await checkers.anyGbp(pensionerPlanSummaryPage.grossPensionAmount);
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossPensionDesc, 'Gross');
    await checkers.containingTextIgnoreCase(pensionerPlanSummaryPage.grossPensionDesc, 'Pension');
    expect(pensionerPlanSummaryPage.grossPenAction.isEnabled()).toBe(true);
  });

  it('AND enable "Pension Breakdown" link in sub nav (as per OUK-4898)', async () => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      pensionerPlanSummaryPage,
      pensionerPlanSummaryPage.planHeader.pensionBreakdownLink,
      pensionerPlanSummaryPage.planHeader.pensionBreakdownLinkText,
      pensionerPlanSummaryPage.planHeader
    );
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(currentPensionPage);
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});

describe(`${scenarioPrefix}Pension breakdown views`, () => {
  /*
    GIVEN the 'Pension Breakdown' feature is enabled
    AND <non inclusive pension elements are available>
    WHEN the Pensioner navigates to the Pension Breakdown page
   */
  beforeAll(async () => {
    await loginAndBrowseToCurrentPensionPage();
  });

  it('THEN show Current Pension view as default view', async () => {
    await checkers.containingTextIgnoreCase(currentPensionPage.currentPensionView, 'Current');
    await checkers.containingTextIgnoreCase(currentPensionPage.currentPensionView, 'Pension');
    expect(currentPensionPage.grossPensionGraphImage.isDisplayed()).toBe(true);
  });

  it('AND [enable Future Benefits view]', () => {
    expect(currentPensionPage.futureBenefitsView.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});

async function checkPensionTableHeader(index, stringHeaderExpectedToContain, deviceType) {
  switch (deviceType) {
    case commonConstants.appDeviceTypeEnum.desktop:
      await checkers.containingTextIgnoreCase(currentPensionPage.getHeaderName(index, deviceType),
        stringHeaderExpectedToContain);
      break;

    case commonConstants.appDeviceTypeEnum.mobile:
      expect(currentPensionPage.getHeaderName(index, deviceType).getAttribute('data-mercer-table-th'))
        .toContain(stringHeaderExpectedToContain);
      break;

    default:
      throw new Error(`deviceType '${deviceType}' is not supported`);
  }
}

async function checkPensionTable(deviceType) {
  await checkPensionTableHeader(0, 'Name', deviceType);
  await checkPensionTableHeader(1, 'Amount', deviceType);
  await checkPensionTableHeader(2, 'Review', deviceType);
  await checkPensionTableHeader(3, 'Checkpoint', deviceType);
  await checkTableData();
}

describe(`${scenarioPrefix}Current Pension view`, () => {
  /*
  GIVEN view is Pension breakdown page
  WHEN the Pensioner navigates to the Current Pension view
 */

  beforeAll(async () => {
    await loginAndBrowseToCurrentPensionPage();
  });

  it('THEN show current gross pension', async () => {
    await checkers.anyGbp(currentPensionPage.grossPensionAmountLabel);
  });

  it('AND show all available inclusive pension elements', async () => {
    await checkPensionTable(global.deviceType);
  });

  // [AND order the elements as defined for the Plan] not coded as cosmetic

  it('AND show graph representing a breakdown of the total pension elements', () => {
    expect(currentPensionPage.grossPensionGraphImage.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});

describe(`${scenarioPrefix}Future Benefits view`, () => {
  /*
    GIVEN view is Pension breakdown page
    AND Future Benefits view is enabled
    WHEN the Pensioner navigates to the Future Benefits view
   */

  beforeAll(async () => {
    await loginAndBrowseToCurrentPensionPage();
  });

  it('THEN show all available non-inclusive pension elements', async () => {
    await checkers.anyText(currentPensionPage.futureBenefitsView);
    await commonTests.clickElement(currentPensionPage.futureBenefitsView);
    await checkPensionTable(global.deviceType);
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});

describe(`${scenarioPrefix}Pension elements information icons`, () => {
  /*
      GIVEN view is Pension breakdown page <selected view>
      AND information text is available for a <pension element type>
      WHEN the Pensioner selects the pension element information icon
     */

  beforeAll(async () => {
    await loginAndBrowseToCurrentPensionPage();
  });

  // TODO: get tooltips check working in mobile
  it(`${commonConstants.bddNotCheckedForMobileYet}`
      + 'THEN show [pension element type information text] (currentPension)', async () => {
    await checkInfoTooltips();
  });

  it(`${commonConstants.bddNotCheckedForMobileYet}`
      + 'THEN show [pension element type information text] (futureBenefits)', async () => {
    await commonTests.clickElement(currentPensionPage.futureBenefitsView);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(currentPensionPage);
    await checkInfoTooltips();
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});

describe(`${scenarioPrefix}Column header information icons`, () => {
  /*
      GIVEN view is Pension breakdown page <selected view>
      AND information text is available for a <column> label
      WHEN the Pensioner selects the column label information icon
     */

  beforeAll(async () => {
    await loginAndBrowseToCurrentPensionPage();
  });

  async function checkTooltips(deviceType) {
    // TODO: get tooltips check working in mobile
    if (deviceType !== commonConstants.appDeviceTypeEnum.mobile) {
      /*
        in bug OUK-9282 Matt Whittle stated, "I dropped the labels for the default views so not a bug. Please close."
        therefore dropping checks for first and second icons
       */
      await checkHeaderInfoIcon(0, deviceType);
      await checkHeaderInfoIcon(1, deviceType);
    }
  }

  // TODO: get tooltips check working in mobile
  it(`${commonConstants.bddNotCheckedForMobileYet}THEN show [column] label information text`, async () => {
    // current pension
    await checkTooltips(global.deviceType);
    await commonTests.clickElement(currentPensionPage.futureBenefitsView);
    await checkTooltips(global.deviceType);
  });

  async function checkSorters() {
    await checkers.containingImage(currentPensionPage.getHeaderInfoSorter(0),
      commonConstants.sorterImageSourceUpward);
    await checkers.containingImage(currentPensionPage.getHeaderInfoSorter(1),
      commonConstants.sorterImageSourceUpward);
    await checkers.containingImage(currentPensionPage.getHeaderInfoSorter(2),
      commonConstants.sorterImageSourceUpward);
    await checkers.containingImage(currentPensionPage.getHeaderInfoSorter(3),
      commonConstants.sorterImageSourceUpward);
  }

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND show [column] label sorter icon`, async () => {
    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await commonTests.clickElement(currentPensionPage.currentPensionView);
        await checkSorters();
        await commonTests.clickElement(currentPensionPage.futureBenefitsView);
        await checkSorters();
        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // sorters do not apply to mobile
        resultMessaging.passTestAsNotApplicable();
        break;

      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(currentPensionPage, loginPage);
  });
});
