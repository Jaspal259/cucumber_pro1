// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbAnnualStatementPage = require('../../page-objects/db-annual-statement.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbAnnualStatementTests = require('../_common/db-annual-statement.spec.js');
const AnnualStatementTests = require('../_common/annual-statement.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbAnnualStatementTests = new DbAnnualStatementTests();
const annualStatementTests = new AnnualStatementTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPageActive = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbAnnualStatementPageActive = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbPlanSummaryPageDeferred = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
const dbAnnualStatementPageDeferred = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey
);

// tests
const scenarioPrefix = `OUK-1569${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageActive, dbAnnualStatementPageActive, standardParticipant, 0);
  } else {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageDeferred, dbAnnualStatementPageDeferred, standardParticipant, 1);
  }
}

function runFeatureNavigationAndIntroTextScenarios(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Feature navigation + Annual Statement intro text - ${participantStatus}`, () => {
    /*
      Feature navigation
      --------------------------------------------------------
      GIVEN Annual Statement content source is MIDAS
      AND Annual Statement data is available for Member and POS
      AND Annual Statement data is permitted for viewing online
      WHEN member navigates to Annual statement page

      Annual Statement intro text
      --------------------------------------------------------
      Scenario - Annual Statement intro text
      GIVEN Annual Statement intro text has been published in CMS
      WHEN Member views Annual Statement page
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    // Feature navigation
    it('(Feature navigation) THEN show all available annual statement periods', async () => {
      await annualStatementTests.checkStatementsAvailableForAtLeastOnePeriod(dbAnnualStatementPage);
    });

    // (Feature navigation) BUT restrict to maximum permitted for plan'
    // don't check - data not set up

    // Annual Statement intro text
    it('(Annual Statement intro text) THEN show Annual Statement intro text', async () => {
      await checkers.anyText(dbAnnualStatementPage.annualStatement.introTextPrecedingStatements);
    });

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runFeatureNavigationAndIntroTextScenarios(dbAnnualStatementPageActive, 'active');
runFeatureNavigationAndIntroTextScenarios(dbAnnualStatementPageDeferred, 'deferred');

function runDataGroupsPreambleAndDrawInfoIconsScenarios(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Scenario - Annual Statement, pre-amble + Annual Statement, data groups`
    + ` Annual Statement, draw icons + Annual Statement, draw info icon - ${participantStatus}`, () => {
    /*
      Annual Statement, pre-amble
      --------------------------------------------------------
      GIVEN Annual Statement pre-amble text has been published in CMS
      WHEN Member views Annual Statement page

      Scenario - Annual Statement, data groups
      --------------------------------------------------------
      GIVEN Annual Statement content source is MIDAS
      AND Annual Statement data is available for the Member, POS and Period
      AND Annual Statement data is permitted for viewing online for that Period
      WHEN Member views Annual Statement page

      Scenario - Annual Statement, draw icons
      --------------------------------------------------------
      GIVEN one or more Annual Statement groups are available
      AND an icon is available for that group
      WHEN Members view Annual Statement page

      Annual Statement, draw info icon
      --------------------------------------------------------
      GIVEN Annual Statement content source is MIDAS
      AND Annual Statement data is available for the Member, POS and Period
      AND Annual Statement data is permitted for viewing online for that Period
      AND Annual statement group info icon text is populated for one or multiple Annual Statement groups available
      AND view is Annual Statement page
      WHEN Member selects Annual Statement Group info icon
     */

    beforeAll(async () => {
      await login(participantStatus);
    });

    // Annual Statement, pre-amble
    it('(Annual Statement, pre-amble) THEN show Annual Statement pre-amble draw as first draw in accordion',
      async () => {
        await annualStatementTests.checkPreAmbleIsFirstStatementShown(dbAnnualStatementPage);
      });

    // Annual Statement, data groups
    it('(Annual Statement, data groups) THEN show one draw for each Annual Statement group available', async () => {
      await annualStatementTests.checkAllStatementsContainHeader(
        dbAnnualStatementPage, 'DB', participantStatus);
    });

    // 'AND order Annual Statement groups as per group sequence in MIDAS' not automated

    // Annual Statement, draw icons
    it('(Annual Statement, draw icons) THEN show Annual Statement group icon for each'
    + ' draw where an icon is available', async () => {
      await annualStatementTests.checkAllStatementsContainHeaderDrawIcon(dbAnnualStatementPage);
    });

    // Annual Statement, draw info icon
    it('(Annual Statement, draw info icon) THEN show info icon message for that Annual Statement group', async () => {
      await annualStatementTests.checkTooltipsForAllStatements(dbAnnualStatementPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runDataGroupsPreambleAndDrawInfoIconsScenarios(dbAnnualStatementPageActive, 'active');
runDataGroupsPreambleAndDrawInfoIconsScenarios(dbAnnualStatementPageDeferred, 'deferred');

function runStatementDataViewAndFrequencyScenarios(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Annual Statement, data view + Annual statement, frequency - ${participantStatus}`, () => {
    /*
      Annual Statement, data view
      --------------------------------------------------------
      GIVEN Annual Statement content source is MIDAS
      AND Annual Statement data is available for the Member, POS and Period
      AND Annual Statement data is permitted for viewing online for that Period
      AND view is Annual Statement page
      WHEN Member expands an Annual Statement group draw containing Annual Statement data

      Scenario - Annual statement, frequency
      --------------------------------------------------------
      GIVEN Annual Statement content source is MIDAS
      AND Annual Statement data from MIDAS is available for Member, POS and Period
      AND Annual Statement data from MIDAS is permitted for viewing online for that Period
      AND monetary annual statement datanames have the frequency populated
      AND the frequency label is published in CMS
      AND view is Annual Statement page
      WHEN Member expands an Annual Statement group draw containing Annual Statement monetary data
    */

    beforeAll(async () => {
      await login(participantStatus);
    });

    // combined 'Annual Statement, data view' and 'Scenario - Annual statement, frequency'
    it('THEN show Annual Statement data for that Annual Statement group'
      + ' + THEN show frequency next to data value', async () => {
      await annualStatementTests.checkDataRowsInAllStatements(dbAnnualStatementPage);
    });

    // note 'AND order Annual Statement data as per field sequence in MIDAS' is not automated

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runStatementDataViewAndFrequencyScenarios(dbAnnualStatementPageActive, 'active');
runStatementDataViewAndFrequencyScenarios(dbAnnualStatementPageDeferred, 'deferred');
