// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcAnnualStatementPage = require('../../page-objects/dc-annual-statement.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// load tests
const DcAnnualStatementTests = require('../_common/dc-annual-statement.spec.js');
const AnnualStatementTests = require('../_common/annual-statement.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcAnnualStatementTests = new DcAnnualStatementTests();
const annualStatementTests = new AnnualStatementTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dcPlanSummaryPageActive = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey
);
const dcAnnualStatementPageActive = new DcAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey
);
const dcPlanSummaryPageDeferred = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey);
const dcAnnualStatementPageDeferred = new DcAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey
);

// tests
const scenarioPrefix = `OUK-6169${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dcAnnualStatementTests.browseToDcAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPageActive, dcAnnualStatementPageActive, standardParticipant, 0);
  } else {
    await dcAnnualStatementTests.browseToDcAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPageDeferred, dcAnnualStatementPageDeferred, standardParticipant, 1);
  }
}

function runPostAmbleAndDataNotAvailableScenarios(dcAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Annual Benefit Statement, post-amble (notes)`
    + ` + Data not available, link available (status: ${participantStatus})`, () => {
    /*
      Annual Benefit Statement, post-amble (notes)
      ---------------------------------------------------
      GIVEN Annual statement post-amble content is available
      WHEN Member views DC Annual Statement page

      Data not available, link available
      ---------------------------------------------------
      GIVEN DB Annual Statement feature is enabled
      AND no statement information is available
      AND view is DB Summary page
      WHEN Member navigates to DC Annual statement page

      TE note - automated test should only test example |Enabled|Enabled|No|Yes|No|
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    // Annual Benefit Statement, post-amble (notes)
    it('(Annual Benefit Statement, post-amble (notes)) THEN show post-amble draw consisting of:\n'
      + '  1. pre-caveat text (CMS)\n'
      + '  2. caveat text (Midas)\n'
      + '  3. post-caveat text (CMS)\n'
      + '  4. footer text (CMS)', async () => {
      await annualStatementTests.checkNotesStatement(dcAnnualStatementPage);
    });

    // Data not available, link available
    it('(Data not available, link available) THEN show empty state', async () => {
      await annualStatementTests.checkTheNoDataContainerIsNotShown(dcAnnualStatementPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dcAnnualStatementPage, loginPage);
    });
  });
}

runPostAmbleAndDataNotAvailableScenarios(dcAnnualStatementPageActive, 'active');
runPostAmbleAndDataNotAvailableScenarios(dcAnnualStatementPageDeferred, 'deferred');
