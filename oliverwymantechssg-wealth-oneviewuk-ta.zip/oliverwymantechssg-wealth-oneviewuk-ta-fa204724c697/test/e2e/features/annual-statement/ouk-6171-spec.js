// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcAnnualStatementPage = require('../../page-objects/dc-annual-statement.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DcAnnualStatementTests = require('../_common/dc-annual-statement.spec.js');
const AnnualStatementTests = require('../_common/annual-statement.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcAnnualStatementTests = new DcAnnualStatementTests();
const annualStatementTests = new AnnualStatementTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dcPlanSummaryPageActive = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey
);
const dcAnnualStatementPageActive = new DcAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey
);
const dcPlanSummaryPageDeferred = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey
);
const dcAnnualStatementPageDeferred = new DcAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey
);

// tests
const scenarioPrefix = `OUK-6171${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dcAnnualStatementTests.browseToDcAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPageActive, dcAnnualStatementPageActive, standardParticipant, 0);
  } else {
    await dcAnnualStatementTests.browseToDcAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPageDeferred, dcAnnualStatementPageDeferred, standardParticipant, 1);
  }
}

// note the OUK-6171 'Feature navigation' and 'Topic info icon' scenarios are no longer automated as,
// for the OV1 client 'mercerdemo' participant used for test automation, these are effectively duplicates
// of the OUK-6167 'Feature navigation' and 'Annual Statement, draw info icon' scenarios

function runDrawAndIconsScenario(dcAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Draw visibility + Topic icon - ${participantStatus}`, () => {
    /*
        Background
        GIVEN DB Annual Statement feature is enabled (see OUK-1569)
        AND Annual Statement content source is Secured Content

        Draw visibility
        --------------------------------------------
        (AND)
        GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
        WHEN Member navigates to DC Annual Statement page

        Topic icon
        --------------------------------------------
        (AND)
        GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
        AND an icon is available for a topic
        WHEN Member navigates to DC Annual Statement page
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    // Draw visibility
    it('THEN show a draw for each available personalised statement topic + AND order draws:\n'
      + ' *BENEFIT_STATEMENT\n'
      + ' *SMPI\n'
      + ' *AVC_STATEMENT\n'
      + ' *AVC_STATEMENT_1\n'
      + ' *AVC_STATEMENT_2\n'
      + ' *AVC_STATEMENT_3\n'
      + ' *AVC_STATEMENT_4\n'
      + ' *SUPP_STATEMENT\n'
      + ' *SUPP_STATEMENT_1\n'
      + ' *SUPP_STATEMENT_2', async () => {
      await annualStatementTests.checkPersonalisedStatementShown(dcAnnualStatementPage);
    });

    // order will not be checked by TE as this is cosmetic and a Business test

    // Topic icon
    it('THEN show topic icon against corresponding draw (personalised statements)', async () => {
      await annualStatementTests.checkTopicIconForPersonalisedStatements(
        dcAnnualStatementPage, 'DC', participantStatus);
    });

    afterAll(async () => {
      await commonTests.logOut(dcAnnualStatementPage, loginPage);
    });
  });
}

runDrawAndIconsScenario(dcAnnualStatementPageActive, 'active');
runDrawAndIconsScenario(dcAnnualStatementPageDeferred, 'deferred');

// note the OUK-6171 'Feature navigation' and 'Topic info icon' scenarios are no longer automated as,
// for the OV1 client 'mercerdemo' participant used for test automation, these are effectively duplicates
// of the OUK-6167 'Feature navigation' and 'Annual Statement, draw info icon' scenarios

function runDrawContentScenario(dcAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Draw content - ${participantStatus}`, () => {
    /*
      GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
      AND view is DC Annual Statement page
      WHEN Member expands a personalised statement draw
     */

    beforeAll(async () => {
      await login(participantStatus);
    });

    it(`THEN show personalised statement type icon 
        AND show document description`, async () => {
      await annualStatementTests.checkDataForAllPersonalisedStatements(dcAnnualStatementPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dcAnnualStatementPage, loginPage);
    });
  });
}

runDrawContentScenario(dcAnnualStatementPageActive, 'active');
runDrawContentScenario(dcAnnualStatementPageDeferred, 'deferred');
