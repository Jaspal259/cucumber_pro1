// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbAnnualStatementPage = require('../../page-objects/db-annual-statement.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load tests
const DbAnnualStatementTests = require('../_common/db-annual-statement.spec.js');
const AnnualStatementTests = require('../_common/annual-statement.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbAnnualStatementTests = new DbAnnualStatementTests();
const annualStatementTests = new AnnualStatementTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPageActive = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbAnnualStatementPageActive = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbPlanSummaryPageDeferred = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
const dbAnnualStatementPageDeferred = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey
);

// tests
const scenarioPrefix = `OUK-2427${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageActive, dbAnnualStatementPageActive, standardParticipant, 0);
  } else {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageDeferred, dbAnnualStatementPageDeferred, standardParticipant, 1);
  }
}

function runPostAmbleAndDataNotAvailableScenarios(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Annual Benefit Statement, post-amble (notes)`
    + ` + Data not available, link available (status: ${participantStatus})`, () => {
    /*
      Annual Benefit Statement, post-amble (notes)
      ---------------------------------------------------
      GIVEN Annual statement post-amble content is available
      WHEN Member views DB Annual Statement page

      Data not available, link available
      ---------------------------------------------------
      GIVEN DB Annual Statement feature is enabled
      AND no statement information is available
      AND view is DB Summary page
      WHEN Member navigates to DB Annual statement page

      TE note - automated test should only test example |Enabled|Enabled|No|Yes|No|
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    // Annual Benefit Statement, post-amble (notes)
    it('(Annual Benefit Statement, post-amble (notes)) THEN show post-amble draw consisting of:\n'
      + '  1. pre-caveat text (CMS)\n'
      + '  2. caveat text (Midas)\n'
      + '  3. post-caveat text (CMS)\n'
      + '  4. footer text (CMS)', async () => {
      await annualStatementTests.checkNotesStatement(dbAnnualStatementPage);
    });

    // Data not available, link available
    it('(Data not available, link available) THEN show no data available modal message', async () => {
      await annualStatementTests.checkTheNoDataContainerIsNotShown(dbAnnualStatementPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runPostAmbleAndDataNotAvailableScenarios(dbAnnualStatementPageActive, 'active');
runPostAmbleAndDataNotAvailableScenarios(dbAnnualStatementPageDeferred, 'deferred');
