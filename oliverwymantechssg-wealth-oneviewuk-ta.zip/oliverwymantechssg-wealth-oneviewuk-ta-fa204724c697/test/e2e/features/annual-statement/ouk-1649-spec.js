// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbAnnualStatementPage = require('../../page-objects/db-annual-statement.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbAnnualStatementTests = require('../_common/db-annual-statement.spec.js');
const AnnualStatementTests = require('../_common/annual-statement.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbAnnualStatementTests = new DbAnnualStatementTests();
const annualStatementTests = new AnnualStatementTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPageActive = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbAnnualStatementPageActive = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey
);
const dbPlanSummaryPageDeferred = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey
);
const dbAnnualStatementPageDeferred = new DbAnnualStatementPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey
);

// tests
const scenarioPrefix = `OUK-1649${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageActive, dbAnnualStatementPageActive, standardParticipant, 0);
  } else {
    await dbAnnualStatementTests.browseToDbAnnualStatementPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageDeferred, dbAnnualStatementPageDeferred, standardParticipant, 1);
  }
}

// note the OUK-1649 'Feature navigation' and 'Topic info icon' scenarios are no longer automated as,
// for the OV1 client 'mercerdemo' participant used for test automation, these are effectively duplicates
// of the OUK-1569 'Feature navigation' and 'Annual Statement, draw info icon' scenarios

function runDrawAndIconsScenario(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Draw visibility + Topic icon - ${participantStatus}`, () => {
    /*
      Background
        GIVEN DB Annual Statement feature is enabled (see OUK-1569)
        AND Annual Statement content source is Secured Content

        Draw visibility
        --------------------------------------------
        (AND)
        GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
        WHEN Member navigates to DB Annual Statement page

        Topic icon
        --------------------------------------------
        (AND)
        GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
        AND an icon is available for a topic
        WHEN Member navigates to DB Annual Statement page
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    // Draw visibility
    it('THEN show a draw for each available personalised statement topic + AND order draws:\n'
      + ' *BENEFIT_STATEMENT\n'
      + ' *SMPI\n'
      + ' *AVC_STATEMENT\n'
      + ' *AVC_STATEMENT_1\n'
      + ' *AVC_STATEMENT_2\n'
      + ' *AVC_STATEMENT_3\n'
      + ' *AVC_STATEMENT_4\n'
      + ' *SUPP_STATEMENT\n'
      + ' *SUPP_STATEMENT_1\n'
      + ' *SUPP_STATEMENT_2', async () => {
      await annualStatementTests.checkPersonalisedStatementShown(dbAnnualStatementPage);
    });

    // order will not be checked by TE as this is cosmetic and a Business test

    // Topic icon
    it('THEN show topic icon against corresponding draw (personalised statements)', async () => {
      await annualStatementTests.checkTopicIconForPersonalisedStatements(
        dbAnnualStatementPage, 'DB', participantStatus);
    });

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runDrawAndIconsScenario(dbAnnualStatementPageActive, 'active');
runDrawAndIconsScenario(dbAnnualStatementPageDeferred, 'deferred');

// note the OUK-1649 'Feature navigation' and 'Topic info icon' scenarios are no longer automated as,
// for the OV1 client 'mercerdemo' participant used for test automation, these are effectively duplicates
// of the OUK-1569 'Feature navigation' and 'Annual Statement, draw info icon' scenarios

function runDrawContentScenario(dbAnnualStatementPage, participantStatus) {
  describe(`${scenarioPrefix}Draw content - ${participantStatus}`, () => {
    /*
      GIVEN a personalised statement is available for at least one topic for the Member, POS and Period
      AND view is Annual Statement page
      WHEN Member expands a personalised statement draw
     */

    beforeAll(async () => {
      await login(participantStatus);
    });

    it(`THEN show personalised statement type icon 
        AND show document description`, async () => {
      await annualStatementTests.checkDataForAllPersonalisedStatements(dbAnnualStatementPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dbAnnualStatementPage, loginPage);
    });
  });
}

runDrawContentScenario(dbAnnualStatementPageActive, 'active');
runDrawContentScenario(dbAnnualStatementPageDeferred, 'deferred');
