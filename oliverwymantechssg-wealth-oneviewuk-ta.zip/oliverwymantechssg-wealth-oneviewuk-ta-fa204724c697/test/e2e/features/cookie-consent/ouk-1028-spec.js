// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const UsefulInfoTermsOfUsePage = require('../../page-objects/useful-info-terms-of-use.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const loginTests = new LoginTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const usefulInfoTermsOfUsePage = new UsefulInfoTermsOfUsePage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-1028${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Visibility`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing a page in OneView
    WHEN the page loads

    TE note - clear cache and check 'show' example, then accept cookies, logout and check cookie message not shown
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoadsWithoutClickingOnAgreeCookiePolicyPrompt(loginPage);
  });

  it('THEN [DISPLAY COOKIE CONSENT MESSAGE] based on [COOKIE CONSENT STATUS] ', async () => {
    // check cookie prompt shown when cookies not agreed
    await commonTests.clickElement(loginPage.cookiePolicy.cookiePolicyAgreeButton);
    await browser.wait(
      until.invisibilityOf(loginPage.cookiePolicy.cookiePolicyAgreeButton),
      commonConstants.shortBrowserWaitDelay,
      'Cookie policy agree button still shown');

    expect(loginPage.cookiePolicy.cookiePolicyText.isPresent()).toBe(false);
    expect(loginPage.cookiePolicy.cookiePolicyAgreeButton.isPresent()).toBe(false);
    expect(loginPage.cookiePolicy.cookiePolicyCancelButton.isPresent()).toBe(false);

    // need to check page is fully loaded again before calling next URL
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);

    await browser.get(usefulInfoTermsOfUsePage.url);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(usefulInfoTermsOfUsePage, true);
    await loginTests.checkLoginPageLoadsWithoutClickingOnAgreeCookiePolicyPrompt(loginPage);

    await browser.wait(
      until.invisibilityOf(loginPage.cookiePolicy.cookiePolicyAgreeButton),
      commonConstants.shortBrowserWaitDelay,
      'Cookie policy agree button still shown');
    expect(loginPage.cookiePolicy.cookiePolicyText.isPresent()).toBe(false);
    expect(loginPage.cookiePolicy.cookiePolicyCancelButton.isPresent()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
