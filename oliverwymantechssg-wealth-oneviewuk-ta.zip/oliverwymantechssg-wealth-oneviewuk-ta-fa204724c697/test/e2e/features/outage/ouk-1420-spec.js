// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const OutageParticipant = require('../../data/participants/participant-ouk-1420-outage');

// load tests

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');
const OutagePage = require('../../page-objects/outage.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const outageParticipant = new OutageParticipant();
const loginPage = new LoginPage(outageParticipant);
const dashboardPage = new DashboardPage(outageParticipant);
const profilePage = new ProfilePage(outageParticipant);
const outagePage = new OutagePage();

// tests
const scenarioPrefix = `OUK-1420${commonConstants.bddScenarioPrefix}`;

function checkOutagePage(url) {
  describe(`${scenarioPrefix}Guest users, outage enabled + Site outage message (url: ${url})`, () => {
    /*
      GIVEN the Participant authentication status is guest
      AND outage has been enabled
      WHEN the Participant <interacts> with the site
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${url}`);
    });

    it('Guest users, outage enabled: THEN redirect Participant to outage page'
      + ' Site outage message: THEN display outage screen'
      + ' AND show outage message', async () => {
      await browser.get(url);

      // check common content
      // note cannot use normal commonTests.checkUnauthPageLoadsAndContainsStandardElements()
      // as browser.wait(until.urlContains(page.url)) times out for this page - suspect this is because
      // page loads 'twice' and URL is being rapidly changed
      expect(browser.getCurrentUrl()).toContain(outagePage.url);
      await commonTests.isPageOV3Page();
      await commonTests.checkUnauthorisedHeaderElements(outagePage.header);
      await commonTests.checkEvenIfInOutageFooterElements(outagePage.footer);
      await commonTests.checkPageHeroImage();

      // check specifically for this scenario
      await checkers.anyText(outagePage.outageHeader);
      await checkers.anyTextOf20CharsPlus(outagePage.outageDescription(global.deviceType));
    });

    afterAll(async () => {
      await commonTests.clearBrowserCacheAndCookies();
    });
  });
}

checkOutagePage(loginPage.url);
checkOutagePage(dashboardPage.url);
checkOutagePage(profilePage.url);
