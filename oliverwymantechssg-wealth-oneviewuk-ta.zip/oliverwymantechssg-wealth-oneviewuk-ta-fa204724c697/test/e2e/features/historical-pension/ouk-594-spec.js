// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const PensionsHistoricalPensionTests = require('../_common/pensioner-historical-pension.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');
const PensionsHistoricalPensionPage = require('../../page-objects/pensioner-historical-pension.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionsHistoricalPensionTests = new PensionsHistoricalPensionTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const pensionsHistoricalPensionPage = new PensionsHistoricalPensionPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-594${commonConstants.bddScenarioPrefix}`;

async function checkHistoricalPensionDataRow(rowIndex) {
  await checkers.anyNumber(pensionsHistoricalPensionPage.periodValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.grossPensionValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.preAdjustmentsValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.taxPaidValue(rowIndex));
  await checkers.anyText(pensionsHistoricalPensionPage.taxCodeValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.postAdjustmentsValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.otherPayeeValue(rowIndex));
  await checkers.anyGbp(pensionsHistoricalPensionPage.netPaymentValue(rowIndex));
}

describe(`${scenarioPrefix}Default data view`, () => {
  /*
    GIVEN that the Pensioner is viewing the Historical Pension Page
    AND [PAYMENT HISTORY] is not [NULL]
    WHEN the [PAYMENT HISTORY FEATURE] loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await pensionsHistoricalPensionTests.browseToPensionsHistoricalPensionPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionsHistoricalPensionPage, standardParticipant, 0);
  });

  it('THEN show [PAYMENT HISTORY DESC] i.e. HISTORICAL PENSION', async () => {
    // check that section header, card header and card description are shown with expected text
    const expectedHeaderText = 'Histor';
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.headerLabel(global.deviceType),
      expectedHeaderText);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.cardHeaderLabel,
      expectedHeaderText);

    // note this not used in STAGE
    expect(pensionsHistoricalPensionPage.historicalPensionTableDescription.isPresent()).toBe(true);
  });

  it('AND [DOWNLOAD OPTION]', () => {
    // check that download links are shown on card header
    expect(pensionsHistoricalPensionPage.printButton(global.deviceType).isDisplayed()).toBe(true);
    expect(pensionsHistoricalPensionPage.downloadButton(global.deviceType).isDisplayed()).toBe(true);
  });

  it('AND for each payment period show [PERIOD]'
    + '  AND [GROSS PENSION]'
    + '  AND [PENSION PRE ADJUSTMENTS]'
    + '  AND [TAX PAID]'
    + '  AND [TAX CODE]'
    + '  AND [POST ADJUSTMENTS]'
    + '  AND [OTHER PAYEE]'
    + '  AND [NET PAYMENT]', async () => {
    await checkers.anyText(pensionsHistoricalPensionPage.periodLabel);
    await checkers.containingImage(pensionsHistoricalPensionPage.periodSorter,
      commonConstants.sorterImageSourceDownward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.grossPensionLabel, 'Gross Pension');
    await checkers.containingImage(pensionsHistoricalPensionPage.grossPensionSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.preAdjustmentsLabel, 'Pre Adjustments');
    await checkers.containingImage(pensionsHistoricalPensionPage.preAdjustmentsSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.taxPaidLabel, 'Tax Paid');
    await checkers.containingImage(pensionsHistoricalPensionPage.taxPaidSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.taxCodeLabel, 'Tax Code');
    await checkers.containingImage(pensionsHistoricalPensionPage.taxCodeSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.postAdjustmentsLabel, 'Post Adjustments');
    await checkers.containingImage(pensionsHistoricalPensionPage.postAdjustmentsSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.otherPayeeLabel, 'Other Payee');
    await checkers.containingImage(pensionsHistoricalPensionPage.otherPayeeSorter,
      commonConstants.sorterImageSourceUpward);
    await checkers.containingTextIgnoreCase(pensionsHistoricalPensionPage.netPaymentLabel, 'Net Payment');
    await checkers.containingImage(pensionsHistoricalPensionPage.netPaymentSorter,
      commonConstants.sorterImageSourceUpward);

    const rowsCount = await pensionsHistoricalPensionPage.getDataTableRowsCount();

    if (rowsCount === 1) {
      await checkHistoricalPensionDataRow(0);
    } else if (rowsCount === 2) {
      await checkHistoricalPensionDataRow(0);
      await checkHistoricalPensionDataRow(1);
    } else if (rowsCount > 2) {
      // check first, mid and last data rows
      await checkHistoricalPensionDataRow(0);
      await checkHistoricalPensionDataRow(Math.round(rowsCount / 2));
      await checkHistoricalPensionDataRow(rowsCount - 1);
    } else {
      fail('No historical pension data listed');
    }
  });

  afterAll(async () => {
    await commonTests.logOut(pensionsHistoricalPensionPage, loginPage);
  });
});
