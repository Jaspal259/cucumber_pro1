// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const Participant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const AnnualAllowancePage = require('../../page-objects/allowances-annual-allowance.po.js');


// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new Participant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);
const annualAllowancePage = new AnnualAllowancePage(participant);

// tests
const scenarioPrefix = `OUK-4541${commonConstants.bddScenarioPrefix}`;

async function login() {
  await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
    loginPage, dashboardPage, pensionerPlanSummaryPage, participant, 0);
}

describe(`${scenarioPrefix}`, () => {
  /*
    GIVEN Allowances is available (OUK-3804)
    WHEN the Participant navigates to the Allowances page
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it('THEN display Plan Header relevant based on Period of Service viewed', async () => {
    await checkers.exactText(pensionerPlanSummaryPage.planHeader.allowancesLink, 'Allowances');
    await commonTests.clickElement(pensionerPlanSummaryPage.planHeader.allowancesLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(annualAllowancePage);
    await checkers.containingTextIgnoreCase(annualAllowancePage.allowancesLabel, 'Annual Allowance');
    await commonTests.clickElement(annualAllowancePage.lifeTimeAllowanceTab);
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowancePlanLabel, 'Plan');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceStatusLabel, 'Status');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceEffectiveDateLabel, 'Effective Date');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceLabel, 'Lifetime Allowance');
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancePage, loginPage);
  });
});
