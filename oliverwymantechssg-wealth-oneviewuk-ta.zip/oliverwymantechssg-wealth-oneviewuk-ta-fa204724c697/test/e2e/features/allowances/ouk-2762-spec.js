// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');
const AnnualAllowanceTest = require('../_common/allowances-annual-allowance.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const AnnualAllowancesPage = require('../../page-objects/allowances-annual-allowance.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const annualAllowancesPage = new AnnualAllowancesPage(standardParticipant);
const annualAllowanceTest = new AnnualAllowanceTest();

// tests
const scenarioPrefix = `OUK-2762${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await annualAllowanceTest.browseToAnnualAllowancePageFromLogin(
    loginPage, dashboardPage, annualAllowancesPage, participant);
}

describe(`${scenarioPrefix}Articles`, () => {
  /*
    GIVEN Participant has accessed the Allowances page
    WHEN the Allowances page loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show a maximum of 3 articles in resources area of page (common to both views)', async () => {
    await checkers.anyText(annualAllowancesPage.resourcesLabel);

    // TODO: replace .logoForArticle with reference article component objects loaded into annualAllowancesPage
    expect(annualAllowancesPage.logoForArticle.isDisplayed()).toBe(true);
    let articleCount = await annualAllowancesPage.logoForArticle.count();
    expect(articleCount).toBe(3);
    expect(annualAllowancesPage.lifeTimeAllowanceTab.isDisplayed().toBe(true));
    await commonTests.clickElement(annualAllowancesPage.lifeTimeAllowanceTab);
    await checkers.anyText(annualAllowancesPage.resourcesLabel);
    expect(annualAllowancesPage.logoForArticle.isDisplayed().toBe(true));
    articleCount = await annualAllowancesPage.logoForArticle.count();
    expect(articleCount).toBe(3);
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Access External Site Pages`, () => {
  /*
    GIVEN Participant has accessed the Allowances page
    AND at least one article is displayed
    WHEN an article is selected
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN open external site page in separate browser window ', async () => {
    // TODO: you need to supply index for logoForArticle, textForArticle, linkForArticle
    expect(annualAllowancesPage.logoForArticle.isDisplayed()).toBe(true);
    await checkers.anyText(annualAllowancesPage.textForArticle);
    await checkers.anyText(annualAllowancesPage.linkForArticle);
    await commonTests.clickElement(annualAllowancesPage.linkForArticle);
    const handlePromiseCount = await browser.driver.getAllWindowHandles().count();
    expect(handlePromiseCount).toBe(2);
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancesPage, loginPage);
  });
});
