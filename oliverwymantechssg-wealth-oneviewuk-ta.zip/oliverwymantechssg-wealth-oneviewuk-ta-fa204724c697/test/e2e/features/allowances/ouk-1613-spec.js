// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const AnnualAllowanceTest = require('../_common/allowances-annual-allowance.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const AnnualAllowancePage = require('../../page-objects/allowances-annual-allowance.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const annualAllowanceTest = new AnnualAllowanceTest();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const annualAllowancePage = new AnnualAllowancePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-1613${commonConstants.bddScenarioPrefix}`;

async function login() {
  await annualAllowanceTest.browseToAnnualAllowancePageFromLogin(
    loginPage, dashboardPage, annualAllowancePage, standardParticipant);
}

describe(`${scenarioPrefix}Annual Allowance full feature display`, () => {
  /*
    GIVEN Participant is viewing the Allowances page
    AND AA is enabled for Scheme
    AND valid AA data is available within the last 4 tax years
    AND <AA Limit> is enabled for client
    AND <AA %> is enabled for client
    WHEN the AA feature loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it('THEN show AA view as primary view', () => {
    expect(browser.getCurrentUrl()).toContain(annualAllowancePage.url);
  });

  it('AND show AA table introductory text', () => {
    expect(annualAllowancePage.allowancesLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.annualAllowancesIntroText.isDisplayed()).toBe(true);
  });

  it('AND show AA table consisting of the following columns ordered as follows;\n'
    + '  1. [Scheme/Plan]\n'
    + '  2. [Pension Input Period End Date] (PIP)\n'
    + '  3. [Tax Year]\n'
    + '  4. [Pension Input Amount] (PIA)\n'
    + '  5. [AA Limit]\n'
    + '  6. [AA %]', () => {
    // TODO: test needs to check labels and values contain text / number / date
    // e.g. a date field contains a date using await checkers.anyUkDate()
    expect(annualAllowancePage.planLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.planValue.isDisplayed()).toBe(true);
    expect(annualAllowancePage.pensionInputPeriodEndDateLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.pensionInputPeriodEndDateValue.isDisplayed()).toBe(true);
    expect(annualAllowancePage.taxYearLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.TaxYearValue.isDisplayed()).toBe(true);
    expect(annualAllowancePage.pensionInputAmountLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.pensionInputAmountValue.isDisplayed()).toBe(true);
    expect(annualAllowancePage.annualAllowanceLimitLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.annualAllowanceLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.annualAllowanceValue.isDisplayed()).toBe(true);
  });

  it('AND show AA guidance text link', () => {
    expect(annualAllowancePage.guidanceLinkForMPAA.isDisplayed()).toBe(true);
  });

  it('AND show MPAA guidance text link', () => {
    expect(annualAllowancePage.guidanceLinkForAA.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancePage, loginPage);
  });
});

// describe(`${scenarioPrefix}PIP Start/End Date`, () => {
//   /*
//     GIVEN AA feature is enabled
//     WHEN AA view loads
//    */
//
//   beforeAll(async () => {
//     await login();
//   });
//
//   it('THEN show PIP Date label based on scheme setting ', async () => {
//     expect(annualAllowancePage.pensionInputPeriodEndDateLabel.isDisplayed()).toBe(true);
//     await checkers.containingAnyUkDate(annualAllowancePage.pensionInputPeriodEndDateValue);
//   });
//
//   afterAll(async () => {
//     await commonTests.logOut(annualAllowancePage, loginPage);
//   });
// });
//
// describe(`${scenarioPrefix}Standard AA data display`, () => {
//   /*
//   GIVEN Participant is viewing the Allowances page
//   AND Participant has permitted AA data
//   WHEN the AA view loads
//     */
//
//   beforeAll(async () => {
//     await login(standardParticipant);
//   });
//
//   it('THEN populate AA table with Participant\'s AA data', () => {
//     // TODO: test needs to check labels and values contain text / number / date
//     // e.g. a date field contains a date using await checkers.anyUkDate()
//     expect(annualAllowancePage.planLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.planValue.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.pensionInputPeriodEndDateLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.pensionInputPeriodEndDateValue.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.taxYearLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.TaxYearValue.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.pensionInputAmountLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.pensionInputAmountValue.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.annualAllowanceLimitLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.limitValueForAA.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.annualAllowanceLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.annualAllowanceValue.isDisplayed()).toBe(true);
//   });
//
//   it('AND show data for each PIP on a separate data line ', () => {
//     expect(annualAllowancePage.pensionInputPeriodEndDateLabel.isDisplayed()).toBe(true);
//     expect(annualAllowancePage.pensionInputPeriodEndDateValue.isDisplayed()).toBe(true);
//   });
//
//   it('BUT replace [AA Limit] data with infolink for 2015/16 and 2016/17 tax years', async () => {
//     expect(annualAllowancePage.annualAllowanceLimitLabel.isDisplayed().toBe(true));
//
//     // TODO: this looks completely wrong
//     expect(annualAllowancePage.limitValueForAA.isDisplayed().toBe(true));
//         await checkers.containingText(annualAllowancePage.limitValueForAA, '2016/17'));
//         annualAllowancePage.limitValueForAA.replace(annualAllowancePage.annualAllowanceLimitInfoLink, '2015/16');
//         annualAllowancePage.limitValueForAA.replace(annualAllowancePage.annualAllowanceLimitInfoLink, '2016/17');
//   });
//
//   it('AND replace [AA %] data with infolink for 2015/16 and 2016/17 tax years ', async () => {
//     expect(annualAllowancePage.annualAllowanceLabel.isDisplayed()).toBe(true);
//
//     // TODO: this looks completely wrong
//     expect(annualAllowancePage.annualAllowanceValue.isDisplayed()).toBe(true);
//         await checkers.containingText(annualAllowancePage.annualAllowanceValue, '2015/16');
//         await checkers.containingText(annualAllowancePage.annualAllowanceValue, '2016/17');
//         annualAllowancePage.annualAllowanceValue.replace(annualAllowancePage.annualAllowanceInfoLink, '2015/16');
//         annualAllowancePage.annualAllowanceValue.replace(annualAllowancePage.annualAllowanceInfoLink, '2016/17');
//   });
//
//   afterAll(async () => {
//     await commonTests.logOut(annualAllowancePage, loginPage);
//   });
// });
//
// describe(`${scenarioPrefix}AA guidance text modal`, () => {
//   /*
//   GIVEN Participant is viewing the Allowances page
//   AND the AA view has loaded
//   WHEN Participant selects the AA guidance text link
//   */
//
//   beforeAll(async () => {
//     await login();
//   });
//
//   it('THEN open AA modal', async () => {
//     expect(annualAllowancePage.guidanceLinkForAA.isDisplayed()).toBe(true);
//     await commonTests.clickElement(annualAllowancePage.guidanceLinkForAA);
//     expect(annualAllowancePage.labelForAA.isDisplayed()).toBe(true);
//   });
//
//   afterAll(async () => {
//     await commonTests.logOut(annualAllowancePage, loginPage);
//   });
// });
//
// describe(`${scenarioPrefix}MPAA guidance text modal `, () => {
//   /*
//   GIVEN Participant is viewing the Allowances page
//   AND the AA view has loaded
//   WHEN Participant selects the MPAA guidance text link
//     */
//
//   beforeAll(async () => {
//     await login(standardParticipant);
//   });
//
//   it('THEN open MPAA modal', async () => {
//     expect(annualAllowancePage.guidanceLinkForMPAA.isDisplayed()).toBe(true);
//     await commonTests.clickElement(annualAllowancePage.guidanceLinkForMPAA);
//     expect(annualAllowancePage.labeForMPAA.isDisplayed()).toBe(true);
//   });
//
//   it('AND display MPAA guidance text based on whether the MPAA has been triggered or not', () => {
//     expect(annualAllowancePage.labeForMPAA.isDisplayed()).toBe(true);
//   });
//
//   afterAll(async () => {
//     await commonTests.logOut(annualAllowancePage, loginPage);
//   });
// });
//
// describe(`${scenarioPrefix}MPAA guidance text via MPAA triggered notification`, () => {
//   /*
//   GIVEN Participant is viewing the Allowances page
//   AND MPAA triggered notification is displayed
//   WHEN Participant selects the notification
//    */
//
//   beforeAll(async () => {
//     await login();
//   });
//
//   it('THEN open MPAA modal', async () => {
//     expect(annualAllowancePage.guidanceLinkForMPAA.isDisplayed()).toBe(true);
//     await commonTests.clickElement(annualAllowancePage.limitsLinkForMPAA);
//     expect(annualAllowancePage.labeForMPAA.isDisplayed()).toBe(true);
//   });
//
//   afterAll(async () => {
//     await commonTests.logOut(annualAllowancePage, loginPage);
//   });
// });
