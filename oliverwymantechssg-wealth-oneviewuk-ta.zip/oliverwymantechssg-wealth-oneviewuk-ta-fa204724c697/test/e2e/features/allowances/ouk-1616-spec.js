// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');
const AnnualAllowanceTest = require('../_common/allowances-annual-allowance.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const AnnualAllowancePage = require('../../page-objects/allowances-annual-allowance.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const annualAllowanceTest = new AnnualAllowanceTest();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const annualAllowancePage = new AnnualAllowancePage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-1616${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await annualAllowanceTest.browseToLifetimeAllowancePageFromLogin(
    loginPage, dashboardPage, pensionerPlanSummaryPage, annualAllowancePage, participant, 0);
}

describe(`${scenarioPrefix}Lifetime Allowance (LTA) feature display`, () => {
  /*
    GIVEN Participant is viewing the Allowances page
    AND LTA is enabled for Scheme
    AND LTA is enabled for Participant Type
    AND LTA is enabled for Participant Status
    AND LTA data is recorded for permitted Allowance/BCE Reason
    WHEN the LTA feature loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('AND show LTA table introductory text', async () => {
    await checkers.anyText(annualAllowancePage.allowanceDescription);
  });

  it('AND show LTA table consisting of the following columns ordered as follows;\n'
    + '  1. [Scheme/Plan]\n'
    + '  2. [Status (at effective date)]\n'
    + '  3. [Effective Date]\n'
    + '  4. [Lifetime Allowance %]', async () => {
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowancePlanLabel, 'Plan');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceStatusLabel, 'Status');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceEffectiveDateLabel, 'Effective Date');
    await checkers.containingTextIgnoreCase(annualAllowancePage.LifeTimeAllowanceLabel, 'Lifetime Allowance');
  });

  it('AND show LTA guidance text expandable view link', async () => {
    expect(annualAllowancePage.lifetimeAllowanceInformationInfo.isDisplayed()).toBe(true);
    await commonTests.clickElement(annualAllowancePage.lifetimeAllowanceLearnMore);
    await checkers.anyText(annualAllowancePage.guidanceWindowOkButton);
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancePage, loginPage);
  });
});

describe(`${scenarioPrefix}LTA data display`, () => {
  /*
    GIVEN Participant is viewing the Allowances page
    AND LTA data is returned
    WHEN the LTA view loads
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN populate LTA table with Participant\'s LTA data ', async () => {
    await checkers.anyGbp(annualAllowancePage.scheme(0));
    await checkers.anyUkDate(annualAllowancePage.statusEffectiveDate(0));
    await checkers.anyUkDate(annualAllowancePage.effectiveDate(0));
    await checkers.anyGbp(annualAllowancePage.allowancePercent(0));
    const recordCount = await annualAllowancePage.getLifeTimeAllowanceRecordCount();

    if (recordCount > 0 && recordCount < 2) {
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, 0);
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, 1);
    } else if (recordCount > 2) {
      const lastRow = await annualAllowancePage.getLifeTimeAllowanceRecordCount();
      const midRow = Math.round(lastRow / 2);
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, 0);
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, midRow);
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, lastRow);
    } else if (recordCount === 1) {
      await annualAllowanceTest.checkLifeTimeAllowanceData(annualAllowancePage, 0);
    } else {
      fail('LifeTimeAllowanceTopic has no data');
    }
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancePage, loginPage);
  });
});

describe(`${scenarioPrefix}LTA guidance text display`, () => {
  /*
    GIVEN Participant is viewing the Allowances page
    AND the LTA view has loaded
    AND the LTA table view is displayed
    WHEN Participant selects the LTA guidance text link
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show available LTA text', async () => {
    await checkers.anyText(annualAllowancePage.lifetimeAllowanceInformationInfo);
    await commonTests.clickElement(annualAllowancePage.lifetimeAllowanceLearnMore);
    await checkers.anyText(annualAllowancePage.guidanceWindowOkButton);
  });

  afterAll(async () => {
    await commonTests.logOut(annualAllowancePage, loginPage);
  });
});
