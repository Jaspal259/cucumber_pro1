// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const beneficiariesPage = new BeneficiariesPage(standardParticipant);
const dcPlanSummaryActivePage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);
const dcPlanSummaryDeferredPage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey);
const dbPlanSummaryActivePage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryDeferredPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// other
const planSelector = dashboardPage.planSelectorModal;

// tests
const scenarioPrefix = `OUK-1913${commonConstants.bddScenarioPrefix}`;
const until = protractor.ExpectedConditions;

async function login() {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
}

/*
  note 'Plan selector view' and 'Plan selector Cancel' scenarios concatenated partly because cancel
  is needed to make logout for first scenario work
 */
describe(`${scenarioPrefix}Plan selector view + Plan selector Cancel`, () => {
  /*
    Plan selector view
    -------------------------------------------------------
    GIVEN a feature is available for multiple POS
    AND <show DC Member Ref is enabled>
    AND <show DB Member Ref is enabled>
    AND <show Client Def ID is enabled>
    WHEN the Participant attempts to navigate to a <feature> which is available for multiple POS

    Plan selector Cancel
    -------------------------------------------------------
    GIVEN view is Plan selector modal
    WHEN the Participant selects the Cancel option
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it('THEN display Plan selector modal,'
    + ' AND show plan information,'
    + ' AND enable Cancel option,'
    + ' AND enable Continue option (primary option)', async () => {
    const present = await browser.isElementPresent(dashboardPage.disclaimer);

    if (!present) {
      fail('Disclaimer is not present');
    } else {
      await commonTests.clickElement(dashboardPage.planSelectorLink);
      const selectorPresent = await browser.isElementPresent(planSelector.container);

      if (!selectorPresent) {
        fail('Plan selector is not present');
      } else {
        await checkers.containingTextIgnoreCase(planSelector.header, 'Select');
        await checkers.anyText(planSelector.description);
        await checkers.anyText(planSelector.dropdownDescription);
        await checkers.containingTextIgnoreCase(planSelector.cancelButton(global.deviceType), 'Cancel');
        expect(planSelector.cancelButton(global.deviceType).isEnabled()).toBe(true);
        await checkers.containingTextIgnoreCase(planSelector.continueButton(global.deviceType), 'OK');
        expect(planSelector.continueButton(global.deviceType).isEnabled()).toBe(false);

        await commonTests.clickElement(planSelector.dropdownRevealer);
        const optionsCount = await planSelector.getDropdownListOptionsCount();

        if (optionsCount !== 5) {
          fail(`Plan selector should have 5 dropdown options but is showing ${optionsCount}`);
        } else {
          let i;

          for (i = 0; i < optionsCount; i += 1) {
            await checkers.anyText(planSelector.dropdownListOption(i));
          }

          await commonTests.clickElement(planSelector.dropdownListOption(0));
          await checkers.isMercerOsButtonSelected(planSelector.continueButton(global.deviceType));
        }
      }
    }
  });

  it('THEN close modal,'
    + ' AND return Participant to the view/URL they were viewing prior to modal being displayed', async () => {
    // expect() used to ensure async handled
    await checkers.containingTextIgnoreCase(planSelector.cancelButton(global.deviceType), 'Cancel');
    expect(planSelector.cancelButton(global.deviceType).isEnabled()).toBe(true);
    await commonTests.clickElement(planSelector.cancelButton(global.deviceType));
    expect(planSelector.container.isPresent()).toBe(false);
    await browser.wait(until.urlContains(dashboardPage.url), commonConstants.mediumBrowserWaitDelay,
      `URL does not contain ${dashboardPage.url}`);
    expect(browser.getCurrentUrl()).toContain(dashboardPage.url);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

/**
 *
 * @param planPage
 * @param planOptionIndex
 * @param headerLabelValue
 * @param posStatusValue - not define for PIP
 */
function runSelectPlanScenario(planPage, planOptionIndex, headerLabelValue, posStatusValue) {
  let reportMsgPostfix;
  if (typeof posStatusValue !== 'undefined') {
    reportMsgPostfix = `${headerLabelValue} ${posStatusValue}`;
  } else {
    reportMsgPostfix = `${headerLabelValue}`;
  }

  describe(`${scenarioPrefix}Plan selector Continue - ${reportMsgPostfix}`, () => {
    /*
      GIVEN view is Plan selector modal
      WHEN the Participant selects a Plan POS
      AND they select Continue
     */

    beforeAll(async () => {
      await login();
    });

    it('THEN redirect Participant to the feature and chosen Plan POS', async () => {
      const present = await browser.isElementPresent(dashboardPage.disclaimer);

      if (!present) {
        fail('Disclaimer is not present');
      } else {
        await commonTests.clickElement(dashboardPage.planSelectorLink);
        const selectorPresent = await browser.isElementPresent(planSelector.container);

        if (!selectorPresent) {
          fail('Selector is not present');
        } else {
          await commonTests.clickElement(planSelector.dropdownRevealer);
          await checkers.anyText(planSelector.dropdownListOption(planOptionIndex));
          await commonTests.clickElement(planSelector.dropdownListOption(planOptionIndex));
          await checkers.anyText(planSelector.continueButton(global.deviceType));

          await browser.wait(
            until.elementToBeClickable(planSelector.continueButton(global.deviceType)),
            commonConstants.shortBrowserWaitDelay,
            'Missing select a plan modal');
          await commonTests.clickElement(planSelector.continueButton(global.deviceType));

          // note check on plan header allows Protractor to first wait for the modal to close ...
          await browser.wait(
            until.visibilityOf(planPage.planHeader.planHeader),
            commonConstants.shortBrowserWaitDelay, 'Plan header not shown');

          // ... and then the redirect to the required page to occur
          await commonTests.checkPlanPageLoadsAndContainsPlanHeader(beneficiariesPage);
          expect(browser.getCurrentUrl()).toContain(beneficiariesPage.partialUrl);
          await checkers.containingTextIgnoreCase(planPage.planHeader.typeLabel, headerLabelValue);

          if (typeof posStatusValue !== 'undefined') {
            await commonTests.clickExpandMoreButtonIfMobile(planPage.planHeader.mobileExpandMore);
            await checkers.containingTextIgnoreCase(planPage.planHeader.posStatusValue, posStatusValue);
          }
        }
      }
    });

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runSelectPlanScenario(dbPlanSummaryActivePage, 0, 'DEFINED BENEFIT', 'Active');
runSelectPlanScenario(dbPlanSummaryDeferredPage, 1, 'DEFINED BENEFIT', 'Deferred');
runSelectPlanScenario(dcPlanSummaryActivePage, 2, 'DEFINED CONTRIBUTION', 'Active');
runSelectPlanScenario(dcPlanSummaryDeferredPage, 3, 'DEFINED CONTRIBUTION', 'Deferred');
runSelectPlanScenario(pensionerPlanSummaryPage, 4, 'PENSIONS IN PAYMENT');
