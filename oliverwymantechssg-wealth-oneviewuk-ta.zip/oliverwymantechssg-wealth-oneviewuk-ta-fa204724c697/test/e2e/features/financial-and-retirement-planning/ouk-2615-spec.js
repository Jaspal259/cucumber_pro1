// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbRetirementPlanningTests = require('../_common/db-retirement-planning.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbRetirementPlanningPage = require('../../page-objects/db-retirement-planning.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbRetirementPlanningTests = new DbRetirementPlanningTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbRetirementPlanningPage = new DbRetirementPlanningPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-2615${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Available assumptions categories`, () => {
  /*
    GIVEN DB Modeller is enabled
    AND view is DB Modeller results page
    GIVEN Assumptions datanames are available for at least one category
    WHEN Member expands Assumptions and Notes accordion
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, participant, 0);
  });

  it('THEN show all available categories (separate accordions)', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.statementsButton);
    await checkers.anyText(dbRetirementPlanningPage.personalDetailsLabel);
    await checkers.anyText(dbRetirementPlanningPage.financialAssumptionsLabel);
    await checkers.anyText(dbRetirementPlanningPage.variableInformationLabel);
    await checkers.anyText(dbRetirementPlanningPage.otherAssumptionsLabel);
    await checkers.anyText(dbRetirementPlanningPage.importantNotesLabel);
  });

  it('AND show all accordions as collapsed', () => {
    expect(dbRetirementPlanningPage.getPersonalInformation(0).isDisplayed()).toBe(false);
    expect(dbRetirementPlanningPage.getFinancialAssumptions(0).isDisplayed()).toBe(false);
    expect(dbRetirementPlanningPage.getVariableInformation(0).isDisplayed()).toBe(false);
    expect(dbRetirementPlanningPage.getOtherAssumptions(0).isDisplayed()).toBe(false);
    expect(dbRetirementPlanningPage.getImportantNotes(0).isDisplayed()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

// OnHold bug ouk-5333 : Gherkin need to change as per new design
describe(`${scenarioPrefix}Available datanames`, () => {
  /*
    GIVEN DB Modeller is enabled
    AND view is DB Modeller results page
    GIVEN Member has expanded Assumptions and Notes accordion
    WHEN Member expands a category accordion
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, participant, 0);
  });

  it('THEN show all available datanames for that group', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.statementsButton);
    await checkers.anyText(dbRetirementPlanningPage.personalDetailsLabel);
    await checkers.anyText(dbRetirementPlanningPage.financialAssumptionsLabel);
    await checkers.anyText(dbRetirementPlanningPage.variableInformationLabel);
    await checkers.anyText(dbRetirementPlanningPage.otherAssumptionsLabel);
    await checkers.anyText(dbRetirementPlanningPage.importantNotesLabel);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});
