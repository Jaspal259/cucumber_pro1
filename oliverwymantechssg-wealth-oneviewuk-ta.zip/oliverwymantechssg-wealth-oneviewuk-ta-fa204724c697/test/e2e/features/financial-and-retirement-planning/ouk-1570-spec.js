// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbRetirementPlanningTests = require('../_common/db-retirement-planning.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbRetirementPlanningPage = require('../../page-objects/db-retirement-planning.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbRetirementPlanningTests = new DbRetirementPlanningTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbRetirementPlanningPage = new DbRetirementPlanningPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-1570${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Default view, Summary view`, () => {
  /*
    GIVEN DB Modeller is enabled
    GIVEN Member has navigated to the DB Modeller results page
    WHEN the page loads
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, participant, 0);
  });

  it('THEN show Pension illustration date', () => {
    expect(dbRetirementPlanningPage.pensionIllustrationDateLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.pensionIllustrationDateValue.isEnabled()).toBe(true);
  });

  it('AND show Transaction ID', () => {
    expect(dbRetirementPlanningPage.transactionIdLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.transactionIdValue.isEnabled()).toBe(true);
  });

  it('AND show Guidance text', () => {
    expect(dbRetirementPlanningPage.retirementIllustratorText.isDisplayed()).toBe(true);
  });

  it('AND show Disclaimer text', () => {
    expect(dbRetirementPlanningPage.disclaimerText.isDisplayed()).toBe(true);
  });

  it('AND show Results card', () => {
    expect(dbRetirementPlanningPage.yourContributionOptionsLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.yourRetainedBenefitsLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.yourRetirementOptionsLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.yourWorkingOptionsLabel.isDisplayed()).toBe(true);
  });

  it('AND show \'Summary\' view as default view', async () => {
    expect(dbRetirementPlanningPage.summaryViewButton.isEnabled()).toBe(true);
    await dbRetirementPlanningPage.summaryViewButton.isDisplayed();
    expect(dbRetirementPlanningPage.retirementDateLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.retirementDateValue.isDisplayed()).toBe(true);
  });

  it('AND show all available default summary view information', async () => {
    await dbRetirementPlanningPage.summaryViewButton.isDisplayed();
    expect(dbRetirementPlanningPage.retirementDateLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.retirementDateValue.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.annualPensionOfLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.annualPensionOfValue.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.cashLumpSumLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.cashLumpSumValue.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

describe(`${scenarioPrefix}Detailed view`, () => {
  /*
    GIVEN DB Modeller is enabled
    GIVEN Member is viewing the DB Modeller results page
    WHEN Member selects 'Detailed view' button in the results card
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, participant, 0);
  });

  it('THEN switch to \'Detailed view\' ', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.detailViewButton);
  });

  it('AND show all available default detailed view information', async () => {
    await dbRetirementPlanningPage.summaryViewButton.isDisplayed();
    expect(dbRetirementPlanningPage.detailViewButton.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.getSummaryElementLabel(1).isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.getBreakdownElementLabel(1).isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.getBreakdownElementValue(1).isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.retirementDate.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.retirementDateValue.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.lifetimeAllowancePercentage.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.lifetimeAllowancePercentageValue.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.annualPensionLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.annualPensionValue.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.cashLumpSumLabel.isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.getCashLumpSumValue(1).isDisplayed()).toBe(true);
    expect(dbRetirementPlanningPage.onYourDeathLabel.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});
