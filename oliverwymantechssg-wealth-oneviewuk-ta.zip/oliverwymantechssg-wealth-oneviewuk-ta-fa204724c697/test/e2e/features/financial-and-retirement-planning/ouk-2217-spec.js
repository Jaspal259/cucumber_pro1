// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbRetirementPlanningTests = require('../_common/db-retirement-planning.spec');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbRetirementPlanningPage = require('../../page-objects/db-retirement-planning.po');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbRetirementPlanningTests = new DbRetirementPlanningTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbRetirementPlanningPage = new DbRetirementPlanningPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-2217${commonConstants.bddScenarioPrefix}`;

async function recalculatePlanner() {
  const present = await browser.isElementPresent(dbRetirementPlanningPage.produceStatementButton);

  if (present) {
    await dbRetirementPlanningPage.avcregInput.sendKeys('12000');
    await commonTests.clickElement(dbRetirementPlanningPage.recalculateButton);
  }
}

describe(`${scenarioPrefix}Results card, produce statement button`, () => {
  /*
    GIVEN DB Modeller produce statement is enabled
    AND view is DB Modeller results page
    WHEN a calculation request completes without fatals
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, dbRetirementPlanningPage, standardParticipant, 0);
  });

  it('THEN show Produce Statement button in active state as primary button', async () => {
    await recalculatePlanner();
    expect(dbRetirementPlanningPage.produceStatementButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

async function checkDbModellerFormData(rowIndex) {
  await checkers.anyText(dbRetirementPlanningPage.getStatementName(rowIndex));
  await checkers.anyImage(dbRetirementPlanningPage.getStatementType(rowIndex));
  await checkers.anyText(dbRetirementPlanningPage.getStatementSize(rowIndex));
  await checkers.anyImage(dbRetirementPlanningPage.getStatementAction(rowIndex));
}

// Test is failing as forms name are different than what mentioned in Gherkin.
describe(`${scenarioPrefix}DB Modeller pack page`, () => {
  /*
    GIVEN Produce Statement button is active
    AND DB Modeller core forms are available
    WHEN Member selects Produce Statement button
   */

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, standardParticipant, 0);
  });

  it('THEN redirect Member to DB Modeller pack page in same browser window ', async () => {
    const present = await browser.isElementPresent(dbRetirementPlanningPage.produceStatementButton);

    if (present) {
      await commonTests.clickElement(dbRetirementPlanningPage.produceStatementButton);
      expect(browser.getCurrentUrl()).toEqual(dbRetirementPlanningPage.url);
    }
  });

  it('AND show all available DB Modeller forms', async () => {
    await checkers.anyText(dbRetirementPlanningPage.getDbModellerColumn(0));
    await checkers.anyText(dbRetirementPlanningPage.getDbModellerColumn(1));
    await checkers.anyText(dbRetirementPlanningPage.getDbModellerColumn(2));
    await checkers.anyText(dbRetirementPlanningPage.getDbModellerColumn(3));

    for (let i = 0; i < 3; i += 1) {
      await checkDbModellerFormData(i);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

// Test is failing as forms name are different than what mentioned in Gherkin.
describe(`${scenarioPrefix}Additional client documents `, () => {
  /*
    GIVEN DB Modeller client forms are available
    WHEN the Participant navigates to the DB Modeller pack page
   */

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, standardParticipant, 0);
  });

  it('THEN show all available DB Modeller client forms ', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.produceStatementButton);

    for (let i = 3; i < 6; i += 1) {
      await checkDbModellerFormData(i);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

// *** TE note - Dan will automate this as hoping to re-use code from elsewhere ***
xdescribe(`${scenarioPrefix}Action behaviour `, () => {
  /*
    GIVEN DB Modeller pack forms are available
    AND view is DB Modeller pack page
    WHEN Member selects a form
   */

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbRetirementPlanningPage, standardParticipant, 0);
  });

  it('THEN based on icon type open form ', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.detailViewButton);
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});

describe(`${scenarioPrefix}Action hover `, () => {
  /*
    GIVEN DB Modeller pack forms are available
    AND view is DB Modeller pack page
    WHEN Member hovers over an action icon
   */

  beforeAll(async () => {
    await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, dbRetirementPlanningPage, standardParticipant, 0);
  });

  it('THEN display action icon label i.e. Download, Open', async () => {
    await commonTests.clickElement(dbRetirementPlanningPage.produceStatementButton);
    await tooltipTests.checkTooltipIsElementContainingText(
      dbRetirementPlanningPage.getStatementAction(0),
      dbRetirementPlanningPage.annualPensionLabel,
      dbRetirementPlanningPage.tooltips.soleTooltip,
      'Download');
  });

  afterAll(async () => {
    await commonTests.logOut(dbRetirementPlanningPage, loginPage);
  });
});
