// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec.js');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new StandardParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-5110${commonConstants.bddScenarioPrefix}`;

async function checkBudgetPlannerSlide(page) {
  // note slide, icon and description text do not have unique IDs so just test label and link
  await browser.wait(
    until.elementToBeClickable(page.carousel.carouselNextButton),
    commonConstants.shortBrowserWaitDelay,
    'Carousel slide has not loaded within timeout after next was clicked');
  await checkers.containingTextIgnoreCase(page.carouselBudgetPlannerSlide.slideLabel, 'Budget Planner');
  await checkers.containingTextIgnoreCase(page.carouselBudgetPlannerSlide.slideLink, 'View');
}

async function checkCarouselSlideAfterSecondNextClick(page) {
  await commonTests.clickElement(page.carousel.carouselNextButton);
  await browser.wait(
    until.elementToBeClickable(page.carousel.carouselNextButton),
    commonConstants.shortBrowserWaitDelay,
    'Carousel next button not shown / cannot be clicked');
  await commonTests.clickElement(page.carousel.carouselNextButton);
  await checkBudgetPlannerSlide(page);
}

function checkBudgetingSubMenuAndCarouselLinks(page, numberOfCarouselNextClicksRequired) {
  it('THEN show Budgeting link in sub-navigation bar', async () => {
    await planHeaderTests.revealAndCheckPlanHeaderNavigationMenuLink(
      page,
      page.planHeader.budgetingLink,
      'budget',
      page.planHeader);
  });

  it('AND enable Budgeting feature in Carousel', async () => {
    if (numberOfCarouselNextClicksRequired === 0) {
      // no clicks required
      await checkBudgetPlannerSlide(page);
    } else {
      await browser.wait(
        until.elementToBeClickable(page.carousel.carouselNextButton),
        commonConstants.shortBrowserWaitDelay,
        'Carousel next button not shown / cannot be clicked');

      switch (numberOfCarouselNextClicksRequired) {
        case 1:
          await commonTests.clickElement(page.carousel.carouselNextButton);
          await checkBudgetPlannerSlide(page);
          break;
        case 2:
          await checkCarouselSlideAfterSecondNextClick(page);
          break;
        default:
          throw new Error(
            `numberOfCarouselNextClicksRequired = ${numberOfCarouselNextClicksRequired} is not supported`);
      }
    }
  });
}

function runBudgetPlannerDCScenario(planType, pos, numberOfCarouselNextClicksRequired) {
  describe(`${scenarioPrefix}Budget Planner visibility - ${planType}`, () => {
    /*
     GIVEN disable budget planner is not enabled
     WHEN the Participant navigates to a <Summary page>
     */

    const page = new DcPlanSummaryPage(
      participant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planType}`);

      switch (planType) {
        case 'DC Active':
          await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
            loginPage, dashboardPage, page, participant, 0);
          break;
        case 'DC Deferred':
          await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
            loginPage, dashboardPage, page, participant, 1);
          break;
        default:
          throw new Error(`The plan type [${planType}] is not supported`);
      }
    });

    checkBudgetingSubMenuAndCarouselLinks(page, numberOfCarouselNextClicksRequired);

    afterAll(async () => {
      await commonTests.logOut(page, loginPage);
    });
  });
}

runBudgetPlannerDCScenario('DC Active', participant.posDcActive, 2);
runBudgetPlannerDCScenario('DC Deferred', participant.posDcDeferred, 2);

function runBudgetPlannerDBScenario(planType, pos, numberOfCarouselNextClicksRequired) {
  describe(`${scenarioPrefix}Budget Planner visibility - ${planType}`, () => {
    /*
     GIVEN disable budget planner is not enabled
     WHEN the Participant navigates to a <Summary page>
     */

    const page = new DbPlanSummaryPage(
      participant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      switch (planType) {
        case 'DB Active':
          await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
            loginPage, dashboardPage, page, participant, 0);
          break;
        case 'DB Deferred':
          await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
            loginPage, dashboardPage, page, participant, 1);
          break;
        default:
          throw new Error(`The plan type [${planType}] is not supported`);
      }
    });

    checkBudgetingSubMenuAndCarouselLinks(page, numberOfCarouselNextClicksRequired);

    afterAll(async () => {
      await commonTests.logOut(page, loginPage);
    });
  });
}

runBudgetPlannerDBScenario('DB Active', participant.posDbActive, 1);
runBudgetPlannerDBScenario('DB Deferred', participant.posDbDeferred, 2);

describe(`${scenarioPrefix}Budget Planner visibility - PIP`, () => {
  /*
   GIVEN disable budget planner is not enabled
   WHEN the Participant navigates to a <Summary page>
   */

  const page = pensionerPlanSummaryPage;

  beforeAll(async () => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, page, participant, 0);
  });

  checkBudgetingSubMenuAndCarouselLinks(page, 1);

  afterAll(async () => {
    await commonTests.logOut(page, loginPage);
  });
});
