// load common
const genericCommonTests = require('../../utilities/generic-common.helper.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcBudgetPlannerTests = require('../_common/dc-budget-planner.spec.js');
const DbBudgetPlannerTests = require('../_common/db-budget-planner.spec.js');
const PensionerBudgetPlannerTests = require('../_common/pensioner-budget-planner.spec.js');
const BudgetPlannerTests = require('../_common/budget-planner.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');
const DcBudgetPlannerPage = require('../../page-objects/dc-budget-planner.po.js');
const DbBudgetPlannerPage = require('../../page-objects/db-budget-planner.po.js');
const PensionerBudgetPlannerPage = require('../../page-objects/pensioner-budget-planner.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new StandardParticipant();
const dcBudgetPlannerTests = new DcBudgetPlannerTests();
const dbBudgetPlannerTests = new DbBudgetPlannerTests();
const pensionerBudgetPlannerTests = new PensionerBudgetPlannerTests();
const budgetPlannerTests = new BudgetPlannerTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const dcActiveBudgetPlannerPage = new DcBudgetPlannerPage(
  participant,
  participant.posDcActive.scheme.data.midasSchemeCode,
  participant.posDcActive.data.periodOfServicePrimaryKey);
const dcDeferredBudgetPlannerPage = new DcBudgetPlannerPage(
  participant,
  participant.posDcDeferred.scheme.data.midasSchemeCode,
  participant.posDcDeferred.data.periodOfServicePrimaryKey);
const dbActiveBudgetPlannerPage = new DbBudgetPlannerPage(
  participant,
  participant.posDbActive.scheme.data.midasSchemeCode,
  participant.posDbActive.data.periodOfServicePrimaryKey);
const dbDeferredBudgetPlannerPage = new DbBudgetPlannerPage(
  participant,
  participant.posDbDeferred.scheme.data.midasSchemeCode,
  participant.posDbDeferred.data.periodOfServicePrimaryKey);
const pensionerBudgetPlannerPage = new PensionerBudgetPlannerPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// tests
const scenarioPrefix = `OUK-5117${commonConstants.bddScenarioPrefix}`;
const until = protractor.ExpectedConditions;

async function login(planType, participantStatus, pos) {
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  switch (planType) {
    case 'DC':
      // set constants for DC summary and budget planner page objects
      if (participantStatus === 'active') {
        await dcBudgetPlannerTests.browseToDcBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dcPlanSummaryPage, dcActiveBudgetPlannerPage, participant, 0);
      } else {
        await dcBudgetPlannerTests.browseToDcBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dcPlanSummaryPage, dcDeferredBudgetPlannerPage, participant, 1);
      }
      break;

    case 'DB':
      // set constants for DB summary and budget planner page objects
      if (participantStatus === 'active') {
        await dbBudgetPlannerTests.browseToDbBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dbPlanSummaryPage, dbActiveBudgetPlannerPage, participant, 0);
      } else {
        await dbBudgetPlannerTests.browseToDbBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dbPlanSummaryPage, dbDeferredBudgetPlannerPage, participant, 1);
      }
      break;

    case 'Pensioner':
      // set constants for Pensioner summary and budget planner page objects
      await pensionerBudgetPlannerTests.browseToPensionerBudgetPlannerPageFromLogin(
        loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerBudgetPlannerPage, participant, 0);
      break;
    default:

      throw new Error(`The plan type [${planType}] is not supported`);
  }
}

async function fillInput(inputElement, value) {
  await browser.wait(until.visibilityOf(inputElement), commonConstants.mediumBrowserWaitDelay,
    'Input element not shown');
  await inputElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
  await inputElement.sendKeys(protractor.Key.BACK_SPACE);
  await inputElement.sendKeys(value);
}

function getRandomNumber() {
  return genericCommonTests.getRandomNumber(101.00, 999.99, 2);
}

function runAmountsIncomeExpensesValidationScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Maximum amounts permitted + Missing expenses validation + Missing income validation
  (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting edit view
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planType} - ${participantStatus}`);
      await login(planType, participantStatus, pos);
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
    });

    function checkInputMaxValue(inputElement, inputLabelElement, inputRequiredErrorElement, inputTitle) {
      it(`WHEN the Participant enters income/expenditure amounts
        THEN restrict amounts to 999,999.99 - ${inputTitle}`, async () => {
        await fillInput(inputElement, '9,999,999.99');
        await browser.actions().mouseMove(inputLabelElement).click().perform();
        await checkers.inputNotContainingText(inputElement, '9,999,999.99');
        await checkers.inputContainingText(inputElement, '999,999.99');
      });
    }

    checkInputMaxValue(
      budgetPlannerEdit.editIncomeInput,
      budgetPlannerEdit.editIncomeLabel,
      budgetPlannerEdit.editIncomeRequiredError,
      'Income'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editMortgageRentInput,
      budgetPlannerEdit.editMortgageRentLabel,
      budgetPlannerEdit.editMortgageRentRequiredError,
      'Mortgage Rent'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editCouncilTaxInput,
      budgetPlannerEdit.editCouncilTaxLabel,
      budgetPlannerEdit.editCouncilTaxRequiredError,
      'Council Tax'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editInsurancesPensionPoliciesInput,
      budgetPlannerEdit.editInsurancesPensionPoliciesLabel,
      budgetPlannerEdit.editInsurancesPensionPoliciesRequiredError,
      'Insurances Pension Policies'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editUtilitiesInput,
      budgetPlannerEdit.editUtilitiesLabel,
      budgetPlannerEdit.editUtilitiesRequiredError,
      'Utilities'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editTvPhoneInternetInput,
      budgetPlannerEdit.editTvPhoneInternetLabel,
      budgetPlannerEdit.editTvPhoneInternetRequiredError,
      'Tv Phone Internet'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editGroceriesInput,
      budgetPlannerEdit.editGroceriesLabel,
      budgetPlannerEdit.editGroceriesRequiredError,
      'Groceries'
    );
    checkInputMaxValue(
      budgetPlannerEdit.editLoanCreditCardInput,
      budgetPlannerEdit.editLoanCreditCardLabel,
      budgetPlannerEdit.editLoanCreditCardRequiredError,
      'Loan Credit Card'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editTravelInput,
      budgetPlannerEdit.editTravelLabel,
      budgetPlannerEdit.editTravelRequiredError,
      'Travel'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editLeisureInput,
      budgetPlannerEdit.editLeisureLabel,
      budgetPlannerEdit.editLeisureRequiredError,
      'Leisure'
    );

    checkInputMaxValue(
      budgetPlannerEdit.editOtherExpensesInput,
      budgetPlannerEdit.editOtherExpensesLabel,
      budgetPlannerEdit.editOtherExpensesRequiredError,
      'Other Expenses'
    );

    it(`AND the Participant has entered an income amount greater than £0.00
        BUT none of the expenses amounts are greater than £0.00
        WHEN the Participant selects save
        THEN retain view as Budgeting edit view
        AND display no expenses alert message `, async () => {
      await fillInput(budgetPlannerEdit.editIncomeInput, '50,000.00');
      await fillInput(budgetPlannerEdit.editMortgageRentInput, '0.00');
      await fillInput(budgetPlannerEdit.editCouncilTaxInput, '0.00');
      await fillInput(budgetPlannerEdit.editInsurancesPensionPoliciesInput, '0.00');
      await fillInput(budgetPlannerEdit.editUtilitiesInput, '0.00');
      await fillInput(budgetPlannerEdit.editTvPhoneInternetInput, '0.00');
      await fillInput(budgetPlannerEdit.editGroceriesInput, '0.00');
      await fillInput(budgetPlannerEdit.editLoanCreditCardInput, '0.00');
      await fillInput(budgetPlannerEdit.editTravelInput, '0.00');
      await fillInput(budgetPlannerEdit.editLeisureInput, '0.00');
      await fillInput(budgetPlannerEdit.editOtherExpensesInput, '0.00');
      await commonTests.clickElement(budgetPlannerEdit.saveButton);
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);
      expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.setBudgetUrl);
      await checkers.anyText(budgetPlannerEdit.toast.message);
      await commonTests.clickElement(budgetPlannerEdit.toast.closeIcon);
      await browser.wait(until.invisibilityOf(budgetPlannerEdit.toast.content),
        commonConstants.briefBrowserWaitDelay,
        'Budget planner edit toast still shown');
    });

    function checkMissingIncomeValue(expensesElement, expensesTitle) {
      it(`AND the Participant has entered "${expensesTitle}" expenses amounts greater than £0.00
        BUT income amount is not greater than £0.00
        WHEN the Participant selects save
        THEN retain view as Budgeting edit view
        AND display no income alert message`, async () => {
        await fillInput(budgetPlannerEdit.editIncomeInput, '0.00');
        await fillInput(expensesElement, '100.00');
        await commonTests.clickElement(budgetPlannerEdit.saveButton);
        await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);
        expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.setBudgetUrl);
        await checkers.anyText(budgetPlannerEdit.toast.message);
        await commonTests.clickElement(budgetPlannerEdit.toast.closeIcon);
        await browser.wait(until.invisibilityOf(budgetPlannerEdit.toast.content),
          commonConstants.briefBrowserWaitDelay,
          'Budget planner edit toast still shown');
      });
    }

    checkMissingIncomeValue(budgetPlannerEdit.editMortgageRentInput, 'Mortgage Rent');
    checkMissingIncomeValue(
      budgetPlannerEdit.editInsurancesPensionPoliciesInput, 'Insurances & pension policies');
    checkMissingIncomeValue(budgetPlannerEdit.editGroceriesInput, 'Groceries Rent');

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runAmountsIncomeExpensesValidationScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runAmountsIncomeExpensesValidationScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runAmountsIncomeExpensesValidationScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runAmountsIncomeExpensesValidationScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runAmountsIncomeExpensesValidationScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runPieSegmentsScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Participant hovers over a segment in the expenses graph
  (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting read view
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;
    const gbpIncomeValue = `500,${getRandomNumber()}`;
    const gbpExpenditureValues = {
      mortgage: `10,${getRandomNumber()}`,
      council: `10,${getRandomNumber()}`,
      insurances: `10,${getRandomNumber()}`,
      utilities: `10,${getRandomNumber()}`,
      tv: `10,${getRandomNumber()}`,
      groceries: `10,${getRandomNumber()}`,
      loan: `10,${getRandomNumber()}`,
      travel: `10,${getRandomNumber()}`,
      leisure: `10,${getRandomNumber()}`,
      other: `10,${getRandomNumber()}`
    };

    async function checkPieChart(sliceElement, labelText, expensesValue) {
      const location = await sliceElement.getLocation();
      await browser.actions().mouseMove(sliceElement, {
        x: location.x / 2,
        y: location.y / 2
      }).perform();
      await browser.wait(until.visibilityOf(budgetPlannerDefault.tooltips.simpleSoleTooltip),
        commonConstants.mediumBrowserWaitDelay, 'Tooltip still shown');
      await checkers.containingTextIgnoreCase(budgetPlannerDefault.tooltips.simpleSoleTooltip, labelText);
      await checkers.containingTextIgnoreCase(budgetPlannerDefault.tooltips.simpleSoleTooltip, expensesValue);
    }

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
    });

    it('AND the expenses total is greater than £0.00', async () => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
      await fillInput(budgetPlannerEdit.editIncomeInput, gbpIncomeValue);
      await fillInput(budgetPlannerEdit.editMortgageRentInput, gbpExpenditureValues.mortgage);
      await fillInput(budgetPlannerEdit.editCouncilTaxInput, gbpExpenditureValues.council);
      await fillInput(budgetPlannerEdit.editInsurancesPensionPoliciesInput, gbpExpenditureValues.insurances);
      await fillInput(budgetPlannerEdit.editUtilitiesInput, gbpExpenditureValues.utilities);
      await fillInput(budgetPlannerEdit.editTvPhoneInternetInput, gbpExpenditureValues.tv);
      await fillInput(budgetPlannerEdit.editGroceriesInput, gbpExpenditureValues.groceries);
      await fillInput(budgetPlannerEdit.editLoanCreditCardInput, gbpExpenditureValues.loan);
      await fillInput(budgetPlannerEdit.editTravelInput, gbpExpenditureValues.travel);
      await fillInput(budgetPlannerEdit.editLeisureInput, gbpExpenditureValues.leisure);
      await fillInput(budgetPlannerEdit.editOtherExpensesInput, gbpExpenditureValues.other);
      await commonTests.clickElement(budgetPlannerEdit.saveButton);
      await browser.wait(until.visibilityOf(budgetPlannerDefault.chart), commonConstants.mediumBrowserWaitDelay,
        'Chart not shown');
      const segmentCount = await budgetPlannerDefault.chartSegments.count();
      expect(segmentCount).toBe(10, 'Wrong pie charts size');
    });

    function runCheckPieChart(index, labelText, expensesValue) {
      it(`WHEN the Participant hovers over a graph segment "${labelText}"
        THEN show expense description
        AND show expense amount`, async () => {
        await checkPieChart(index, labelText, expensesValue);
      });
    }

    if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.mortgageRentSlice,
        'Mortgage / Rent', `£${gbpExpenditureValues.mortgage}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.councilTaxSlice,
        'Council Tax', `£${gbpExpenditureValues.council}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.insurancesSlice,
        'Insurances & Pension Policies', `£${gbpExpenditureValues.insurances}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.utilitiesSlice,
        'Utilities (gas, electricity, water)', `£${gbpExpenditureValues.utilities}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.tvSlice,
        'TV / Phone / Internet (incl. mobile', `£${gbpExpenditureValues.tv}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.groceriesSlice,
        'Groceries', `£${gbpExpenditureValues.groceries}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.loanSlice,
        'Loan / Credit Card Repayments', `£${gbpExpenditureValues.loan}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.travelSlice,
        'Travel', `£${gbpExpenditureValues.travel}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.leisureSlice,
        'Leisure', `£${gbpExpenditureValues.leisure}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.otherSlice,
        'Other Expenses', `£${gbpExpenditureValues.other}`);
    } else {
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.mortgageRentSlice,
        'Household', `£${gbpExpenditureValues.mortgage}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.councilTaxSlice,
        'Utilities', `£${gbpExpenditureValues.council}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.insurancesSlice,
        'Insurance', `£${gbpExpenditureValues.insurances}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.utilitiesSlice,
        'Family', `£${gbpExpenditureValues.utilities}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.tvSlice,
        'Transport', `£${gbpExpenditureValues.tv}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.groceriesSlice,
        'Debt repayments', `£${gbpExpenditureValues.groceries}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.loanSlice,
        'Health', `£${gbpExpenditureValues.loan}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.travelSlice,
        'Lifestyle', `£${gbpExpenditureValues.travel}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.leisureSlice,
        'Annual Expenses', `£${gbpExpenditureValues.leisure}`);
      runCheckPieChart(budgetPlannerDefault.budgetPlannerPieChart.otherSlice,
        'Other', `£${gbpExpenditureValues.other}`);
    }

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runPieSegmentsScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runPieSegmentsScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runPieSegmentsScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runPieSegmentsScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runPieSegmentsScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runCancelLoseChangesScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Scenario - Cancel/Lose changes (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting read view
     AND the Participant is editing a form field
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
      await browser.wait(
        until.visibilityOf(budgetPlannerEdit.editIncomeInput),
        commonConstants.mediumBrowserWaitDelay,
        'Edit income input not shown');
    });

    it(`WHEN Participant select the Cancel button
        THEN show Lose changes warning modal
        AND show Cancel button in active state
        AND show Continue button in active state as primary
        WHEN Participant selects Cancel button
        THEN close modal message
        AND return Participant to edit view of feature the Participant was updating`, async () => {
      // use common test to ensure page is fully loaded before continuing
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);

      // required as pensionerBudgetPlannerPage.url is more of a root URL
      expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.setBudgetUrl);
      await fillInput(budgetPlannerEdit.editIncomeInput, '10,000.00');
      await unsavedChangesModalTests.cancelCancelUnsavedChanges(
        budgetPlannerPage,
        budgetPlannerEdit.cancelButton(global.deviceType),
        budgetPlannerEdit.unsavedChangesModal,
        budgetPlannerPage.setBudgetUrl
      );
    });

    it(`WHEN Participant selects Continue button
        THEN discard edits made
        AND close modal message
        AND return Participant to read view of feature the Participant was updating`, async () => {
      await unsavedChangesModalTests.confirmCancelUnsavedChanges(
        budgetPlannerEdit.cancelButton(global.deviceType),
        budgetPlannerEdit.unsavedChangesModal,
        budgetPlannerPage.setBudgetUrl,
        budgetPlannerPage,
        true
      );
    });

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runCancelLoseChangesScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runCancelLoseChangesScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runCancelLoseChangesScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runCancelLoseChangesScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runCancelLoseChangesScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);
