// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');
const resultMessaging = require('../../utilities/result-messaging.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec');
const LoginTests = require('../_common/authentication-login.spec');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const DcTransferTests = require('../_common/dc-transfer.spec');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec');
const DbTransferTests = require('../_common/db-transfer.spec');
const DbRetirementPlanningTests = require('../_common/db-retirement-planning.spec');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const commonTests = new CommonTests();
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po');
const EducationArticleCard = require('../../page-component-objects/education-article-card.co');
const EducationCentrePage = require('../../page-objects/education-centre.po');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po');
const DcTransferPage = require('../../page-objects/dc-transfer.po');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po');
const DbTransferPage = require('../../page-objects/db-transfer.po');
const DbRetirementPlanningPage = require('../../page-objects/db-retirement-planning.po');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const dashboardTests = new DashboardTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const dcTransferTests = new DcTransferTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const dbTransferTests = new DbTransferTests();
const dbRetirementPlanningTests = new DbRetirementPlanningTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const educationArticleCard = new EducationArticleCard(0);
const educationCentrePage = new EducationCentrePage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
let dcPlanSummaryPage;
let dcTransferPage;
let dbPlanSummaryPage;
let dbTransferPage;
let dbRetirementPlanningPage;
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testPensionerPlanSummaryArticles = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments in bug OUK-9197
  testPensionerPlanSummaryArticles = false;
}

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-2199${commonConstants.bddScenarioPrefix}`;

async function checkArticleCard(article) {
  const waitMs = commonConstants.mediumShortBrowserWaitDelay;
  await browser.wait(
    until.visibilityOf(article.icon),
    waitMs,
    `Article is not displayed after wait of ${waitMs}ms`);

  await checkers.anyText(article.articleDesc);
  await checkers.anyText(article.headline);
  await checkers.anyImage(article.icon);
}

async function checkArticleCardsPresent(page) {
  const articles = await page.allArticles;
  const articleCount = await articles.length;

  if (articleCount === 0) {
    resultMessaging.publishFailBasic('Missing article cards');
  } else {
    for (let i = 0; i < articleCount; i += 1) {
      await checkArticleCard(page.getArticleCard(i));
    }
  }
}

function runAmalgamatedScenarios(navigationPageName, posInstance) {
  describe(`${scenarioPrefix}Articles visibility + Accessing an article`
      + ` (${navigationPageName}, POS instance ${posInstance})`, () => {
    /*
        *** note these scenarios are all merged together - they are really same scenario - more efficient for TE ***
        Login page articles
        Dashboard articles visibility
        DC articles visibility
        DB articles visibility
        PIP articles visibility
        ------------------------------------------------------
        GIVEN Education Centre is enabled
        WHEN the Member navigates to a page containing articles

        Accessing an article
        ------------------------------------------------------
        GIVEN the Participant is viewing a <page> containing an <article card>
        WHEN they select the link to view the full article content
       */
    let dcPos;
    let dbPos;
    let navigationPage;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${navigationPageName}`);

      switch (posInstance) {
        case 0:
        case 'n/a':
          // note 'n/a' only needed here so DC and DB pages are created successfully even though not needed
          dcPos = standardParticipant.posDcActive;
          dbPos = standardParticipant.posDbActive;
          break;
        case 1:
          dcPos = standardParticipant.posDcDeferred;
          dbPos = standardParticipant.posDbDeferred;
          break;
        default:
          fail(`The posInstance of ${posInstance} is not supported`);
      }

      dcPlanSummaryPage = new DcPlanSummaryPage(
        standardParticipant,
        dcPos.scheme.data.midasSchemeCode,
        dcPos.data.periodOfServicePrimaryKey);
      dcTransferPage = new DcTransferPage(
        standardParticipant,
        dcPos.scheme.data.midasSchemeCode,
        dcPos.data.periodOfServicePrimaryKey);
      dbPlanSummaryPage = new DbPlanSummaryPage(
        standardParticipant,
        dbPos.scheme.data.midasSchemeCode,
        dbPos.data.periodOfServicePrimaryKey);
      dbTransferPage = new DbTransferPage(
        standardParticipant,
        dbPos.scheme.data.midasSchemeCode,
        dbPos.data.periodOfServicePrimaryKey);
      dbRetirementPlanningPage = new DbRetirementPlanningPage(
        standardParticipant,
        dbPos.scheme.data.midasSchemeCode,
        dbPos.data.periodOfServicePrimaryKey);

      switch (navigationPageName) {
        case 'loginPage':
          await loginTests.checkLoginPageLoads(loginPage);
          navigationPage = loginPage;
          break;
        case 'dashboardPage':
          await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
          navigationPage = dashboardPage;
          break;
        case 'dcPlanSummaryPage':
          await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
            loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, posInstance);
          navigationPage = dcPlanSummaryPage;
          break;
        case 'dcTransferPage':
          await dcTransferTests.browseToDcTransferPageFromLogin(
            loginPage, dashboardPage, dcPlanSummaryPage, dcTransferPage, standardParticipant, posInstance);
          navigationPage = dcTransferPage;
          break;
        case 'dbPlanSummaryPage':
          await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
            loginPage, dashboardPage, dbPlanSummaryPage, standardParticipant, posInstance);
          navigationPage = dbPlanSummaryPage;
          break;
        case 'dbTransferPage':
          await dbTransferTests.browseToDbTransferPageFromLogin(
            loginPage, dashboardPage, dbPlanSummaryPage, dbTransferPage, standardParticipant, posInstance);
          navigationPage = dbTransferPage;
          break;
        case 'dbRetirementPlanningPage':
          await dbRetirementPlanningTests.browseToDbRetirementPlanningPageFromLogin(
            loginPage, dashboardPage, dbPlanSummaryPage, dbRetirementPlanningPage, standardParticipant, posInstance);
          navigationPage = dbRetirementPlanningPage;
          break;
        case 'pensionerPlanSummaryPage':
          await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
            loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, posInstance);
          navigationPage = pensionerPlanSummaryPage;
          break;
        default:
          fail(`Page ${navigationPageName} not supported`);
      }
    });

    // Login page articles
    // Dashboard articles visibility
    // DC articles visibility
    // DB articles visibility
    // PIP articles visibility
    it(`THEN show [article cards] for ${navigationPageName}`, async () => {
      await checkArticleCardsPresent(navigationPage);
    });

    // Accessing an article
    it('(Accessing an article) THEN redirect the Participant to the [article full page view]', async () => {
      // just check 1 article
      await commonTests.clickElement(navigationPage.article1.callToAction);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(educationCentrePage);
      expect(browser.getCurrentUrl()).toContain(navigationPage.article1Url());
    });

    afterAll(async () => {
      if (navigationPageName !== 'loginPage') {
        await commonTests.logOut(educationArticleCard, loginPage);
      } else {
        await commonTests.clearBrowserCacheAndCookies();
      }
    });
  });
}

if (testPensionerPlanSummaryArticles) {
  /*
    note DC retirement planning page checks for articles removed 18/03/2019 as only 1 not 3 cards
    and URL is different format to other pages - not enough time to support difference
   */
  runAmalgamatedScenarios('loginPage', 'n/a');
  runAmalgamatedScenarios('dashboardPage', 'n/a');
  runAmalgamatedScenarios('dcPlanSummaryPage', 0);
  runAmalgamatedScenarios('dcPlanSummaryPage', 1);
  runAmalgamatedScenarios('dcTransferPage', 0);
  runAmalgamatedScenarios('dbPlanSummaryPage', 0);
  runAmalgamatedScenarios('dbPlanSummaryPage', 1);
  runAmalgamatedScenarios('dbTransferPage', 1);
  runAmalgamatedScenarios('dbRetirementPlanningPage', 0);
  runAmalgamatedScenarios('pensionerPlanSummaryPage', 0);
}
