// TODO: finish code
// ************************ NOTE THIS IS UNFINISHED CODE *****************************

/*
  5228 was postcode validation check in view profile - now moved to contact details under POS
 */

// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ProfileInformationTests = require('../_common/profile.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');

// create new objects
const standardParticipant = new StandardParticipant();
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const profileInformationTests = new ProfileInformationTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const profilePage = new ProfilePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-5609${commonConstants.bddScenarioPrefix}`;

// other
const until = protractor.ExpectedConditions;

async function checkInvalidPostalCode(invalidCode) {
  const errorMsg = 'Post Code is invalid';
  await profilePage.postCodeValue.clear();
  await profilePage.postCodeValue.sendKeys(invalidCode);

  await commonTests.clickElement(profilePage.editContactDetailsSaveButton);
  await browser.wait(
    until.visibilityOf(profilePage.postCodeValueRequiredError),
    commonConstants.briefBrowserWaitDelay,
    `Missing required error message for Post code input: ${invalidCode} code`);
  await checkers.containingTextIgnoreCase(profilePage.postCodeValueRequiredError, errorMsg);
}

// TODO: update old ouk-5228 code so checks contact details in each POS
describe(`${scenarioPrefix}Check profile page rejects invalid postcodes (was 5228)`, () => {
  /*
    GIVEN view is Profile contact details edit view
    WHEN the Participant attempts to navigate away from the postal code field and the code is <invalid postal code>
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await profileInformationTests.browseToProfileInformationPageFromLogin(
      loginPage, dashboardPage, profilePage, standardParticipant);
  });

  it('THEN highlight invalid field', async () => {
    const present = await browser.isElementPresent(profilePage.contactDetailsEditButton);

    if (!present) {
      fail('Contact edit details button not present');
    } else {
      await commonTests.clickElement(profilePage.contactDetailsEditButton);
      await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
      expect(browser.getCurrentUrl()).toContain(profilePage.editContactDetailsUrl);
      await checkInvalidPostalCode('aSE1 3rY');
      await checkInvalidPostalCode('PO 16 3FF');
      await checkInvalidPostalCode('P O16 3FF');
      await checkInvalidPostalCode('1o16 3dF');
      await checkInvalidPostalCode(' o16 3Ff');
      await checkInvalidPostalCode('1O16 RFF');
      await checkInvalidPostalCode('P O16 3FF');
      await checkInvalidPostalCode('PO163FF');
      await checkInvalidPostalCode('P#16!FF');
      await checkInvalidPostalCode('$O1% 3*F');
      await unsavedChangesModalTests.cancelUnsavedChangesIncludingCancelCancel(
        profilePage,
        profilePage.editContactDetailsCancelButton,
        profilePage.unsavedChangesModal,
        profilePage.editContactDetailsUrl,
        profilePage,
        true);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});
