// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ViewProfilePage = require('../../page-objects/view-profile.po.js');

// load participant(s)
const StandardParticipant
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ViewProfilePageTests = require('../_common/view-profile.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const viewProfilePageTests = new ViewProfilePageTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const viewProfilePage = new ViewProfilePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-2152${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await viewProfilePageTests.browseToViewProfilePageFromLogin(loginPage, dashboardPage, viewProfilePage, participant);
}

describe(`${scenarioPrefix}Default Read Only View`, () => {
  /*
    GIVEN that the Participant is viewing [USER PROFILE]
    AND selects [PROFILE]
    AND [BCM] is [ENABLED]
    AND [BCM OPTOUT] is [ENABLED]
    WHEN [PROFILE PAGE] loads
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show [ECOMMS PREFERENCE FEATURE]'
    + ' AND show recorded [ECOMMS PREFERENCE] for [PARTICIPANT]'
    + ' AND show [EDIT LINK]', async () => {
    await checkers.containingTextIgnoreCase(viewProfilePage.electronicCommunicationHeader,
      'Electronic Communication Preferences');

    if (viewProfilePage.ecRadioYesDisabledLabel.isSelected()) {
      expect(viewProfilePage.ecRadioYesDisabledLabelValue.getAttribute('value')).toEqual('true');
    } else {
      expect(viewProfilePage.ecRadioNoDisabledLabelValue.getAttribute('value')).toEqual('true');
    }

    expect(viewProfilePage.ecRadioYesDisabledLabel.isDisplayed()).toBe(true);
    expect(viewProfilePage.ecRadioNoDisabledLabel.isDisplayed()).toBe(true);
    expect(viewProfilePage.electronicCommunicationEditButton.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

async function clickSaveButton() {
  await commonTests.clickElement(viewProfilePage.electronicCommunicationSaveButton);
  expect(viewProfilePage.electronicCommunicationRadioLabelDisabled.isDisplayed()).toBe(true);
  expect(viewProfilePage.ecRadioYesDisabledLabel.isDisplayed()).toBe(true);
  expect(viewProfilePage.ecRadioNoDisabledLabel.isDisplayed()).toBe(true);
  await checkers.containingTextIgnoreCase(viewProfilePage.successMsgLabel,
    'You have successfully submitted your changes');
}

describe(`${scenarioPrefix}Edit View, Confirmation`, () => {
  /*
    GIVEN that the Participant is viewing [USER PROFILE]
    AND selects [PROFILE]
    AND [PARTICIPANT] wishes to change their [ECOMMS PREFERENCE]
    WHEN [EDIT LINK] selected
  */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN enter [EDIT VIEW]'
    + ' AND show current preference as selected'
    + ' AND show [SAVE BUTTON]'
    + ' AND show [CANCEL BUTTON]', async () => {
    await commonTests.clickElement(viewProfilePage.electronicCommunicationEditButton);

    if (viewProfilePage.ecRadioYesLabel.isSelected()) {
      expect(viewProfilePage.ecRadioYesLabelValue.getAttribute('value')).toEqual('true');
    } else {
      expect(viewProfilePage.ecRadioNoLabelValue.getAttribute('value')).toEqual('true');
    }

    expect(viewProfilePage.electronicCommunicationSaveButton.isEnabled()).toBe(true);
    expect(viewProfilePage.electronicCommunicationCancelButton.isEnabled()).toBe(true);
  });

  /*
    GIVEN that the Participant is viewing [USER PROFILE]
    AND selects [PROFILE]
    AND data has been changed
    WHEN [SAVE BUTTON] selected
  */

  it('THEN return to [READ ONLY VIEW] AND show [UPDATE CONFIRMATION MESSAGE]', async () => {
    if (viewProfilePage.ecRadioYesLabel.isSelected()) {
      await commonTests.clickElement(viewProfilePage.ecRadioYesLabel);
      await clickSaveButton();
    } else {
      await commonTests.clickElement(viewProfilePage.ecRadioNoLabel);
      await clickSaveButton();
    }
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}No Changes`, () => {
  /*
      GIVEN that the Participant is viewing [USER PROFILE]
      AND selects [PROFILE]
      AND view is [EDIT VIEW]
      AND data has not been changed
      WHEN [SAVE BUTTON] selected
 */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN return to [READ ONLY VIEW] ', async () => {
    await commonTests.clickElement(viewProfilePage.electronicCommunicationEditButton);
    await commonTests.clickElement(viewProfilePage.electronicCommunicationSaveButton);
    expect(viewProfilePage.electronicCommunicationRadioLabelDisabled.isDisplayed()).toBe(true);
    expect(viewProfilePage.ecRadioYesDisabledLabel.isDisplayed()).toBe(true);
    expect(viewProfilePage.ecRadioNoDisabledLabel.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});
