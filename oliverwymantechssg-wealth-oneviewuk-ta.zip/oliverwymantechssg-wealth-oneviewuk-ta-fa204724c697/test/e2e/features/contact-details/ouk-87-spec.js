// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ProfileTests = require('../_common/profile.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');

// create new objects
const standardParticipant = new StandardParticipant();
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const profileTests = new ProfileTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const profilePage = new ProfilePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-87${commonConstants.bddScenarioPrefix}`;

// TODO: contact details now per POS rather than in profile ... and all IDs seem to have disappeared - leave for moment

async function selectDropdownbyIndex(element, index) {
  const options = await element(by.tagName('option'));
  await commonTests.clickElement(options.get(index));
}

async function enterValuesIntoContactDetailsFields(profileContactDetailsPage) {
  await element(profileContactDetailsPage.addressLine1).sendKeys('Westgate House');
  await element(profileContactDetailsPage.addressLine2).sendKeys('52 Chichester');
  await element(profileContactDetailsPage.addressLine3).sendKeys('United Kingdom 2158');
  await element(profileContactDetailsPage.postCodeValue).sendKeys('PO19 3Z2');
  await element(profileContactDetailsPage.emailAddressValue).sendKeys('mercerdemo@mercer.com');
  await element(profileContactDetailsPage.phoneNumberValue).sendKeys('(0)345 600 0229');
  await selectDropdownbyIndex(element(profileContactDetailsPage.residencySelectValue), 0);
  await selectDropdownbyIndex(element(profileContactDetailsPage.phoneTypeSelectValue), 0);
  await selectDropdownbyIndex(element(profileContactDetailsPage.phoneNumberSelectValue), 0);
}

describe(`${scenarioPrefix}Read view`, () => {
  /*
   GIVEN that the Participant has navigated to the Profile page
   WHEN the Profile page loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await profileTests.browseToProfileInformationPageFromLogin(
      loginPage, dashboardPage, profilePage, standardParticipant);
  });

  it('THEN show postal address details from main POS', async () => {
    await checkers.containingTextIgnoreCase(profilePage.contactDetailsTitle, 'Contact Details');
    expect(profilePage.contactDetailsInfoIcon.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(profilePage.postalAddressLabel, 'Postal Address');
    await checkers.containingTextIgnoreCase(profilePage.postalAddressValue, 'define');
    await checkers.containingTextIgnoreCase(profilePage.residencyLabel, 'Residency');
    await checkers.containingTextIgnoreCase(profilePage.residencyValue, 'define');
  });

  it('AND show email address details from main POS', async () => {
    await checkers.containingTextIgnoreCase(profilePage.emailAddressLabel, 'Email Address');
    await checkers.containingTextIgnoreCase(profilePage.emailAddressValue, 'define');
  });

  it('AND show telephone number from main POS', async () => {
    await checkers.containingTextIgnoreCase(profilePage.phoneNumberLabel, 'Telephone Number');
    await checkers.containingTextIgnoreCase(profilePage.phoneNumberValue, 'define');
  });

  it('AND show contact details edit button in active state', async () => {
    await checkers.anyText(profilePage.contactDetailsEditButton);
    expect(profilePage.contactDetailsEditButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

function runResidencyReadViewScenario(overseasIndicator, residency, participant) {
  describe(`${scenarioPrefix}Residency, read view`, () => {
    /*
     GIVEN that the Participant has navigated to the Profile page
     WHEN the Profile page loads
     */

    const thenLabel
      = `THEN ${residency} residency based on ${overseasIndicator} overseas indicator from main POS`;

    beforeAll(async () => {
      await profileTests.browseToProfileInformationPageFromLogin(
        loginPage, dashboardPage, profilePage, participant);
    });

    // THEN show residency based on overseas indicator from main POS
    it(thenLabel, async () => {
      switch (overseasIndicator) {
        case 'NULL':
          await checkers.containingTextIgnoreCase(profilePage.residencyValue, 'United Kingdom');
          break;
        case 'Y':
          await checkers.containingTextIgnoreCase(profilePage.residencyValue, 'Overseas');
          break;
        case 'N':
          await checkers.containingTextIgnoreCase(profilePage.residencyValue, 'United Kingdom');
          break;
        default:
          fail(`The  ${participant} doesn't have valid overseas indicator`);
      }
      expect(profilePage.residencyValue.isEnabled()).toEqual(false);
    });

    afterAll(async () => {
      await commonTests.logOut(profilePage, loginPage);
    });
  });
}

runResidencyReadViewScenario('N', 'United Kingdom', standardParticipant);

describe(`${scenarioPrefix}Label info icon`, () => {
  /*
   GIVEN that the Participant has navigated to the Profile page
   WHEN the Participant selects the contact details info icon
   */

  beforeAll(async () => {
    await profileTests.browseToProfileInformationPageFromLogin(
      loginPage, dashboardPage, profilePage, standardParticipant);
  });

  it('THEN display contact details guidance text', async () => {
    await tooltipTests.checkTooltipIsElementContainingText(
      profilePage.contactDetailsInfoIcon,
      profilePage.contactDetailsTitle,
      profilePage.tooltips.firstRightTooltip,
      'define');
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit view + Successful update`, () => {
  /*
   GIVEN that the Participant has navigated to the Profile page
   WHEN the Participant selects the contact details edit button
   */

  beforeAll(async () => {
    await profileTests.browseToProfileInformationPageFromLogin(
      loginPage, dashboardPage, profilePage, standardParticipant);
  });

  it('THEN permit updates to contact details AND show Cancel button in active state '
    + 'AND show Save button in active state as primary button', async () => {
    await commonTests.clickElement(profilePage.contactDetailsEditButton);
    await checkers.anyText(profilePage.contactDetailsCancelButton);
    expect(profilePage.contactDetailsCancelButton.isEnabled()).toBe(true);
    await checkers.anyText(profilePage.contactDetailSaveButton);
    expect(profilePage.contactDetailSaveButton.isEnabled()).toBe(true);
    await enterValuesIntoContactDetailsFields(profilePage);
    await commonTests.clickElement(profilePage.greetingPreferencesSaveButton);
    const postalAddress = element(by.id(profilePage.postalAddressValue));
    expect(profilePage.residencyValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.residencyValue, 'Overseas');
    expect(profilePage.emailAddressValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.emailAddressValue, 'mercerdemo@mercer.com');
    expect(profilePage.phoneNumberValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.phoneNumberValue, '(0)345 600 0229');
    await checkers.exactText(profilePage.toast.message,
      `${commonConstants.profileSuccessToastMessage}`);
    expect(profilePage.postalAddressValue.isEnabled()).toEqual(false);
    await checkers.anyText(profilePage.postalAddressValue);
    await checkers.containingTextIgnoreCase(postalAddress, 'Westgate House');
    await checkers.containingTextIgnoreCase(postalAddress, '52 Chichester');
    await checkers.containingTextIgnoreCase(postalAddress, 'United Kingdom 2158');
    await checkers.containingTextIgnoreCase(postalAddress, 'PO19 3Z2');
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Cancel, no changes`, () => {
  /*
   GIVEN that the Participant has navigated to the Profile page
   AND the Participant has selected the edit button
   BUT no edits have been made
   WHEN the Participant selects the cancel button
   */

  beforeAll(async () => {
    await profileTests.browseToProfileInformationPageFromLogin(
      loginPage, dashboardPage, profilePage, standardParticipant);
  });

  it('THEN return Participant to read view', async () => {
    const postalAddress = await element(by.id(profilePage.postalAddressValue)).getText();
    const residency = await element(by.id(profilePage.residencyValue)).getText();
    const emailAddress = await element(by.id(profilePage.emailAddressValue)).getText();
    const phoneNumber = await element(by.id(profilePage.phoneNumberValue).getText());

    await commonTests.clickElement(profilePage.contactDetailsEditButton);
    await enterValuesIntoContactDetailsFields(profilePage);
    await commonTests.clickElement(profilePage.contactDetailsCancelButton);
    expect(profilePage.postalAddressValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.postalAddressValue, `${postalAddress}`);
    expect(profilePage.residencyValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.residencyValue, `${residency}`);
    expect(profilePage.emailAddressValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.emailAddressValue, `${emailAddress}`);
    expect(profilePage.phoneNumberValue.isEnabled()).toEqual(false);
    await checkers.containingTextIgnoreCase(profilePage.phoneNumberValue, `${phoneNumber}`);
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});
