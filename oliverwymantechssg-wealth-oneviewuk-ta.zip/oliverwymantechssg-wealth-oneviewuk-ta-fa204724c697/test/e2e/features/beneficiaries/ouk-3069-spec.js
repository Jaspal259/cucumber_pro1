// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const beneficiariesTests = new BeneficiariesTests();
const participant = standardParticipant;
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const beneficiariesPage = new BeneficiariesPage('lump sum');
const dbPlanSummaryPage = new DbPlanSummaryPage(participant,
  participant.posDbActive.scheme.data.midasSchemeCode,
  participant.posDbActive.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-3069${commonConstants.bddScenarioPrefix}`;

async function editBeneficiaries(newShareValue) {
  const present = await browser.isElementPresent(beneficiariesPage.lumpSumTab);

  if (present) {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    await beneficiariesPage.editShareOfBenefitValue.clear();
    await beneficiariesPage.editShareOfBenefitValue.sendKeys(newShareValue);
    await commonTests.clickElement(beneficiariesPage.editBenefiConfirmButton);
    await commonTests.clickElement(beneficiariesPage.beneficiariesSaveButton(global.deviceType));
    await commonTests.clickElement(beneficiariesPage.beneficiariesAttentionButton);
  }
}

describe(`${scenarioPrefix}Upon Submit`, () => {
  /*
    GIVEN view is Beneficiaries page
    AND updates have been made to Beneficiary records
    AND Total Benefit Share for updated Beneficiary data does not equal 100%
    WHEN Submit button selected
   */

  let value = 0;
  let newShareValue = 0;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await beneficiariesTests.browseToBeneficiariesPageViaDbPlanSummaryPage(
      loginPage, dashboardPage, dbPlanSummaryPage, beneficiariesPage, participant, 0);
  });

  it('THEN display Total Benefit Share warning message'
    + ' AND do not update Beneficiary records', async () => {
    const oldShareValue = await beneficiariesPage.getShareOfBenefitValue(0).getText();
    value = oldShareValue.substr(0, oldShareValue.length - 4);
    newShareValue = (value + 1);
    await editBeneficiaries(newShareValue);
    await checkers.exactText(beneficiariesPage.beneficiariesWarningMessageLabel,
      'Total must equal 100.00%');
    await browser.navigate().refresh();
    const shareValue = await beneficiariesPage.getShareOfBenefitValue(0).getText();

    if (shareValue === oldShareValue) {
      resultMessaging.passTestWithCustomMessage('Beneficiary records not updated.');
    }
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});
