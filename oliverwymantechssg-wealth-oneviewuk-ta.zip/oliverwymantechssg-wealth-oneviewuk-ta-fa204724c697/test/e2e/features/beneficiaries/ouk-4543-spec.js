// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const Participant001 = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new Participant001();
const beneficiariesTests = new BeneficiariesTests();
const dbPlanSummaryPage = new DbPlanSummaryPage(participant,
  participant.posDbActive.scheme.data.midasSchemeCode,
  participant.posDbActive.data.periodOfServicePrimaryKey);
const dcPlanSummaryPage = new DcPlanSummaryPage(participant,
  participant.posDcActive.scheme.data.midasSchemeCode,
  participant.posDcActive.data.periodOfServicePrimaryKey);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const beneficiariesPage = new BeneficiariesPage(participant);

// tests
const scenarioPrefix = `OUK-4543${commonConstants.bddScenarioPrefix}`;

async function checkPlanHeaderDisplayed() {
  const lumpSumTabPresent = await browser.isElementPresent(beneficiariesPage.lumpSumTab);

  if (lumpSumTabPresent) {
    await checkers.containingTextIgnoreCase(beneficiariesPage.lumpSumTab, 'Lump');
    await checkers.containingTextIgnoreCase(beneficiariesPage.lumpSumTab, 'Sum');
  }

  const dependantsTabPresent = await browser.isElementPresent(beneficiariesPage.dependantsTab);

  if (dependantsTabPresent) {
    await checkers.containingTextIgnoreCase(beneficiariesPage.dependantsTab, 'Dependants');
  }
}

function runAddPlanHeaderScenario(planType) {
  describe(`${scenarioPrefix}add Plan header/Move to full page template (${planType})`, () => {
    /*
      GIVEN Beneficiaries is available (OUK-3804)
      WHEN the Participant navigates to the Beneficiaries page
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planType}`);

      if (planType === 'DC') {
        await beneficiariesTests.browseToBeneficiariesPageViaDcPlanSummaryPage(
          loginPage, dashboardPage, dcPlanSummaryPage,
          beneficiariesPage, participant, 0);
      } else if (planType === 'DB') {
        await beneficiariesTests.browseToBeneficiariesPageViaDbPlanSummaryPage(
          loginPage, dashboardPage, dbPlanSummaryPage,
          beneficiariesPage, participant, 0);
      } else {
        await beneficiariesTests.browseToBeneficiariesPageViaPipPlanSummaryPage(
          loginPage, dashboardPage,
          pensionerPlanSummaryPage, beneficiariesPage, participant, 0);
      }
    });

    it('THEN display Plan Header relevant to the Plan Period of Service', async () => {
      await checkPlanHeaderDisplayed();
    });

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runAddPlanHeaderScenario('DC');
runAddPlanHeaderScenario('DB');
runAddPlanHeaderScenario('Pensioner');
