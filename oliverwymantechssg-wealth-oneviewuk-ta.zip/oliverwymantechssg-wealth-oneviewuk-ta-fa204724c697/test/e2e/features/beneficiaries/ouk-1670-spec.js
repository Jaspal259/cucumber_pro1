// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const beneficiariesPage = new BeneficiariesPage(standardParticipant);
const beneficiariesTests = new BeneficiariesTests(standardParticipant);

// additional
const bmView = beneficiariesPage.beneficiaryManagementView;

// tests
const scenarioPrefix = `OUK-1670${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await beneficiariesTests.browseToBeneficiariesPageFromLogin(
    loginPage, dashboardPage, beneficiariesPage, participant);

  /*
    lump sum beneficiaries visibility applies to pensioners and members and is set by the following Midas CC items:
    - CanSeeNominationForm     (DC LOB rights)  Y = visible
    - CanSeeNominationForm     (DB LOB rights)  Y = visible

    source: Dev data mapping document: http://wiki.mercer.com/pages/viewpage.action?pageId=667714639
   */
}

function checkFooterWarningCancelAndConfirmControls() {
  it('AND show [LS FOOTER WARNING MESSAGE] i.e. Selecting confirm will update this information,'
    + ' once confirmed you still need to save all of your changes.', async () => {
    expect(bmView.warningIcon.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(bmView.warningLabel, 'confirm');
    await checkers.containingTextIgnoreCase(bmView.warningLabel, 'update');
    await checkers.containingTextIgnoreCase(bmView.warningLabel, 'save');
  });

  it('AND show [CANCEL] in [ACTIVE] state', () => {
    expect(bmView.cancelButton.isDisplayed()).toBe(true);
    expect(bmView.cancelButton.isEnabled()).toBe(true);
  });

  it('AND show [CONFIRM BUTTON] in [ACTIVE] state', () => {
    expect(bmView.confirmButton.isDisplayed()).toBe(true);
    expect(bmView.confirmButton.isEnabled()).toBe(true);

    // note this test will not test the order of the fields - this is layout
    resultMessaging.passTestAsLayoutTest();
  });
}

async function cancelUpdateAndLogOut() {
  await commonTests.clickElement(bmView.cancelButton);
  expect(bmView.beneficiaryManagementView.isPresent()).toBe(false);
  await commonTests.logOut(beneficiariesPage, loginPage);
}

async function updateName() {
  await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
  expect(beneficiariesPage.beneficiaryManagementView.isPresent()).toBe(true);
  await beneficiariesPage.beneficiaryManagementView.fullNameValue.clear();
  await beneficiariesPage.beneficiaryManagementView.fullNameValue.sendKeys('TestQA');
  await commonTests.clickElement(beneficiariesPage.beneficiaryManagementView.beneficiariesSaveButton);
}

describe(`${scenarioPrefix}Add Beneficiary`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [NOMS READ ONLY] is [DISABLED]
    AND [NOM GUARDIAN AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    WHEN the [ADD BUTTON] is selected
   */

  /*
    Extra JIRA test info:

    #Ben type list of values comes from back-end but should also include ‘Choose one’ as the first item in the list
    #Standard modal for Beneficiary management view
    #confirm button is primary button
    #order of fields as listed above
    #Spreadsheet attached shows which fields are mandatory/optional - * to be shown for mandatory fields
   */

  // TODO: participant must have one beneficiary already

  /*
    dependants beneficiaries visibility applies to pensioners and members and is set by the following Midas CC items:
    - CCIsPenDependantsAvail  (pensioner)       if no CCIsPenDependantsAvail use DB/DC CC items below
    - CCIsDependantsAvail     (DC LOB rights)
    - CCIsDependantsAvail     (DB LOB rights)

    If any cc item Exists return true (feature visible), otherwise false
    source: Dev data mapping document: http://wiki.mercer.com/pages/viewpage.action?pageId=667714639
   */

  /*
    edit / read-only status only applies to pensioners and members is set by the following Midas CC items:
    - CCIsPenDepsViewOnly     (pensioner)         True = edit disabled
    - IsMbrNomsViewOnly       (DC LOB rights)     True = edit disabled
    - IsMbrNomsViewOnly       (DB LOB rights)     True = edit disabled

    If cc item exists return true (edit disabled), otherwise false
    source: Dev data mapping document: http://wiki.mercer.com/pages/viewpage.action?pageId=667714639
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(participant);
  });

  it('THEN open [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);
  });

  it('AND show [ADD TITLE] i.e. Add Beneficiary', async () => {
    await checkers.exactText(bmView.viewHeading, 'Add Beneficiary');
  });

  it('AND show [REQUIRED FILED] wording i.e. *Required', async () => {
    await checkers.exactText(bmView.requiredFieldLabel, '*Required');
  });

  it('AND show [NAME] as blank', async () => {
    await checkers.exactText(bmView.fullNameLabel, 'Name *');
    await checkers.noText(bmView.fullNameValue);
  });

  it('AND show [ADDRESS] as blank', async () => {
    await checkers.exactText(bmView.addressLabel, 'Address *');
    await checkers.noText(bmView.addressValue);
  });

  it('AND show [DOB] as blank', async () => {
    await checkers.exactText(bmView.dateOfBirthLabel, 'Date of Birth');
    await checkers.noText(bmView.dateOfBirthValue);
  });

  it('AND show [BEN TYPE] as [Choose One]', async () => {
    await checkers.exactText(bmView.beneficiaryTypeLabel, 'Choose Beneficiary Type *');
    await checkers.exactText(bmView.beneficiaryTypeValue, 'Choose One');
  });

  it('AND show [BEN SHARE PERC] as blank', async () => {
    // note [BEN SHARE PERC] should only be shown as mandatory if at least 1 beneficiary for this participant already
    // * to be shown in label for mandatory fields
    await checkers.exactText(bmView.shareOfBenefitLabel, 'Share of Benefit % *');
    await checkers.noText(bmView.shareOfBenefitValue);
  });

  it('AND show [GUARD NAME] as blank', async () => {
    await checkers.exactText(bmView.guardianFullNameLabel, 'Guardian Name *');
    await checkers.noText(bmView.guardianFullNameValue);
  });

  it('AND show [GUARD ADDRESS] as blank', async () => {
    await checkers.exactText(bmView.guardianAddressLabel, 'Guardian Address *');
    await checkers.noText(bmView.guardianAddressValue);
  });

  checkFooterWarningCancelAndConfirmControls();

  afterAll(async () => {
    await cancelUpdateAndLogOut();
  });
});

describe(`${scenarioPrefix}Edit Beneficiary`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [NOMS READ ONLY] is [DISABLED]
    AND [NOM GUARDIAN AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    WHEN [EDIT BUTTON] is selected
   */

  /*
    Extra JIRA test info:

    #Standard modal for Beneficiary management view
    #where no data is held, show blank for that field
    #confirm button is primary button
    #order of fields as listed above
    #Spreadsheet attached shows which fields are mandatory/optional - * to be shown for mandatory fields
   */

  // TODO: participant must have one beneficiary already

  const participant = standardParticipant;
  const row = 0; // beneficiary to edit

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN open [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(row, global.deviceType));
    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);
  });

  it('AND show [EDIT TITLE] i.e. Edit Beneficiary', async () => {
    await checkers.exactText(bmView.viewHeading, 'Edit Beneficiary');
  });

  it('AND show [REQUIRED FILED] wording i.e. *Required', async () => {
    await checkers.exactText(bmView.requiredFieldLabel, '*Required');
  });

  it('AND show [NAME] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.fullNameLabel, 'Name *');
    await checkers.exactText(bmView.fullNameValue, 'lastNameValue');
  });

  it('AND show [ADDRESS DATA] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.addressLabel, 'Address *');
    await checkers.exactText(bmView.addressValue, 'addressValue');
  });

  it('AND show [DOB] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.dateOfBirthLabel, 'Date of Birth');
    await checkers.exactText(bmView.dateOfBirthValue, 'dateOfBirthValue');
  });

  it('AND show [BEN TYPE DATA] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.beneficiaryTypeLabel, 'Choose Beneficiary Type *');
    await checkers.exactText(bmView.beneficiaryTypeValue, 'beneficiaryTypeValue');
  });

  it('AND show [BEN SHARE PERC] as recorded for beneficiary', async () => {
    // note [BEN SHARE PERC] should only be shown as mandatory if at least 1 beneficiary for this participant already
    // * to be shown in label for mandatory fields
    // TODO: insert known values
    await checkers.exactText(bmView.shareOfBenefitLabel, 'Share of Benefit % *');
    await checkers.exactText(bmView.shareOfBenefitValue, 'shareOfBenefitValue');
  });

  it('AND show [GUARD NAME] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.guardianFullNameLabel, 'Guardian Name *');
    await checkers.exactText(bmView.guardianFullNameValue, 'guardianLastNameValue');
  });

  it('AND show [GUARD ADDRESS] as recorded for beneficiary', async () => {
    // TODO: insert known values
    await checkers.exactText(bmView.guardianAddressLabel, 'Guardian Address *');
    await checkers.exactText(bmView.guardianAddressValue, 'guardianAddressValue');
  });

  checkFooterWarningCancelAndConfirmControls();

  afterAll(async () => {
    await cancelUpdateAndLogOut();
  });
});

xdescribe(`${scenarioPrefix}Guardian disabled${commonConstants.bddScenarioSuffixTestManually}`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [NOM GUARDIAN AVAIL] is [DISABLED]
    WHEN [BENEFICIARY MANAGEMENT VIEW] loads
   */

  xit('THEN hide [GUARD NAME]', () => {
    // test this manually
  });

  xit('AND hide [GUARD ADDRESS]', () => {
    // test this manually
  });
});

xdescribe(`${scenarioPrefix}Beneficiary Type not valid${commonConstants.bddScenarioSuffixTestManually}`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND the [BEN TYPE] is not permitted online
    WHEN [BENEFICIARY MANAGEMENT VIEW] loads
   */

  /*
    Extra JIRA test info:

    #Ben type list of values comes from back-end but should also include ‘Choose one’ as the first item in the list

    Example:
    Member A has a beneficiary recorded against Brother-in-law, however, the permitted online beneficiary types are
    Spouse, Child and Charity.  Here we would show 'Choose one'
   */

  xit('THEN show default ‘Choose one’ in drop down list', () => {
    // test this manually
  });
});

// TODO: code this scenario
describe(`${scenarioPrefix}Field validations`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND data provided does not meet permitted field format
    WHEN [MEMBER] navigates away from a field
   */

  /*
    Extra JIRA test info:

    #see field validations in the attached spreadsheet
    #navigate away includes clicking in another field or using the tab button
   */

  it('THEN display [FIELD VALIDATION MESSAGE]', () => {
    resultMessaging.failStubTest();
  });
});

xdescribe(`${scenarioPrefix}Tab navigation{commonConstants.bddScenarionSuffixTestManually}`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    WHEN [MEMBER] navigates away from a field using the [TAB BUTTON] on their keyboard
   */

  xit('THEN move [MEMBER] to next field/button', () => {
    // test this manually
  });
});

// TODO: code this scenario
describe(`${scenarioPrefix}Confirm button validations`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided does not meet permitted field format
    WHEN [CONFIRM] button selected
   */

  /*
    Extra JIRA test info:

    #see field validations in attached spreadsheet
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN display [FIELD VALIDATION MESSAGE] for all fields which don’t meet the permitted field format', () => {
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await cancelUpdateAndLogOut();
  });
});

describe(`${scenarioPrefix}Confirm button no updates`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND [BENEFICIARY RECORD] has not been updated
    WHEN [CONFIRM] button selected
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN display [NO CHANGES MESSAGE] i.e. You have not made any changes', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);

    await commonTests.clickElement(bmView.confirmButton);
    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(bmView.errorMessageLabel, 'no');
    await checkers.containingTextIgnoreCase(bmView.errorMessageLabel, 'changes');
  });

  afterAll(async () => {
    await cancelUpdateAndLogOut();
  });
});

// *** QA note - will omit - already covered under 'Field validations' and 'Confirm button validations' scenarios ***
xdescribe(`${scenarioPrefix}Address format{commonConstants.bddScenarionSuffixRedundant}`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    WHEN editing address information
   */

  /*
    Extras JIRA test info:

    #to add new address lines users select return key on their device
    #see spreadsheet for all address validations

    Example: Member goes to edit a beneficiary with the address data below.  Here we should show the validation
    message when they navigate away from the address field or select confirm:

    Address line 1
    Address line 2

    Address line 3
   */

  xit('THEN do not permit spaces between address lines', () => {
    // already tested under 'Field validations' and 'Confirm button validations' scenarios
  });

  xit('AND show validation message', () => {
    // already tested under 'Field validations' and 'Confirm button validations' scenarios
  });
});

describe(`${scenarioPrefix}Successfully add`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND update is [ADD]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided meets all field validations
    WHEN [CONFIRM BUTTON] selected
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN close [BENEFICIARY MANAGEMENT VIEW]', async () => {
    const initialNumberOfBeneficiaries = await beneficiariesPage.getNumberOfBeneficiariesStored();

    // TODO: define valid data
    const newNameValue = 'define';
    const newBeneficiaryTypeValue = 'define';
    const newGuardianValue = 'define';
    const newShareOfBenefitValue = 'define';

    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);

    // TODO: save

    // check add view hidden
    expect(bmView.beneficiaryManagementView.isPresent()).toBe(false);
    expect(browser.getCurrentUrl()).toContain(beneficiariesPage.url);

    // check beneficiary added
    const newNumberOfBeneficiaries = await beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries + 1);
    expect(beneficiariesPage.nameValue(newNumberOfBeneficiaries - 1)).toBe(newNameValue);
    expect(beneficiariesPage.beneficiaryTypeValue(newNumberOfBeneficiaries - 1, global.deviceType))
      .toBe(newBeneficiaryTypeValue);
    expect(beneficiariesPage.guardianValue(newNumberOfBeneficiaries - 1, global.deviceType))
      .toBe(newGuardianValue);
    expect(beneficiariesPage.shareOfBenefitValue(newNumberOfBeneficiaries - 1, global.deviceType))
      .toBe(newShareOfBenefitValue);

    // TODO: hover over guardian data for row and check data
  });

  it('AND return Member to [LS SUMMARY VIEW]', () => {
    resultMessaging.passTestWithCustomMessage('Checked in previous THEN');
  });

  it('AND add new [BENEFICIARY RECORD] to end of existing [BENEFICIARY RECORD] list', () => {
    resultMessaging.passTestWithCustomMessage('Checked in previous THEN');
  });

  it('AND highlight added [BENEFICIARY RECORD]', () => {
    // TODO: write code
    resultMessaging.failStubTest();
  });

  it('AND show updated [LS TOTAL BEN SHARE PERC] to 2dp', () => {
    // TODO: write code
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// Added on 11/10/2017 for fulfilling P2 task //

async function getNewNameEditedIfValid(i, finalLastNameValue, finalFirstNameValue, newNameEdited) {
  let newName = newNameEdited;
  const nameEdited = await beneficiariesPage.nameValue(i).getText();

  if (nameEdited === `${finalLastNameValue}, ${finalFirstNameValue}`) {
    newName = nameEdited;
  }

  return newName;
}

async function getNewPercEditedIfValid(i, initialBeneficiaryPert, newPercEdited) {
  let newPerc = newPercEdited;
  const sharePerc = await beneficiariesPage.shareOfBenefitValue(i, global.deviceType).getText();

  if (sharePerc === initialBeneficiaryPert) {
    newPerc = sharePerc;
  }

  return newPerc;
}

describe(`${scenarioPrefix}Successfully edit`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND update is [EDIT]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided meets all field validations
    WHEN [CONFIRM BUTTON] selected
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN close [BENEFICIARY MANAGEMENT VIEW]', async () => {
    const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

    // TODO: define valid edit case test data
    const initialBeneficiaryPert = 'define';
    const finalFirstNameValue = 'define';
    const finalLastNameValue = 'define';
    const finalBeneficiaryPert = 'define';
    let newNameEdited = NaN;
    let newPercEdited = NaN;


    for (let i = 0; i < initialNumberOfBeneficiaries; i += 1) {
      if (beneficiariesPage.actionEdit(i, global.deviceType).isDisplayed()) {
        await commonTests.clickElement(beneficiariesPage.actionEdit(i, global.deviceType));
        break;
      }
    } // editing beneficiary name here

    expect(bmView.beneficiaryManagementView.isDisplayed()).toBe(true);

    if (bmView.beneficiaryManagementView.isDisplayed()) {
      await bmView.beneficiaryManagementView.fullNameValue.clear();
      await bmView.beneficiaryManagementView.shareOfBenefitValue.clear();
      await bmView.beneficiaryManagementView.fullNameValue.sendKeys(finalLastNameValue);
      await bmView.beneficiaryManagementView.shareOfBenefitValue.sendKeys(finalBeneficiaryPert);
      await commonTests.clickElement(bmView.beneficiaryManagementView.confirmButton);
    } else {
      fail('Beneficiary Edit Page did not load');
    }

    // check add view hidden
    expect(bmView.beneficiaryManagementView.isPresent()).toBe(false);

    // check beneficiary name and percentage edited
    for (let i = 0; i < initialNumberOfBeneficiaries; i += 1) {
      newNameEdited = await getNewNameEditedIfValid(i, finalLastNameValue, finalFirstNameValue, newNameEdited);
      newPercEdited = await getNewPercEditedIfValid(i, initialBeneficiaryPert, newPercEdited);
    }

    await checkers.exactText(newPercEdited, finalBeneficiaryPert);
    await checkers.exactText(newNameEdited, `${finalLastNameValue}, ${finalFirstNameValue}`);
    await checkers.anyNumberToSpecifiedDp(beneficiariesPage.beneficiariesTotalSharePerc, 2);
  });


  it('AND return Member to [LS SUMMARY VIEW]', () => {
    // TODO: check this would work - prob need to check for non-display of edit page
    expect(browser.getCurrentUrl()).toContain(beneficiariesPage.url);
  });

  it('AND keep edited [BENEFICIARY RECORD] in same order in list as prior to edit', () => {
    resultMessaging.passTestWithCustomMessage('Layout related test');
  });

  it('AND highlight edited [BENEFICIARY RECORD]', () => {
    resultMessaging.failStubTest();
  });

  it('AND show updated [LS TOTAL BEN SHARE PERC] to 2dp', () => {
    resultMessaging.passTestWithCustomMessage('Done Above');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Delete Beneficiary Record`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [NOMS READ ONLY] is [DISABLED]
    AND view is [LS SUMMARY VIEW]
    WHEN [DELETE BUTTON] selected
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN show [LS DELETE MESSAGE]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    expect(beneficiariesPage.deleteBeneficiaryPopup.isDisplayed()).toBe(true);
  });

  it('AND show [LS DELETE MESSAGE TITLE]', async () => {
    await checkers.exactText(beneficiariesPage.deleteBenPopupTitle, 'Are you Sure?');
  });

  it('AND show [LS DELETE MESSAGE TEXT]', async () => {
    await checkers.exactText(beneficiariesPage.deleteBenPopupMessage,
      'Are you sure you want to delete this beneficiary?');
  });

  it('AND show [DELETE YES BUTTON]', async () => {
    await checkers.exactText(beneficiariesPage.deleteYesButton, 'Yes');
  });

  it('AND show [DELETE NO BUTTON]', async () => {
    await checkers.exactText(beneficiariesPage.deleteNoButton, 'No');

    // TODO: add click of 'No' and check delete abandoned
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Delete confirmed`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [LS DELETE MESSAGE] is displayed
    WHEN Member selects [DELETE YES BUTTON]
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN return Member to [LS SUMMARY VIEW] AND delete [BENEFICIARY RECORD]', async () => {
    await checkers.exactText(beneficiariesPage.nameValue(0), 'Name of First Beneficiary');
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    expect(beneficiariesPage.deleteBeneficiaryPopup.isDisplayed()).toBe(true);
    expect(beneficiariesPage.deleteYesButton.isDisplayed()).toBe(true);
    await commonTests.clickElement(beneficiariesPage.deleteYesButton);
    expect(browser.getCurrentUrl()).toBe(beneficiariesPage.url);
    expect(beneficiariesPage.nameValue(0).isPresent()).toBe(false); // check if the record has been deleted
  });

  it('AND show updated [LS TOTAL BEN SHARE PERC] to 2dp', async () => {
    await checkers.anyNumberToSpecifiedDp(beneficiariesPage.beneficiariesTotalSharePerc, 2);
  });

  it('AND update [SUBMIT BUTTON] to [ACTIVE STATE]', () => {
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// test manually
xdescribe(`${scenarioPrefix}All Beneficiary Records Deleted`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    WHEN all [BENEFICIARY RECORDS] deleted
   */

  xit('THEN show updated [LS TOTAL BEN SHARE PERC] as zero to 2dp', () => {
    // test manually
  });
});

describe(`${scenarioPrefix}Delete cancelled`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [LS DELETE MESSAGE] is displayed
    WHEN Member selects [DELETE NO BUTTON]
   */

  const participant = standardParticipant;
  let sharePerc = NaN;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN return Member to [LS SUMMARY VIEW]', async () => {
    const text = await beneficiariesPage.beneficiariesTotalSharePerc.getText();
    sharePerc = text;

    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    expect(beneficiariesPage.deleteNoButton.isDisplayed()).toBe(true);

    await commonTests.clickElement(beneficiariesPage.deleteNoButton);
    expect(beneficiariesPage.deleteBeneficiaryPopup.isDisplayed()).toBe(false);
    expect(browser.getCurrentUrl()).toBe(beneficiariesPage.url);
  });

  it('AND ignore delete request', async () => {
    const perc = await beneficiariesPage.beneficiariesTotalSharePerc.getText();
    expect(perc).toBe(sharePerc);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

function checkPercentageMessage(scenarioParticipant) {
  describe(`${scenarioPrefix}Total benefit percentage`, () => {
    /*
      GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
      AND [LUMP SUM AVAIL] is [ENABLED]
      AND [BENEFICIARY DATA] is recorded for [MAIN POS]
      WHEN [LUMP SUM FEATURE] loads
     */

    /*
      Extra JIRA test info:

      Example:
      |TOTAL BEN SHARE PERC   |DISPLAY LS TOTAL WARNING
      |=100.00%               |HIDE                                                     |
      |</>100.00%             |SHOW
     */

    beforeAll(async () => {
      await login(scenarioParticipant);
    });

    it('THEN [DISPLAY LS TOTAL WARNING] based on [TOTAL BEN SHARE PERC]', async () => {
      const perc = await beneficiariesPage.beneficiariesTotalSharePerc.getText();

      if (perc === '100.00%') {
        expect(beneficiariesPage.beneficiariesMessage.isPresent()).toBe(false);
      } else {
        await checkers.containingTextIgnoreCase(
          beneficiariesPage.beneficiariesMessage, 'Total must equal 100.00%');
      }
    });

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

// TODO: add participant?
checkPercentageMessage(standardParticipant); // for 100pc case
// checkPercentageMessage(standardParticipant); // for <>100pc case

// TODO: parameterise to check both options?
describe(`${scenarioPrefix}Submit Button`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    AND updates to [BENEFICIARY RECORDS] have been made
    AND [TOTAL BEN SHARE PERC] equals 100.00%
    WHEN [LS SUMMARY VIEW] loads
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN show [SUBMIT BUTTON] in [ACTIVE STATE]', async () => {
    // TODO: add the data update - or do as aprt of other scenario?
    const perc = await beneficiariesPage.beneficiariesTotalSharePerc.getText();

    if (perc === '100.00%') {
      expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    } else {
      expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(false);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// TODO: data drive? do manually?
describe(`${scenarioPrefix}Submit Beneficiary Record Updates`, () => { // need discussion with BA
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    AND [BENEFICIARY RECORDS] have been updated
    AND [SUBMIT BUTTON] is in [ACTIVE STATE]
    WHEN [SUBMIT BUTTON] is selected
   */

  /*
    Extra JIRA test info:

    Examples:
    |MAIN POS |LINKED |ELIGIBLE |SAME SCHEME  |SAME CLIENT  |WRITEBACK
    |UPDATE   |YES    |YES      |YES          |YES          |UPDATE
    |UPDATE   |YES    |YES      |NO           |YES          |UPDATE
    |UPDATE   |YES    |NO       |YES          |YES          |NO UPDATE
    |UPDATE   |NO     |YES      |YES          |YES          |NO UPDATE
    |UPDATE   |NO     |NO       |YES          |YES          |NO UPDATE

    #write-back MIDAS updates should include full audit trail
    #Example of the audit e-mail sent is attached
    #Where Beneficiary record has Guardian details stored but Guardian is disabled, then Guardian details will
    be removed as per OV 2.0 processing.
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN show [LS CONFIRMATION MESSAGE]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(beneficiariesPage.beneficiaryManagementView.isDisplayed()).toBe(true);
    await beneficiariesPage.beneficiaryManagementView.fullNameValue.clear();
    await beneficiariesPage.beneficiaryManagementView.fullNameValue.sendKeys('QATest');
    await commonTests.clickElement(beneficiariesPage.beneficiaryManagementView.confirmButton);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    await commonTests.clickElement(beneficiariesPage.beneficiariesSaveButton(global.deviceType));
    // TODO: add confirm tests
  });

  it('AND write-back all [BENEFICIARY RECORD UPDATES] to all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT]', () => {
    resultMessaging.failStubTest();
  });

  it('AND update [LS VERIFIED DATE] for all [LINKED] [ELIGIBLE] records for that [MEMBER] and that [CLIENT]', () => {
    resultMessaging.failStubTest();
  });

  it('AND update [NOMINATIONS FLAG] as ‘Y’ on [BASIC DETAILS RECORD] for all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT]', () => {
    resultMessaging.failStubTest();
  });

  it('AND update [NOM COMPLETED DATE] on [BASIC DETAILS RECORD] for all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT]', () => {
    resultMessaging.failStubTest();
  });

  it('AND add updates for inclusion in [AUDIT E-MAIL]', () => {
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// TODO: test manually?
xdescribe(`${scenarioPrefix}All Beneficiaries Deleted Confirmed`, () => { // need discussion with BA
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND all [BENEFICIARY RECORDS] deleted
    WHEN write-back all [BENEFICIARY RECORD UPDATES] to all [LINKED] [ELIGIBLE] records for that [MEMBER]
    and that [CLIENT] actioned
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN update [NOMINATIONS FLAG] as ‘N’ on [BASIC DETAILS RECORD] for all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT]', async () => {
    const benCount = await beneficiariesPage.getNumberOfBeneficiariesStored();

    for (let i = 0; i <= benCount; i += 1) {
      if (beneficiariesPage.actionDelete(i, global.deviceType).isDisplayed()) {
        await commonTests.clickElement(beneficiariesPage.actionDelete(i, global.deviceType));

        if (beneficiariesPage.deleteBeneficiaryPopup.isDisplayed()) {
          await commonTests.clickElement(beneficiariesPage.deleteYesButton);
        }
      }
    }
    expect(beneficiariesPage.deleteBeneficiaryPopup.isDisplayed()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// TODO: turn into function and data drive
describe(`${scenarioPrefix}Lose changes`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    WHEN Member attempts to navigate away from current view
   */

  /*
    Extra JIRA test info:

    |VIEW                         |BENEFICIARY RECORDS UPDATED  |ACTION         |DISPLAY CANCEL WARNING MESSAGE
    |SUMMARY VIEW                 |YES                          |SELECT CANCEL  |YES
    |SUMMARY VIEW                 |NO                           |SELECT CANCEL  |NO
    |SUMMARY VIEW                 |YES                          |SELECT BACK    |YES
    |SUMMARY VIEW                 |NO                           |SELECT BACK    |NO
    |SUMMARY VIEW                 |YES                          |NAVIGATE AWAY  |YES
    |SUMMARY VIEW                 |NO                           |NAVIGATE AWAY  |NO
    |BENEFICIARY MANAGEMENT VIEW  |YES                          |SELECT CANCEL  |YES
    |BENEFICIARY MANAGEMENT VIEW  |NO                           |SELECT CANCEL  |NO

    #Beneficiary updates cover add, edit and delete
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN [DISPLAY LOSE CHANGES WARNING MESSAGE] based on [VIEW], [ACTION], [BENEFICIARY RECORDS UPDATED]',
    async () => {
      await commonTests.clickElement(beneficiariesPage.beneficiariesTab);
      await updateName(); // shows a edit
      await commonTests.clickElement(beneficiariesPage.beneficiaryCancelButton);
      expect(beneficiariesPage.beneficiaryLoseChanges.isDisplayed()).toBe(true);
    });

  it('AND show [LOSE CHANGES WARNING TITLE]', async () => {
    await checkers.exactText(beneficiariesPage.beneficiaryLoseTitle, 'Are you Sure?');
  });

  it('AND show [LOSE CHANGES WARNING TEXT]', async () => {
    await checkers.exactText(beneficiariesPage.beneficiaryLoseText,
      'Are you sure you want to lose these changes?');
  });

  it(' AND show [LOSE CHANGES YES BUTTON]', async () => {
    await checkers.exactText(beneficiariesPage.beneficiaryLoseYes, 'Yes');
  });

  it('AND show [LOSE CHANGES NO BUTTON]', async () => {
    await checkers.exactText(beneficiariesPage.beneficiaryLoseNo, 'No');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


// TODO: bearing in mind comment below why is there code here?
// remaining scenarios to be done manually

// TODO: amalgamate 'Lose changes action' and 'Lose changes' scenarios for QA testing - more efficient
describe(`${scenarioPrefix}Lose changes action`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND [LOSE CHANGES WARNING MESSAGE] is displayed
    WHEN Member selects [LOSE CHANGE BUTTON]
   */

  /*
    Extra JIRA test info:

    Example:
    |VIEW                         |BUTTON SELECTED  |RETURN USER ACTION                         |RETAIN CHANGES
    |SUMMARY VIEW                 |LOSE CHANGES YES |RETURN USER TO PREVIOUS PAGE               |NO
    |SUMMARY VIEW                 |LOSE CHANGES NO  |RETURN USER TO SUMMARY VIEW                |YES
    |BENEFICIARY MANAGEMENT VIEW  |LOSE CHANGES YES |RETURN USER TO SUMMARY VIEW                |NO
    |BENEFICIARY MANAGEMENT VIEW  |LOSE CHANGE NO   |RETURN USER TO BENEFICIARY MANAGEMENT VIEW |YES

    #previous page is the page the Member was viewing prior to navigating to the Beneficiaries page
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN based on [LOSE CHANGE BUTTON] selected, [RETURN USER ACTION]', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiariesTab);
    await updateName(); // shows a edit
    await commonTests.clickElement(beneficiariesPage.beneficiaryCancelButton);
    expect(beneficiariesPage.beneficiaryLoseChanges.isDisplayed()).toBe(true);
    await checkers.exactText(beneficiariesPage.beneficiaryLoseYes, 'Yes');
    await commonTests.clickElement(beneficiariesPage.beneficiaryLoseYes);
    expect(browser.getCurrentUrl()).toBe(beneficiariesPage.url);
  });

  it('AND [RETAIN CHANGES]', async () => {
    await checkers.exactText(beneficiariesPage.nameValue(0),
      `${beneficiariesPage.beneficiaryManagementView.fullNameValue}`);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// *** QA note - will manually test - Midas record will need to be locked for test so
// difficult to repeat for test automation ***
xdescribe(`${scenarioPrefix}Error handling`, () => { // need discussion with BA
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    AND [BENEFICIARY RECORDS] have been updated
    AND [SUBMIT BUTTON] is in [ACTIVE STATE]
    AND the [BENEFICIARY RECORD] is [LOCKED]
    WHEN [SUBMIT BUTTON] selected
   */

  /*
    Extra JIRA test info:

    #locked examples include unauthorised beneficiary records or a System Administrator being in the record
    at the time the Member attempts to update it.  NEED DAVE/LOUISE TO PROVIDE OTHER EXAMPLES BASED ON
    EXISTING BEHAVIOUR
   */

  xit('THEN show [BENEFICIARY RECORD LOCKED MESSAGE]', () => {
  });
});

// TODO: add missing scenario
describe(`${scenarioPrefix}Return key summary view`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [LS SUMMARY VIEW]
    WHEN [RETURN KEY] is selected
   */

  /*
    Extra JIRA test info:

    Examples:
    |SUBMIT BUTTON VISIBILITY |SUBMIT BUTTON STATE  |CAPTURE CONFIRM BUTTON VIS.  |ADD BUTTON VIS.  |SELECT BUTTON
    |SHOW                     |ACTIVE               |N/A                          |SHOW             |SUBMIT
    |SHOW                     |DISABLED             |N/A                          |SHOW             |ADD
    |HIDE                     |N/A                  |SHOW                         |SHOW             |CAPTURE CONFIRM
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN [SELECT BUTTON] based on [SUBMIT BUTTON VISIBILITY], [SUBMIT BUTTON STATE],'
    + ' [CAPTURE CONFIRM BUTTON VISIBILITY], [ADD BUTTON VISIBILITY]', () => {
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Return key Beneficiary Management view`, () => {
  /*
    GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
    AND [LUMP SUM AVAIL] is [ENABLED]
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND current field is not [ADDRESS]
    AND current field is not [GUARD ADDRESS]
    WHEN [RETURN KEY] is selected
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await login(participant);
  });

  it('THEN select [CONFIRM BUTTON]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(beneficiariesPage.beneficiaryManagementView.isDisplayed()).toBe(true);
    await browser.actions().sendKeys(protractor.Key.ENTER).perform();
    expect(beneficiariesPage.beneficiaryManagementView.confirmButton.isSelected()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});
