// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const beneficiariesTests = new BeneficiariesTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dcPlanSummaryPage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);
const beneficiariesPage = new BeneficiariesPage('lumpSum');

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-1038 (inc. OUK-5873)${commonConstants.bddScenarioPrefix}`;

async function login(summaryType) {
  switch (summaryType) {
    case 'DC':
      await beneficiariesTests.browseToBeneficiariesPageViaDcPlanSummaryPage(
        loginPage, dashboardPage, dcPlanSummaryPage, beneficiariesPage, standardParticipant, 0);
      break;
    case 'DB':
      await beneficiariesTests.browseToBeneficiariesPageViaDbPlanSummaryPage(
        loginPage, dashboardPage, dbPlanSummaryPage, beneficiariesPage, standardParticipant, 0);
      break;
    default:
      throw new Error(`The summaryType [${summaryType}] is not supported`);
  }

  const present = await browser.isElementPresent(beneficiariesPage.dependantsTab);

  if (present) {
    // note lump sum tab is not clickable if only lump sum tab present
    // and if is present we have to check for presence of lump sum tab too otherwise click can fail
    const present2 = await browser.isElementPresent(beneficiariesPage.lumpSumTab);

    if (present2) {
      await commonTests.clickElement(beneficiariesPage.lumpSumTab);
    }
  }
}

async function checkBeneficiaryDataRow(index) {
  await checkers.anyText(beneficiariesPage.nameValue(index));
  await checkers.anyText(beneficiariesPage.addressValue(index));
  await checkers.anyText(beneficiariesPage.beneficiaryTypeValue(index, global.deviceType));
  await checkers.anyPercent(beneficiariesPage.shareOfBenefitValue(index, global.deviceType));
  await checkers.anyText(beneficiariesPage.guardianValue(index, global.deviceType));
  await checkers.containingImage(beneficiariesPage.actionEdit(index, global.deviceType),
    commonConstants.actionEditImageSource);
  await checkers.containingImage(beneficiariesPage.actionDelete(index, global.deviceType),
    commonConstants.actionDeleteImageSource);
}

function runPrePopulatedDataCancelLinkAndBackLinkScenarios(summaryType, returnPage) {
  describe(`${scenarioPrefix}Pre-populated data + Cancel link + Back link (${summaryType})`, () => {
    /*
      Common
      ----------------------------------------------------------
      GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
      AND [LUMP SUM AVAIL] is [ENABLED]

      Pre-populated data
      ----------------------------------------------------------
      AND [BENEFICIARY DATA] is recorded for [MAIN POS]
      WHEN [LS SUMMARY VIEW] loads

      Cancel link
      ----------------------------------------------------------
      AND no changes have been made

      Back link
      ----------------------------------------------------------
      AND no changes have been made
      WHEN the back link is selected
     */

    /*
      Extra JIRA test info:
      #where data is missing, display a dash i.e. ‘-‘
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${summaryType}`);
      await login(summaryType);
    });

    it('Pre-populated data: THEN show [BENEFICIARY DATA] for [MAIN POS]', async () => {
      // have added until.visibilityOf on nameLabel to try and eliminate Jenkins-only 'stale element reference' error
      await browser.wait(
        until.visibilityOf(beneficiariesPage.nameLabel),
        commonConstants.briefBrowserWaitDelay,
        `Name label on beneficiaries page not shown within ${commonConstants.briefBrowserWaitDelay}ms`);

      // check every header and first, mid and last data rows
      await checkers.containingTextIgnoreCase(beneficiariesPage.nameLabel, 'Name');
      await checkers.containingImage(beneficiariesPage.nameSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.addressLabel, 'Address');
      await checkers.containingImage(beneficiariesPage.addressSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.beneficiaryTypeLabel, 'Beneficiary Type');
      await checkers.containingImage(beneficiariesPage.beneficiaryTypeSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.shareOfBenefitLabel, 'Share');
      await checkers.containingImage(beneficiariesPage.shareOfBenefitSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.guardianLabel, 'Guardian');
      await checkers.containingImage(beneficiariesPage.guardianSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.actionLabel, 'Action');

      const beneficiaryCount = await beneficiariesPage.getNumberOfBeneficiariesStored();

      if (beneficiaryCount === 1) {
        await checkBeneficiaryDataRow(0);
      } else if (beneficiaryCount === 2) {
        await checkBeneficiaryDataRow(0);
        await checkBeneficiaryDataRow(1);
      } else if (beneficiaryCount > 2) {
        // check first, mid and last data rows
        await checkBeneficiaryDataRow(0);
        await checkBeneficiaryDataRow(Math.round(beneficiaryCount / 2));
        await checkBeneficiaryDataRow(beneficiaryCount - 1);
      } else {
        fail('No beneficiaries listed');
      }
    });

    beneficiariesTests.checkCancelAndBackLinks(beneficiariesPage, summaryType, returnPage);

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runPrePopulatedDataCancelLinkAndBackLinkScenarios('DC', dcPlanSummaryPage);
runPrePopulatedDataCancelLinkAndBackLinkScenarios('DB', dbPlanSummaryPage);

function runDobAddressGuardianAndDisclaimerScenario(summaryType) {
  describe(`${scenarioPrefix}DOB visibility + Address Details hover view`
    + ' + Guardian Details hover view + Disclaimer view'
    + ` Print and Download buttons visibility (OUK-5873) + Last date updated (OUK-5873) - (${summaryType})`, () => {
    /*
      common
      ----------------------------------------------------------
      GIVEN the [MEMBER] is viewing the [BENEFICIARIES] page
      AND [LUMP SUM AVAIL] is [ENABLED]

      DOB visibility
      ----------------------------------------------------------
      AND one or multiple [BENEFICAIARIES] are showing
      WHEN the [MEMBER] hovers over the [BENEFICIARY NAME]

      Address Details hover view
      ----------------------------------------------------------
      WHEN [MEMBER] hovers over [ADDRESS STATUS]

      Guardian Details hover view
      ----------------------------------------------------------
      AND [NOM GUARDIAN AVAIL]
      WHEN [PARTICIPANT] hovers over [GUARDIAN STATUS]

      Disclaimer view
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads

      Print and Download buttons visibility (OUK-5873)
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads

      Last date updated label and value visibility (OUK-5873)
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads
     */

    /*
      Extra JIRA test info:
      #on separate lines (maximum of 5 data lines displayed)
      #standard tooltip for showing address

      Example:
      |ADDRESS STATUS | DISPLAY ADDRESS DATA
      |Y              |SHOW
      |N              |HIDE
     */

    /*
      Extra JIRA info:
      #standard tooltip for showing Guardian details

      Example:
      |GUARDIAN STATUS |DISPLAY GUARD NAME |GUARD ADDRESS RECORDED |DISPLAY GUARD ADDRESS
      |Y               |SHOW               |RECORDED               |SHOW
      |Y               |SHOW               |NULL                   |HIDE
      |N               |HIDE               |N/A                    |HIDE
     */

    beforeAll(async () => {
      await login(summaryType);
    });

    beneficiariesTests.checkTooltipsAndDisclaimer(beneficiariesPage);
    beneficiariesTests.checkPrintAndDownloadButtons(beneficiariesPage);
    beneficiariesTests.checkLastDateUpdated(beneficiariesPage);

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runDobAddressGuardianAndDisclaimerScenario('DC');
runDobAddressGuardianAndDisclaimerScenario('DB');
