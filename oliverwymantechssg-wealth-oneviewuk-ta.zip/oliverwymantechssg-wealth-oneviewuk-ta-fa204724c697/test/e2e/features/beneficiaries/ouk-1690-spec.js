// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const Participant001 = require('../../data/participants/ov1-p001-dc-db-pensioner');
const Participant002 = require('../../data/participants/participant-ouk-100-002-2-db');
const Participant003 = require('../../data/participants/participant-ouk-100-003-2-dc'); // For WHI Guardian is Disabled

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant001 = new Participant001();
const participant002 = new Participant002();
const participant003 = new Participant003();
const beneficiariesTests = new BeneficiariesTests();
const newAddressValue1 = 'Test1\nTest2\n\nTest4';
const newAddressValue2 = 'Test1\nTest2\nTest3\nTest4';

// tests
const scenarioPrefix = `OUK-1690${commonConstants.bddScenarioPrefix}`;

async function login(loginPage, dashboardPage, beneficiariesPage, participant) {
  await beneficiariesTests.browseToBeneficiariesPageFromLogin(
    loginPage, dashboardPage, beneficiariesPage, participant);

  const present = await browser.isElementPresent(beneficiariesPage.lumpSumTab);

  if (present) {
    // note dependants tab is not clickable if only dependants tab present
    // and if is present we have to check for presence of dependants tab too otherwise click can fail
    const present2 = await browser.isElementPresent(beneficiariesPage.dependantsTab);

    if (present2) {
      await commonTests.clickElement(beneficiariesPage.dependantsTab);
    }
  }
}

describe(`${scenarioPrefix}Add Beneficiary`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [NOMS READ ONLY] is [DISABLED]
    AND [DEP GUARDIAN AVAIL] is [ENABLED]
    AND view is [DEPS SUMMARY VIEW]
    WHEN the [ADD BUTTON] is selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN open [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
  });

  it('AND show [ADD TITLE] i.e. Add Beneficiary', async () => {
    await checkers.exactText(managementView.viewHeading, 'Add Beneficiary');
  });

  it('AND show [REQUIRED FILED] wording i.e. *Required', async () => {
    await checkers.exactText(managementView.requiredFieldLabel, '*Required');
  });

  it('AND show [NAME] as blank', async () => {
    await checkers.exactText(managementView.fullNameLabel, 'Name *');
    await checkers.noText(managementView.fullNameValue);
  });

  it('AND show [ADDRESS] as blank', async () => {
    await checkers.exactText(managementView.addressLabel, 'Address *');
    await checkers.noText(managementView.addressValue);
    await checkers.noText(managementView.postCodeLabel);
  });

  it('AND show [DOB] as blank', async () => {
    await checkers.exactText(managementView.dateOfBirthLabel, 'Date of Birth');
    await checkers.noText(managementView.dateOfBirthValue);
  });

  it('AND show [BEN TYPE] as [Choose One]', async () => {
    await checkers.exactText(managementView.beneficiaryTypeLabel, 'Choose Beneficiary Type *');
    await checkers.exactText(managementView.beneficiaryTypeValue, 'Choose One');
  });

  it('AND show [GUARD NAME] as blank', async () => {
    await checkers.exactText(managementView.guardianFullNameLabel, 'Guardian Name *');
    await checkers.noText(managementView.guardianFullNameValue);
  });

  it('AND show [GUARD ADDRESS] as blank', async () => {
    await checkers.exactText(managementView.guardianAddressLabel, 'Guardian Address *');
    await checkers.noText(managementView.guardianAddressValue);
    await checkers.noText(managementView.guardianPostCodeValue);
  });

  it('AND show [LS FOOTER WARNING MESSAGE] i.e. Selecting confirm will update this information,'
    + 'once confirmed you still need to save all of your changes.', async () => {
    expect(managementView.warningIcon.isDisplayed()).toBe(true);
    await checkers.exactText(managementView.warningLabel,
      'Selecting confirm will update this information,'
      + ' once confirmed you still need to save all of your changes.');
  });

  it('AND show [CANCEL] in [ACTIVE] state', () => {
    expect(managementView.cancelButton.isDisplayed()).toBe(true);
    expect(managementView.cancelButton.isEnabled()).toBe(true);
  });

  it('AND show [CONFIRM BUTTON] in [ACTIVE] state', () => {
    expect(managementView.confirmButton.isDisplayed()).toBe(true);
    expect(managementView.confirmButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit Beneficiary`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [NOMS READ ONLY] is [DISABLED]
    AND [DEP GUARDIAN AVAIL] is [ENABLED]
    AND view is [DEPS SUMMARY VIEW]
    WHEN [EDIT BUTTON] is selected
   */

  const participant = participant002;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN open [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
  });

  it('AND show [EDIT TITLE] i.e. Edit Beneficiary', async () => {
    await checkers.exactText(managementView.viewHeading, 'Edit Beneficiary');
  });

  it('AND show [REQUIRED FILED] wording i.e. *Required ', async () => {
    await checkers.exactText(managementView.requiredFieldLabel, '*Required');
  });

  it('AND show [NAME] as recorded for beneficiary', async () => {
    await checkers.exactText(managementView.fullNameLabel, 'Name *');
    await checkers.exactText(managementView.fullNameValue, 'TESTER');
  });

  it('AND show [ADDRESS DATA] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.addressLabel, 'Address *');
    await checkers.exactText(managementView.addressValue, 'TEST 1'
      + 'TEST 2'
      + 'TEST 3'
      + 'TEST 4');
    await checkers.exactText(managementView.postCodeLabel, 'TEST 5');
  });

  it('AND show [BEN TYPE DATA] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.beneficiaryTypeLabel, 'Choose Beneficiary Type *');
    await checkers.exactText(managementView.beneficiaryTypeValue, 'D');
  });

  it('AND show [GUARDIAN DATA] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.guardianFullNameLabel, 'Guardian Name *');
    await checkers.exactText(managementView.guardianFullNameValue, 'ATESTER');
  });

  it('AND show [BEN SHARE PERC] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.shareOfBenefitLabel, 'Share of Benefit % *');
    await checkers.noText(managementView.shareOfBenefitValue);
  });

  it('AND show [GUARD NAME] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.guardianFullNameLabel, 'Guardian Name *');
    await checkers.exactText(managementView.guardianFullNameValue, 'ATESTER');
  });

  it('AND show [GUARD ADDRESS] as recorded for beneficiary ', async () => {
    await checkers.exactText(managementView.guardianAddressLabel, 'Guardian Address *');
    await checkers.exactText(managementView.guardianAddressValue, 'TEST 11'
      + 'TEST 22'
      + 'TEST 33'
      + 'TEST 44');
    await checkers.exactText(managementView.guardianPostCodeValue, 'TEST 55');
  });

  it('AND show [LS FOOTER WARNING MESSAGE] i.e. Selecting confirm will update this information, once confirmed'
    + ' you still need to save all of your changes. ', async () => {
    expect(managementView.warningIcon.isDisplayed()).toBe(true);
    await checkers.exactText(managementView.warningLabel,
      'Selecting confirm will update this information,'
      + ' once confirmed you still need to save all of your changes.');
  });

  it('AND show [CANCEL] in [ACTIVE] state', () => {
    expect(managementView.cancelButton.isDisplayed()).toBe(true);
    expect(managementView.cancelButton.isEnabled()).toBe(true);
  });

  it('AND show [CONFIRM BUTTON] in [ACTIVE] state', () => {
    expect(managementView.confirmButton.isDisplayed()).toBe(true);
    expect(managementView.confirmButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Guardian disabled`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [DEP GUARDIAN AVAIL] is [DISABLED]
    WHEN [BENEFICIARY MANAGEMENT VIEW] loads
   */

  const participant = participant003;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN hide [GUARD NAME]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.guardianFullNameLabel.isDisplayed()).toEqual(false);
  });

  it('AND hide [GUARD ADDRESS]', () => {
    expect(managementView.guardianAddressLabel.isDisplayed()).toEqual(false);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// test manually
xdescribe(`${scenarioPrefix}Beneficiary Type not valid`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND the [BEN TYPE] is not permitted online
    WHEN [BENEFICIARY MANAGEMENT VIEW] loads
   */
});


describe(`${scenarioPrefix}Field validations`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND data provided does not meet permitted field format
    WHEN [PARTICIPANT] navigates away from a field
   */

  // Note - #navigate away includes clicking in another field or using the tab button

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN display [FIELD VALIDATION MESSAGE]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);

    await managementView.fullNameValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'Name is required');
    await managementView.fullNameValue.sendKeys('Test');

    await managementView.addressValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    expect(managementView.warningLabel, 'Address is required');
    await managementView.addressValue.sendKeys(newAddressValue1);
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'A blank line is not permitted in middle of Address');
    await managementView.addressValue.sendKeys(newAddressValue2);

    await managementView.dateOfBirthValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel,
      'Format must be DD/MM/YYYY and cannot be in the future');
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');

    await managementView.beneficiaryTypeValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'Please select a Beneficiary Type');
    await managementView.beneficiaryTypeValue.sendKeys('Spouse');

    await managementView.guardianFullNameValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'Name is required');
    await managementView.guardianFullNameValue.sendKeys('Test');

    await managementView.guardianAddressValue.clear();
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'Address is required');
    await managementView.guardianAddressValue.sendKeys('Test');

    await managementView.guardianAddressValue.sendKeys(newAddressValue1);
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
    await checkers.exactText(managementView.warningLabel, 'A blank line is not permitted in middle of Address');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// test manually
xdescribe(`${scenarioPrefix}Tab navigation`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    WHEN [PARTICIPANT] navigates away from a field using the [TAB BUTTON] on their keyboard
   */
});


describe(`${scenarioPrefix}Confirm button validations`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided does not meet permitted field format
    WHEN [CONFIRM] button selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN display [FIELD VALIDATION MESSAGE] for all fields which don’t meet the permitted field format ',
    async () => {
      await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
      expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
      await managementView.fullNameValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel, 'Name is required');
      await managementView.fullNameValue.sendKeys('Test');
      await managementView.addressValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel, 'Address is required');
      await managementView.addressValue.sendKeys('Test');
      await managementView.addressValue.sendKeys(newAddressValue1);
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel,
        'A blank line is not permitted in middle of Address');
      await managementView.addressValue.sendKeys('newAddressValue2');
      await managementView.dateOfBirthValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel,
        'Format must be DD/MM/YYYY and cannot be in the future');
      await managementView.dateOfBirthValue.sendKeys('01/01/1990');
      await managementView.beneficiaryTypeValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel, 'Please select a Beneficiary Type');
      await managementView.beneficiaryTypeValue.sendKeys('Spouse');
      await managementView.guardianFullNameValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel, 'Name is required');
      await managementView.guardianFullNameValue.sendKeys('Test');
      await managementView.guardianAddressValue.clear();
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel, 'Address is required');
      await managementView.guardianAddressValue.sendKeys('Test');
      await managementView.guardianAddressValue.sendKeys(newAddressValue1);
      await commonTests.clickElement(managementView.confirmButton);
      await checkers.exactText(managementView.warningLabel,
        'A blank line is not permitted in middle of Address');
    });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Confirm button no updates`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND [BENEFICIARY RECORD] has not been updated
    WHEN [CONFIRM] button selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN display [NO CHANGES MESSAGE] i.e. You have not made any changes.', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await commonTests.clickElement(managementView.confirmButton);
    await checkers.exactText(beneficiariesPage.beneficiariesMessageLabel, 'You have not made any changes.');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Address format`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    WHEN editing address information
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN do not permit spaces between address lines', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.addressValue.sendKeys(newAddressValue1);
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
  });

  it('AND show validation message', async () => {
    await checkers.exactText(managementView.warningLabel, 'A blank line is not permitted in middle of Address');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Successfully add`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND update is [ADD]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided meets all field validations
    WHEN [CONFIRM BUTTON] selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

  it('THEN close [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);
    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
  });

  it('AND return [PARTICIPANT] to [DEPS SUMMARY VIEW]', () => {
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
  });

  it('AND add new [BENEFICIARY RECORD] to end of existing [BENEFICIARY RECORD] list', async () => {
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries + 1);
    beneficiariesPage.nameValue(newNumberOfBeneficiaries);
    await checkers.exactText(beneficiariesPage.nameValue(newNumberOfBeneficiaries), 'Test,Tester');
  });

  // test manually
  xit('AND highlight added [BENEFICIARY RECORD]', () => {
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Successfully edit`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND update is [EDIT]
    AND [BENEFICIARY RECORD] has been updated
    AND data provided meets all field validations
    WHEN [CONFIRM BUTTON] selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

  it('THEN close [BENEFICIARY MANAGEMENT VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);
    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
  });

  it('AND return [PARTICIPANT] to [DEPS SUMMARY VIEW]', () => {
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
  });

  it('AND keep edited [BENEFICIARY RECORD] in same order in list as prior to edit', async () => {
    await checkers.exactText(beneficiariesPage.nameValue(0), 'Test,Tester');
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries + 1);
  });

  // test manually
  xit('AND highlight edited [BENEFICIARY RECORD]', () => {
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Delete Beneficiary Record`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [NOMS READ ONLY] is [DISABLED]
    AND view is [DEPS SUMMARY VIEW]
    WHEN [DELETE BUTTON] selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN show [DEPS DELETE MESSAGE]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    expect(beneficiariesPage.areYouSurePopup.isDisplayed()).toBe(true);
  });

  it('AND show [DEPS DELETE MESSAGE TITLE] i.e. \'Are you Sure?\'', () => {
    expect(beneficiariesPage.confirmBeneficiaryDeleteHeading.isDisplayed()).toBe(true);
  });

  it('AND show [DEPS DELETE MESSAGE TEXT] i.e. Are you sure you want to delete this beneficiary?', async () => {
    await checkers.exactText(beneficiariesPage.confirmBeneficiaryDeleteHeadingText,
      'Are you sure you want to delete this beneficiary?');
  });

  it('AND show [DELETE YES BUTTON]', () => {
    expect(beneficiariesPage.deleteBeneficiaryButton.isDisplayed()).toBe(true);
  });

  it('AND show [DELETE NO BUTTON]', () => {
    expect(beneficiariesPage.cancelButton.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Delete confirmed`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [DEPS DELETE MESSAGE] is displayed
    WHEN [PARTICIPANT] selects [DELETE YES BUTTON]
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

  it('THEN return [PARTICIPANT] to [DEPS SUMMARY VIEW] AND delete [BENEFICIARY RECORD]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    await commonTests.clickElement(beneficiariesPage.deleteBeneficiaryButton);
    expect(beneficiariesPage.beneficiariesTable.isDisplayed()).toBe(true);
  });

  it('AND update [SUBMIT BUTTON] to [ACTIVE STATE]', () => {
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries - 1);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Delete cancelled`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [DEPS DELETE MESSAGE] is displayed
    WHEN [PARTICIPANT] selects [DELETE NO BUTTON]
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

  it('THEN return [PARTICIPANT] to [DEPS SUMMARY VIEW]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    await commonTests.clickElement(beneficiariesPage.cancelButton);
    expect(beneficiariesPage.beneficiariesTable.isDisplayed()).toBe(true);
  });

  it('AND ignore delete request', () => {
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Submit Button`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [DEPS SUMMARY VIEW]
    AND updates to [BENEFICIARY RECORDS] have been made
    WHEN [DEPS SUMMARY VIEW] loads
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN show [SUBMIT BUTTON] in [ACTIVE STATE]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionDelete(0, global.deviceType));
    await commonTests.clickElement(beneficiariesPage.cancelButton);
    expect(beneficiariesPage.beneficiariesTable.isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    resultMessaging.passTestWithCustomMessage(
      'For Edit and Add New record the button is enabled is tested in above scenarios');
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Submit Beneficiary Record Updates`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [DEPS SUMMARY VIEW]
    AND [BENEFICIARY RECORDS] have been updated
    AND [SUBMIT BUTTON] is in [ACTIVE STATE]
    WHEN [SUBMIT BUTTON] is selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN show [DEPS CONFIRMATION MESSAGE] i.e. You have successfully updated your beneficiaries.', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);
    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    await commonTests.clickElement(beneficiariesPage.beneficiariesSaveButton(global.deviceType));
    await checkers.exactText(beneficiariesPage.beneficiariesMessageLabel,
      'You have successfully updated your beneficiaries.');
  });

  // test manually
  xit(' AND write-back all [BENEFICIARY RECORD UPDATES] to all [LINKED] [ELIGIBLE] records for that [PARTICIPANT]'
  + ' and that [CLIENT] ', () => {
  });

  // test manually
  xit(' AND update [LS VERIFIED DATE] for all [LINKED] [ELIGIBLE] records for that [PARTICIPANT] and'
    + ' that [CLIENT]', () => {
  });

  // test manually
  xit(' AND update [NOMINATIONS FLAG] as ‘Y’ on [BASIC DETAILS RECORD] for all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT] ', () => {
  });

  // test manually
  xit('AND update [NOM COMPLETED DATE] on [BASIC DETAILS RECORD] for all [LINKED] [ELIGIBLE] records for that'
    + ' [MEMBER] and that [CLIENT] ', () => {
  });

  // test manually
  xit('AND update [BENEFICIARY FLAG] as \'Y\' for all [LINKED] [ELIGIBLE] records for that [PENSIONER]'
    + ' and that [CLIENT] where [PARTICIPANT TYPE] is [MEMBER] ', () => {
  });

  // test manually
  xit('AND add updates for inclusion in [AUDIT E-MAIL]', () => {
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// test manually
xdescribe(`${scenarioPrefix}All Beneficiaries Deleted Confirmed`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND all [BENEFICIARY RECORDS] deleted
    WHEN write-back all [BENEFICIARY RECORD UPDATES] to all [LINKED] [ELIGIBLE] records for that
    [PARTICIPANT] and that [CLIENT] actioned
   */
});


describe(`${scenarioPrefix}Lose changes`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    WHEN [PARTICIPANT] attempts to navigate away from current view
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN [DISPLAY LOSE CHANGES WARNING MESSAGE] based on [VIEW], [ACTION], [BENEFICIARY RECORDS UPDATED]',
    async () => {
      await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
      expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
      await managementView.fullNameValue.sendKeys('Tester');
      await managementView.addressValue.sendKeys(newAddressValue2);
      await managementView.dateOfBirthValue.sendKeys('01/01/1990');
      await managementView.beneficiaryTypeValue.sendKeys('Child');
      await managementView.guardianFullNameValue.sendKeys('Tester');
      await managementView.guardianAddressValue.sendKeys(newAddressValue2);

      await commonTests.clickElement(managementView.confirmButton);
      expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
      expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);

      await commonTests.clickElement(beneficiariesPage.beneficiariesCancelButton(global.deviceType));
      expect(beneficiariesPage.loseChangesAreYouSurePopup.isDisplayed()).toBe(true);
    });

  it('AND show [LOSE CHANGES WARNING TITLE] i.e. \'Are you Sure?\'', async () => {
    await checkers.exactText(beneficiariesPage.loseChangesHeading, '\'Are you Sure?\'');
  });

  it('AND show [LOSE CHANGES WARNING TEXT] i.e. Are you sure you want to lose these changes?', async () => {
    await checkers.exactText(beneficiariesPage.loseChangesText,
      'Are you sure you want to lose these changes?');
  });

  it('AND show [LOSE CHANGES YES BUTTON]', () => {
    expect(beneficiariesPage.loseChangesYesButton.isDisplayed()).toBe(true);
  });

  it('AND show [LOSE CHANGES NO BUTTON]', () => {
    expect(beneficiariesPage.loseChangesNoButton.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Lose changes action`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [LOSE CHANGES WARNING MESSAGE] is displayed
    WHEN [PARTICIPANT] selects [LOSE CHANGE BUTTON]
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  const initialNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();

  it('THEN based on [LOSE CHANGE BUTTON] selected, [RETURN USER ACTION] - No Button selected', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);

    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);

    await commonTests.clickElement(beneficiariesPage.beneficiariesCancelButton(global.deviceType));
    expect(beneficiariesPage.loseChangesAreYouSurePopup.isDisplayed()).toBe(true);

    await commonTests.clickElement(beneficiariesPage.loseChangesNoButton);
  });

  it('AND [RETAIN CHANGES]', () => {
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries + 1);
  });

  it('THEN based on [LOSE CHANGE BUTTON] selected, [RETURN USER ACTION] - Yes Button selected', async () => {
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);

    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);

    await commonTests.clickElement(beneficiariesPage.beneficiariesCancelButton(global.deviceType));
    expect(beneficiariesPage.loseChangesAreYouSurePopup.isDisplayed()).toBe(true);

    await commonTests.clickElement(beneficiariesPage.loseChangesYesButton);
  });

  it('AND [RETAIN CHANGES] - Changes not retained', () => {
    const newNumberOfBeneficiaries = beneficiariesPage.getNumberOfBeneficiariesStored();
    expect(newNumberOfBeneficiaries).toEqual(initialNumberOfBeneficiaries);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

// test manually
xdescribe(`${scenarioPrefix}Error handling`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [DEPS SUMMARY VIEW]
    AND [BENEFICIARY RECORDS] have been updated
    AND [SUBMIT BUTTON] is in [ACTIVE STATE]
    AND the [BENEFICIARY RECORD] is [LOCKED]
    WHEN [SUBMIT BUTTON] selected
   */
});

// test manually
xdescribe(`${scenarioPrefix}Periodic Capture of Personal Details`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [NOMS READ ONLY] is [DISABLED]
    AND [LS VERIFIED DATE] has [EXPIRED]
    WHEN [DEPS SUMMARY VIEW] loads
   */
});

// test manually
xdescribe(`${scenarioPrefix}Capture Confirm button`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND no [BENEFICIARY RECORDS] have been updated
    AND [CAPTURE CONTINUE BUTTON] has been selected
    WHEN [DEPS SUMMARY VIEW] loads
   */
});

// test manually
xdescribe(`${scenarioPrefix}Capture confirm button behaviour on updates`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    WHEN [CAPTURE CONFIRM BUTTON] has been selected
   */
});

describe(`${scenarioPrefix}Capture confirm button behaviour no updates`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND [CAPTURE CONTINUE BUTTON] has been selected
    AND [BENEFICIARY RECORDS] have been updated
    WHEN [DEPS SUMMARY VIEW] loads
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN replace [CAPTURE CONFIRM BUTTON] button with [SUBMIT] in [ACTIVE STATE]', async () => {
    expect(beneficiariesPage.captureMessageContinueButton.isDisplayed()).toBe(true);
    await commonTests.clickElement(beneficiariesPage.captureMessageContinueButton);
    await commonTests.clickElement(beneficiariesPage.beneficiaryAddButton);
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);

    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.captureConfirmButton.isDisplayed()).toBe(false);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});

describe(`${scenarioPrefix}Return key summary view`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [DEPS SUMMARY VIEW]
    WHEN [RETURN KEY] is selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  it('THEN [SELECT SUBMIT BUTTON] based on [SUBMIT BUTTON VISIBILITY = SHOW], [SUBMIT BUTTON STATE = ACTIVE],'
    + ' [CAPTURE CONFIRM BUTTON VISIBILITY = N/A], [ADD BUTTON VISIBILITY = SHOW] ', async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await managementView.addressValue.sendKeys(newAddressValue2);
    await managementView.dateOfBirthValue.sendKeys('01/01/1990');
    await managementView.beneficiaryTypeValue.sendKeys('Child');
    await managementView.guardianFullNameValue.sendKeys('Tester');
    await managementView.guardianAddressValue.sendKeys(newAddressValue2);
    await commonTests.clickElement(managementView.confirmButton);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(true);
    await browser.actions().sendKeys(protractor.Key.ENTER).perform();
    await checkers.exactText(beneficiariesPage.beneficiariesMessageLabel,
      'You have successfully updated your beneficiaries.');
  });

  it('THEN [SELECT SUBMIT BUTTON] based on [SUBMIT BUTTON VISIBILITY = SHOW], [SUBMIT BUTTON STATE = ACTIVE],'
    + ' [CAPTURE CONFIRM BUTTON VISIBILITY = N/A], [ADD BUTTON VISIBILITY = SHOW] ', async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
    await browser.actions().sendKeys(protractor.Key.ENTER).perform();
    await checkers.exactText(beneficiariesPage.beneficiariesMessageLabel, 'You have not made any changes.');
  });

  it('THEN [SELECT ADD BUTTON] based on [SUBMIT BUTTON VISIBILITY = DISABLED], [SUBMIT BUTTON STATE = ACTIVE],'
    + ' [CAPTURE CONFIRM BUTTON VISIBILITY = N/A], [ADD BUTTON VISIBILITY = SHOW] ', async () => {
    // TODO: Need a member which do not have any beneficiary
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
    await browser.actions().sendKeys(protractor.Key.ENTER).perform();
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
  });

  // test manually
  xit('THEN [SELECT Capture Confirm Button] based on [SUBMIT BUTTON VISIBILITY = DISABLED], [SUBMIT BUTTON STATE ='
    + ' ACTIVE],[CAPTURE CONFIRM BUTTON VISIBILITY = SHOW], [ADD BUTTON VISIBILITY = SHOW] ', () => {
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});


describe(`${scenarioPrefix}Return key Beneficiary Management view`, () => {
  /*
    GIVEN the [PARTICIPANT] is viewing the [BENEFICIARIES] page
    AND [DEPENDANTS FEATURE] is displayed
    AND view is [BENEFICIARY MANAGEMENT VIEW]
    AND current field is not [ADDRESS]
    AND current field is not [GUARD ADDRESS]
    WHEN [RETURN KEY] is selected
   */

  const participant = participant001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const beneficiariesPage = new BeneficiariesPage(participant);
  const managementView = beneficiariesPage.beneficiaryManagementView;

  beforeAll(async () => {
    await login(loginPage, dashboardPage, beneficiariesPage, participant);
  });

  it('THEN select [CONFIRM BUTTON]', async () => {
    await commonTests.clickElement(beneficiariesPage.actionEdit(0, global.deviceType));
    expect(managementView.beneficiaryManagementView.isDisplayed()).toBe(true);
    await managementView.fullNameValue.sendKeys('Tester');
    await browser.actions().sendKeys(protractor.Key.ENTER).perform();
    expect(beneficiariesPage.dependantsTab.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(beneficiariesPage, loginPage);
  });
});
