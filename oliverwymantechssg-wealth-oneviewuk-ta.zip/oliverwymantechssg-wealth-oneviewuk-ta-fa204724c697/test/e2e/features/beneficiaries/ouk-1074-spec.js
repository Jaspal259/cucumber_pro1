// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const BeneficiariesTests = require('../_common/beneficiaries.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const BeneficiariesPage = require('../../page-objects/beneficiaries.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new StandardParticipant();
const beneficiariesTests = new BeneficiariesTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const dbPlanSummaryPage = new DbPlanSummaryPage(
  participant,
  participant.posDbActive.scheme.data.midasSchemeCode,
  participant.posDbActive.data.periodOfServicePrimaryKey);
const dcPlanSummaryPage = new DcPlanSummaryPage(
  participant,
  participant.posDcActive.scheme.data.midasSchemeCode,
  participant.posDcActive.data.periodOfServicePrimaryKey);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);
const beneficiariesPage = new BeneficiariesPage('dependants');

// tests
const scenarioPrefix = `OUK-1074 (inc. OUK-5873)${commonConstants.bddScenarioPrefix}`;

async function login(summaryType) {
  switch (summaryType) {
    case 'DC':
      await beneficiariesTests.browseToBeneficiariesPageViaDcPlanSummaryPage(
        loginPage, dashboardPage, dcPlanSummaryPage, beneficiariesPage, participant, 0);
      break;
    case 'DB':
      await beneficiariesTests.browseToBeneficiariesPageViaDbPlanSummaryPage(
        loginPage, dashboardPage, dbPlanSummaryPage, beneficiariesPage, participant, 0);
      break;
    case 'Pensioner':
      await beneficiariesTests.browseToBeneficiariesPageViaPipPlanSummaryPage(
        loginPage, dashboardPage, pensionerPlanSummaryPage, beneficiariesPage, participant, 0);
      break;
    default:
      throw new Error(`The summaryType [${summaryType}] is not supported`);
  }

  const present = await browser.isElementPresent(beneficiariesPage.lumpSumTab);

  if (present) {
    // note dependants tab is not clickable if only dependants tab present
    // and if is present we have to check for presence of dependants tab too otherwise click can fail
    const present2 = await browser.isElementPresent(beneficiariesPage.dependantsTab);

    if (present2) {
      await commonTests.clickElement(beneficiariesPage.dependantsTab);
    }
  }
}

async function checkBeneficiaryDataRow(index) {
  await checkers.anyText(beneficiariesPage.nameValue(index));
  await checkers.anyText(beneficiariesPage.addressValue(index));
  await checkers.anyText(beneficiariesPage.beneficiaryTypeValue(index, global.deviceType));
  await checkers.anyText(beneficiariesPage.guardianValue(index, global.deviceType));
  await checkers.containingImage(beneficiariesPage.actionEdit(index, global.deviceType),
    commonConstants.actionEditImageSource);
  await checkers.containingImage(beneficiariesPage.actionDelete(index, global.deviceType),
    commonConstants.actionDeleteImageSource);
}

function runPrePopulatedDataCancelLinkAndBackLinkScenarios(summaryType, returnPage) {
  describe(`${scenarioPrefix}Pre-populated data + [ouk-2320]Change to Address Status display`
   + `[ouk-2320]Change to Guardian Data display + Cancel link + Back link (${summaryType})`, () => {
    /*
      Common
      ----------------------------------------------------------
      GIVEN [PARTICIPANT] is viewing the [BENEFICIARIES] page
      AND [DEPENDANTS FEATURE] is [ENABLED]

      Pre-populated data
      ----------------------------------------------------------
      AND [DEPENDANTS DATA] is recorded for [MAIN POS]
      WHEN [DEPS SUMMARY VIEW] loads

      Cancel link
      ----------------------------------------------------------
      AND no changes have been made

      Back link
      ----------------------------------------------------------
      AND no changes have been made
      WHEN the back link is selected
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${summaryType}`);
      await login(summaryType);
    });

    it('Pre-populated data: THEN show [DEPENDANTS DATA] for [MAIN POS]', async () => {
      await checkers.containingTextIgnoreCase(beneficiariesPage.nameLabel, 'Name');
      await checkers.containingImage(beneficiariesPage.nameSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.addressLabel, 'Address');
      await checkers.containingImage(beneficiariesPage.addressSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.beneficiaryTypeLabel, 'Beneficiary Type');
      await checkers.containingImage(beneficiariesPage.beneficiaryTypeSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.guardianLabel, 'Guardian');
      await checkers.containingImage(beneficiariesPage.guardianSorter,
        commonConstants.sorterImageSourceUpward);
      await checkers.containingTextIgnoreCase(beneficiariesPage.actionLabel, 'Action');

      const beneficiaryCount = await beneficiariesPage.getNumberOfBeneficiariesStored();

      if (beneficiaryCount === 1) {
        await checkBeneficiaryDataRow(0);
      } else if (beneficiaryCount === 2) {
        await checkBeneficiaryDataRow(0);
        await checkBeneficiaryDataRow(1);
      } else if (beneficiaryCount > 2) {
        // check first, mid and last data rows
        await checkBeneficiaryDataRow(0);
        await checkBeneficiaryDataRow(Math.round(beneficiaryCount / 2));
        await checkBeneficiaryDataRow(beneficiaryCount - 1);
      } else {
        fail('No beneficiaries listed');
      }
    });

    beneficiariesTests.checkCancelAndBackLinks(beneficiariesPage, summaryType, returnPage);

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runPrePopulatedDataCancelLinkAndBackLinkScenarios('DC', dcPlanSummaryPage);
runPrePopulatedDataCancelLinkAndBackLinkScenarios('DB', dbPlanSummaryPage);
runPrePopulatedDataCancelLinkAndBackLinkScenarios('Pensioner', pensionerPlanSummaryPage);

function runDobAddressGuardianAndDisclaimerScenario(summaryType) {
  describe(`${scenarioPrefix}DOB visibility + Address Details hover view`
    + ' + Guardian Details hover view + Disclaimer view'
    + ` Print and Download buttons visibility (OUK-5873) + Last date updated (OUK-5873) (${summaryType})`, () => {
    /*
      common
      ----------------------------------------------------------
      GIVEN [PARTICIPANT] is viewing the [BENEFICIARIES] page
      AND [DEPENDANTS FEATURE] is [ENABLED]

      DOB visibility
      ----------------------------------------------------------
      AND one or multiple [BENEFICIARIES] are showing
      WHEN the [PARTICIPANT] hovers over the [DEPENDANT NAME]

      Address Details hover view
      ----------------------------------------------------------
      WHEN [PARTICIPANT] hovers over [ADDRESS STATUS]

      Guardian Details hover view
      ----------------------------------------------------------
      AND [DEPS GUARDIAN AVAIL]
      WHEN [PARTICIPANT] hovers over [GUARDIAN STATUS]

      Disclaimer view
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads

      Print and Download buttons visibility (OUK-5873)
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads

      Last date updated label and value visibility (OUK-5873)
      ----------------------------------------------------------
      WHEN [LS SUMMARY VIEW] loads
     */

    /*
      Extra JIRA test info:
      #on separate lines (maximum of 5 data lines displayed)
      #standard tooltip for showing address

      Example:
      |ADDRESS STATUS | DISPLAY ADDRESS DATA
      |Y              |SHOW
      |N              |HIDE
     */

    /*
      Extra JIRA test info:
      #on separate lines (maximum of 5 data lines displayed)
      #standard tooltip for showing address

      Example:
      |ADDRESS STATUS | DISPLAY ADDRESS DATA
      |Y              |SHOW
      |N              |HIDE
     */

    /*
      Extra JIRA info:
      #standard tooltip for showing Guardian details

      Example:
      |GUARDIAN STATUS  |DISPLAY GUARD NAME |GUARD ADDRESS RECORDED |DISPLAY GUARD ADDRESS
      |Y                |SHOW               |RECORDED               |SHOW
      |Y                |SHOW               |NULL                   |HIDE
      |N                |HIDE               |N/A                    |HIDE
     */

    beforeAll(async () => {
      await login(summaryType);
    });

    beneficiariesTests.checkTooltipsAndDisclaimer(beneficiariesPage);
    beneficiariesTests.checkPrintAndDownloadButtons(beneficiariesPage);
    beneficiariesTests.checkLastDateUpdated(beneficiariesPage);

    afterAll(async () => {
      await commonTests.logOut(beneficiariesPage, loginPage);
    });
  });
}

runDobAddressGuardianAndDisclaimerScenario('DC');
runDobAddressGuardianAndDisclaimerScenario('DB');
runDobAddressGuardianAndDisclaimerScenario('Pensioner');
