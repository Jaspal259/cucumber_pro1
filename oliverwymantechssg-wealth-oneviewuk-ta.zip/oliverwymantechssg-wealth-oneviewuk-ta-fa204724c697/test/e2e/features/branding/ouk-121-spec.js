// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const footer = dashboardPage.footer;

// tests
const scenarioPrefix = `OUK-121${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Always present + Content`, () => {
  /*
    Always present
    ----------------------------------------
    GIVEN that the Participant is viewing a page in OneView
    WHEN they scroll to the bottom of the page

    Content
    ----------------------------------------
    GIVEN that the Participant is viewing a page in OneView
    WHEN they view the [MERCER SKINNY FOOTER]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);

    // just use page straight after login to check OUK-121
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Always present
  it('(Always present) THEN show [MERCER SKINNY FOOTER]', () => {
    expect(footer.commonFooter.isDisplayed()).toBe(true);
  });

  // Content
  it('(Content) THEN show [COPYRIGHT] from CMS', async () => {
    await commonTests.doesCommonFooterShowCopyrightSymbol(footer);
    await commonTests.doesCommonFooterShowCopyrightLabel(footer);
  });

  it('(Content) AND [COPYRIGHT YEAR] is [CURRENT YEAR] from Participants local machine', async () => {
    await commonTests.doesCommonFooterShowCopyrightYear(footer);
  });

  it('(Content) AND [MERCER LOGO] from CMS', async () => {
    await commonTests.doesCommonFooterShowMercerMissionStatementLogo(footer);
  });

  // '(Content) AND [MISSION STATEMENT] from CMS' omitted as already tested by previous test
  // statement is now part of image

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
