// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const loginPage = new LoginPage(standardParticipant);


// tests
const scenarioPrefix = `OUK-1192${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Login page, has logo`, () => {
  /*
    GIVEN that the [PARTICIPANT] has navigated to the Login Page
    AND the [PRODUCT LOGO] is available
    WHEN the Login page loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN show [PRODUCT LOGO]', async () => {
    // note cannot test location but can check existence and image used
    await checkers.containingImage(loginPage.productLogo.standardMercerLogoImage, 'logo');
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
