// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const HelpAndContactsPage = require('../../page-objects/help-and-contacts.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const HelpAndContactsTests = require('../_common/help-and-contacts.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const helpAndContactsTests = new HelpAndContactsTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const helpAndContactsPage = new HelpAndContactsPage(standardParticipant);
const profilePage = new ProfilePage(standardParticipant);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testOuk7741 = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments
  testOuk7741 = false;
}

// tests
const scenarioPrefix = `OUK-4271${commonConstants.bddScenarioPrefix}`;
const until = protractor.ExpectedConditions;

describe(`${scenarioPrefix}Contacts, Online message option`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN <online message> is available for all Periods of Service
    AND <Mercer mailbox address> is available
    AND <view Contact details> is available for all Periods of Service
    AND <contact details for main period of service> are available
    AND <edit contact details> is available for all Periods of Service
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'online');
  });

  it('THEN [display online message option]', async () => {
    await checkers.anyText(helpAndContactsPage.enterYourQuestionsLabel);
    await checkers.noText(helpAndContactsPage.textArea);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.editContactDetailsLabel, 'contact details');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.editButton, 'EDIT');
    await checkers.anyText(helpAndContactsPage.postalAddressLabel);
    await checkers.anyText(helpAndContactsPage.addressLine1);
    await checkers.anyText(helpAndContactsPage.residencyLabel);
    await checkers.anyText(helpAndContactsPage.emailAddressLabel);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.emailAddressValue, '@');
    await checkers.anyText(helpAndContactsPage.residencyValue);
    await checkers.anyText(helpAndContactsPage.phoneNumberLabel);
    await checkers.anyText(helpAndContactsPage.phoneNumberValue);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.secureMessageSubmit, 'proce');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.descriptionForContactDetails, 'contact details');
    await checkers.anyText(helpAndContactsPage.submitButton);
  });

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Contacts, default display`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN <online message option is available>
    WHEN the Participant navigates to the Contacts Page
  */

  beforeAll(async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'contact us');
  });

  it('THEN show all <available contacts options', async () => {
    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsOnlineDesktopSubTab, 'online');
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneDesktopSubTab, 'phone');
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostDesktopSubTab, 'post');
        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // contact us option from dropdown
        await commonTests.clickElement(helpAndContactsPage.contactUsTypeMobileDropDown);
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsOnlineMobileDropdownOption, 'online');
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneMobileDropdownOption, 'phone');
        await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostMobileDropdownOption, 'post');
        break;

      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  });

  it('AND show [contact option as default view]', async () => {
    await checkers.isMercerOsTabSelected(helpAndContactsPage.contactUsTab);
  });

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Online message view, default view + OUK-7741 test`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN online message option is available
    WHEN the Participant navigates to Online message view

    OUK-7741 test
    -----------------------------------------
    Help & Contacts pages BOTH Authenticated and Non Authenticated views need disclaimer as they
    could contain external links which require a legal disclaimer
  */

  beforeAll(async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'online');
  });

  it('THEN show blank message input form field', async () => {
    await checkers.anyText(helpAndContactsPage.enterYourQuestionsLabel);
    await checkers.noText(helpAndContactsPage.textArea);
  });

  it('AND show Contact details (see below)', async () => {
    await checkers.containingTextIgnoreCase(helpAndContactsPage.editContactDetailsLabel, 'contact details');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.editButton, 'EDIT');
    await checkers.anyText(helpAndContactsPage.postalAddressLabel);
    await checkers.anyText(helpAndContactsPage.addressLine1);
    await checkers.anyText(helpAndContactsPage.residencyLabel);
    await checkers.anyText(helpAndContactsPage.emailAddressLabel);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.emailAddressValue, '@');
    await checkers.anyText(helpAndContactsPage.residencyValue);
    await checkers.anyText(helpAndContactsPage.phoneNumberLabel);
    await checkers.anyText(helpAndContactsPage.phoneNumberValue);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.secureMessageSubmit, 'proce');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.descriptionForContactDetails, 'contact details');
    await checkers.anyText(helpAndContactsPage.submitButton);
  });

  it('AND enable submit button ', async () => {
    await checkers.anyText(helpAndContactsPage.submitButton);
  });

  if (testOuk7741) {
    // OUK-7741 test
    it('THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Online, submit message, success + Online, confirmation success view, back option`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN view is Contacts online message view
    AND the Participant has entered at least 1 character in the question form
    BUT less than 501 characters
    AND where applicable they have selected a Plan name
    AND the <postal address meets the required format>
    WHEN the Participant submits the online message
    AND the request is successful
  */

  beforeAll(async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'online');
  });

  it('THEN show online message confirmation view AND enable back to dashboard button', async () => {
    await checkers.noText(helpAndContactsPage.textArea);
    await helpAndContactsPage.textArea.sendKeys('a');
    await checkers.anyText(helpAndContactsPage.postalAddressLabel);
    await checkers.anyText(helpAndContactsPage.addressLine1);

    await commonTests.clickElement(helpAndContactsPage.submitButton);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.successMessageText, 'Thank you');
    expect(helpAndContactsPage.backButton.isEnabled()).toBe(true);
  });

  it('THEN return Participant to dashboard page ', async () => {
    await commonTests.clickElement(helpAndContactsPage.backButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(dashboardPage);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

async function checkEnteringAndSavingInvalidContentIsRejected() {
  await profilePage.phoneNumberInput.clear();
  await profilePage.phoneNumberInput.sendKeys('a');   // try invalid content
  await profilePage.emailAddressInput.clear();
  await profilePage.emailAddressInput.sendKeys('mercer');
  await commonTests.clickElement(profilePage.editContactDetailsSaveButton);

  // check save denied
  await checkers.anyTextOf20CharsPlus(profilePage.phoneNumberRequiredError);
  await checkers.anyTextOf20CharsPlus(profilePage.emailAddressInputRequiredError);
}

describe(`${scenarioPrefix}Contacts, submit but with dirty validations`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN view is Contacts online message view
    AND edits have been made
    BUT not all form fields meet the required validations
    WHEN the Participant selects submit
  */

  const editContactDetailsUrl = `${profilePage.editContactDetailsUrl}?from=help`;

  beforeAll(async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'online');
  });

  it('AND display toast alert', async () => {
    // use expect to check edit button has loaded
    expect(helpAndContactsPage.editButton.isEnabled()).toBe(true);
    await commonTests.clickElement(helpAndContactsPage.editButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
    expect(browser.getCurrentUrl()).toContain(editContactDetailsUrl);

    // check page REALLY loaded
    await browser.wait(until.visibilityOf(profilePage.phoneNumberInput), commonConstants.briefBrowserWaitDelay,
      'Phone number input is not visible on contact details edit page');

    // written as a separate function to improve code legibility
    await checkEnteringAndSavingInvalidContentIsRejected();
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check invalid edit can be cancelled`, async () => {
    await unsavedChangesModalTests.cancelUnsavedChangesIncludingCancelCancel(
      profilePage,
      profilePage.editContactDetailsCancelButton,
      profilePage.unsavedChangesModal,
      profilePage.editContactDetailsUrl,
      helpAndContactsPage,
      true);

    await commonTests.checkPageLoadsAndContainsStandardElements(helpAndContactsPage);
    expect(browser.getCurrentUrl()).toContain(helpAndContactsPage.contactUsOnlineUrl);
  });

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Online message, no edits, cancel through navigating away`, () => {
  /*
    GIVEN that the Participant has logged into OneView
    AND Contact Us is available

    GIVEN view is Contacts online message view
    AND no <edits> have been made
    WHEN the Participant attempts to navigate away
  */

  beforeAll(async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'online');
  });

  it('THEN navigate Participant to page/view selected', async () => {
    await commonTests.clickElement(helpAndContactsPage.helpTabLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(helpAndContactsPage);
    expect(browser.getCurrentUrl()).toContain(helpAndContactsPage.helpUrl);
  });

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});
