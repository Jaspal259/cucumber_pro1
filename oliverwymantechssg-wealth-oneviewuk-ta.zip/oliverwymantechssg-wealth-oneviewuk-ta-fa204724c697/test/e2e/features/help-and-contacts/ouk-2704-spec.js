// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const HelpAndContactsPage = require('../../page-objects/help-and-contacts.po.js');
const LoginPage = require('../../page-objects/authentication-login.po.js');
const ForgotUserCredentialPage = require('../../page-objects/authentication-forgot-user-credential.po');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const LoginTests = require('../_common/authentication-login.spec.js');
const HelpAndContactsTests = require('../_common/help-and-contacts.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const helpAndContactsTests = new HelpAndContactsTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const forgotUserCredentialPage = new ForgotUserCredentialPage(standardParticipant);
const helpAndContactsPage = new HelpAndContactsPage(standardParticipant);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testOuk7741 = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments
  testOuk7741 = false;
}

// tests
const scenarioPrefix = `OUK-2704${commonConstants.bddScenarioPrefix}`;

// 'Link Visibility' scenario not TE coded as will be covered by 'Help view' scenario

describe(`${scenarioPrefix}Help view + OUK-7741 test`, () => {
  /*
    GIVEN that the Participant has not yet logged in
    GIVEN the Participant is viewing a page where the Help & Contacts link is available
    WHEN they select the Help & Contacts link

    OUK-7741 test
    -----------------------------------------
    Help & Contacts pages BOTH Authenticated and Non Authenticated views need disclaimer as they
    could contain external links which require a legal disclaimer
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN direct Participant to Help page in same browser session', async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageWithoutLogin(
      loginPage, forgotUserCredentialPage, helpAndContactsPage, standardParticipant, 'help');
  });

  it('AND display all available non-authenticated help topics', async () => {
    await helpAndContactsTests.checkHelpTopicsAndSubTopics(helpAndContactsPage);
  });

  it('AND enable Contact Us view', async () => {
    await checkers.isMercerOsTabSelected(helpAndContactsPage.helpTab);
    await checkers.isMercerOsTabUnselected(helpAndContactsPage.contactUsTab);
  });

  if (testOuk7741) {
    // OUK-7741 test
    it('THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});

describe(`${scenarioPrefix}Contact Us view + OUK-7741 test`, () => {
  /*
    GIVEN that the Participant has not yet logged in
    GIVEN the Participant is viewing the Help page
    WHEN they select the Contact Us view

    OUK-7741 test
    -----------------------------------------
    Help & Contacts pages BOTH Authenticated and Non Authenticated views need disclaimer as they
    could contain external links which require a legal disclaimer
   */

  beforeAll(async () => {
    await loginTests.checkLoginPageLoads(loginPage);
  });

  it('THEN switch views to Contact Us view', async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageWithoutLogin(
      loginPage, forgotUserCredentialPage, helpAndContactsPage, standardParticipant, 'help');
    await helpAndContactsTests.clickRequiredTabOfHelpAndContactsPage(
      helpAndContactsPage, 'contact us', false);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(helpAndContactsPage);
    expect(browser.getCurrentUrl()).toContain(helpAndContactsPage.contactUsPhoneUrl);
  });

  it('AND display OneView contact details', async () => {
    // phone - note only phone contact is allowed for unauth page - confirmed by bug 8066
    await checkers.anyText(helpAndContactsPage.contactUsPhoneHeader);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneMethod(1),
      'OV1 TE unauth contact us by phone');
  });

  if (testOuk7741) {
    // OUK-7741 test
    it('THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
