// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const HelpAndContactsPage = require('../../page-objects/help-and-contacts.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const HelpAndContactsTests = require('../_common/help-and-contacts.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const helpAndContactsTests = new HelpAndContactsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const helpAndContactsPage = new HelpAndContactsPage(standardParticipant);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testOuk7741 = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments
  testOuk7741 = false;
}

// tests
const scenarioPrefix = `OUK-4477${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}By Phone option + By Post option + OUK-7741 test`, () => {
  /*
    By Phone option
    -----------------------------------------
    GIVEN the Participant has logged into OneView
    GIVEN view is Contacts page
    WHEN the Participant navigates to the By Phone view

    By Post option
    -----------------------------------------
    GIVEN the Participant has logged into OneView
    GIVEN view is Contacts page
    WHEN the Participant navigates to the By Post view

    OUK-7741 test
    -----------------------------------------
    Help & Contacts pages BOTH Authenticated and Non Authenticated views need disclaimer as they
    could contain external links which require a legal disclaimer
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await helpAndContactsTests.browseToHelpAndContactsPageFromLogin(
      loginPage, dashboardPage, helpAndContactsPage, standardParticipant, 'phone');
  });

  // By Phone option
  it('(By Phone option) THEN show OneView contact number', async () => {
    await checkers.anyText(helpAndContactsPage.contactUsPhoneHeader);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneMethod(1),
      'OV1 TE auth contact us by phone - pensioner');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneMethod(2),
      'OV1 TE auth contact us by phone - active');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPhoneMethod(3),
      'OV1 TE auth contact us by phone - deferred');
  });

  if (testOuk7741) {
    // OUK-7741 test (phone)
    it('(By Phone option) THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  // By Post option
  it('(By Post option) THEN show pensions postal address details for each unique status'
  + ' based on Participant Period of service', async () => {
    await helpAndContactsTests.clickRequiredTabOfHelpAndContactsPage(
      helpAndContactsPage, 'post', true);
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostHeader, 'Post');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostMethod(0),
      'OV1 TE auth contact us by post - pensioner');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostMethod(1),
      'OV1 TE auth contact us by post - active');
    await checkers.containingTextIgnoreCase(helpAndContactsPage.contactUsPostMethod(2),
      'OV1 TE auth contact us by post - deferred');
  });

  if (testOuk7741) {
    // OUK-7741 test (post)
    it('(By Post option) THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  afterAll(async () => {
    await commonTests.logOut(helpAndContactsPage, loginPage);
  });
});
