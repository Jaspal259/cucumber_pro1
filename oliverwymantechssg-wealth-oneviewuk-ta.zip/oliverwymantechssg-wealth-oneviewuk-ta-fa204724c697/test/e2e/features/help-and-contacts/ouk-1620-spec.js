// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const HelpAndContactsPage = require('../../page-objects/help-and-contacts.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const HelpAndContactsTests = require('../_common/help-and-contacts.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const helpAndContactsTests = new HelpAndContactsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const helpAndContactsPage = new HelpAndContactsPage(standardParticipant);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testOuk7741 = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments
  testOuk7741 = false;
}

// tests
const scenarioPrefix = `OUK-1620${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Link Visibility + Help & Contacts page + Help Topic Display + OUK-7741 test`, () => {
  /*
    Link Visibility
    ----------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    WHEN [DASHBOARD] loads

    TE note - only test example where all enabled

    Example:
    |HELP AVAIL  |CONTACT US AVAIL         |DISPLAY H&C LINK
    |ENABLED     |ENABLED                  |SHOW

    Help & Contacts page
    ----------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    AND [CONTACT US] is [ENABLED]
    AND [HELP] is [ENABLED]
    WHEN [H&C LINK] is selected

    Help Topic Display
    ----------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    AND [HELP] is [ENABLED]
    WHEN Help Page loads

    OUK-7741 test
    -----------------------------------------
    Help & Contacts pages BOTH Authenticated and Non Authenticated views need disclaimer as they
    could contain external links which require a legal disclaimer
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Link Visibility
  it('(Link Visibility) THEN [DISPLAY H&C LINK] based on availability of [HELP] AND [CONTACT US]', async () => {
    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await checkers.anyText(dashboardPage.header.commonHeaderMenuHelpAndContacts(true));
        expect(dashboardPage.header.commonHeaderMenuHelpAndContacts(true).isEnabled()).toBe(true);
        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // will be tested in next it() block
        break;

      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  });

  // Help & Contacts page
  it('(Help & Contacts page) THEN redirect Participant to [H&C PAGE] in same browser page ', async () => {
    await helpAndContactsTests.browseToHelpAndContactsPageFromDashboard(
      dashboardPage, helpAndContactsPage, standardParticipant, 'help');
  });

  it('(Help & Contacts page) AND show [PAGE NAME] i.e. Help & Contacts', async () => {
    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await checkers.anyText(helpAndContactsPage.helpAndContactsLabel(global.deviceType));
        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // n/a to mobile
        break;

      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  });

  it('(Help & Contacts page) AND show [H&C TITLE] i.e. Useful Information ', async () => {
    await checkers.anyText(helpAndContactsPage.usefulInformationHeaderLabel(global.deviceType));
  });

  it('(Help & Contacts page) AND show [HELP FEATURE] as primary view ', async () => {
    await checkers.isMercerOsTabSelected(helpAndContactsPage.helpTab);
  });

  it('(Help & Contacts page) AND show [CONTACT US FEATURE] as secondary view  ', async () => {
    await checkers.isMercerOsTabUnselected(helpAndContactsPage.contactUsTab);
  });

  // Help Topic Display
  it('(Help Topic Display) THEN [DISPLAY HELP TOPICS] based on [HELP TOPIC AVAIL] ', async () => {
    await helpAndContactsTests.checkHelpTopicsAndSubTopics(helpAndContactsPage);
  });

  if (testOuk7741) {
    // OUK-7741 test
    it('THEN test OUK-7741 "Help & Contacts page requires disclaimer labels"', async () => {
      await checkers.anyTextOf20CharsPlus(helpAndContactsPage.disclaimer);
    });
  }

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
