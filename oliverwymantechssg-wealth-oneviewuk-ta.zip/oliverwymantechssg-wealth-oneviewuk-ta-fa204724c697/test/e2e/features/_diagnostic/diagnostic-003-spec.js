/* eslint-disable no-console */

// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
// really n/a as this is an early test just to check existence of 'create account' link - doesn't do anything yet
// but need participant to set client for page URL
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const LoginTests = require('../_common/authentication-login.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);

// tests
const scenarioPrefix = `TE-DIAGNOSTIC-003 (testing error handling)${commonConstants.bddScenarioPrefix}`;

// other
const until = protractor.ExpectedConditions;

describe(`${scenarioPrefix}Access`, () => {
  /*
    GIVEN that the Participant has not yet registered
    AND they wish to create an account
    WHEN they view the [Login page]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);

    try {
      await browser.waitForAngularEnabled(true);
    } catch (e) {
      resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
    }

    await commonTests.printToConsoleLogWithDateTime(`Login page requested: ${loginPage.url}`);
    await loginTests.checkLoginPageLoads(loginPage);
    await browser.wait(until.urlContains(loginPage.url), commonConstants.mediumBrowserWaitDelay,
      `Current page does not have URL containing ${loginPage.url}`);
    expect(browser.getCurrentUrl()).toContain(loginPage.url);
    expect(loginPage.header.clientLogoImage.isPresent()).toBe(true);

    const footer = loginPage.footer;

    console.log('beforeAll NEW here 000');

    // force errors
    const quack = element(by.tagName('quack'));
    await checkers.anyText(quack);
    await quack.isDisplayed();
    await quack.click();

    // await checkers.noText(footer.marshLink);

    // TODO: replace toBeElementWithAnyText with
    await checkers.anyText(footer.marshLink);
    await checkers.anyTextOf20CharsPlus(footer.marshLink);
    await checkers.containingText(footer.marshLink, 'ars');
    await checkers.containingTextIgnoreCase(footer.marshLink, 'ArS');
    await checkers.notContainingText(footer.marshLink, 'Marsh');
    await checkers.anyUkDate(footer.marshLink);
    await checkers.anyUkDateOrNA(footer.marshLink);
    await checkers.exactUkDate(footer.marshLink, '30/06/2019');
    await checkers.containingAnyUkDate(footer.marshLink);
    await checkers.containingUkDate(footer.marshLink, '30/06/2019');
    await checkers.containingCurrentUkDate(footer.marshLink);
    await checkers.anyUkYear(footer.marshLink);
    await checkers.anyGbp(footer.marshLink);
    await checkers.isGbpGreaterThan(footer.marshLink, '£100,00.10');
    await checkers.isGbpLessThan(footer.marshLink, '£100,00.10');
    await checkers.isGbpLessThan(loginPage.userIdInput, '£100,00.10');
    await checkers.anyImage(loginPage.header.clientLogoImage);
    await checkers.anyImage(footer.marshLink);
    await checkers.exactImage(footer.marshLink, '/files/pages/product_logo_white');
    await checkers.exactImage(loginPage.header.clientLogoImage, '/files/pages/product_logo_white');
    await checkers.exactImage(loginPage.header.clientLogoImage,
      'https://v218-dal-qa-merceros.mercer.com:10491/resources/files/pages/mercer_client_logo.png');
    await checkers.containingImage(footer.marshLink, '/files/pages/product_logo_white');
    await checkers.containingImage(loginPage.header.clientLogoImage, '/files/pages/product_logo_white');
    await checkers.containingImage(loginPage.header.clientLogoImage, 'mercer_client_logo.png');
    await checkers.readOnly(footer.marshLink);
    await checkers.readOnly(loginPage.userIdInput);
    await checkers.inputNoText(footer.marshLink);
    await checkers.inputNoText(loginPage.userIdInput);
    await checkers.inputAnyText(footer.marshLink);
    await checkers.inputAnyText(loginPage.userIdInput);
    await checkers.inputExactText(footer.marshLink, '60-17-21');
    await checkers.inputExactText(loginPage.userIdInput, '60-17-21');
    await checkers.inputContainingText(footer.marshLink, '60-17');
    await checkers.inputContainingText(loginPage.userIdInput, '60-17');
    await checkers.inputNotContainingText(footer.marshLink, '60-17-DUMMY');
    await checkers.inputNotContainingText(loginPage.userIdInput, '60-17-DUMMY');
    await checkers.inputAnyGbpNumberFormat(footer.marshLink);
    await checkers.inputAnyGbpNumberFormat(loginPage.userIdInput);
    await checkers.anyPercent(footer.marshLink);
    await checkers.exactPercent(footer.marshLink, '4.99%');
    await checkers.isPercentGreaterThan(footer.marshLink, '4.99%');
    await checkers.isPercentLessThan(footer.marshLink, '4.99%');
    await checkers.anyNumber(footer.marshLink);
    await checkers.anyNumberToSpecifiedDp(footer.marshLink, 2);
    await checkers.exactNumber(footer.marshLink, 223);
    await checkers.isNumberGreaterThan(footer.marshLink, 223);
    await checkers.isNumberLessThan(footer.marshLink, 223);
    await checkers.containingAnyNumber(footer.marshLink);
    await checkers.containingNumber(footer.marshLink, 223);
    await checkers.anyLink(loginPage.userIdInput);
    await checkers.anyLink(footer.marshLink);
    await checkers.exactLink(loginPage.userIdInput, 'https://www.marsh.com/');
    await checkers.exactLink(footer.marshLink, 'https://www.marsh.co');
    await checkers.exactLink(footer.marshLink, 'https://www.marsh.com/');
    await checkers.containingLink(loginPage.userIdInput, 'https://www.marsh');
    await checkers.containingLink(footer.marshLink, 'https://www.moosh');
    await checkers.containingLink(footer.marshLink, 'https://www.marsh');
    await checkers.isMercerOsButtonSelected(footer.marshLink);
    await checkers.isMercerOsButtonUnselected(footer.marshLink);
    await checkers.isMercerOsTabSelected(footer.marshLink);
    await checkers.isMercerOsTabUnselected(footer.marshLink);

    console.log('beforeAll NEW here 001');

    // await checkers.containingImage(footer.mercerFooterLogoImage,
    //   '/mercer-assets/img/logos/mmc/mmc_logo_rgb.png'
    // );

    // // external MMC links
    await checkers.exactText(footer.marshLink, 'Marsh');
    // expect(footer.marshLink.getAttribute('href')).toContain('https://www.marsh.com');
    await checkers.exactText(footer.guyCarpenterLink, 'Guy Carpenter');
    // expect(footer.guyCarpenterLink.getAttribute('href')).toContain(
    //   'http://www.guycarp.com/content/guycarp/en/home.html');
    await checkers.exactText(footer.mercerLink, 'Mercer');
    // expect(footer.mercerLink.getAttribute('href')).toContain('https://www.mercer.com');
    await checkers.exactText(footer.oliverWymanLink, 'Oliver Wyman');
    // expect(footer.oliverWymanLink.getAttribute('href')).toContain('http://www.oliverwyman.com/index.html');
  });

  it('STEP 01', () => {
    //
  });

  afterAll(async () => {
    // await commonTests.clearBrowserCacheAndCookies();
  });
});
