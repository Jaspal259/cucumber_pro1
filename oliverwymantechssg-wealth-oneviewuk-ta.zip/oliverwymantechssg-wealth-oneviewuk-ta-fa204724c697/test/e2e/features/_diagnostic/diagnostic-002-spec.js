/* eslint-disable no-console */

// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginTests = new LoginTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const testName = 'TE-DIAGNOSTIC-002 (log in/out)';
const scenarioPrefix = `${testName}${commonConstants.bddScenarioPrefix}`;

async function logMemoryUsage(messageTimeDescription) {
  await console.log(`Memory usage ${messageTimeDescription}`);
  await commonTests.debugBrowserMemoryUsage();
}

function runLoginLogoutScenario(instance) {
  describe(`${scenarioPrefix}Go to login page and check the Url loads (instance = ${instance})`, () => {
    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}(instance = ${instance})`);
      await console.log(`${testName} beforeAll() instance = ${instance}`);

      // go to login page and check the Url loads (note no page objects checked)
      try {
        await browser.waitForAngularEnabled(true);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      await logMemoryUsage('before login (start of test)');
      await loginTests.attemptLogin(loginPage, standardParticipant);
      await browser.wait(until.urlContains(dashboardPage.url), commonConstants.mediumBrowserWaitDelay,
        `Current page does not have URL containing ${dashboardPage.url}`);
      await logMemoryUsage('after login');
      expect(browser.getCurrentUrl()).toContain(dashboardPage.url);
    });

    it(`${testName} it() instance = ${instance}`, async () => {
      await console.log(`${testName} it() instance = ${instance}`);
    });

    afterAll(async () => {
      await console.log(`${testName} afterAll() instance = ${instance}`);
      await commonTests.logOut(dashboardPage, loginPage);
      await logMemoryUsage('after logout (end of test)');
    });
  });
}

let i;

// set number of iterations to test - e.g. 95
for (i = 1; i <= 1; i += 1) {
  runLoginLogoutScenario(i);
}
