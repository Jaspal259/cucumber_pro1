/* eslint-disable no-console */

// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const loginTests = new LoginTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const testName = 'TE-DIAGNOSTIC-001 (login page loads)';
const scenarioPrefix = `${testName}${commonConstants.bddScenarioPrefix}`;

async function logMemoryUsage(messageTimeDescription) {
  await console.log(`Memory usage ${messageTimeDescription}`);
  await commonTests.debugBrowserMemoryUsage();
}

function runGoToLoginPageScenario(instance) {
  describe(`${scenarioPrefix}Go to login page and check the Url loads (instance = ${instance})`, () => {
    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}(instance = ${instance})`);
      await console.log(`${testName} beforeAll() instance = ${instance}`);
      await logMemoryUsage('at start of test');

      // go to login page and check the Url loads (note no page objects checked)
      try {
        await browser.waitForAngularEnabled(true);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      await loginTests.checkLoginPageLoads(loginPage);
      await logMemoryUsage('after URL requested');
      await browser.wait(until.urlContains(loginPage.url), commonConstants.mediumBrowserWaitDelay,
        `Current page does not have URL containing ${loginPage.url}`);
      await logMemoryUsage('after URL loaded');
      expect(browser.getCurrentUrl()).toContain(loginPage.url);
      await logMemoryUsage('after URL checked');
    });

    it(`${testName} it() instance = ${instance}`, async () => {
      await logMemoryUsage('at start of it() block');

      await console.log(`${testName} it() instance = ${instance}`);

      await logMemoryUsage('at end of it() block');
    });

    afterAll(async () => {
      await console.log(`${testName} afterAll() instance = ${instance}`);
      await commonTests.clearBrowserCacheAndCookies();

      await logMemoryUsage('at end of test');
    });
  });
}

let i;

// set number of iterations to test - e.g. 30
for (i = 1; i <= 1; i += 1) {
  runGoToLoginPageScenario(i);
}
