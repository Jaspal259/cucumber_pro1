// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-220${commonConstants.bddScenarioPrefix}`;

async function login() {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
}

describe(`${scenarioPrefix}Feature display + Log out prompt + Log out message - Yes behaviour `, () => {
  /*
    Feature display
    ---------------------------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    WHEN they view their [Profile] options

    Log out prompt
    ---------------------------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    AND they are viewing the [PROFILE] options
    WHEN the [LOG OUT LINK] is selected

    Log out message - Yes behaviour
    ---------------------------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    AND the [LOG OUT MODAL] is displayed
    WHEN they select [YES]
   */

  const header = dashboardPage.header;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it('THEN show [LOG OUT LINK] AND [LOG OUT LINK DESCRIPTION] from CMS', async () => {
    await commonTests.clickElement(header.userDropDown);
    await checkers.containingTextIgnoreCase(header.logoutLink, 'Log Out');
  });

  it('THEN display [LOG OUT MODAL]', async () => {
    await commonTests.clickElement(header.logoutLink);

    // check content
    await checkers.containingTextIgnoreCase(header.logoutModal.header, 'log');
    await checkers.containingTextIgnoreCase(header.logoutModal.header, 'out');
    await checkers.anyTextOf20CharsPlus(header.logoutModal.descriptionUpper);
    await checkers.anyTextOf20CharsPlus(header.logoutModal.descriptionLower);

    // can be 'cancel' or 'continue'
    await checkers.containingTextIgnoreCase(header.logoutModal.continueButton(global.deviceType), 'c');

    await checkers.containingTextIgnoreCase(header.logoutModal.logoutButton(global.deviceType), 'log');
    await checkers.containingTextIgnoreCase(header.logoutModal.logoutButton(global.deviceType), 'out');
  });

  it('THEN direct Participant to [Login Page]', async () => {
    await commonTests.clickElement(header.logoutModal.logoutButton(global.deviceType));
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  });

  it('AND show [LOGGED OUT MESSAGE]', async () => {
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'logged out');
  });

  afterAll(async () => {
    await commonTests.clearBrowserCacheAndCookies();
  });
});
