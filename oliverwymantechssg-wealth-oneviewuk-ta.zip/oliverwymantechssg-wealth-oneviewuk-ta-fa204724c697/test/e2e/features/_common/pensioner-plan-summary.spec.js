// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');


// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const pensionerPlanSummaryTests = function pensionerPlanSummaryTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions

  this.browseToPensionerPlanSummaryPageFromLogin = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, participant, pensionerServiceInstance) => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);

    // go to the Pensioner plan summary page
    await self.browseToPensionerPlanSummaryPageFromDashboard(
      dashboardPage, pensionerPlanSummaryPage, pensionerServiceInstance);
  };

  this.browseToPensionerPlanSummaryPageFromDashboard
    = async (dashboardPage, pensionerPlanSummaryPage, pensionerServiceInstance) => {
      switch (pensionerServiceInstance) {
        case 0:
          await commonTests.clickElement(dashboardPage.pensionerCard0.detailsButton(global.deviceType));
          break;

        case 1:
          await commonTests.clickElement(dashboardPage.pensionerCard1.detailsButton(global.deviceType));
          break;

        default:
          throw new Error(`Does not support pensionerServiceInstance === ${pensionerServiceInstance}`);
      }

      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionerPlanSummaryPage);
    };
};
module.exports = pensionerPlanSummaryTests;
