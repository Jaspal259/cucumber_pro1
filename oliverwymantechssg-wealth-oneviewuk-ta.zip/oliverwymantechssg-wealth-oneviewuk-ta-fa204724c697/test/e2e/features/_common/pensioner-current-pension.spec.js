// load common
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// create new objects
const commonTests = new CommonTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();

// tests
const currentPensionTests = function currentPensionTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions
  this.browseToCurrentPensionPageViaPipPlanSummaryPage = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, currentPensionPage, participant, pensionerServiceInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, participant, pensionerServiceInstance);
    await self.browseToCurrentPensionPageFromPlanSummaryPage(
      pensionerPlanSummaryPage, currentPensionPage);
  };

  this.browseToCurrentPensionPageFromPlanSummaryPage = async (pensionerPlanSummaryPage, currentPensionPage) => {
    await checkers.containingTextIgnoreCase(currentPensionPage.grossPenAction, 'View Breakdown');
    await commonTests.clickElement(currentPensionPage.grossPenAction);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(currentPensionPage);
  };

  this.checkPensionerData = async (currentPensionPage, rowIndex) => {
    await checkers.anyText(currentPensionPage.getElementName(rowIndex));
    await checkers.anyGbp(currentPensionPage.getCurrentAmount(rowIndex));
    await checkers.anyUkDateOrNA(currentPensionPage.getReviewDate(rowIndex));
    await checkers.anyUkDateOrNA(currentPensionPage.getCheckpointDate(rowIndex));
  };
};

module.exports = currentPensionTests;
