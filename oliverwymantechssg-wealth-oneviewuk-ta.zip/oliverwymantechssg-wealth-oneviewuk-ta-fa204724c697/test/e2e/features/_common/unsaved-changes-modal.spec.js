// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// other
const until = protractor.ExpectedConditions;
const missingModalMessage = 'Missing unsaved changes modal';

// tests
const unsavedChangesModalTests = function unsavedChangesModalTests() {
  // exposed functions

  async function checkContentOfModal(unsavedChangesModal) {
    await checkers.containingTextIgnoreCase(unsavedChangesModal.header, 'Unsaved Changes');
    await checkers.anyText(unsavedChangesModal.description);
    await checkers.containingTextIgnoreCase(unsavedChangesModal.cancelCancelButton(global.deviceType), 'Cancel');
    await checkers.isMercerOsButtonUnselected(unsavedChangesModal.cancelCancelButton(global.deviceType));
    expect(unsavedChangesModal.cancelCancelButton(global.deviceType).isEnabled()).toBe(true);
    await checkers.containingTextIgnoreCase(unsavedChangesModal.confirmCancelButton(global.deviceType), 'Continue');
    await checkers.isMercerOsButtonSelected(unsavedChangesModal.confirmCancelButton(global.deviceType));
    expect(unsavedChangesModal.confirmCancelButton(global.deviceType).isEnabled()).toBe(true);
  }

  this.cancelCancelUnsavedChanges = async (
    currentPage, cancelButton, unsavedChangesModal, urlAfterCancelCancel) => {
    await checkers.anyText(cancelButton);
    await commonTests.clickElement(cancelButton);
    await browser.wait(
      until.visibilityOf(unsavedChangesModal.headerContainer),
      commonConstants.briefBrowserWaitDelay,
      missingModalMessage);
    await checkContentOfModal(unsavedChangesModal);
    await commonTests.clickElement(unsavedChangesModal.cancelCancelButton(global.deviceType));

    // re-check the page itself is loaded - use unauth check as less checks than auth page check
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(currentPage, true);
    expect(browser.getCurrentUrl()).toContain(urlAfterCancelCancel);
  };

  this.confirmCancelUnsavedChanges = async (
    cancelButton, unsavedChangesModal, urlAfterCancelCancel, pageAfterConfirmCancel, isPageAfterAuthPage) => {
    await checkers.anyText(cancelButton);
    await commonTests.clickElement(cancelButton);
    await browser.wait(
      until.visibilityOf(unsavedChangesModal.headerContainer),
      commonConstants.briefBrowserWaitDelay,
      missingModalMessage);
    await checkContentOfModal(unsavedChangesModal);
    await commonTests.clickElement(unsavedChangesModal.confirmCancelButton(global.deviceType));
    await browser.wait(until.not(until.urlContains(urlAfterCancelCancel)),
      commonConstants.briefBrowserWaitDelay,
      `URL still contains ${urlAfterCancelCancel}`);

    if (isPageAfterAuthPage) {
      await commonTests.checkPageLoadsAndContainsStandardElements(pageAfterConfirmCancel);
    } else {
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(pageAfterConfirmCancel, true);
    }

    expect(browser.getCurrentUrl()).not.toContain(urlAfterCancelCancel);
  };

  this.cancelUnsavedChangesIncludingCancelCancel = async (
    currentPage, cancelButton, unsavedChangesModal,
    urlAfterCancelCancel, pageAfterConfirmCancel, isPageAfterAuthPage) => {
    await this.cancelCancelUnsavedChanges(currentPage, cancelButton, unsavedChangesModal, urlAfterCancelCancel);
    await this.confirmCancelUnsavedChanges(
      cancelButton, unsavedChangesModal, urlAfterCancelCancel, pageAfterConfirmCancel, isPageAfterAuthPage);
  };
};
module.exports = unsavedChangesModalTests;
