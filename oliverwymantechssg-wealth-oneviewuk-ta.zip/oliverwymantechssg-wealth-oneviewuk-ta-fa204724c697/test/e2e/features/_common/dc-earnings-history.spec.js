// load common
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const DcPlanSummaryTests = require('./dc-plan-summary.spec');

// create new objects
const dcPlanSummaryTests = new DcPlanSummaryTests();
const commonTests = new CommonTests();

// tests
const dcEarningHistoryTests = function dcEarningHistoryTests() {
  // private functions


  // private properties

  // exposed properties


  // exposed functions
  this.browseToDcEarningsHistoryPageFromLogin = async (
    loginPage, dashboardPage, dcPlanSummaryPage, dcEarningsHistoryPage, participant, dcServiceInstance) => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(loginPage, dashboardPage, dcPlanSummaryPage,
      participant, dcServiceInstance);

    // go to the dcEarningsHistory page
    await this.browseToDcEarningsHistoryPageFromDcSummary(dcEarningsHistoryPage);
  };

  this.browseToDcEarningsHistoryPageFromDcSummary = async (dcEarningsHistoryPage) => {
    await commonTests.clickElement(dcEarningsHistoryPage.planHeader.earningsHistoryLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcEarningsHistoryPage);
  };

  this.showAnnualEarningsDetails = async (dcEarningsHistoryPage) => {
    const earningsCount = await dcEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);
    await checkers.exactText(dcEarningsHistoryPage.annualEarningsLink, 'ANNUAL EARNINGS');
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(earningsCount - 1));
  };

  this.showBonusDetails = async (dcEarningsHistoryPage) => {
    const earningsCount = await dcEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);
    await checkers.exactText(dcEarningsHistoryPage.salaryTypeTab(2), 'GROSS EARNINGS');
    expect(dcEarningsHistoryPage.salaryTypeTab(2).isEnabled()).toBe(true);
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(earningsCount - 1));
  };

  this.showPensionableSalaryDetails = async (dcEarningsHistoryPage) => {
    const earningsCount = await dcEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);
    await checkers.exactText(dcEarningsHistoryPage.salaryTypeTab(0), 'PENSIONABLE SALARY');
    expect(dcEarningsHistoryPage.salaryTypeTab(0).isEnabled()).toBe(true);
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dcEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dcEarningsHistoryPage.amountValue(earningsCount - 1));
  };
};
module.exports = dcEarningHistoryTests;
