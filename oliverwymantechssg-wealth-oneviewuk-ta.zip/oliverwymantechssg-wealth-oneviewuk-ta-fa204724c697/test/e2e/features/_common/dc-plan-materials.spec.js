// load common
const CommonTests = require('../../utilities/common-tests.js');
const DcPlanSummaryTests = require('./dc-plan-summary.spec');
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dcPlanMaterialsTests = function dcPlanMaterialsTests() {
  // exposed functions

  this.browseToDcPlanMaterialsPageFromLogin
    = async (loginPage, dashboardPage, dcPlanSummaryPage, dcPlanMaterialsPage, participant, dcServiceInstance) => {
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, participant, dcServiceInstance);

      // go to the PlanMaterial page
      await this.browseToPlanMaterialsPageFromDcSummary(dcPlanSummaryPage, dcPlanMaterialsPage);
    };

  this.browseToPlanMaterialsPageFromDcSummary = async (dcPlanSummaryPage, dcPlanMaterialsPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dcPlanSummaryPage,
      dcPlanSummaryPage.planHeader.planMaterialsLink,
      'material',
      dcPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcPlanMaterialsPage);
  };
};
module.exports = dcPlanMaterialsTests;
