// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const helpAndContactsTests = function helpAndContactsTests() {
  // private functions


  // private properties

  const self = this;
  const until = protractor.ExpectedConditions;


  // exposed properties


  // exposed functions

  this.browseToHelpAndContactsPageFromLogin
    = async (loginPage, dashboardPage, helpAndContactsPage, participant, requiredTab) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
      await self.browseToHelpAndContactsPageFromDashboard(
        dashboardPage, helpAndContactsPage, participant, requiredTab);
    };

  this.browseToHelpAndContactsPageFromDashboard
    = async (dashboardPage, helpAndContactsPage, participant, requiredTab) => {
      await commonTests.clickCommonHeaderLink(
        dashboardPage.header, dashboardPage.header.commonHeaderLinkEnum.help, true);
      await commonTests.checkPageLoadsAndContainsStandardElements(helpAndContactsPage);
      await self.clickRequiredTabOfHelpAndContactsPage(helpAndContactsPage, requiredTab, true);
    };

  this.browseToHelpAndContactsPageWithoutLogin
    = async (loginPage, forgotUserCredentialPage, helpAndContactsPage, participant, requiredTab) => {
      await commonTests.clickElement(loginPage.forgotUserIdLink);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(forgotUserCredentialPage, true);
      await commonTests.clickCommonHeaderLink(
        forgotUserCredentialPage.header, forgotUserCredentialPage.header.commonHeaderLinkEnum.help, false);
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(helpAndContactsPage, false);
      await self.clickRequiredTabOfHelpAndContactsPage(helpAndContactsPage, requiredTab, false);
    };

  this.browseToContactUsType = async (helpAndContactsPage, requiredContactUsType) => {
    let contactUsTypeDesktopSubTab;
    let contactUsMobileDropdownOption;
    let contactUsTypeUrl;
    let elementPresent;

    switch (requiredContactUsType) {
      case 'online':
        // contact us - online
        contactUsTypeDesktopSubTab = helpAndContactsPage.contactUsOnlineDesktopSubTab;
        contactUsMobileDropdownOption = helpAndContactsPage.contactUsOnlineMobileDropdownOption;
        contactUsTypeUrl = helpAndContactsPage.contactUsOnlineUrl;
        break;

      case 'phone':
        // contact us - phone
        contactUsTypeDesktopSubTab = helpAndContactsPage.contactUsPhoneDesktopSubTab;
        contactUsMobileDropdownOption = helpAndContactsPage.contactUsPhoneMobileDropdownOption;
        contactUsTypeUrl = helpAndContactsPage.contactUsPhoneUrl;
        break;

      case 'post':
        // contact us - post
        contactUsTypeDesktopSubTab = helpAndContactsPage.contactUsPostDesktopSubTab;
        contactUsMobileDropdownOption = helpAndContactsPage.contactUsPostMobileDropdownOption;
        contactUsTypeUrl = helpAndContactsPage.contactUsPostUrl;
        break;

      default:
        throw new Error(`The requiredContactUsType value '${requiredContactUsType}' is not supported`);
    }

    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        // select contact us tab
        elementPresent = browser.isElementPresent(contactUsTypeDesktopSubTab);

        if (elementPresent) {
          await commonTests.clickElement(contactUsTypeDesktopSubTab);
          await browser.wait(until.urlContains(contactUsTypeUrl), commonConstants.shortBrowserWaitDelay,
            `URL does not contain ${contactUsTypeUrl}`);
          expect(browser.getCurrentUrl()).toContain(contactUsTypeUrl);
        }
        break;

      case commonConstants.appDeviceTypeEnum.mobile:
        // contact us option from dropdown
        await commonTests.clickElement(helpAndContactsPage.contactUsTypeMobileDropDown);
        await commonTests.clickElement(contactUsMobileDropdownOption);
        await browser.wait(until.urlContains(contactUsTypeUrl), commonConstants.shortBrowserWaitDelay,
          `URL does not contain ${contactUsTypeUrl}`);
        expect(browser.getCurrentUrl()).toContain(contactUsTypeUrl);
        break;

      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  };

  async function clickContactUsTabOfHelpAndContactsPage(helpAndContactsPage, isAuthPage) {
    await commonTests.clickElement(helpAndContactsPage.contactUsTabLink);
    await browser.wait(
      until.urlContains(helpAndContactsPage.baseContactUsUrl), commonConstants.shortBrowserWaitDelay,
      `URL does not contain ${helpAndContactsPage.baseContactUsUrl}`);
    await checkHelpAndContactsPageLoads(helpAndContactsPage, isAuthPage);
    expect(browser.getCurrentUrl()).toContain(helpAndContactsPage.baseContactUsUrl);
  }

  async function checkHelpAndContactsPageLoads(helpAndContactsPage, isAuthPage) {
    if (isAuthPage) {
      await commonTests.checkPageLoadsAndContainsStandardElements(helpAndContactsPage);
    } else {
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(helpAndContactsPage, false);
    }
  }

  this.clickRequiredTabOfHelpAndContactsPage
    = async (helpAndContactsPage, requiredTab, isAuthPage) => {
      await checkHelpAndContactsPageLoads(helpAndContactsPage, isAuthPage);

      switch (requiredTab) {
        case 'help':
          await commonTests.clickElement(helpAndContactsPage.helpTabLink);
          await browser.wait(
            until.urlContains(helpAndContactsPage.helpUrl), commonConstants.shortBrowserWaitDelay,
            `URL does not contain ${helpAndContactsPage.helpUrl}`);
          await checkHelpAndContactsPageLoads(helpAndContactsPage, isAuthPage);
          expect(browser.getCurrentUrl()).toContain(helpAndContactsPage.helpUrl);
          break;

        case 'contact us':
          // contact us - default - note use of baseContactUsUrl
          await clickContactUsTabOfHelpAndContactsPage(helpAndContactsPage, isAuthPage);
          break;

        case 'online':
        case 'phone':
        case 'post':
          // contact us - online / phone / post
          await clickContactUsTabOfHelpAndContactsPage(helpAndContactsPage, isAuthPage);
          await this.browseToContactUsType(helpAndContactsPage, requiredTab);
          break;

        default:
          throw new Error(`The requiredTab value '${requiredTab}' is not supported`);
      }
    };

  this.checkHelpTopicsAndSubTopics = async (helpAndContactsPage) => {
    const topicCount = await helpAndContactsPage.getHelpTopicCount();

    if (topicCount <= 0) {
      fail('Expecting 1 or more topics');
    } else {
      let i;

      for (i = 0; i < topicCount; i += 1) {
        await checkers.anyImage(helpAndContactsPage.helpTopicIcon(i));
        await checkers.anyText(helpAndContactsPage.helpTopicLabel(i));
        await checkers.containingImage(helpAndContactsPage.helpTopicExpander(i),
          commonConstants.keyboardArrowDownImageSource);

        // TODO: get this working
        // self.checkHelpStories(i);
      }
    }
  };

  this.checkHelpStories = async (helpAndContactsPage, topicIndex) => {
    const topicExpander = await helpAndContactsPage.helpTopicExpander(topicIndex);

    await commonTests.clickElement(topicExpander);
    const helpStoryCount = await helpAndContactsPage.getHelpStoryCount(topicIndex);

    if (helpStoryCount <= 0) {
      fail(`Expecting 1 or more help stories under topic ${topicIndex}`);
    } else {
      let s;

      for (s = 0; s < helpStoryCount; s += 1) {
        // check help stories
        await checkers.anyText(helpAndContactsPage.helpStoryLabel(topicIndex, s));
        await checkers.containingImage(helpAndContactsPage.helpStoryExpander(topicIndex, s),
          commonConstants.keyboardArrowDownImageSource);
        await self.checkHelpStoryContent(helpAndContactsPage, topicIndex, s);

        // TODO: if auth topic is 'Using Mercer OneView' check existence of 'OV1 TE auth help story'
        // TODO: if unauth topic is 'Using Mercer OneView' check existence of 'OV1 TE unauth help story'
      }

      await commonTests.clickElement(topicExpander);
      let st;

      for (st = 0; st < helpStoryCount; st += 1) {
        // check help stories hidden
        expect(helpAndContactsPage.helpStoryLabel(topicIndex, st).isDisplayed()).toBe(false);
        expect(helpAndContactsPage.helpStoryExpander(topicIndex, st).isDisplayed()).toBe(false);

        // TODO: if help story is 'OV1 TE auth help story' check content is 'OV1 TE auth help story'
        // TODO: if help story is 'OV1 TE unauth help story' check content is 'OV1 TE unauth help story'
      }
    }
  };

  this.checkHelpStoryContent = async (helpAndContactsPage, topicIndex, helpStoryIndex) => {
    const helpStory = await helpAndContactsPage.helpStoryContent(topicIndex, helpStoryIndex);
    expect(helpStory.isDisplayed()).toBe(false);

    await commonTests.clickElement(helpAndContactsPage.helpStoryExpander(topicIndex, helpStoryIndex));
    expect(helpStory.isDisplayed()).toBe(true);
    await checkers.anyText(helpStory);
    await commonTests.clickElement(helpAndContactsPage.helpStoryExpander(topicIndex, helpStoryIndex));
    expect(helpStory.isDisplayed()).toBe(false);
  };
};
module.exports = helpAndContactsTests;
