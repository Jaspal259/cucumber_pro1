// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load component objects
const CookiePolicy = require('../../page-component-objects/cookie-policy.co.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const cookiePolicy = new CookiePolicy();

// tests
const LoginTests = function LoginTests() {
  // private functions


  // private properties


  // exposed properties


  // exposed functions

  this.checkLoginPageLoadsWithoutClickingOnAgreeCookiePolicyPrompt = async (loginPage) => {
    /*
      waitForAngularEnabled = true added here to ensure Angular waiting is switched on
      (can be switched off when testing non-Angular pages such as PDF downloads)
     */
    try {
      await browser.waitForAngularEnabled(true);
    } catch (e) {
      resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
    }

    await commonTests.printToConsoleLogWithDateTime(`Login page requested: ${loginPage.url}`);

    /*
      it now looks like - from watching a local debug test on Chrome QA run after:
       - clearing node_modules folder
       - re-installing with: npm install
       - clearing Chrome cache
      that calling the login URL is sometimes failing not because the OV3 site is slow but because
      firing up the WebDriver connection to Chrome is slow (suspect that this has been happening on
      Jenkins)

      to try and solve this the standard getPageTimeout of 40000ms (40s) is being increased for the login
      page to 60000ms (60s)
     */
    await browser.get(loginPage.url, commonConstants.longBrowserWaitDelay);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  };

  this.checkLoginPageLoads = async (loginPage) => {
    // note function call required as OUK-1028 requires login page load check without clicking on cookie prompt
    await this.checkLoginPageLoadsWithoutClickingOnAgreeCookiePolicyPrompt(loginPage);
    await cookiePolicy.agreeCookiePolicy(true);

    // ensure page is loaded fully after clicking cookie policy agree button
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  };

  this.attemptLogin = async (loginPage, participant) => {
    await this.checkLoginPageLoads(loginPage);
    const userIdPresent = await browser.isElementPresent(loginPage.userIdInput);

    if (userIdPresent) {
      await loginPage.userIdInput.sendKeys(participant.data.userId);
    } else {
      fail('User ID input not shown');
    }

    const passcodePresent = await browser.isElementPresent(loginPage.passcodeInput);

    if (passcodePresent) {
      const passcode = participant.data.passcode();
      await loginPage.passcodeInput.sendKeys(passcode);
    } else {
      fail('Passcode input not shown');
    }

    const loginBtnPresent = await browser.isElementPresent(loginPage.loginBtn);

    if (loginBtnPresent) {
      await commonTests.clickElement(loginPage.loginBtn);
    } else {
      fail('Login button not shown');
    }

    return true;
  };

  this.checkPageElements = async (loginPage) => {
    await checkers.containingText(loginPage.welcomeMessageLabel(global.deviceType), 'Welcome to');
    await checkers.containingImage(loginPage.largeMercerLogo(global.deviceType), 'logo');

    await checkers.containingTextIgnoreCase(loginPage.loginFormSelectedTab,
      loginPage.loginFormSelectedTabDefaultText);
    await checkers.containingTextIgnoreCase(loginPage.loginFormUnselectedTab,
      loginPage.loginFormUnselectedTabDefaultText);

    await checkers.containingTextIgnoreCase(loginPage.userIdLabel, 'User ID');
    await checkers.inputNoText(loginPage.userIdInput);

    await checkers.containingTextIgnoreCase(loginPage.passcodeLabel, 'Passcode');
    await checkers.inputNoText(loginPage.passcodeInput);

    await checkers.containingTextIgnoreCase(loginPage.loginBtn, 'Log In');
    await checkers.isMercerOsButtonSelected(loginPage.loginBtn);
    expect(loginPage.loginBtn.isEnabled()).toBe(true, 'Login button is disabled');

    await checkers.anyTextOf20CharsPlus(loginPage.forgetCredentialLabel);
    await checkers.containingTextIgnoreCase(loginPage.forgotUserIdLink, 'User ID');
    await checkers.containingTextIgnoreCase(loginPage.forgotPasscodeLink, 'Passcode');
  };
};
module.exports = LoginTests;
