// load common
const CommonTests = require('../../utilities/common-tests.js');
const PensionerPlanSummaryTests = require('./pensioner-plan-summary.spec');
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const pensionsPlanMaterialsTests = function pensionsPlanMaterialsTests() {
  // private properties

  // exposed functions
  this.browseToPensionsPlanMaterialsPageFromLogin
    = async (loginPage, dashboardPage, pensionerPlanSummaryPage, pensionsPlanMaterialsPage,
      participant, pensionsServiceInstance) => {
      await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
        loginPage, dashboardPage, pensionerPlanSummaryPage, participant, pensionsServiceInstance);

      // go to the PlanMaterial page
      await this.browseToPensionPlanMaterialsPageFromPensionerSummary(
        pensionerPlanSummaryPage, pensionsPlanMaterialsPage);
    };

  this.browseToPensionPlanMaterialsPageFromPensionerSummary
    = async (pensionerPlanSummaryPage, pensionsPlanMaterialsPage) => {
      await planHeaderTests.clickPlanHeaderNavigationMenuLink(
        pensionerPlanSummaryPage,
        pensionerPlanSummaryPage.planHeader.planMaterialsLink,
        'material',
        pensionerPlanSummaryPage.planHeader);
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionsPlanMaterialsPage);
    };
};

module.exports = pensionsPlanMaterialsTests;
