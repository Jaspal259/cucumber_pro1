// load common
const PensionerPlanSummaryTests = require('./pensioner-plan-summary.spec.js');
const BudgetPlannerTests = require('./budget-planner.spec.js');

// create new objects
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const budgetPlannerTests = new BudgetPlannerTests();

// tests
const pensionerBudgetPlannerTests = function pensionerBudgetPlannerTests() {
  // private properties
  const self = this;

  // exposed functions
  this.browseToPensionerBudgetPlannerPageFromLogin
    = async (loginPage, dashboardPage, pensionerPlanSummaryPage,
      pensionerBudgetPlannerPage, participant, pensionerServiceInstance) => {
      await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(loginPage, dashboardPage,
        pensionerPlanSummaryPage, participant, pensionerServiceInstance);

      // go to the Budget planner page
      await self.browseToPensionerBudgetPlannerPageFromPensionerSummary(
        pensionerPlanSummaryPage, pensionerBudgetPlannerPage);
    };

  this.browseToPensionerBudgetPlannerPageFromPensionerSummary
    = async (pensionerPlanSummaryPage, pensionerBudgetPlannerPage) => {
      await budgetPlannerTests.browseToBudgetPlannerPageFromPlanSummary(
        pensionerPlanSummaryPage, pensionerBudgetPlannerPage);
    };

  this.browseToPensionerEditBudgetFromBudgetPlannerPage
    = async (pensionerBudgetPlannerPage, pensionerBudgetPlannerDefault, pensionerBudgetPlannerEdit) => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        pensionerBudgetPlannerPage, pensionerBudgetPlannerDefault, pensionerBudgetPlannerEdit);
    };
};
module.exports = pensionerBudgetPlannerTests;
