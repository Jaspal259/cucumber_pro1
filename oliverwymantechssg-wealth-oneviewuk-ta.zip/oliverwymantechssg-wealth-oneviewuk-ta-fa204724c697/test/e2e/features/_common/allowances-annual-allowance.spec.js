// load common
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const DashboardTests = require('./dashboard.spec.js');
const PensionerPlanSummaryTests = require('./pensioner-plan-summary.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();

// tests
const annualAllowanceTest = function annualAllowanceTest() {
  // private functions

  // private properties

  const self = this;

  // exposed properties

  // exposed functions

  this.browseToPensionerAllowancesPageFromLogin
    = async (loginPage, dashboardPage, annualAllowancePage, participant) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
      await self.browseToPensionerAllowancesPageFromDashBoard(dashboardPage, annualAllowancePage);
    };

  this.browseToPensionerAllowancesPageFromDashBoard = async (page, annualAllowancePage) => {
    await commonTests.clickElement(page.header.commonHeaderAllowances);
    expect(annualAllowancePage.annualAllowanceTab.isDisplayed()).toBe(true);
    await commonTests.checkPageLoadsAndContainsStandardElements(annualAllowancePage);
  };

  this.browseToLifetimeAllowancePageFromLogin
    = async (loginPage, dashboardPage, pensionerPlanSummaryPage,
      annualAllowancePage, participant, pensionerServiceInstance) => {
      await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(loginPage, dashboardPage,
        pensionerPlanSummaryPage, participant, pensionerServiceInstance);
      await commonTests.clickElement(annualAllowancePage.planHeader.allowancesLink);
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(annualAllowancePage);
      await this.browseToLifeTimeAllowancePageFromAllowancePage(annualAllowancePage);
    };

  this.browseToLifeTimeAllowancePageFromAllowancePage = async (annualAllowancePage) => {
    await commonTests.clickElement(annualAllowancePage.lifeTimeAllowanceTab);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(annualAllowancePage);
    expect(browser.getCurrentUrl()).toContain(annualAllowancePage.lifeTimeAllowance);
  };

  this.checkLifeTimeAllowanceData = async (allowancePage, rowIndex) => {
    await checkers.anyText(allowancePage.scheme(rowIndex));
    await checkers.anyImage(allowancePage.statusEffectiveDate(rowIndex));
    await checkers.anyText(allowancePage.effectiveDate(rowIndex));
    await checkers.anyImage(allowancePage.allowancePercent(rowIndex));
  };
};

module.exports = annualAllowanceTest;
