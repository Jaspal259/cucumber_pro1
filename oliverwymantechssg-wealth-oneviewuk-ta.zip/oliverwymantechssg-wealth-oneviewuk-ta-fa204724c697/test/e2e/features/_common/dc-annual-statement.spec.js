// load common
const CommonTests = require('../../utilities/common-tests.js');
const DcPlanSummaryTests = require('./dc-plan-summary.spec.js');

// create new objects
const commonTests = new CommonTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();

// tests
const dbAnnualStatementTests = function dbAnnualStatementTests() {
  // private properties
  const self = this;

  // exposed functions
  this.browseToDcAnnualStatementPageFromLogin
    = async (loginPage, dashboardPage, dcPlanSummaryPage, dcAnnualStatementPage, participant, dcServiceInstance) => {
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, participant, dcServiceInstance);
      await self.browseToDcAnnualStatementPageFromDbSummary(dcPlanSummaryPage, dcAnnualStatementPage);
    };

  this.browseToDcAnnualStatementPageFromDbSummary = async (dcPlanSummaryPage, dcAnnualStatementPage) => {
    await commonTests.clickElement(dcPlanSummaryPage.planHeader.annualBenefitStatementLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcAnnualStatementPage);
  };
};
module.exports = dbAnnualStatementTests;
