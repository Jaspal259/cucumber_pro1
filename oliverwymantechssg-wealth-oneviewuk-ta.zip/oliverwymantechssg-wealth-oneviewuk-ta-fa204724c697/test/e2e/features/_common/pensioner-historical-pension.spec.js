// load common
const CommonTests = require('../../utilities/common-tests.js');
const PensionPlanSummaryTests = require('./pensioner-plan-summary.spec');

// create new objects
const commonTests = new CommonTests();
const pensionPlanSummaryTests = new PensionPlanSummaryTests();

// tests
const pensionsHistoricalPensionTests = function pensionsHistoricalPensionTests() {
  // private properties

  // exposed functions
  this.browseToPensionsHistoricalPensionPageFromLogin
    = async (loginPage, dashboardPage, pensionerPlanSummaryPage,
      pensionsHistoricalPensionPage, participant, pensionsServiceInstance) => {
      await pensionPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(loginPage, dashboardPage,
        pensionerPlanSummaryPage, participant, pensionsServiceInstance);

      await this.browseToPensionsHistoricalPensionPageFromPIPSummary(pensionsHistoricalPensionPage);
    };

  this.browseToPensionsHistoricalPensionPageFromPIPSummary = async (pensionsHistoricalPensionPage) => {
    await commonTests.clickElement(pensionsHistoricalPensionPage.planHeader.historicalPensionLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionsHistoricalPensionPage);
  };
};
module.exports = pensionsHistoricalPensionTests;
