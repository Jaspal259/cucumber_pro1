/*
    NOTE:
    This test library contains tests specific to DC, DB and pensioner which have been gathered here for
    ease of maintenance
 */

// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// other
const until = protractor.ExpectedConditions;

// tests
const planHeaderTests = function planHeaderTests() {
  // private functions

  // private properties

  const self = this;


  // exposed properties


  // exposed functions

  /**
    * @example
    * revealAndCheckPlanHeaderNavigationMenuLink(
    *   pensionerPlanSummaryPage,
    *   pensionerPlanSummaryPage.planHeader.bankAccountDetailsLink,
    *   'Bank',
    *   pensionerPlanSummaryPage.planHeader);
    */
  this.revealAndCheckPlanHeaderNavigationMenuLink = async (page, linkElement, linkText, planHeader) => {
    const linkPresent = await browser.isElementPresent(linkElement);

    if (linkPresent) {
      await checkers.containingTextIgnoreCase(linkElement, linkText);
    } else {
      await browser.wait(
        until.elementToBeClickable(planHeader.moreButton),
        commonConstants.shortBrowserWaitDelay,
        'Plan header navigation \'More\' button not shown / cannot be clicked');
      await checkers.containingTextIgnoreCase(planHeader.moreButton, planHeader.moreButtonText);
      await commonTests.clickElement(planHeader.moreButton);

      // re-check the page itself is loaded - use unauth check as less checks than auth page check
      await commonTests.checkUnauthPageLoadsAndContainsStandardElements(page, true);

      await browser.wait(
        until.visibilityOf(linkElement),
        commonConstants.mediumMediumBrowserWaitDelay,
        'Plan header navigation element not shown');
      await checkers.containingTextIgnoreCase(linkElement, linkText);
    }
  };

  /**
    * @example
    * clickPlanHeaderNavigationMenuLink(
    *   pensionerPlanSummaryPage,
    *   pensionerPlanSummaryPage.planHeader.bankAccountDetailsLink,
    *   'Bank',
    *   pensionerPlanSummaryPage.planHeader);
    */
  this.clickPlanHeaderNavigationMenuLink = async (page, linkElement, linkText, planHeader) => {
    await this.revealAndCheckPlanHeaderNavigationMenuLink(page, linkElement, linkText, planHeader);
    await browser.wait(
      until.elementToBeClickable(linkElement),
      commonConstants.shortBrowserWaitDelay,
      'Plan header navigation element not shown / cannot be clicked');
    await commonTests.clickElement(linkElement);
  };

  this.verifyCardContentScenario = (planHeader, pos) => {
    self.checkPlanName(planHeader, pos);
    self.checkMemberStatus(planHeader, pos);
    self.checkDateOfExit(planHeader, pos);
    self.checkDateJoinedPlan(planHeader, pos);
    self.checkRetirementDate(planHeader, pos);
  };

  this.checkPlanName = (planHeader, pos) => {
    it('AND [PLAN NAME] (OUK-102)', async () => {
      await checkers.containingTextIgnoreCase(planHeader.longSchemeNameValue, pos.scheme.data.longSchemeNameValue);
    });
  };

  this.checkMemberStatus = (planHeader, pos) => {
    it('AND [MEMBER STATUS] (OUK-103)', async () => {
      await checkers.containingTextIgnoreCase(planHeader.posStatusLabel, pos.data.posStatusLabel);
      await checkers.containingTextIgnoreCase(planHeader.posStatusValue, pos.data.posStatusValue);
    });
  };

  this.checkDateJoinedPlan = (planHeader, pos) => {
    it('AND [DATE JOINED PLAN] (OUK-108)', async () => {
      if (pos.data.posStatusValueAsNumber === 1 || pos.data.posStatusValueAsNumber === 4) {
        expect(planHeader.dateJoinedSchemeLabel.isDisplayed()).toBe(true);
        expect(planHeader.dateJoinedSchemeValue.isDisplayed()).toBe(true);
      } else {
        expect(planHeader.dateJoinedSchemeLabel.isPresent()).toBe(false);
        expect(planHeader.dateJoinedSchemeValue.isPresent()).toBe(false);
      }
    });
  };

  this.checkDateOfExit = (planHeader, pos) => {
    it('AND [DATE OF EXIT] (OUK-108)', async () => {
      if (pos.data.posStatusValueAsNumber === 4) {
        expect(planHeader.dateOfExitLabel.isDisplayed()).toBe(true);
        expect(planHeader.dateOfExitValue.isDisplayed()).toBe(true);
      } else {
        expect(planHeader.dateOfExitLabel.isPresent()).toBe(false);
        expect(planHeader.dateOfExitValue.isPresent()).toBe(false);
      }
    });
  };

  this.checkRetirementDate = (planHeader, pos) => {
    it('AND [RETIREMENT DATE] (OUK-122)', async () => {
      await self.checkRetirementDateLabelAndValue(planHeader, pos);
    });
  };

  this.checkRetirementDateLabelAndValue = async (planHeader, pos) => {
    if (pos.data.planType !== 'Pensioner') {
      await self.isRetirementDateLabelShown(planHeader.dateOfRetirementLabel, planHeader.dateOfRetirementInfoIcon, pos);
      await checkers.exactUkDate(planHeader.dateOfRetirementValue, pos.data.trdValue);
    } else {
      expect(planHeader.dateOfRetirementLabel.isPresent()).toBe(false);
      expect(planHeader.dateOfRetirementInfoIcon.isPresent()).toBe(false);
      expect(planHeader.dateOfRetirementValue.isPresent()).toBe(false);
    }
  };

  this.isRetirementDateLabelShown = async (dateOfRetirementLabel, dateOfRetirementInfoIcon, pos) => {
    // because of the way the retirement label is built it includes the info icon hence
    // the need for more complex code here
    await checkers.containingTextIgnoreCase(dateOfRetirementLabel, pos.data.retirementDateLabel);
  };

  this.checkCardContentIsRelevantToPos = async (planHeader, pos) => {
    const scheme = pos.scheme;
    await checkers.containingTextIgnoreCase(planHeader.typeLabel, pos.data.typeLabel);
    await checkers.containingTextIgnoreCase(planHeader.longSchemeNameValue, scheme.data.longSchemeNameValue);

    await checkers.containingTextIgnoreCase(planHeader.posStatusLabel, pos.data.posStatusLabel);
    await checkers.containingTextIgnoreCase(planHeader.posStatusValue, pos.data.posStatusValue);

    await checkers.containingTextIgnoreCase(planHeader.dateJoinedSchemeLabel, pos.data.dateJoinedSchemeLabel);
    await checkers.exactUkDate(planHeader.dateJoinedSchemeValue, pos.data.dateJoinedSchemeValue);

    if (pos.data.posStatusValueAsNumber === 4) {
      await checkers.containingTextIgnoreCase(planHeader.dateOfExitLabel, pos.data.dateOfExitLabel);
      await checkers.exactUkDate(planHeader.dateOfExitValue, pos.data.dateOfExitValue);
    }

    await self.checkRetirementDateLabelAndValue(planHeader, pos);
  };
};
module.exports = planHeaderTests;
