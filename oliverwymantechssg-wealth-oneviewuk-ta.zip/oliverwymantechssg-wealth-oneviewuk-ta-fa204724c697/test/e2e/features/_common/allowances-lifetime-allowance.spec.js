// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const lifetimeAllowanceTest = function lifetimeAllowanceTest() {
  // private functions

  // private properties

  const self = this;

  // exposed properties

  // exposed functions

  this.browseToLifetimeAllowancePageFromLogin
    = async (loginPage, dashboardPage, lifetimeAllowancePage, participant) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
      await self.browseToLifetimeAllowancePageFromDashBoard(dashboardPage, lifetimeAllowancePage);
    };

  this.browseToLifetimeAllowancePageFromDashBoard = async (page, lifetimeAllowancePage) => {
    await commonTests.clickElement(page.header.commonHeaderAllowances);
    expect(lifetimeAllowancePage.annualAllowanceTab.isDisplayed()).toBe(true);
    await commonTests.clickElement(lifetimeAllowancePage.lifetimeTab);
    await commonTests.checkPageLoadsAndContainsStandardElements(lifetimeAllowancePage);
  };
};

module.exports = lifetimeAllowanceTest;
