// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const dcPlanSummaryTests = function dcPlanSummaryTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions

  this.browseToDcPlanSummaryPageFromLogin
    = async (loginPage, dashboardPage, dcPlanSummaryPage, participant, dcServiceInstance) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);

      // go to the DC plan summary page
      await self.browseToDcPlanSummaryPageFromDashboard(dashboardPage, dcPlanSummaryPage, dcServiceInstance);
    };

  this.browseToDcPlanSummaryPageFromDashboard = async (dashboardPage, dcPlanSummaryPage, dcServiceInstance) => {
    switch (dcServiceInstance) {
      case 0:
        await commonTests.clickElement(dashboardPage.dcCard0.detailsButton(global.deviceType));
        break;

      case 1:
        await commonTests.clickElement(dashboardPage.dcCard1.detailsButton(global.deviceType));
        break;

      default:
        throw new Error(`Does not support dcServiceInstance === ${dcServiceInstance}`);
    }

    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcPlanSummaryPage);
  };
};
module.exports = dcPlanSummaryTests;
