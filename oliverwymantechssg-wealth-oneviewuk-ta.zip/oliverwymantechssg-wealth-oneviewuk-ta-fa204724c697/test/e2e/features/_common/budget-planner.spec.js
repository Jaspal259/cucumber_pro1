/*
    NOTE:
    This test library contains tests specific to DC, DB and pensioner which have been gathered here for
    ease of maintenance
 */

// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');

// load tests
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const planHeaderTests = new PlanHeaderTests();

// other
const until = protractor.ExpectedConditions;

// tests
const budgetPlannerTests = function budgetPlannerTests() {
  // private functions
  // --------------------------------------------------


  // exposed functions
  // --------------------------------------------------

  this.browseToBudgetPlannerPageFromPlanSummary = async (planSummaryPage, budgetPlannerPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      planSummaryPage,
      planSummaryPage.planHeader.budgetingLink,
      'budget',
      planSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);

    // required as budgetPlannerPage.url is more of a root URL
    expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.defaultBudgetUrl);
  };

  this.browseToEditBudgetFromBudgetPlannerPage
    = async (budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit) => {
      await commonTests.clickElement(budgetPlannerDefault.setBudgetButton);
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);
      await browser.wait(
        until.visibilityOf(budgetPlannerEdit.cancelButton(global.deviceType)),
        commonConstants.briefBrowserWaitDelay,
        'Edit budget page probably not loaded as cancel button not shown');
      expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.setBudgetUrl);
    };
};
module.exports = budgetPlannerTests;
