// load common
const CommonTests = require('../../utilities/common-tests.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const pensionerChangeBankAccountDetailsTests = function pensionerChangeBankAccountDetailsTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions
  this.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage,
    participant, pensionerServiceInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, participant, pensionerServiceInstance);
    await self.browseToChangeBankAccountDetailsPageFromPlanSummaryPage(
      pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage);
  };

  this.browseToChangeBankAccountDetailsPageFromPlanSummaryPage = async (
    pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage) => {
    const planHeader = pensionerPlanSummaryPage.planHeader;
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      pensionerPlanSummaryPage,
      planHeader.bankAccountDetailsLink,
      planHeader.bankAccountDetailsLinkText,
      planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionerChangeBankAccountDetailsPage);
    expect(browser.getCurrentUrl()).toContain(
      pensionerPlanSummaryPage.url + pensionerChangeBankAccountDetailsPage.partialUrl);
  };

  this.cancelBankAccountEditConfirmingLoseChanges = async (pensionerChangeBankAccountDetailsPage) => {
    await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsCancelButton);
    await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.loseChangesConfirmButton(global.deviceType));
  };
};
module.exports = pensionerChangeBankAccountDetailsTests;
