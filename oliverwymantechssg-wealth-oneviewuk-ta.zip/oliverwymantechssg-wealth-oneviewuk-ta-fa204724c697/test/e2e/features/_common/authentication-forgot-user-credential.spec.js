// load common
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load tests
const CommonTests = require('../../utilities/common-tests.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// other
const until = protractor.ExpectedConditions;

// tests
const ForgotUserCredentialTests = function ForgotUserCredentialTests() {
  // private functions


  // private properties


  // exposed properties


  // exposed functions

  this.checkElementsAtTopOfPage = async (forgotUserCredentialPage) => {
    if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      await checkers.containingTextIgnoreCase(forgotUserCredentialPage.helpAndContactUsLink, 'Help & Contacts');
    }
  };

  this.checkDefaultUserIdControlElements = async (forgotUserCredentialPage) => {
    await checkers.containingImage(forgotUserCredentialPage.defaultUserIdIcon,
      commonConstants.personImageSource);
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.defaultUserIdLabel, 'User ID');
    await checkers.inputNoText(forgotUserCredentialPage.defaultUserIdInput);
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdLink, 'Forgot');
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.forgotUserIdLink, 'User ID');
  };

  this.checkEmailAddressControlElements = async (forgotUserCredentialPage) => {
    await checkers.containingImage(forgotUserCredentialPage.emailAddressIcon,
      commonConstants.emailOutlineImageSource);
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.emailAddressLabel, 'E-mail Address');
    await checkers.inputNoText(forgotUserCredentialPage.emailAddressInput);
  };

  this.checkCardFooterElements = async (forgotUserCredentialPage) => {
    // includes tests for OUK-6213 - note will check false once 6213 finished by Dev
    expect(forgotUserCredentialPage.backButton.isPresent()).toBe(true);

    // rest of tests
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.cancelButton, 'Cancel');
    await checkers.isMercerOsButtonUnselected(forgotUserCredentialPage.cancelButton);
    expect(forgotUserCredentialPage.cancelButton.isEnabled()).toBe(true);
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.continueButton, 'Continue');
    await checkers.isMercerOsButtonSelected(forgotUserCredentialPage.continueButton);
    expect(forgotUserCredentialPage.continueButton.isEnabled()).toBe(false);
  };

  this.checkElementsOnPageCommonToForgotUserIdAndForgotPasscode = async (forgotUserCredentialPage) => {
    await this.checkElementsAtTopOfPage(forgotUserCredentialPage);
    await this.checkDefaultUserIdControlElements(forgotUserCredentialPage);
    await this.checkEmailAddressControlElements(forgotUserCredentialPage);
    await this.checkCardFooterElements(forgotUserCredentialPage);
  };

  this.checkValidUserIdAndEmailCanBeEntered = async (forgotUserCredentialPage, loginPage, participant) => {
    await forgotUserCredentialPage.defaultUserIdInput.sendKeys(participant.data.userId);
    await forgotUserCredentialPage.emailAddressInput.sendKeys(participant.data.emailAddress);
    await commonTests.clickElement(forgotUserCredentialPage.continueButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  };

  this.checkInvalidEmailRejected = async (forgotUserCredentialPage, invalidEmail) => {
    await forgotUserCredentialPage.emailAddressInput.clear();
    await forgotUserCredentialPage.emailAddressInput.sendKeys(invalidEmail);
    await commonTests.clickElement(forgotUserCredentialPage.defaultUserIdInput);
    await browser.wait(
      until.visibilityOf(forgotUserCredentialPage.emailAddressFieldError),
      commonConstants.briefBrowserWaitDelay,
      'No error displayed to state e-mail is invalid');
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.emailAddressFieldError,
      'must contain @ and .');
  };

  this.checkSetOfInvalidEmailsRejected = async (forgotUserCredentialPage) => {
    await this.checkInvalidEmailRejected(forgotUserCredentialPage, '#@%^%#$@#$@#.com');
    await this.checkInvalidEmailRejected(forgotUserCredentialPage, '@test.com');
    await this.checkInvalidEmailRejected(forgotUserCredentialPage, 'email.test.com');
    await this.checkInvalidEmailRejected(forgotUserCredentialPage, 'email@test..com');
  };

  this.checkBlankUserIdRejected = async (forgotUserCredentialPage) => {
    await forgotUserCredentialPage.defaultUserIdInput.sendKeys('sdf');
    await forgotUserCredentialPage.defaultUserIdInput.clear();
    await commonTests.clickElement(forgotUserCredentialPage.emailAddressInput);
    await forgotUserCredentialPage.emailAddressInput.sendKeys('a');
    await browser.wait(
      until.visibilityOf(forgotUserCredentialPage.userIdFieldError),
      commonConstants.briefBrowserWaitDelay,
      'No error displayed to state user ID is blank');
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.userIdFieldError, 'User ID');
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.userIdFieldError, 'required');
  };

  this.checkCancel = async (forgotUserCredentialPage, loginPage) => {
    await checkers.containingTextIgnoreCase(forgotUserCredentialPage.cancelButton, 'Cancel');
    await commonTests.clickElement(forgotUserCredentialPage.cancelButton);
    await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
  };
};
module.exports = ForgotUserCredentialTests;
