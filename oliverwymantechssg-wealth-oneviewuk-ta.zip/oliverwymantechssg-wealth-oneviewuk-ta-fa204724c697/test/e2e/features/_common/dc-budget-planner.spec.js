// load common
const DcPlanSummaryTests = require('./dc-plan-summary.spec.js');
const BudgetPlannerTests = require('./budget-planner.spec.js');

// create new objects
const dcPlanSummaryTests = new DcPlanSummaryTests();
const budgetPlannerTests = new BudgetPlannerTests();

// tests
const dcBudgetPlannerTests = function dcBudgetPlannerTests() {
  // private properties
  const self = this;

  // exposed functions
  this.browseToDcBudgetPlannerPageFromLogin
    = async (loginPage, dashboardPage, dcPlanSummaryPage, dcBudgetPlannerPage, participant, dcServiceInstance) => {
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(loginPage, dashboardPage,
        dcPlanSummaryPage, participant, dcServiceInstance);

      // go to the Budget planner page
      await self.browseToDcBudgetPlannerPageFromDcSummary(dcPlanSummaryPage, dcBudgetPlannerPage);
    };

  this.browseToDcBudgetPlannerPageFromDcSummary = async (dcPlanSummaryPage, dcBudgetPlannerPage) => {
    await budgetPlannerTests.browseToBudgetPlannerPageFromPlanSummary(dcPlanSummaryPage, dcBudgetPlannerPage);
  };

  this.browseToDcEditBudgetFromBudgetPlannerPage
    = async (dcBudgetPlannerPage, dcBudgetPlannerDefault, dcBudgetPlannerEdit) => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        dcBudgetPlannerPage, dcBudgetPlannerDefault, dcBudgetPlannerEdit);
    };
};
module.exports = dcBudgetPlannerTests;
