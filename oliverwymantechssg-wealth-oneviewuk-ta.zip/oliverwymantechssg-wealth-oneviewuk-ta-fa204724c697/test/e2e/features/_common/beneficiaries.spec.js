// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const tooltipTests = new TooltipTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const beneficiariesTests = function beneficiariesTests() {
  // private functions


  // private properties

  const self = this;
  const until = protractor.ExpectedConditions;


  // exposed properties


  // exposed functions

  this.browseToBeneficiariesPageViaDcPlanSummaryPage = async (
    loginPage, dashboardPage, dcPlanSummaryPage, beneficiariesPage, participant, posInstance) => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, posInstance);
    await self.browseToBeneficiariesPageFromPlanSummaryPage(
      dcPlanSummaryPage, beneficiariesPage);
  };

  this.browseToBeneficiariesPageViaDbPlanSummaryPage = async (
    loginPage, dashboardPage, dbPlanSummaryPage, beneficiariesPage, participant, posInstance) => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, participant, posInstance);
    await self.browseToBeneficiariesPageFromPlanSummaryPage(
      dbPlanSummaryPage, beneficiariesPage);
  };

  this.browseToBeneficiariesPageViaPipPlanSummaryPage = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, beneficiariesPage, participant, posInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, participant, posInstance);
    await self.browseToBeneficiariesPageFromPlanSummaryPage(
      pensionerPlanSummaryPage, beneficiariesPage);
  };

  this.browseToBeneficiariesPageFromPlanSummaryPage = async (summaryPage, beneficiariesPage) => {
    // note summary page has to be DB plan summary, DC plan summary or pensions in payment summary
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      summaryPage,
      summaryPage.planHeader.beneficiariesLink(global.deviceType),
      'beneficiaries',
      summaryPage.planHeader);

    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(beneficiariesPage);
    expect(browser.getCurrentUrl()).toContain(summaryPage.url + beneficiariesPage.partialUrl);

    // clear the message for too many beneficiaries if it is displayed
    const present = await browser.isElementPresent(beneficiariesPage.tooManyBeneficiariesMessageContinue);

    if (present) {
      await commonTests.clickElement(beneficiariesPage.tooManyBeneficiariesMessageContinue);
      const presentAgain = await browser.isElementPresent(beneficiariesPage.tooManyBeneficiariesMessageContinue);

      if (presentAgain) {
        fail('The tooManyBeneficiariesMessageContinue element should not now be shown');
      }
    }
  };

  this.checkBottomOfSummaryScreenElementsDisplayed = async (beneficiariesPage) => {
    // environments are set up slightly differently
    const ov3Environment = await commonTests.getOv3Environment();

    if (ov3Environment === commonConstants.appEnvironmentEnum.qa
    || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
      await checkers.anyText(beneficiariesPage.beneficiariesDisclaimer);
    }

    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(false);
    expect(beneficiariesPage.beneficiariesCancelButton(global.deviceType).isDisplayed()).toBe(true);
    expect(beneficiariesPage.beneficiariesCancelButton(global.deviceType).isEnabled()).toBe(false);
  };

  this.checkBottomOfSummaryScreenElementsHidden = (beneficiariesPage) => {
    expect(beneficiariesPage.beneficiariesDisclaimer.isPresent()).toBe(false);
    expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isPresent()).toBe(false);
    expect(beneficiariesPage.beneficiariesCancelButton(global.deviceType).isPresent()).toBe(false);
  };

  this.checkDobTooltipForName = async (beneficiariesPage, index) => {
    await tooltipTests.checkTooltipIsElementWithAnyText(
      beneficiariesPage.nameValue(index),
      beneficiariesPage.beneficiaryTypeValue(index, global.deviceType),
      beneficiariesPage.tooltips.firstRightTooltip);
  };

  this.checkTooltipForAddress = async (beneficiariesPage, index) => {
    const tooltip = await beneficiariesPage.tooltips.firstRightTooltip;
    const el = await beneficiariesPage.addressValue(index);
    let address = await el.getText();
    address = address.toLowerCase();
    let tableViewTip = beneficiariesPage.tooltips.dataTableValueView;
    tableViewTip = tableViewTip.toLowerCase();

    if (address.indexOf(tableViewTip) !== -1) {
      await tooltipTests.checkTooltipIsElementWithAnyText(
        el, beneficiariesPage.beneficiaryTypeValue(index, global.deviceType), tooltip);
    } else {
      await tooltipTests.checkTooltipNotShown(el, tooltip);
    }
  };

  this.checkTooltipForGuardian = async (beneficiariesPage, index) => {
    const tooltip = await beneficiariesPage.tooltips.firstRightTooltip;
    const el = await beneficiariesPage.guardianValue(index, global.deviceType);

    let guardianDetails = await el.getText();
    guardianDetails = guardianDetails.toLowerCase();
    let tableViewTip = beneficiariesPage.tooltips.dataTableValueView;
    tableViewTip = tableViewTip.toLowerCase();

    if (guardianDetails.indexOf(tableViewTip) !== -1) {
      await tooltipTests.checkTooltipIsElementWithAnyText(
        el, beneficiariesPage.beneficiaryTypeValue(index, global.deviceType), tooltip);
    } else {
      await tooltipTests.checkTooltipNotShown(el, tooltip);
    }
  };

  this.checkTooltipsForEditAndDeleteActionIcons = async (beneficiariesPage, index) => {
    const tooltip = await beneficiariesPage.tooltips.topTooltip;
    const elementWithNoTooltip = await beneficiariesPage.beneficiaryTypeValue(index, global.deviceType);

    await tooltipTests.checkTooltipIsElementWithText(
      beneficiariesPage.actionEdit(index, global.deviceType),
      elementWithNoTooltip,
      tooltip,
      'Edit');

    await tooltipTests.checkTooltipIsElementWithText(
      beneficiariesPage.actionDelete(index, global.deviceType),
      elementWithNoTooltip,
      tooltip,
      'Delete');
  };

  this.checkTooltipsAndDisclaimer = (beneficiariesPage) => {
    // note variables for middle and last rows are declared here and re-defined in the first it() block
    // then used in the subsequent it() blocks which is why all it() blocks are in the same function
    const firstRow = 0;
    let midRow = 0;
    let lastRow = 0;

    // check DOB tooltip on name cell
    // ----------------------------------------------------------------
    it('Name (DOB) tooltip: THEN [DISPLAY DOB] based on [DOB RECORDED]', async () => {
      const beneficiaryCount = await beneficiariesPage.getNumberOfBeneficiariesStored();

      if (beneficiaryCount === 1) {
        // no need to re-define
      } else if (beneficiaryCount === 2) {
        lastRow = 1;
      } else if (beneficiaryCount > 2) {
        // check first, mid and last data rows
        midRow = Math.round(beneficiaryCount / 2);
        lastRow = beneficiaryCount - 1;
      } else {
        fail('No beneficiaries listed');
      }

      // check page re-loads - this is to improve resilience of tooltip checking
      await browser.wait(until.visibilityOf(beneficiariesPage.nameValue(0)),
        commonConstants.shortBrowserWaitDelay,
        'Page has probably not re-loaded as name value in first row of beneficiaries table is not visible');

      // check at least 1 row
      await self.checkDobTooltipForName(beneficiariesPage, firstRow);

      if (midRow !== 0) {
        await self.checkDobTooltipForName(beneficiariesPage, midRow);
      }

      if (lastRow !== 0) {
        await self.checkDobTooltipForName(beneficiariesPage, lastRow);
      }
    });

    // check address details tooltip on address cell
    // ----------------------------------------------------------------
    it('Address tooltip: THEN [DISPLAY ADDRESS DATA] based on [ADDRESS STATUS]'
    + ' AND hide hover view when [MEMBER] moves away from [ADDRESS STATUS]', async () => {
      // check at least 1 row
      await self.checkTooltipForAddress(beneficiariesPage, firstRow);

      if (midRow !== 0) {
        await self.checkTooltipForAddress(beneficiariesPage, midRow);
      }

      if (lastRow !== 0) {
        await self.checkTooltipForAddress(beneficiariesPage, lastRow);
      }
    });

    // check guardian details tooltip on guardian cell
    // ----------------------------------------------------------------
    it('Guardian tooltip: THEN show [GUARDIAN STATUS] based on [GUARD NAME RECORDED]'
    + ' AND based on [GUARD ADDRESS RECORDED] [DISPLAY GUARD ADDRESS]'
    + ' AND hide hover view when [PARTICIPANT] moves away from [GUARDIAN STATUS]', async () => {
      // check at least 1 row
      await self.checkTooltipForGuardian(beneficiariesPage, firstRow);

      if (midRow !== 0) {
        await self.checkTooltipForGuardian(beneficiariesPage, midRow);
      }

      if (lastRow !== 0) {
        await self.checkTooltipForGuardian(beneficiariesPage, lastRow);
      }
    });

    // check tooltips for the edit and delete action icons
    // ----------------------------------------------------------------
    it('Additional: Check tooltips for the edit and delete action icons', async () => {
      // check at least 1 row
      await self.checkTooltipsForEditAndDeleteActionIcons(beneficiariesPage, firstRow);

      if (midRow !== 0) {
        await self.checkTooltipsForEditAndDeleteActionIcons(beneficiariesPage, midRow);
      }

      if (lastRow !== 0) {
        await self.checkTooltipsForEditAndDeleteActionIcons(beneficiariesPage, lastRow);
      }
    });

    // check disclaimer shown
    // ----------------------------------------------------------------
    it('Disclaimer: THEN show [DISCLAIMER VIEW] based on [ACTION]', async () => {
      await self.checkBottomOfSummaryScreenElementsDisplayed(beneficiariesPage);
    });
  };

  this.checkCancelAndBackLinks = (beneficiariesPage, summaryType, returnPage) => {
    it('Cancel button: THEN Save button and Cancel buttons disabled', async () => {
      expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isDisplayed()).toBe(true);
      expect(beneficiariesPage.beneficiariesSaveButton(global.deviceType).isEnabled()).toBe(false);
      expect(beneficiariesPage.beneficiariesCancelButton(global.deviceType).isDisplayed()).toBe(true);
      expect(beneficiariesPage.beneficiariesCancelButton(global.deviceType).isEnabled()).toBe(false);
    });

    /*
      WHEN the back link is selected
     */

    it('Back button: THEN return [PARTICIPANT] to previous page ', async () => {
      await commonTests.checkPageLoadsAndContainsStandardElements(returnPage);
    });
  };

  this.checkPrintAndDownloadButtons = (beneficiariesPage) => {
    it('Print and Download buttons: THEN "Print" button is enabled'
    + ' AND "Download" button is enabled (OUK-5873)', async () => {
      expect(beneficiariesPage.printButton(global.deviceType).isDisplayed()).toBe(true);
      expect(beneficiariesPage.printButton(global.deviceType).isEnabled()).toBe(true);
      await checkers.containingImage(beneficiariesPage.printButton(global.deviceType),
        commonConstants.actionPrintImageSource);

      expect(beneficiariesPage.downloadButton(global.deviceType).isDisplayed()).toBe(true);
      expect(beneficiariesPage.downloadButton(global.deviceType).isEnabled()).toBe(true);
      await checkers.containingImage(beneficiariesPage.downloadButton(global.deviceType),
        commonConstants.actionDownloadImageSource);
    });
  };

  this.checkLastDateUpdated = (beneficiariesPage) => {
    it('Last date updated: THEN "label" contains "Updated" AND "value" in UK time format (OUK-5873)', async () => {
      await checkers.containingTextIgnoreCase(beneficiariesPage.beneficiaryLastUpdatedLabelAndValue,
        'Updated');
      await checkers.containingAnyUkDate(beneficiariesPage.beneficiaryLastUpdatedLabelAndValue);
    });
  };
};
module.exports = beneficiariesTests;
