// load common
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const PensionerPlanSummaryTests = require('./pensioner-plan-summary.spec');
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const annualAllowanceTest = function annualAllowanceTest() {
  // private functions

  // private properties

  const self = this;

  // exposed properties

  // exposed functions

  this.browseToPensionerAllowancesPageFromLogin = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, annualAllowancePage, participant, pensionerServiceInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(loginPage, dashboardPage,
      pensionerPlanSummaryPage, participant, pensionerServiceInstance);


    await self.browseToPensionerAllowancesPageFromDashBoard(dashboardPage, annualAllowancePage);
  };

  this.browseToPensionerAllowancesPageFromDashBoard = async (pensionerPlanSummaryPage, annualAllowancePage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      pensionerPlanSummaryPage,
      pensionerPlanSummaryPage.planHeader.allowancesLink,
      'allowances',
      pensionerPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(annualAllowancePage);

    // TODO: check selected
    expect(annualAllowancePage.annualAllowanceTab.isDisplayed()).toBe(true);
  };

  this.browseToLifetimeAllowancePageFromLogin = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, annualAllowancePage, participant, pensionerServiceInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(loginPage, dashboardPage,
      pensionerPlanSummaryPage, participant, pensionerServiceInstance);
    await commonTests.clickElement(annualAllowancePage.planHeader.allowancesLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(annualAllowancePage);
    await this.browseToLifeTimeAllowancePageFromAllowancePage(annualAllowancePage);
  };

  this.browseToLifeTimeAllowancePageFromAllowancePage = async (annualAllowancePage) => {
    await commonTests.clickElement(annualAllowancePage.lifeTimeAllowanceTab);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(annualAllowancePage);
    expect(browser.getCurrentUrl()).toContain(annualAllowancePage.lifeTimeAllowance);
  };

  this.checkLifeTimeAllowanceData = async (allowancePage, rowIndex) => {
    await checkers.anyText(allowancePage.scheme(rowIndex));
    await checkers.anyImage(allowancePage.statusEffectiveDate(rowIndex));
    await checkers.anyText(allowancePage.effectiveDate(rowIndex));
    await checkers.anyImage(allowancePage.allowancePercent(rowIndex));
  };
};

module.exports = annualAllowanceTest;
