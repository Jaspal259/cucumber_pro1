// load common
const CommonTests = require('../../utilities/common-tests.js');
const PensionerPlanSummaryTests = require('./pensioner-plan-summary.spec');

// create new objects
const commonTests = new CommonTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();

// tests
const pensionerDependantsTests = function pensionerDependantsTests() {
  // private properties

  // exposed functions
  this.browseToPensionerDependantsPageFromLogin = async (
    loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerDependantsPage,
    participant, pensionsServiceInstance) => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, participant, pensionsServiceInstance);

    await this.browseToPensionerDependantsPageFromPensionerSummary(pensionerPlanSummaryPage, pensionerDependantsPage);
  };

  this.browseToPensionerDependantsPageFromPensionerSummary
    = async (pensionerPlanSummaryPage, pensionerDependantsPage) => {
      await commonTests.clickElement(pensionerPlanSummaryPage.planHeader.dependantsLink);
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionerDependantsPage);
    };
};
module.exports = pensionerDependantsTests;
