// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const profileTests = function profileTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions

  this.browseToProfileInformationPageFromLogin = async (loginPage, dashboardPage, profilePage, participant) => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);

    // go to the Profile Information page
    await self.browseToProfileInformationPageFromDashBoard(dashboardPage, profilePage);
  };

  this.browseToProfileInformationPageFromDashBoard = async (dashboardPage, profilePage) => {
    await commonTests.clickCommonHeaderLink(
      dashboardPage.header, dashboardPage.header.commonHeaderLinkEnum.viewProfile, true);
    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
  };
};
module.exports = profileTests;
