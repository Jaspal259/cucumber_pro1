// load common
const CommonTests = require('../../utilities/common-tests.js');
const DbPlanSummaryTests = require('./db-plan-summary.spec');
const PlanHeaderTests = require('./plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dbPlanMaterialsTests = function dbPlanMaterialsTests() {
  // exposed functions
  this.browseToDbPlanMaterialsPageFromLogin
    = async (loginPage, dashboardPage, dbPlanSummaryPage, dbPlanMaterialsPage, participant, dbServiceInstance) => {
      await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dbPlanSummaryPage, participant, dbServiceInstance);

      // go to the PlanMaterial page
      await this.browseToPlanMaterialsPageFromDbSummary(dbPlanSummaryPage, dbPlanMaterialsPage);
    };

  this.browseToPlanMaterialsPageFromDbSummary = async (dbPlanSummaryPage, dbPlanMaterialsPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dbPlanSummaryPage,
      dbPlanSummaryPage.planHeader.planMaterialsLink,
      'material',
      dbPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbPlanMaterialsPage);
  };
};
module.exports = dbPlanMaterialsTests;
