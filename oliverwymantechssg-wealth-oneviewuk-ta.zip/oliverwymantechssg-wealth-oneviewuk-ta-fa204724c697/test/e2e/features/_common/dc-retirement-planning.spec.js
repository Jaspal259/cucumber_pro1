// load common
const CommonTests = require('../../utilities/common-tests.js');
const DcPlanSummaryTests = require('./dc-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dcRetirementPlanningTests = function dcRetirementPlanningTests() {
  // exposed functions
  this.browseToDcRetirementPlanningPageFromLogin = async (
    loginPage, dashboardPage, dcPlanSummaryPage, dcRetirementPlanningPage, participant, dcServiceInstance) => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(loginPage, dashboardPage, dcPlanSummaryPage,
      participant, dcServiceInstance);
    await this.browseToDcRetirementPlanningPageFromDcSummary(dcPlanSummaryPage, dcRetirementPlanningPage);
  };

  this.browseToDcRetirementPlanningPageFromDcSummary = async (dcPlanSummaryPage, dcRetirementPlanningPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dcPlanSummaryPage,
      dcPlanSummaryPage.planHeader.retirementPlanningLink,
      'retirement planner',
      dcPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcRetirementPlanningPage);
  };
};
module.exports = dcRetirementPlanningTests;
