// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const viewProfilePageTests = function viewProfilePageTests() {
  // exposed functions

  this.browseToViewProfilePageFromLogin
    = async (loginPage, dashboardPage, viewProfilePage, participant) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
      await commonTests.clickElement(viewProfilePage.rsDropDownIcon);
      await commonTests.clickElement(viewProfilePage.profileLink);
      await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    };
};
module.exports = viewProfilePageTests;
