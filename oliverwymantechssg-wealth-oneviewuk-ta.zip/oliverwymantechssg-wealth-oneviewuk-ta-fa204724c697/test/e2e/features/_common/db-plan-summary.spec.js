// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const dbPlanSummaryTests = function dbPlanSummaryTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions
  this.browseToDbPlanSummaryPageFromLogin
    = async (loginPage, dashboardPage, dbPlanSummaryPage, participant, dbServiceInstance) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
      await self.browseToDbPlanSummaryPageFromDashboard(dashboardPage, dbPlanSummaryPage, dbServiceInstance);
    };

  this.browseToDbPlanSummaryPageFromDashboard = async (dashboardPage, dbPlanSummaryPage, dbServiceInstance) => {
    switch (dbServiceInstance) {
      case 0:
        await commonTests.clickElement(dashboardPage.dbCard0.detailsButton(global.deviceType));
        break;

      case 1:
        await commonTests.clickElement(dashboardPage.dbCard1.detailsButton(global.deviceType));
        break;

      default:
        throw new Error(`Does not support dbServiceInstance === ${dbServiceInstance}`);
    }
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbPlanSummaryPage);
  };
};
module.exports = dbPlanSummaryTests;
