// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load tests
const TooltipTests = require('../_common/tooltips.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const tooltipTests = new TooltipTests();

// other
const until = protractor.ExpectedConditions;

// tests
const annualStatementTests = function annualStatementTests() {
  // private functions
  // --------------------------------------------------

  // exposed functions
  // --------------------------------------------------
  this.checkStatementsAvailableForAtLeastOnePeriod = async (annualStatementPage) => {
    const statementPage = await annualStatementPage.annualStatement;

    // tabs or dropdown shown for period selection?
    const tabsCount = await statementPage.getAnnualStatementTabsCount();

    if (tabsCount > 0) {
      // tabs
      for (let i = 0; i < tabsCount; i += 1) {
        await checkers.anyUkYear(statementPage.annualStatementTab(i));
      }
    } else {
      const dropdownPresent = await browser.isElementPresent(statementPage.periodDropdownLabel);

      if (dropdownPresent) {
        // dropdown
        await checkers.containingTextIgnoreCase(statementPage.periodDropdownLabel, 'select');
        await checkers.anyUkYear(statementPage.periodDropdownSelectionValue);
        await commonTests.clickElement(statementPage.periodDropdownSelection);
        const optionsCount = await statementPage.getPeriodDropdownOptionsCount();

        // sanity check
        expect(optionsCount).toBeLessThan(101);

        for (let i = 0; i < optionsCount; i += 1) {
          await checkers.anyUkYear(statementPage.periodDropdownOption(i));
        }
      } else {
        // single period
        await checkers.containingTextIgnoreCase(statementPage.statementCardHeaderTextWhenSinglePeriod,
          'statement');
      }
    }
  };

  this.checkPreAmbleIsFirstStatementShown = async (annualStatementPage) => {
    const statementPage = annualStatementPage.annualStatement;
    const statementsCount = await statementPage.getStatementsCount();
    expect(statementsCount).not.toBe(0, 'No statements shown');
    const statementsId = await statementPage.statements.get(0).getAttribute('id');
    expect(statementsId).toContain(
      'statement-preamble',
      'The pre-amble is not the first draw in the accordion');

    // no need to click first draw as now first draw open by default when page opened
    await checkers.anyText(statementPage.preambleStatementText);
  };

  this.checkDataRowsInStatement = async (annualStatementPage, statementInstance, statement) => {
    const statementPage = annualStatementPage.annualStatement;
    await browser.wait(until.presenceOf(statementPage.statementDataRows(statement)),
      commonConstants.briefBrowserWaitDelay,
      `No data row found for statement instance ${statementInstance}`);
    const rowCount = await statementPage.statementDataRows(statement).count();

    for (let r = 0; r < rowCount; r += 1) {
      // row content varies so much that all we can do here is check for text
      // the original design of rows must have been different but must have changed as Gherkin
      // no longer reflects Zeplin design
      const row = await statementPage.statementDataRows(statement).get(r);
      await checkers.anyText(row);
    }
  };

  this.checkDataRowsInAllStatements = async (annualStatementPage) => {
    const statementPage = annualStatementPage.annualStatement;

    const statementsCount = await statementPage.getStatementsCount();

    if (statementsCount === 0) {
      fail('No statements shown');
    } else {
      for (let s = 0; s < statementsCount; s += 1) {
        const statement = statementPage.statement(s);

        if (s === 0) {
          // no need to click first draw as now first draw open by default when page opened
          await this.checkDataRowsInStatement(annualStatementPage, s, statement);
        } else {
          await commonTests.clickElement(statementPage.statementHeaderArrow(statement));
          await this.checkDataRowsInStatement(annualStatementPage, s, statement);
        }
      }
    }
  };

  this.checkAllStatementsContainHeader = async (annualStatementPage, planType, participantStatus) => {
    const statementPage = annualStatementPage.annualStatement;
    const statementCount = await statementPage.statements.count();

    if (statementCount === 0) {
      fail('No statements shown');
    } else {
      for (let s = 0; s < statementCount; s += 1) {
        const statement = await statementPage.statement(s);
        await checkers.anyText(statementPage.statementHeaderLabel(statement));

        if (s === 0) {
          await checkers.containingImage(statementPage.statementHeaderArrow(statement),
            commonConstants.keyboardArrowUpImageSource);
        } else {
          await checkers.containingImage(statementPage.statementHeaderArrow(statement),
            commonConstants.keyboardArrowDownImageSource);
        }
      }

      // now check number of statements shown is correct
      const planTypeParticipantStatus = planType + participantStatus;

      switch (planTypeParticipantStatus) {
        case 'DCactive':
          expect(statementCount).toBe(3);
          break;
        case 'DCdeferred':
          expect(statementCount).toBe(4);
          break;
        case 'DBactive':
          expect(statementCount).toBe(4);
          break;
        case 'DBdeferred':
          expect(statementCount).toBe(3);
          break;
        default:
          fail(`Plan type + participant status '${planTypeParticipantStatus}' not supported`);
      }
    }
  };

  this.checkAllStatementsContainHeaderDrawIcon = async (annualStatementPage) => {
    const statementPage = annualStatementPage.annualStatement;
    const statementCount = await statementPage.statements.count();

    if (statementCount === 0) {
      fail('No statements shown');
    } else {
      for (let s = 0; s < statementCount; s += 1) {
        await checkers.anyImage(statementPage.statementHeaderIcon(statementPage.statement(s)));
      }
    }
    return statementCount;
  };

  this.checkTooltipsForAllStatements = async (annualStatementPage) => {
    const statementPage = await annualStatementPage.annualStatement;
    const statementCount = await statementPage.statements.count();

    if (statementCount === 0) {
      fail('No statements shown');
    } else {
      for (let s = 0; s < statementCount; s += 1) {
        const statement = statementPage.statement(s);
        const present = await browser.isElementPresent(statementPage.statementHeaderInfoIcon(statement));

        if (present) {
          await checkers.containingImage(statementPage.statementHeaderInfoIcon(statement),
            commonConstants.infoImageSource);
          await tooltipTests.checkTooltipIsElementWithAnyText(
            statementPage.statementHeaderInfoIcon(statement),
            statementPage.statementHeaderLabel(statement),
            annualStatementPage.tooltips.soleTooltip
          );
        }
      }
    }
  };

  this.checkNotesStatement = async (annualStatementPage) => {
    const statementPage = annualStatementPage.annualStatement;
    await checkers.containingTextIgnoreCase(statementPage.notesStatementLabel, 'Notes');
    await commonTests.clickElement(statementPage.statementHeaderArrow(statementPage.notesStatement));
    await checkers.anyText(statementPage.notesStatementText);
  };

  this.checkTheNoDataContainerIsNotShown = async (annualStatementPage) => {
    // here were are testing the modal is not shown as there is data
    await browser.wait(until.invisibilityOf(
      annualStatementPage.annualStatement.noDataContainer), commonConstants.shortBrowserWaitDelay,
    'No data modal still shown');
  };

  this.checkPersonalisedStatementShown = async (annualStatementPage) => {
    const statementPage = await annualStatementPage.annualStatement;
    const statementsCount = await statementPage.getPersonalisedStatementsCount();
    expect(statementsCount).not.toBe(0,
      'Missing personalised statements group items');

    for (let i = 0; i < statementsCount; i += 1) {
      const personalisedStatement = await statementPage.personalisedStatements.get(i);
      const personalisedStatementLabel
        = await statementPage.statementHeaderLabel(personalisedStatement);
      await checkers.anyText(personalisedStatementLabel);
    }
  };

  this.checkTopicIconForPersonalisedStatements = async (annualStatementPage, planType, participantStatus) => {
    const statementPage = await annualStatementPage.annualStatement;
    const planTypeParticipantStatus = planType + participantStatus;

    const personalisedStatementCount = await statementPage.getPersonalisedStatementsCount();

    if (personalisedStatementCount === 0) {
      fail('Missing personalised statement items');
    } else {
      switch (planTypeParticipantStatus) {
        case 'DCactive':
          expect(personalisedStatementCount).toBe(1);
          // SMPI
          await checkers.anyImage(statementPage.personalisedStatementIcon(0));
          break;

        case 'DCdeferred':
          expect(personalisedStatementCount).toBe(2);
          // your personalised statement
          await checkers.anyImage(statementPage.personalisedStatementIcon(0));
          // SMPI
          await checkers.anyImage(statementPage.personalisedStatementIcon(1));
          break;

        case 'DBactive':
          expect(personalisedStatementCount).toBe(2);
          // your personalised statement
          await checkers.anyImage(statementPage.personalisedStatementIcon(0));
          // SMPI
          await checkers.anyImage(statementPage.personalisedStatementIcon(1));
          break;

        case 'DBdeferred':
          expect(personalisedStatementCount).toBe(1);
          // SMPI
          await checkers.anyImage(statementPage.personalisedStatementIcon(0));
          break;

        default:
          fail(`Plan type + participant status '${planTypeParticipantStatus}' not supported`);
      }
    }
  };

  this.checkDataForAllPersonalisedStatements = async (annualStatementPage) => {
    const statementPage = annualStatementPage.annualStatement;
    const statementsCount = await statementPage.getPersonalisedStatementsCount();
    expect(statementsCount).not.toBe(0, 'Missing personalised statements group items');

    for (let i = 0; i < statementsCount; i += 1) {
      const personalisedStatement = statementPage.personalisedStatements.get(i);
      await commonTests.clickElement(statementPage.statementHeaderArrow(personalisedStatement));
      await checkers.containingTextIgnoreCase(
        statementPage.personalisedStatementTypeHeaderLabel(personalisedStatement), 'Type');
      await checkers.containingTextIgnoreCase(
        statementPage.personalisedStatementNameHeaderLabel(personalisedStatement), 'Period');
      await checkers.containingTextIgnoreCase(
        statementPage.personalisedStatementActionHeaderLabel(personalisedStatement), 'Action');

      const rows = statementPage.personalisedStatementRows(personalisedStatement);
      const rowsCount = await rows.count();
      let r;

      for (r = 0; r < rowsCount; r += 1) {
        const row = rows.get(r);
        await checkers.anyImage(statementPage.personalisedStatementRowTypeIcon(row));
        await checkers.anyText(statementPage.personalisedStatementRowNameText(row));
        await checkers.anyImage(statementPage.personalisedStatementRowActionButton(row));
      }
    }
  };
};
module.exports = annualStatementTests;
