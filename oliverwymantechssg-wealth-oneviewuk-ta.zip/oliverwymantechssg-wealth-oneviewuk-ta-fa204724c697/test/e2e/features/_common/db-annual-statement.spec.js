// load common
const CommonTests = require('../../utilities/common-tests.js');
const DbPlanSummaryTests = require('./db-plan-summary.spec.js');

// create new objects
const commonTests = new CommonTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();

// tests
const dbAnnualStatementTests = function dbAnnualStatementTests() {
  // private properties
  const self = this;

  // exposed functions
  this.browseToDbAnnualStatementPageFromLogin
    = async (loginPage, dashboardPage, dbPlanSummaryPage, dbAnnualStatementPage, participant, dbServiceInstance) => {
      await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dbPlanSummaryPage, participant, dbServiceInstance);
      await self.browseToDbAnnualStatementPageFromDbSummary(dbPlanSummaryPage, dbAnnualStatementPage);
    };

  this.browseToDbAnnualStatementPageFromDbSummary = async (dbPlanSummaryPage, dbAnnualStatementPage) => {
    await commonTests.clickElement(dbPlanSummaryPage.planHeader.annualBenefitStatementLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbAnnualStatementPage);
  };
};
module.exports = dbAnnualStatementTests;
