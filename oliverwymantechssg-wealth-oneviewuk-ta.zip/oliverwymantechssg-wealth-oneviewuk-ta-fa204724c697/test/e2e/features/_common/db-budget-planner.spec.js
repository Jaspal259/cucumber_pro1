// load common
const DbPlanSummaryTests = require('./db-plan-summary.spec.js');
const BudgetPlannerTests = require('./budget-planner.spec.js');

// create new objects
const dbPlanSummaryTests = new DbPlanSummaryTests();
const budgetPlannerTests = new BudgetPlannerTests();

// tests
const dbBudgetPlannerTests = function dbBudgetPlannerTests() {
  // private properties
  const self = this;

  // exposed functions
  this.browseToDbBudgetPlannerPageFromLogin
    = async (loginPage, dashboardPage, dbPlanSummaryPage, dbBudgetPlannerPage, participant, dbServiceInstance) => {
      await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(loginPage, dashboardPage,
        dbPlanSummaryPage, participant, dbServiceInstance);

      // go to the Budget planner page
      await self.browseToDbBudgetPlannerPageFromDbSummary(dbPlanSummaryPage, dbBudgetPlannerPage);
    };

  this.browseToDbBudgetPlannerPageFromDbSummary = async (dbPlanSummaryPage, dbBudgetPlannerPage) => {
    await budgetPlannerTests.browseToBudgetPlannerPageFromPlanSummary(dbPlanSummaryPage, dbBudgetPlannerPage);
  };

  this.browseToDbEditBudgetFromBudgetPlannerPage
    = async (dbBudgetPlannerPage, dbBudgetPlannerDefault, dbBudgetPlannerEdit) => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        dbBudgetPlannerPage, dbBudgetPlannerDefault, dbBudgetPlannerEdit);
    };
};
module.exports = dbBudgetPlannerTests;
