// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load tests
const LoginTests = require('../_common/authentication-login.spec');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const loginTests = new LoginTests();

// other
const until = protractor.ExpectedConditions;

// tests
const dashboardTests = function dashboardTests() {
  // private functions


  // private properties


  // exposed properties


  // exposed functions

  this.checkDashboardPageLoadsWithCards = async (dashboardPage, participant) => {
    await commonTests.checkPageLoadsAndContainsStandardElements(dashboardPage);

    // need to check dashboard cards load as they load last
    if (participant.data.participantTestId === 'ov1Participant001'
      || participant.data.participantTestId === 'ovtParticipant001') {
      if (!global.ov3TestIsRunOnSauceLabs) {
        await this.checkCardIsDisplayed(dashboardPage.dcCard0, 'DC active');
        await this.checkCardIsDisplayed(dashboardPage.dcCard1, 'DC deferred');
        await this.checkCardIsDisplayed(dashboardPage.dbCard0, 'DB active');
        await this.checkCardIsDisplayed(dashboardPage.dbCard1, 'DB deferred');
      }

      await this.checkCardIsDisplayed(dashboardPage.pensionerCard0, 'Pensioner');
    }
  };

  this.closeToast = async (dashboardPage) => {
    /*
      if a toast is shown on dashboard page (after login) it can obscure links (such as the profile
      dropdown) so therefore it must be closed if displayed

      note use of browser.sleep() then browser.isElementPresent() construction to detect the
      presence or otherwise of the toast - we have to use this rather than
      browser.wait(until.presenceOf([element]), [wait time], [error]) because until.presenceOf
      will not allow us to do nothing if the element is not found - it can only report an error message
     */
    await browser.sleep(commonConstants.momentaryBrowserWaitDelay);
    const present = await browser.isElementPresent(dashboardPage.toast.closeIcon);

    if (present) {
      await browser.wait(
        until.elementToBeClickable(dashboardPage.toast.closeIcon),
        commonConstants.shortBrowserWaitDelay,
        'Dashboard toast close button is not clickable');
      await commonTests.clickElement(dashboardPage.toast.closeIcon);
      await browser.wait(
        until.stalenessOf(dashboardPage.toast.closeIcon),
        commonConstants.briefBrowserWaitDelay,
        'Clicking close button did not remove dashboard toast');
    } else {
      /*
        do nothing
        toast not present
        no error to report
       */
    }
  };

  this.checkDashboardShownAfterLogin = async (loginPage, dashboardPage, participant) => {
    await loginTests.attemptLogin(loginPage, participant);
    await this.checkDashboardPageLoadsWithCards(dashboardPage, participant);
    await this.closeToast(dashboardPage);
  };

  this.checkCardIsDisplayed = async (card, cardTypeDescription) => {
    const planType = card.planType;

    if (planType !== 'DC' && planType !== 'DB' && planType !== 'PIP') {
      throw new Error(`The planType value [${planType}] is not supported`);
    } else {
      await browser.wait(
        until.visibilityOf(card.card(global.deviceType)),
        commonConstants.mediumMediumBrowserWaitDelay,
        `${cardTypeDescription} dashboard card is not shown`);
    }
  };

  this.getSelectedDashboardSummaryCard = (dashboardPage, planDesign, cardInstance) => {
    let selectedCard;

    switch (planDesign) {
      case 'DC':
        switch (cardInstance) {
          case 0:
            selectedCard = dashboardPage.dcCard0;
            break;

          case 1:
            selectedCard = dashboardPage.dcCard1;
            break;

          default:
            throw new Error(`The cardInstance value [${cardInstance}] is not supported`);
        }
        break;

      case 'DB':
        switch (cardInstance) {
          case 0:
            selectedCard = dashboardPage.dbCard0;
            break;

          case 1:
            selectedCard = dashboardPage.dbCard1;
            break;

          default:
            throw new Error(`The cardInstance value [${cardInstance}] is not supported`);
        }
        break;

      case 'Pensioner':
        switch (cardInstance) {
          case 0:
            selectedCard = dashboardPage.pensionerCard0;
            break;

          case 1:
            selectedCard = dashboardPage.pensionerCard1;
            break;

          default:
            throw new Error(`The cardInstance value [${cardInstance}] is not supported`);
        }
        break;

      default:
        throw new Error(`The planDesign value [${planDesign}] is not supported`);
    }


    return selectedCard;
  };

  this.expandCardForMobileOnly = async (card, deviceType, planDesign) => {
    let mobileExpandMore;
    let elementToCheckAfterExpand = await card.posStatusValue(deviceType);

    if (planDesign === 'Pensioner') {
      elementToCheckAfterExpand = await card.pensionStartDateValue(deviceType);
    }

    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        // do nothing - card already expanded
        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        mobileExpandMore = await card.mobileExpandMore(deviceType);
        await checkers.containingImage(mobileExpandMore, commonConstants.dropdownImageSource);
        await commonTests.clickElement(mobileExpandMore);
        await browser.wait(until.visibilityOf(elementToCheckAfterExpand),
          commonConstants.briefBrowserWaitDelay,
          `Mobile ${planDesign} dashboard summary card has not been expanded`);

        await checkers.anyText(elementToCheckAfterExpand);
        break;
      default:
        throw new Error(
          `The deviceType '${deviceType}' is not supported.`);
    }
  };

  this.expandMobileCardsForStandardParticipant = async (dashboardPage, deviceType) => {
    await this.expandCardForMobileOnly(dashboardPage.dcCard0, deviceType, 'DC');
    await this.expandCardForMobileOnly(dashboardPage.dcCard1, deviceType, 'DC');
    await this.expandCardForMobileOnly(dashboardPage.dbCard0, deviceType, 'DB');
    await this.expandCardForMobileOnly(dashboardPage.dbCard1, deviceType, 'DB');
    await this.expandCardForMobileOnly(dashboardPage.pensionerCard0, deviceType, 'Pensioner');
  };
};
module.exports = dashboardTests;
