/*
    NOTE:
    This test library contains tests specific to DC, DB and pensioner which have been gathered here for
    ease of maintenance
 */

// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load tests
const TooltipTests = require('../_common/tooltips.spec.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const tooltipTests = new TooltipTests();

// other
const until = protractor.ExpectedConditions;

// tests
const planMaterialsTests = function planMaterialsTests() {
  // private functions
  // --------------------------------------------------

  async function checkDocumentDownloadUrlAndTooltip(topicEnum, planMaterials, page, rowIndex, mediaUrl) {
    await commonTests.forceCallingFunctionToBeSynchronous();
    let downloadUrlRoot;
    let fullDownloadUrlSuffix;

    switch (topicEnum) {
      case planMaterials.selectedTopicEnum.pensionerPayslips:
        downloadUrlRoot = page.securedContentDownloadUrlRoot;
        fullDownloadUrlSuffix = `/payslips${commonConstants.downloadUrlSuffix}`;
        break;
      case planMaterials.selectedTopicEnum.pensionerP60s:
        downloadUrlRoot = page.securedContentDownloadUrlRoot;
        fullDownloadUrlSuffix = `/p60s${commonConstants.downloadUrlSuffix}`;
        break;
      case planMaterials.selectedTopicEnum.pensionerPensionIncreaseLetters:
        downloadUrlRoot = page.securedContentDownloadUrlRoot;
        fullDownloadUrlSuffix = '/pensionincreaseletters';
        break;
      case planMaterials.selectedTopicEnum.pensionerConfirmationOfPayment:
        downloadUrlRoot = page.securedContentDownloadUrlRoot;
        fullDownloadUrlSuffix = '/confirmationofpayment';
        break;
      default:
        downloadUrlRoot = browser.params.ov3RootDownloadUrl;
        fullDownloadUrlSuffix = '';
    }

    expect(mediaUrl).toContain(
      `${downloadUrlRoot}${fullDownloadUrlSuffix}`);
    await tooltipTests.checkTooltipIsElementContainingText(
      planMaterials.planMaterialsAction(rowIndex, global.deviceType),
      planMaterials.planMaterialsName(rowIndex),
      page.tooltips.topTooltip,
      'download');
  }

  async function checkPublicLinkTooltip(planMaterials, rowIndex, page) {
    await tooltipTests.checkTooltipIsElementContainingText(
      planMaterials.planMaterialsAction(rowIndex, global.deviceType),
      planMaterials.planMaterialsName(rowIndex),
      page.tooltips.topTooltip,
      'open');
  }

  // exposed functions
  // --------------------------------------------------

  /**
   * @example
   * const topic = await this.getTopic(planMaterials, selectedTopicInstance);
   * await checkers.anyText(topic);
   */
  this.getTopic = async (planMaterials, topicInstance) => {
    let topic = commonConstants.notYetDefined;

    const topicCount = await planMaterials.getPlanMaterialsTopicCount();

    if (topicCount > 1) {
      topic = planMaterials.planMaterialsMultipleTopic(topicInstance);
    } else {
      topic = planMaterials.planMaterialsLoneTopic;
    }

    return topic;
  };

  // required as clicking plan materials tab does not load topics instantaneously
  this.clickTabAndWaitForTopicsToLoad = async (planMaterials, tab, selectedTabInstance) => {
    await commonTests.clickElement(tab);
    const firstOrLoneTopic = await this.getTopic(planMaterials, 0);
    await browser.wait(
      until.visibilityOf(firstOrLoneTopic),
      commonConstants.mediumShortBrowserWaitDelay,
      `Plan materials tab instance ${selectedTabInstance} did not fully load as first topic not visible`);
    const topicDisplayed = await firstOrLoneTopic.isDisplayed();

    if (topicDisplayed) {
      return true;
    }
    return false;
  };

  this.checkPageContentHeaders = async (page) => {
    await checkers.anyText(page.header.pageCategoryHeader(global.deviceType));
    await checkers.containingTextIgnoreCase(page.header.pageHeader(global.deviceType), 'Materials');
    await checkers.containingTextIgnoreCase(page.header.backButton(global.deviceType), 'Back');
    await checkers.anyText(page.header.pageContentHeader);
    await checkers.anyText(page.header.pageContent);
  };

  this.checkOnlyFirstTopicSelected = async (planMaterials, topicCount) => {
    if (topicCount > 1) {
      let i;

      for (i = 0; i < topicCount; i += 1) {
        if (i === 0) {
          await checkers.isMercerOsButtonSelected(planMaterials.planMaterialsMultipleTopic(i));
        } else {
          await checkers.isMercerOsButtonUnselected(planMaterials.planMaterialsMultipleTopic(i));
        }
      }
    }
  };

  this.clickTopicAndCheckTopicContent
    = async (planMaterials, selectedTopicEnum, topic, selectedTopicInstance) => {
      await commonTests.clickElement(topic);
      await this.checkTopicContent(planMaterials, selectedTopicEnum, selectedTopicInstance, topic);
    };

  /**
   * @param selectedTopicInstance - if >= 0 then multiple topics, if === -1 then lone topic
   */
  this.checkTopicContent = async (planMaterials, topicEnum, selectedTopicInstance, topic) => {
    await this.checkSelectedTopicIsShownAsSelected(planMaterials, selectedTopicInstance);
    await this.checkTopicName(planMaterials, topicEnum, topic);
    await this.checkDataTable(planMaterials, topicEnum, selectedTopicInstance);
  };

  this.checkSelectedTopicIsShownAsSelected = async (planMaterials, selectedTopicInstance) => {
    const topicCount = await planMaterials.getPlanMaterialsTopicCount();

    if (topicCount === 1) {
      // lone topic - no selection as just heading
    } else {
      let i;

      for (i = 0; i < topicCount; i += 1) {
        if (i === selectedTopicInstance) {
          await checkers.isMercerOsButtonSelected(planMaterials.planMaterialsMultipleTopic(i));
        } else {
          await checkers.isMercerOsButtonUnselected(planMaterials.planMaterialsMultipleTopic(i));
        }
      }
    }
  };

  this.checkTopicName = async (planMaterials, topicEnum, topic) => {
    await commonTests.forceCallingFunctionToBeSynchronous();
    let expectedTopicName;

    switch (topicEnum) {
      // DOCUMENTS TAB - can contain secured content
      case planMaterials.selectedTopicEnum.dcPolicyDocuments:
      case planMaterials.selectedTopicEnum.dbPolicyDocuments:
      case planMaterials.selectedTopicEnum.pensionerPolicyDocuments:
        expectedTopicName = 'Policy';
        break;
      case planMaterials.selectedTopicEnum.pensionerPayslips:
        expectedTopicName = 'Payslip';
        break;
      case planMaterials.selectedTopicEnum.pensionerP60s:
        expectedTopicName = 'P60';
        break;
      case planMaterials.selectedTopicEnum.pensionerPensionIncreaseLetters:
        expectedTopicName = 'Pension Increase Letter';
        break;
      case planMaterials.selectedTopicEnum.pensionerConfirmationOfPayment:
        expectedTopicName = 'Payment';
        break;

      // PLAN MATERIALS TAB
      case planMaterials.selectedTopicEnum.dcPlanBooklets:
      case planMaterials.selectedTopicEnum.dbPlanBooklets:
      case planMaterials.selectedTopicEnum.pensionerPlanBooklets:
        expectedTopicName = 'Booklet';
        break;
      case planMaterials.selectedTopicEnum.dcAddendums:
      case planMaterials.selectedTopicEnum.dbAddendums:
      case planMaterials.selectedTopicEnum.pensionerAddendums:
        expectedTopicName = 'Addendum';
        break;
      case planMaterials.selectedTopicEnum.dcPlanInfo:
      case planMaterials.selectedTopicEnum.dbPlanInfo:
      case planMaterials.selectedTopicEnum.pensionerPlanInfo:
        expectedTopicName = 'Info';
        break;
      case planMaterials.selectedTopicEnum.dcAnnouncements:
      case planMaterials.selectedTopicEnum.dbAnnouncements:
      case planMaterials.selectedTopicEnum.pensionerAnnouncements:
        expectedTopicName = 'Announcement';
        break;
      case planMaterials.selectedTopicEnum.dcNewsletters:
      case planMaterials.selectedTopicEnum.dbNewsletters:
      case planMaterials.selectedTopicEnum.pensionerNewsletters:
        expectedTopicName = 'News';
        break;
      case planMaterials.selectedTopicEnum.dcForms:
      case planMaterials.selectedTopicEnum.dbForms:
      case planMaterials.selectedTopicEnum.pensionerForms:
        expectedTopicName = 'Forms';
        break;
      case planMaterials.selectedTopicEnum.dcInvestmentGuides:
      case planMaterials.selectedTopicEnum.dbInvestmentGuides:
      case planMaterials.selectedTopicEnum.pensionerInvestmentGuides:
        expectedTopicName = 'Invest';
        break;
      case planMaterials.selectedTopicEnum.dcFundFactsheets:
      case planMaterials.selectedTopicEnum.dbFundFactsheets:
      case planMaterials.selectedTopicEnum.pensionerFundFactsheets:
        expectedTopicName = 'Fact';
        break;
      case planMaterials.selectedTopicEnum.dcFundManagerInfo:
      case planMaterials.selectedTopicEnum.dbFundManagerInfo:
      case planMaterials.selectedTopicEnum.pensionerFundManagerInfo:
        expectedTopicName = 'Manager';
        break;
      default:
        throw new Error(`Tab topic instance selectedTopicEnum of '${topicEnum}' is not supported`);
    }

    await checkers.containingTextIgnoreCase(topic, expectedTopicName);
  };

  /*
    Most of the functions below have been updated or added to cater for newer story OUK-8502
    Note OUK-8502 will only be covered in TE code by these updates to existing TE code for stories OUK-949, 1065, 1075
   */

  this.isSizeColumnInDataTable = async (planMaterials, topicEnum) => {
    await commonTests.forceCallingFunctionToBeSynchronous();

    // check table headers
    let showSizeColumn;

    switch (topicEnum) {
      case planMaterials.selectedTopicEnum.pensionerPayslips:
      case planMaterials.selectedTopicEnum.pensionerP60s:
      case planMaterials.selectedTopicEnum.pensionerPensionIncreaseLetters:
      case planMaterials.selectedTopicEnum.pensionerConfirmationOfPayment:
      case planMaterials.selectedTopicEnum.dcPolicyDocuments:
      case planMaterials.selectedTopicEnum.dbPolicyDocuments:
      case planMaterials.selectedTopicEnum.pensionerPolicyDocuments:
        showSizeColumn = false;
        break;
      default:
        showSizeColumn = true;
    }

    return showSizeColumn;
  };

  this.isNetPensionColumnInDataTable = async (planMaterials, topicEnum) => {
    await commonTests.forceCallingFunctionToBeSynchronous();

    // check table headers
    let showNetPensionColumn;

    switch (topicEnum) {
      case planMaterials.selectedTopicEnum.pensionerPayslips:
        showNetPensionColumn = true;
        break;
      default:
        showNetPensionColumn = false;
    }

    return showNetPensionColumn;
  };

  this.isSizeOrNetPensionColumnInDataTable = async (planMaterials, topicEnum) => {
    // check table headers
    let showSizeOrNetPensionColumn = false;
    const showSizeColumn = await this.isSizeColumnInDataTable(planMaterials, topicEnum);
    const showNetPensionColumn = await this.isNetPensionColumnInDataTable(planMaterials, topicEnum);

    if (showSizeColumn || showNetPensionColumn) {
      showSizeOrNetPensionColumn = true;
    }

    return showSizeOrNetPensionColumn;
  };

  this.checkDataTable = async (planMaterials, topicEnum, selectedTopicInstance) => {
    await browser.wait(
      until.presenceOf(planMaterials.planMaterialsDataRows),
      commonConstants.mediumMediumBrowserWaitDelay,
      `Data table rows not present for topicEnum ${topicEnum}`);
    const recordCountExcHeader = await planMaterials.getPlanMaterialsRecordCount();

    // check table headers
    const showSizeColumn = await this.isSizeColumnInDataTable(planMaterials, topicEnum);
    const showNetPensionColumn = await this.isNetPensionColumnInDataTable(planMaterials, topicEnum);
    const showSizeOrNetPensionColumn = await this.isSizeOrNetPensionColumnInDataTable(planMaterials, topicEnum);

    await checkers.anyText(planMaterials.columnHeaderName);
    await checkers.anyText(planMaterials.columnHeaderType);

    if (showSizeColumn) {
      await checkers.anyText(planMaterials.columnHeaderSize);
    }

    if (showNetPensionColumn) {
      await checkers.anyText(planMaterials.columnHeaderNetPension);
    }

    await checkers.anyText(planMaterials.columnHeaderAction(showSizeOrNetPensionColumn));

    // check column sorters
    // name column header has sorter
    if (topicEnum === planMaterials.selectedTopicEnum.pensionerPayslips
          || topicEnum === planMaterials.selectedTopicEnum.pensionerP60s) {
      await checkers.containingImage(planMaterials.planMaterialsSortIcon(0),
        commonConstants.sorterImageSourceDownward);
    } else {
      await checkers.containingImage(planMaterials.planMaterialsSortIcon(0),
        commonConstants.sorterImageSourceUpward);
    }

    const iconCount = await planMaterials.getPlanMaterialsSortIconCount();

    if (showSizeColumn || showNetPensionColumn) {
      // size or net pension column header has sorter
      await checkers.containingImage(planMaterials.planMaterialsSortIcon(1),
        commonConstants.sorterImageSourceUpward);
      expect(iconCount).toEqual(2);
    } else {
      expect(iconCount).toEqual(1);
    }

    // check table data rows
    if (recordCountExcHeader === 1) {
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, 0);
    } else if (recordCountExcHeader > 1 && recordCountExcHeader < 4) {
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, 0);
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, 1);
    } else if (recordCountExcHeader > 3) {
      const lastRow = recordCountExcHeader - 1;
      const midRow = (Math.round((recordCountExcHeader) / 2));
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, 0);
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, midRow);
      await this.checkPlanMaterialsData(
        planMaterials, topicEnum, selectedTopicInstance, lastRow);
    } else {
      fail(`planMaterialTopic instance ${selectedTopicInstance} has no data`);
    }
  };

  this.checkPlanMaterialsData = async (planMaterials, topicEnum, selectedTopicInstance, rowIndex) => {
    switch (topicEnum) {
      case planMaterials.selectedTopicEnum.pensionerPayslips:
        await checkers.containingAnyUkDate(planMaterials.planMaterialsName(rowIndex));
        break;
      case planMaterials.selectedTopicEnum.pensionerP60s:
        await checkers.containingAnyUkDate(planMaterials.planMaterialsName(rowIndex));
        break;
      default:
        await checkers.anyText(planMaterials.planMaterialsName(rowIndex));
    }

    await this.checkPlanMaterialsTypeSizeAndActionData(planMaterials, topicEnum, rowIndex);
  };

  this.determineActionType = async (planMaterials, rowIndex) => {
    await commonTests.forceCallingFunctionToBeSynchronous();
    const url = await planMaterials.planMaterialsDataRow(rowIndex + 1).getAttribute('href');

    if (url.indexOf(browser.params.ov3RootUrl) !== -1) {
      return planMaterials.actionType.documentDownload;
    }

    return planMaterials.actionType.publicLink;
  };

  this.checkIconIsCorrectForMediaLinkType = async (mediaUrl, planMaterials, rowIndex) => {
    if (mediaUrl.indexOf(browser.params.ov3RootDownloadUrl) !== -1) {
      // media is OV3 download
      // -----------------------------------
      if (mediaUrl.indexOf('.pdf') !== -1 || mediaUrl.indexOf('.PDF') !== -1) {
        // PDF
        await checkers.containingImage(planMaterials.planMaterialsType(rowIndex),
          commonConstants.pdfImageSource);
        await checkers.containingImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType),
          commonConstants.actionDownloadImageSource);
      } else if (mediaUrl.indexOf('.zip') !== -1 || mediaUrl.indexOf('.ZIP') !== -1
        || mediaUrl.indexOf('.doc') !== -1 || mediaUrl.indexOf('.DOC') !== -1
        || mediaUrl.indexOf('.xls') !== -1 || mediaUrl.indexOf('.XLS') !== -1
        || mediaUrl.indexOf('.csv') !== -1 || mediaUrl.indexOf('.CSV') !== -1) {
        // ZIP folder for ZIP, DOC, XLS, CSV
        await checkers.containingImage(planMaterials.planMaterialsType(rowIndex),
          commonConstants.pdfImageSource);
        await checkers.containingImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType),
          commonConstants.actionDownloadImageSource);
      } else if (mediaUrl.indexOf(browser.params.ov3RootDownloadUrl) !== -1) {
        // we know this is a download but not which type
        await checkers.containingImage(planMaterials.planMaterialsType(rowIndex),
          commonConstants.pdfImageSource);
        await checkers.containingImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType),
          commonConstants.actionDownloadImageSource);
      } else {
        fail(`Media URL ${mediaUrl} is not supported as not PDF, ZIP, DOC, XLS or CSV`);
      }
    } else {
      // media is public link
      // -----------------------------------
      await checkers.containingImage(planMaterials.planMaterialsType(rowIndex),
        commonConstants.linkImageSource);
      await checkers.containingImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType),
        commonConstants.actionOpenPublicLinkImageSource);
    }
  };

  this.checkPlanMaterialsTypeSizeAndActionData = async (planMaterials, topicEnum, rowIndex) => {
    const showSizeColumn = await this.isSizeColumnInDataTable(planMaterials, topicEnum);
    const showNetPensionColumn = await this.isNetPensionColumnInDataTable(planMaterials, topicEnum);

    // check all elements exist before checking specifics relating to type of media
    await checkers.anyImage(planMaterials.planMaterialsType(rowIndex));

    if (showSizeColumn) {
      await checkers.anyText(planMaterials.planMaterialsSize(rowIndex));
    }

    if (showNetPensionColumn) {
      await checkers.anyText(planMaterials.planMaterialsNetPension(rowIndex));
    }

    await checkers.anyImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType));

    // now use the download link to determine what media type and action controls should be shown
    const mediaUrl = await commonTests.getUrlOfMediaLink(
      planMaterials.planMaterialsAction(rowIndex, global.deviceType),
      `planMaterials.planMaterialsAction(${rowIndex})`);

    if (mediaUrl === commonConstants.notSupportedYet) {
      /*
        we can only check for the existence of any image and we cannot click on the action to open the
        linked URL / download to determine a more detailed check
       */
      await checkers.anyImage(planMaterials.planMaterialsType(rowIndex));
      await checkers.anyImage(planMaterials.planMaterialsAction(rowIndex, global.deviceType));
    } else {
      await this.checkIconIsCorrectForMediaLinkType(mediaUrl, planMaterials, rowIndex);
    }

    if (showNetPensionColumn) {
      await checkers.anyGbp(planMaterials.planMaterialsNetPension(rowIndex));
    }
  };

  this.checkActionUrlAndTooltipForTopic = async (page, planMaterials, topicEnum, topic) => {
    await commonTests.clickElement(topic);
    await browser.wait(until.presenceOf(planMaterials.planMaterialsDataRows),
      commonConstants.mediumMediumBrowserWaitDelay,
      `Data table rows not present for topicEnum ${topicEnum}`);
    const recordCountExcHeaders = await planMaterials.getPlanMaterialsRecordCount();

    if (recordCountExcHeaders === 1) {
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, 0);
    } else if (recordCountExcHeaders > 1 && recordCountExcHeaders < 4) {
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, 0);
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, 1);
    } else if (recordCountExcHeaders > 3) {
      const lastRow = recordCountExcHeaders - 1;
      const midRow = (Math.round((recordCountExcHeaders) / 2));
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, 0);
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, midRow);
      await this.checkPlanMaterialsActionUrlAndTooltip(
        page, planMaterials, topicEnum, lastRow);
    } else {
      fail(`planMaterialTopic topicEnum ${topicEnum} has no data`);
    }
  };

  this.checkPlanMaterialsActionUrlAndTooltip = async (page, planMaterials, topicEnum, rowIndex) => {
    // now use the download link to determine what URL and tooltip should exist
    const mediaUrl = await commonTests.getUrlOfMediaLink(
      planMaterials.planMaterialsAction(rowIndex, global.deviceType),
      `planMaterials.planMaterialsAction(${rowIndex})`);

    if (mediaUrl === commonConstants.notSupportedYet) {
      // we can only check for the existence of a tooltip - we cannot click on the action to
      // open the linked URL / download to get URL info which can determine the more detailed check
      await tooltipTests.checkTooltipIsElementWithAnyText(
        planMaterials.planMaterialsAction(rowIndex, global.deviceType),
        planMaterials.planMaterialsName(rowIndex),
        page.tooltips.topTooltip);
    } else if (mediaUrl.indexOf(browser.params.ov3RootDownloadUrl) !== -1) {
      // row contains document
      await checkDocumentDownloadUrlAndTooltip(topicEnum, planMaterials, page, rowIndex, mediaUrl);
    } else {
      // row contains public link
      await checkPublicLinkTooltip(planMaterials, rowIndex, page);
    }
  };
};
module.exports = planMaterialsTests;
