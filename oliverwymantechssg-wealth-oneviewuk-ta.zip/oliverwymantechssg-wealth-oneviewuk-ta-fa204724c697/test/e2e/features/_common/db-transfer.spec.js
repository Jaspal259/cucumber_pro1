// load common
const CommonTests = require('../../utilities/common-tests.js');
const DbPlanSummaryTests = require('./db-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dbTransferTests = function dbTransferTests() {
  // exposed functions
  this.browseToDbTransferPageFromLogin = async (
    loginPage, dashboardPage, dbPlanSummaryPage, dbTransferPage, participant, dbServiceInstance) => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(loginPage, dashboardPage, dbPlanSummaryPage,
      participant, dbServiceInstance);

    // go to the PlanMaterial page
    await this.browseToDbTransferPageFromDbSummary(dbPlanSummaryPage, dbTransferPage);
  };

  this.browseToDbTransferPageFromDbSummary = async (dbPlanSummaryPage, dbTransferPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dbPlanSummaryPage,
      dbPlanSummaryPage.planHeader.transferValueLink,
      dbPlanSummaryPage.planHeader.transferValueText,
      dbPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbTransferPage);
    expect(browser.getCurrentUrl()).toContain(dbTransferPage.url);
  };
};
module.exports = dbTransferTests;
