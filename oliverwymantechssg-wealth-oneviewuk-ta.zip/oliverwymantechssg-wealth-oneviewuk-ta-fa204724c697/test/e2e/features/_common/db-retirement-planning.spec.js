// load common
const CommonTests = require('../../utilities/common-tests.js');
const DbPlanSummaryTests = require('./db-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dbRetirementPlanningTests = function dbRetirementPlanningTests() {
  // private functions


  // private properties
  // exposed properties


  // exposed functions
  this.browseToDbRetirementPlanningPageFromLogin
    = async (loginPage, dashboardPage, dbPlanSummaryPage, dbRetirementPlanningPage, participant, dbServiceInstance) => {
      await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(loginPage, dashboardPage, dbPlanSummaryPage,
        participant, dbServiceInstance);

      // go to the retirement page
      await this.browseToDbRetirementPlanningPageFromDbSummary(dbPlanSummaryPage, dbRetirementPlanningPage);
    };

  this.browseToDbRetirementPlanningPageFromDbSummary = async (dbPlanSummaryPage, dbRetirementPlanningPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dbPlanSummaryPage,
      dbPlanSummaryPage.planHeader.dbModellerLink,
      dbPlanSummaryPage.planHeader.dbModellerText,
      dbPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbRetirementPlanningPage);
  };
};

module.exports = dbRetirementPlanningTests;
