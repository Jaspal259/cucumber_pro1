// load common
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const DbPlanSummaryTests = require('./db-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dbEarningsHistoryTests = function dbEarningsHistoryTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions
  this.browseToDbEarningsHistoryPageFromLogin = async (
    loginPage, dashboardPage, dbPlanSummaryPage, dbEarningsHistoryPage, participant, dbServiceInstance) => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(loginPage, dashboardPage, dbPlanSummaryPage,
      participant, dbServiceInstance);
    // go to the Earnings History page
    await self.browseToDbEarningsHistoryPageFromDbSummary(dbPlanSummaryPage, dbEarningsHistoryPage);
  };

  this.browseToDbEarningsHistoryPageFromDbSummary = async (dbPlanSummaryPage, dbEarningsHistoryPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dbPlanSummaryPage,
      dbPlanSummaryPage.planHeader.earningsHistoryLink,
      dbPlanSummaryPage.planHeader.earningsHistoryText,
      dbPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbEarningsHistoryPage);
  };

  this.browseToDbEarningsHistoryPageFromDashboard
    = async (dashboardPage, dbEarningsHistoryPage, dbServiceInstance) => {
      switch (dbServiceInstance) {
        case 0:
          await commonTests.clickElement(dashboardPage.dbCard0.detailsButton(global.deviceType));
          await commonTests.clickElement(dbEarningsHistoryPage.dbEarningsHistoryTab);
          break;

        case 1:
          await commonTests.clickElement(dashboardPage.dbCard1.detailsButton(global.deviceType));
          await commonTests.clickElement(dbEarningsHistoryPage.dbEarningsHistoryTab);
          break;

        default:
          throw new Error(`Does not support dbServiceInstance === ${dbServiceInstance}`);
      }

      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbEarningsHistoryPage);
    };

  this.showAnnualEarningsDetails = async (dbEarningsHistoryPage) => {
    const earningsCount = await dbEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);
    await checkers.exactText(
      dbEarningsHistoryPage.earningHistorySalaryTypeDropdown, 'ANNUAL EARNINGS');
    expect(dbEarningsHistoryPage.earningHistorySalaryTypeDropdown.isEnabled()).toBe(true);
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(earningsCount - 1));
  };

  this.showBonusDetails = async (dbEarningsHistoryPage) => {
    await commonTests.clickElement(dbEarningsHistoryPage.salaryTypeTab(2));
    const earningsCount = await dbEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);

    await checkers.exactText(dbEarningsHistoryPage.salaryTypeTab(2), 'GROSS EARNINGS');
    expect(dbEarningsHistoryPage.salaryTypeTab(2).isEnabled()).toBe(true);
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(earningsCount - 1));
  };

  this.showPensionableSalaryDetails = async (dbEarningsHistoryPage) => {
    const earningsCount = await dbEarningsHistoryPage.getEarningHistoryRecordCount();
    const middleRow = Math.floor(earningsCount / 2);
    await checkers.exactText(dbEarningsHistoryPage.salaryTypeTab(0), 'PENSIONABLE SALARY');
    expect(dbEarningsHistoryPage.salaryTypeTab(0).isEnabled()).toBe(true);
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(0));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(0));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(middleRow));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(middleRow));
    await checkers.anyUkDate(dbEarningsHistoryPage.dateValue(earningsCount - 1));
    await checkers.anyText(dbEarningsHistoryPage.amountValue(earningsCount - 1));
  };
};
module.exports = dbEarningsHistoryTests;
