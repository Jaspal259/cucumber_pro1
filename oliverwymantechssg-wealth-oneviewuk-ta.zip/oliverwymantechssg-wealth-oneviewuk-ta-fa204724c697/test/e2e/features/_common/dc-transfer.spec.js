// load common
const CommonTests = require('../../utilities/common-tests.js');
const DcPlanSummaryTests = require('./dc-plan-summary.spec');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// create new objects
const commonTests = new CommonTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const planHeaderTests = new PlanHeaderTests();

// tests
const dcTransferTests = function dcTransferTests() {
  // exposed functions
  this.browseToDcTransferPageFromLogin = async (
    loginPage, dashboardPage, dcPlanSummaryPage, dcTransferPage, participant, dcServiceInstance) => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(loginPage, dashboardPage, dcPlanSummaryPage,
      participant, dcServiceInstance);
    await this.browseToDcTransferPageFromDcSummary(dcPlanSummaryPage, dcTransferPage);
  };

  this.browseToDcTransferPageFromDcSummary = async (dcPlanSummaryPage, dcTransferPage) => {
    await planHeaderTests.clickPlanHeaderNavigationMenuLink(
      dcPlanSummaryPage,
      dcPlanSummaryPage.planHeader.transferValueLink,
      dcPlanSummaryPage.planHeader.transferValueText,
      dcPlanSummaryPage.planHeader);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dcTransferPage);
  };
};
module.exports = dcTransferTests;
