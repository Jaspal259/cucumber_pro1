// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// tests
const tooltipTests = function tooltipTests() {
  // private properties
  const until = protractor.ExpectedConditions;

  // private functions

  async function checkTooltipIsVisible(tooltip) {
    await browser.wait(until.visibilityOf(tooltip), commonConstants.briefBrowserWaitDelay, 'Tooltip is not shown');

    // expect statement here not strictly necessary for checking but helps resilience of function
    expect(tooltip.isDisplayed()).toBe(true);
  }

  const hoverMouseToGetTooltip = async (elementWithTooltip, tooltip) => {
    expect(elementWithTooltip.isDisplayed()).toBe(true);

    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await browser.actions().mouseMove(elementWithTooltip).perform();
        await checkTooltipIsVisible(tooltip);
        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        await browser.wait(until.elementToBeClickable(tooltip), commonConstants.briefBrowserWaitDelay,
          'Tooltip cannot be clicked');
        await commonTests.clickElement(elementWithTooltip);
        await checkTooltipIsVisible(tooltip);
        break;
      default:
        throw new Error(
          `The deviceType '${global.deviceType}' is not supported.`
          + ' Please ensure no tests are switched off using xdescribe.');
    }
  };

  async function checkTooltipIsNotPresent(tooltip) {
    await browser.wait(until.stalenessOf(tooltip), commonConstants.briefBrowserWaitDelay, 'Tooltip is still present');

    // expect statement here not strictly necessary for checking but helps resilience of function
    expect(tooltip.isPresent()).toBe(false);
  }

  const hoverMouseWhereNoTooltip = async (elementWithNoTooltip, tooltip) => {
    expect(elementWithNoTooltip.isDisplayed()).toBe(true);

    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        await browser.actions().mouseMove(elementWithNoTooltip).perform();
        await checkTooltipIsNotPresent(tooltip);
        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        await commonTests.clickElement(elementWithNoTooltip);
        await checkTooltipIsNotPresent(tooltip);
        break;
      default:
        throw new Error(
          `The deviceType '${global.deviceType}' is not supported.`
          + ' Please ensure no tests are switched off using xdescribe.');
    }
  };


  // exposed properties


  // exposed functions

  this.checkTooltipIsElementWithAnyText = async (elementWithTooltip, elementWithNoTooltip, tooltip) => {
    // TODO: will need updating to support mobile
    if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      // eslint-disable-next-line no-console
      console.log('No tooltip testing in mobile as yet - checkTooltipIsElementWithAnyText()');
    } else {
      await hoverMouseToGetTooltip(elementWithTooltip, tooltip);
      await checkers.anyText(tooltip);
      await hoverMouseWhereNoTooltip(elementWithNoTooltip, tooltip);
    }
  };

  this.checkTooltipIsElementWithText = async (elementWithTooltip, elementWithNoTooltip, tooltip, expectedText) => {
    // TODO: will need updating to support mobile
    if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      // eslint-disable-next-line no-console
      console.log('No tooltip testing in mobile as yet - checkTooltipIsElementWithText()');
    } else {
      await hoverMouseToGetTooltip(elementWithTooltip, tooltip);
      await checkers.exactText(tooltip, expectedText);
      await hoverMouseWhereNoTooltip(elementWithNoTooltip, tooltip);
    }
  };

  this.checkTooltipIsElementContainingText
    = async (elementWithTooltip, elementWithNoTooltip, tooltip, expectedText) => {
    // TODO: will need updating to support mobile
      if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      // eslint-disable-next-line no-console
        console.log('No tooltip testing in mobile as yet - checkTooltipIsElementContainingText()');
      } else {
        await hoverMouseToGetTooltip(elementWithTooltip, tooltip);
        await checkers.containingTextIgnoreCase(tooltip, expectedText);
        await hoverMouseWhereNoTooltip(elementWithNoTooltip, tooltip);
      }
    };

  this.checkTooltipIsElementContainingUkDate = async (
    elementWithTooltip, elementWithNoTooltip, tooltip, expectedDate) => {
    // TODO: will need updating to support mobile
    if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      // eslint-disable-next-line no-console
      console.log('No tooltip testing in mobile as yet - checkTooltipIsElementContainingUkDate()');
    } else {
      await hoverMouseToGetTooltip(elementWithTooltip, tooltip);
      await checkers.containingUkDate(tooltip, expectedDate);
      await hoverMouseWhereNoTooltip(elementWithNoTooltip, tooltip);
    }
  };

  this.checkTooltipNotShown = async (elementWithNoTooltip, tooltip) => {
    // TODO: will need updating to support mobile
    if (global.deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      // eslint-disable-next-line no-console
      console.log('No tooltip testing in mobile as yet');
    } else {
      await hoverMouseWhereNoTooltip(elementWithNoTooltip, tooltip);
    }
  };
};
module.exports = tooltipTests;
