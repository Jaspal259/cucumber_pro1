// load common
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('./dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();

// tests
const deferredStatementTests = function deferredStatementTests() {
  // private functions


  // private properties

  const self = this;


  // exposed properties


  // exposed functions
  this.browseToDbDeferredStatementPageFromLogin
    = async (loginPage, dashboardPage, deferredStatementPage, participant, dbServiceInstance) => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);

      // go to the DeferredStatement page
      await self.browseToDbDeferredStatementPageFromDashboard(dashboardPage, deferredStatementPage, dbServiceInstance);
    };

  this.browseToDbDeferredStatementPageFromDashboard
    = async (dashboardPage, deferredStatementPage, dbServiceInstance) => {
      switch (dbServiceInstance) {
        case 0:
          await commonTests.clickElement(dashboardPage.dbCard0.detailsButton(global.deviceType));
          await commonTests.clickElement(deferredStatementPage.planHeader.deferredStatementLink);
          break;

        case 1:
          await commonTests.clickElement(dashboardPage.dbCard1.detailsButton(global.deviceType));
          await commonTests.clickElement(deferredStatementPage.planHeader.deferredStatementLink);
          break;

        default:
          throw new Error(`Does not support dbServiceInstance === ${dbServiceInstance}`);
      }
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(deferredStatementPage);
    };
};

module.exports = deferredStatementTests;
