// load common
const genericCommonTests = require('../../utilities/generic-common.helper.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcBudgetPlannerTests = require('../_common/dc-budget-planner.spec.js');
const DbBudgetPlannerTests = require('../_common/db-budget-planner.spec.js');
const PensionerBudgetPlannerTests = require('../_common/pensioner-budget-planner.spec.js');
const BudgetPlannerTests = require('../_common/budget-planner.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po.js');
const DcBudgetPlannerPage = require('../../page-objects/dc-budget-planner.po.js');
const DbBudgetPlannerPage = require('../../page-objects/db-budget-planner.po.js');
const PensionerBudgetPlannerPage = require('../../page-objects/pensioner-budget-planner.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new StandardParticipant();
const dcBudgetPlannerTests = new DcBudgetPlannerTests();
const dbBudgetPlannerTests = new DbBudgetPlannerTests();
const pensionerBudgetPlannerTests = new PensionerBudgetPlannerTests();
const budgetPlannerTests = new BudgetPlannerTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const dcActiveBudgetPlannerPage = new DcBudgetPlannerPage(
  participant,
  participant.posDcActive.scheme.data.midasSchemeCode,
  participant.posDcActive.data.periodOfServicePrimaryKey);
const dcDeferredBudgetPlannerPage = new DcBudgetPlannerPage(
  participant,
  participant.posDcDeferred.scheme.data.midasSchemeCode,
  participant.posDcDeferred.data.periodOfServicePrimaryKey);
const dbActiveBudgetPlannerPage = new DbBudgetPlannerPage(
  participant,
  participant.posDbActive.scheme.data.midasSchemeCode,
  participant.posDbActive.data.periodOfServicePrimaryKey);
const dbDeferredBudgetPlannerPage = new DbBudgetPlannerPage(
  participant,
  participant.posDbDeferred.scheme.data.midasSchemeCode,
  participant.posDbDeferred.data.periodOfServicePrimaryKey);
const pensionerBudgetPlannerPage = new PensionerBudgetPlannerPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// tests
const scenarioPrefix = `OUK-1629${commonConstants.bddScenarioPrefix}`;
const until = protractor.ExpectedConditions;

async function login(planType, participantStatus, pos) {
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
    participant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  switch (planType) {
    case 'DC':
      // set constants for DC summary and budget planner page objects
      if (participantStatus === 'active') {
        await dcBudgetPlannerTests.browseToDcBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dcPlanSummaryPage, dcActiveBudgetPlannerPage, participant, 0);
      } else {
        await dcBudgetPlannerTests.browseToDcBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dcPlanSummaryPage, dcDeferredBudgetPlannerPage, participant, 1);
      }
      break;
    case 'DB':
      // set constants for DB summary and budget planner page objects
      if (participantStatus === 'active') {
        await dbBudgetPlannerTests.browseToDbBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dbPlanSummaryPage, dbActiveBudgetPlannerPage, participant, 0);
      } else {
        await dbBudgetPlannerTests.browseToDbBudgetPlannerPageFromLogin(
          loginPage, dashboardPage, dbPlanSummaryPage, dbDeferredBudgetPlannerPage, participant, 1);
      }
      break;
    case 'Pensioner':
      // set constants for Pensioner summary and budget planner page objects
      await pensionerBudgetPlannerTests.browseToPensionerBudgetPlannerPageFromLogin(
        loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerBudgetPlannerPage, participant, 0);
      break;
    default:
      throw new Error(`The plan type [${planType}] is not supported`);
  }
}

async function checkInfoModal(budgetPlannerPage, infoLinkElement, labelText) {
  await checkers.anyText(infoLinkElement);
  await commonTests.clickElement(infoLinkElement);
  await browser.wait(
    until.visibilityOf(budgetPlannerPage.budgetPlannerEdit.infoModal.container),
    commonConstants.shortBrowserWaitDelay,
    'Edit info modal not shown');
  await checkers.containingTextIgnoreCase(budgetPlannerPage.budgetPlannerEdit.infoModal.header, labelText);
  await checkers.anyText(budgetPlannerPage.budgetPlannerEdit.infoModal.description);
  await checkers.anyText(budgetPlannerPage.budgetPlannerEdit.infoModal.continueButton(global.deviceType));
  await commonTests.clickElement(budgetPlannerPage.budgetPlannerEdit.infoModal.continueButton(global.deviceType));
}

async function fillInput(inputElement, value) {
  await browser.wait(
    until.visibilityOf(inputElement), commonConstants.briefBrowserWaitDelay, 'Input element not shown');
  await inputElement.sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
  await inputElement.sendKeys(protractor.Key.BACK_SPACE);
  await inputElement.sendKeys(value);
}

function getRandomNumber() {
  return genericCommonTests.getRandomNumber(101.00, 999.99, 2);
}

function runBudgetingEditView(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Budgeting edit view (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting read view
     WHEN the Participant <selects edit button>
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planType} - ${participantStatus}`);
      await login(planType, participantStatus, pos);
    });

    it('THEN redirect Participant to Budgeting edit view', async () => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
      expect(browser.getCurrentUrl()).toContain(budgetPlannerPage.setBudgetUrl);
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.editHeaderLabel(global.deviceType), 'Budget');
      await checkers.anyText(budgetPlannerEdit.editSubHeaderLabel(global.deviceType));
    });

    it('AND enable Participants to manage their "Monthly Income"', async () => {
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.editIncomeLabel, 'Income');
      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editIncomeInput);
      await checkers.anyText(budgetPlannerEdit.editIncomeDescription);
    });

    it('AND enable Participants to manage their "Mortgage / Rent"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editMortgageRentLabel, 'Mortgage');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editMortgageRentLabel, 'Household');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editMortgageRentInput);
      await checkers.anyText(budgetPlannerEdit.editMortgageRentInfoLink);
    });

    it('AND enable Participants to manage their "Council Tax"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editCouncilTaxLabel, 'Council');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editCouncilTaxLabel, 'Utilities');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editCouncilTaxInput);
      await checkers.anyText(budgetPlannerEdit.editCouncilTaxInfoLink);
    });

    it('AND enable Participants to manage their "Insurances & Pension Policies"', async () => {
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.editInsurancesPensionPoliciesLabel, 'Insurance');
      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editInsurancesPensionPoliciesInput);
      await checkers.anyText(budgetPlannerEdit.editInsurancesPensionPoliciesInfoLink);
    });

    it('AND enable Participants to manage their "Utilities (gas, electricity, water)"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editUtilitiesLabel, 'Utilities');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editUtilitiesLabel, 'Family');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editUtilitiesInput);
      await checkers.anyText(budgetPlannerEdit.editUtilitiesInfoLink);
    });

    it('AND enable Participants to manage their "TV / Phone / Internet (incl. mobile)"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editTvPhoneInternetLabel, 'TV');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editTvPhoneInternetLabel, 'Transport');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editTvPhoneInternetInput);
      await checkers.anyText(budgetPlannerEdit.editTvPhoneInternetInfoLink);
    });

    it('AND enable Participants to manage their "Groceries"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editGroceriesLabel, 'Groceries');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editGroceriesLabel, 'Debt repayments');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editGroceriesInput);
      await checkers.anyText(budgetPlannerEdit.editGroceriesInfoLink);
    });

    it('AND enable Participants to manage their "Loan / Credit Card Repayments"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        expect(budgetPlannerEdit.editLoanCreditCardLabel, 'Loan');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editLoanCreditCardLabel, 'Health');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editLoanCreditCardInput);
      await checkers.anyText(budgetPlannerEdit.editLoanCreditCardInfoLink);
    });

    it('AND enable Participants to manage their "Travel"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editTravelLabel, 'Travel');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editTravelLabel, 'Lifestyle');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editTravelInput);
      await checkers.anyText(budgetPlannerEdit.editTravelInfoLink);
    });

    it('AND enable Participants to manage their "Leisure"', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editLeisureLabel, 'Leisure');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerEdit.editLeisureLabel, 'Annual Expenses');
      }

      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editLeisureInput);
      await checkers.anyText(budgetPlannerEdit.editLeisureInfoLink);
    });

    it('AND enable Participants to manage their "Other Expenses"', async () => {
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.editOtherExpensesLabel, 'Other');
      await checkers.inputAnyGbpNumberFormat(budgetPlannerEdit.editOtherExpensesInput);
      await checkers.anyText(budgetPlannerEdit.editOtherExpensesInfoLink);
    });

    it('AND enable cancel button', async () => {
      expect(budgetPlannerEdit.cancelButton(global.deviceType).isEnabled()).toBe(true);
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.cancelButton(global.deviceType), 'Cancel');
      await checkers.isMercerOsButtonUnselected(budgetPlannerEdit.cancelButton(global.deviceType));
    });

    it('AND enable save button (primary style button)', async () => {
      expect(budgetPlannerEdit.saveButton.isEnabled()).toBe(true);
      await checkers.containingTextIgnoreCase(budgetPlannerEdit.saveButton, 'Save');
      await checkers.isMercerOsButtonSelected(budgetPlannerEdit.saveButton);
    });

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runBudgetingEditView(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runBudgetingEditView(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runBudgetingEditView(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runBudgetingEditView(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runBudgetingEditView(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runBudgetingUpdateScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Budgeting, successful update (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting edit view
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;
    const gbpIncomeValue = `500,${getRandomNumber()}`;
    const gbpExpenditureValues = {
      mortgage: `10,${getRandomNumber()}`,
      council: `1,${getRandomNumber()}`,
      insurances: getRandomNumber(),
      utilities: getRandomNumber(),
      tv: getRandomNumber(),
      groceries: getRandomNumber(),
      loan: `1,${getRandomNumber()}`,
      travel: `15,${getRandomNumber()}`,
      leisure: `2,${getRandomNumber()}`,
      other: `32,${getRandomNumber()}`
    };

    const totalExpenses = Object.keys(gbpExpenditureValues).reduce(
      (a, b) => Number(a.toString().replace(',', '')) + Number(gbpExpenditureValues[b].toString().replace(',', '')), 0)
      .toFixed(2);

    // const totalExpenses = Object.keys(gbpExpenditureValues).reduce(
    //   a => Number(gbpExpenditureValues[a].toString().replace(',', '')), 1).toFixed(2);

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
    });

    it('WHEN the Participant submits valid income/expenditure values'
      + ' THEN return Participant to Budgeting read view', async () => {
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
      await fillInput(budgetPlannerEdit.editIncomeInput, gbpIncomeValue);
      await fillInput(budgetPlannerEdit.editMortgageRentInput, gbpExpenditureValues.mortgage);
      await fillInput(budgetPlannerEdit.editCouncilTaxInput, gbpExpenditureValues.council);
      await fillInput(budgetPlannerEdit.editInsurancesPensionPoliciesInput, gbpExpenditureValues.insurances);
      await fillInput(budgetPlannerEdit.editUtilitiesInput, gbpExpenditureValues.utilities);
      await fillInput(budgetPlannerEdit.editTvPhoneInternetInput, gbpExpenditureValues.tv);
      await fillInput(budgetPlannerEdit.editGroceriesInput, gbpExpenditureValues.groceries);
      await fillInput(budgetPlannerEdit.editLoanCreditCardInput, gbpExpenditureValues.loan);
      await fillInput(budgetPlannerEdit.editTravelInput, gbpExpenditureValues.travel);
      await fillInput(budgetPlannerEdit.editLeisureInput, gbpExpenditureValues.leisure);
      await fillInput(budgetPlannerEdit.editOtherExpensesInput, gbpExpenditureValues.other);
      await commonTests.clickElement(budgetPlannerEdit.saveButton);
      await browser.wait(until.visibilityOf(budgetPlannerDefault.mortgageRentLabel),
        commonConstants.shortBrowserWaitDelay,
        'Mortgage rent label not shown');
    });

    it('AND display updated income/expenditure values', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.mortgageRentLabel, 'Mortgage');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.councilTaxLabel, 'Council');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.tvPhoneInternetLabel, 'TV');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.groceriesLabel, 'Groceries');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.loanCreditCardLabel, 'Loan');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.travelLabel, 'Travel');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.leisureLabel, 'Leisure');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.mortgageRentLabel, 'Household');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.councilTaxLabel, 'Utilities');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.tvPhoneInternetLabel, 'Transport');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.groceriesLabel, 'Debt repayments');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.loanCreditCardLabel, 'Health');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.travelLabel, 'Lifestyle');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.leisureLabel, 'Annual Expenses');
      }

      await checkers.exactGbp(budgetPlannerDefault.mortgageRentValue(global.deviceType),
        `£${gbpExpenditureValues.mortgage}`);
      await checkers.exactGbp(budgetPlannerDefault.councilTaxValue(global.deviceType),
        `£${gbpExpenditureValues.council}`);
      await checkers.containingTextIgnoreCase(budgetPlannerDefault.insurancesPensionPoliciesLabel, 'Insurance');
      await checkers.exactGbp(budgetPlannerDefault.insurancesPensionPoliciesValue(global.deviceType),
        `£${gbpExpenditureValues.insurances}`);
      await checkers.exactGbp(budgetPlannerDefault.utilitiesValue(global.deviceType),
        `£${gbpExpenditureValues.utilities}`);
      await checkers.exactGbp(budgetPlannerDefault.tvPhoneInternetValue(global.deviceType),
        `£${gbpExpenditureValues.tv}`);
      await checkers.exactGbp(budgetPlannerDefault.groceriesValue(global.deviceType),
        `£${gbpExpenditureValues.groceries}`);
      await checkers.exactGbp(budgetPlannerDefault.loanCreditCardValue(global.deviceType),
        `£${gbpExpenditureValues.loan}`);
      await checkers.exactGbp(budgetPlannerDefault.travelValue(global.deviceType),
        `£${gbpExpenditureValues.travel}`);
      await checkers.exactGbp(budgetPlannerDefault.leisureValue(global.deviceType),
        `£${gbpExpenditureValues.leisure}`);
      await checkers.containingTextIgnoreCase(budgetPlannerDefault.otherExpensesLabel, 'Other');
      await checkers.exactGbp(budgetPlannerDefault.otherExpensesValue(global.deviceType),
        `£${gbpExpenditureValues.other}`);
    });

    it('AND display updated income/expenditure outcome', async () => {
      if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.expensesLabel, 'Expenses');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.budgetLabel, 'Budget');
      } else {
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.expensesLabel, 'EXPENSES');
        await checkers.containingTextIgnoreCase(budgetPlannerDefault.budgetLabel, 'INCOME');
      }

      await checkers.exactGbp(budgetPlannerDefault.expensesValue, totalExpenses);
      await checkers.exactGbp(budgetPlannerDefault.budgetValue, gbpIncomeValue);
    });

    it('AND display date last updated (format DD/MM/YYYY)', async () => {
      await checkers.containingCurrentUkDate(budgetPlannerDefault.lastUpdateDate);
    });

    it('AND display insights based on income/expenditure outcome', async () => {
      const expensesValue = await budgetPlannerDefault.expensesValue.getText();
      await checkers.isGbpGreaterThan(budgetPlannerDefault.budgetValue, expensesValue);
      expect(budgetPlannerDefault.chart.isDisplayed()).toBe(true);
    });

    it('AND display guidance text based on income/expenditure outcome', async () => {
      await checkers.containingTextIgnoreCase(budgetPlannerDefault.infoLabel, 'under budget');
    });

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runBudgetingUpdateScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runBudgetingUpdateScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runBudgetingUpdateScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runBudgetingUpdateScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runBudgetingUpdateScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runInfoLinksEditViewScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Income/Expenditure labels, info links (Edit view)
  (${planType} ${participantStatus})`, () => {
    /*
     GIVEN guidance text has been populated for <income/expenditure>
     AND view is "Edit"
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);
    });

    function checkInfoIcon(expenseDescription, expenseInfoLink) {
      it(`WHEN the Participant selects the "${expenseDescription}" info icon button `
        + ` THEN display corresponding "${expenseDescription}" guidance text`, async () => {
        await checkInfoModal(budgetPlannerPage, expenseInfoLink, expenseDescription);
      });
    }

    if (ov3Environment === commonConstants.appEnvironmentEnum.qa
      || ov3Environment === commonConstants.appEnvironmentEnum.uat) {
      checkInfoIcon('Mortgage / Rent', budgetPlannerEdit.editMortgageRentInfoLink);
      checkInfoIcon('Council Tax', budgetPlannerEdit.editCouncilTaxInfoLink);
      checkInfoIcon('Insurances & Pension Policies', budgetPlannerEdit.editInsurancesPensionPoliciesInfoLink);
      checkInfoIcon('Utilities (gas, electricity, water)', budgetPlannerEdit.editUtilitiesInfoLink);
      checkInfoIcon('TV / Phone / Internet', budgetPlannerEdit.editTvPhoneInternetInfoLink);
      checkInfoIcon('Groceries', budgetPlannerEdit.editGroceriesInfoLink);
      checkInfoIcon('Loan / Credit Card Repayments', budgetPlannerEdit.editLoanCreditCardInfoLink);
      checkInfoIcon('Travel', budgetPlannerEdit.editTravelInfoLink);
      checkInfoIcon('Leisure', budgetPlannerEdit.editLeisureInfoLink);
      checkInfoIcon('Other Expenses', budgetPlannerEdit.editOtherExpensesInfoLink);
    } else {
      checkInfoIcon('Household', budgetPlannerEdit.editMortgageRentInfoLink);
      checkInfoIcon('Utilities', budgetPlannerEdit.editCouncilTaxInfoLink);
      checkInfoIcon('Insurance', budgetPlannerEdit.editInsurancesPensionPoliciesInfoLink);
      checkInfoIcon('Family', budgetPlannerEdit.editUtilitiesInfoLink);
      checkInfoIcon('Transport', budgetPlannerEdit.editTvPhoneInternetInfoLink);
      checkInfoIcon('Debt repayments', budgetPlannerEdit.editGroceriesInfoLink);
      checkInfoIcon('Health', budgetPlannerEdit.editLoanCreditCardInfoLink);
      checkInfoIcon('Lifestyle', budgetPlannerEdit.editTravelInfoLink);
      checkInfoIcon('Annual Expenses', budgetPlannerEdit.editLeisureInfoLink);
      checkInfoIcon('Other', budgetPlannerEdit.editOtherExpensesInfoLink);
    }

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runInfoLinksEditViewScenario(
  dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runInfoLinksEditViewScenario(
  dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runInfoLinksEditViewScenario(
  dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runInfoLinksEditViewScenario(
  dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runInfoLinksEditViewScenario(
  pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runInfoLinksReadViewScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Income/Expenditure labels, info links (Read view)
  (${planType} ${participantStatus})`, () => {
    /*
     GIVEN guidance text has been populated for <income/expenditure>
     AND view is "Read"
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
    });

    function checkInfoIcon(expenseDescription, expenseInfoIcon, expenseLabel) {
      it(`WHEN the Participant selects the "${expenseDescription}" info icon button`
        + ` THEN display corresponding "${expenseDescription}" guidance text`, async () => {
        await tooltipTests.checkTooltipIsElementWithAnyText(
          expenseInfoIcon,
          expenseLabel,
          budgetPlannerDefault.tooltips.soleTooltip
        );
      });
    }

    checkInfoIcon(
      'Mortgage / Rent',
      budgetPlannerDefault.mortgageRentInfoIcon,
      budgetPlannerDefault.mortgageRentLabel);
    checkInfoIcon(
      'Council Tax',
      budgetPlannerDefault.councilTaxInfoIcon,
      budgetPlannerDefault.councilTaxLabel);
    checkInfoIcon(
      'Insurances & Pension Policies',
      budgetPlannerDefault.insurancesPensionPoliciesInfoIcon,
      budgetPlannerDefault.insurancesPensionPoliciesLabel);
    checkInfoIcon(
      'Utilities (gas, electricity, water)',
      budgetPlannerDefault.utilitiesInfoIcon,
      budgetPlannerDefault.utilitiesLabel);
    checkInfoIcon(
      'TV / Phone / Internet (incl. mobile)',
      budgetPlannerDefault.tvPhoneInternetInfoIcon,
      budgetPlannerDefault.tvPhoneInternetLabel);
    checkInfoIcon(
      'Groceries',
      budgetPlannerDefault.groceriesInfoIcon,
      budgetPlannerDefault.groceriesLabel);
    checkInfoIcon(
      'Loan / Credit Card Repayments',
      budgetPlannerDefault.loanCreditCardInfoIcon,
      budgetPlannerDefault.loanCreditCardLabel);
    checkInfoIcon(
      'Travel',
      budgetPlannerDefault.travelInfoIcon,
      budgetPlannerDefault.travelLabel);
    checkInfoIcon(
      'Leisure',
      budgetPlannerDefault.leisureInfoIcon,
      budgetPlannerDefault.leisureLabel);
    checkInfoIcon('Other Expenses',
      budgetPlannerDefault.otherExpensesInfoInfo,
      budgetPlannerDefault.otherExpensesLabel);

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runInfoLinksReadViewScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runInfoLinksReadViewScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runInfoLinksReadViewScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runInfoLinksReadViewScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runInfoLinksReadViewScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);

function runCancelNoEditScenario(budgetPlannerPage, planType, participantStatus, pos) {
  describe(`${scenarioPrefix}Cancel no edit (${planType} ${participantStatus})`, () => {
    /*
     GIVEN view is Budgeting edit view
     AND no edits to the <income/expenditure> amounts have been made
     AND amounts shown are same as before edit was attempted
     */

    const budgetPlannerDefault = budgetPlannerPage.budgetPlannerDefault;
    const budgetPlannerEdit = budgetPlannerPage.budgetPlannerEdit;
    const expectedExpenditureValues = {};

    async function getExpenditureValue(element, key) {
      const value = await element.getText();
      expectedExpenditureValues[`${key}`] = value;
    }

    beforeAll(async () => {
      await login(planType, participantStatus, pos);
    });


    it(`WHEN the Participant selects cancel
        THEN return Participant to Budgeting read view`, async () => {
      await getExpenditureValue(budgetPlannerDefault.mortgageRentValue(global.deviceType), 'mortgage');
      await getExpenditureValue(budgetPlannerDefault.councilTaxValue(global.deviceType), 'council');
      await getExpenditureValue(budgetPlannerDefault.insurancesPensionPoliciesValue(global.deviceType), 'insurances');
      await getExpenditureValue(budgetPlannerDefault.utilitiesValue(global.deviceType), 'utilities');
      await getExpenditureValue(budgetPlannerDefault.tvPhoneInternetValue(global.deviceType), 'tv');
      await getExpenditureValue(budgetPlannerDefault.groceriesValue(global.deviceType), 'groceries');
      await getExpenditureValue(budgetPlannerDefault.loanCreditCardValue(global.deviceType), 'loan');
      await getExpenditureValue(budgetPlannerDefault.travelValue(global.deviceType), 'travel');
      await getExpenditureValue(budgetPlannerDefault.leisureValue(global.deviceType), 'leisure');
      await getExpenditureValue(budgetPlannerDefault.otherExpensesValue(global.deviceType), 'other');

      await budgetPlannerTests.browseToEditBudgetFromBudgetPlannerPage(
        budgetPlannerPage, budgetPlannerDefault, budgetPlannerEdit);

      await commonTests.clickElement(budgetPlannerEdit.cancelButton(global.deviceType));
      await commonTests.checkPlanPageLoadsAndContainsPlanHeader(budgetPlannerPage);
      await checkers.exactText(budgetPlannerDefault.mortgageRentValue(global.deviceType),
        expectedExpenditureValues.mortgage);
      await checkers.exactText(budgetPlannerDefault.councilTaxValue(global.deviceType),
        expectedExpenditureValues.council);
      await checkers.exactText(budgetPlannerDefault.insurancesPensionPoliciesValue(global.deviceType),
        expectedExpenditureValues.insurances);
      await checkers.exactText(budgetPlannerDefault.utilitiesValue(global.deviceType),
        expectedExpenditureValues.utilities);
      await checkers.exactText(budgetPlannerDefault.tvPhoneInternetValue(global.deviceType),
        expectedExpenditureValues.tv);
      await checkers.exactText(budgetPlannerDefault.groceriesValue(global.deviceType),
        expectedExpenditureValues.groceries);
      await checkers.exactText(budgetPlannerDefault.loanCreditCardValue(global.deviceType),
        expectedExpenditureValues.loan);
      await checkers.exactText(budgetPlannerDefault.travelValue(global.deviceType),
        expectedExpenditureValues.travel);
      await checkers.exactText(budgetPlannerDefault.leisureValue(global.deviceType),
        expectedExpenditureValues.leisure);
      await checkers.exactText(budgetPlannerDefault.otherExpensesValue(global.deviceType),
        expectedExpenditureValues.other);
    });

    afterAll(async () => {
      await commonTests.logOut(budgetPlannerPage, loginPage);
    });
  });
}

runCancelNoEditScenario(dcActiveBudgetPlannerPage, 'DC', 'active', participant.posDcActive);
runCancelNoEditScenario(dcDeferredBudgetPlannerPage, 'DC', 'deferred', participant.posDcDeferred);
runCancelNoEditScenario(dbActiveBudgetPlannerPage, 'DB', 'active', participant.posDbActive);
runCancelNoEditScenario(dbDeferredBudgetPlannerPage, 'DB', 'deferred', participant.posDbDeferred);
runCancelNoEditScenario(pensionerBudgetPlannerPage, 'Pensioner', '', participant.posPensioner);
