// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const PensionerPlanMaterialsPage = require('../../page-objects/pensioner-plan-materials.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const PensionerPlanMaterialsTests = require('../_common/pensioner-plan-materials.spec');
const PlanMaterialsTests = require('../_common/plan-materials.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionerPlanMaterialsTests = new PensionerPlanMaterialsTests();
const planMaterialsTests = new PlanMaterialsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const pensionerPlanMaterialsPage = new PensionerPlanMaterialsPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const planMaterials = pensionerPlanMaterialsPage.planMaterials;

// other
let tabInstanceCountExpected;
let tabInstanceEnum;
let documentsTopicCountExpected;
let documentsTopicInstanceEnum;
let planMaterialsTopicCountExpected;
let planMaterialsTopicInstanceEnum;
const until = protractor.ExpectedConditions;

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// DEFINE EXPECTED TABS HERE
switch (ov3Environment) {
  // note we cannot easily use e.g. documentsTopicInstanceEnum.length because of the dreaded async problem
  // hence the specific *CountExpected variables
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    tabInstanceCountExpected = 2;
    tabInstanceEnum = {
      documents: 0,
      planMaterials: 1
    };

    documentsTopicCountExpected = 5;
    documentsTopicInstanceEnum = {
      policyDocuments: 0,
      payslips: 1,
      p60s: 2,
      pensionIncreaseLetters: 3,
      confirmationOfPayment: 4
    };

    planMaterialsTopicCountExpected = 6;
    planMaterialsTopicInstanceEnum = {
      planBooklets: 0,
      addendums: 1,
      planInfo: 2,
      announcements: 3,
      newsletters: 4,
      forms: 5
    };

    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

// tests
const scenarioPrefix = `OUK-1075${commonConstants.bddScenarioPrefix}`;

async function pensionerCheckTabName(pensionerPlanMaterialsTab, selectedTabInstance) {
  let expectedTabName;

  const tabName = await pensionerPlanMaterialsTab.getText();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      expectedTabName = 'Documents';
      break;
    case tabInstanceEnum.planMaterials:
      expectedTabName = 'Materials';
      break;
    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }

  expect(tabName).toContain(expectedTabName);
  return tabName;
}

async function pensionerGetSelectedTopicEnum(selectedTabInstance, selectedTopicInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      switch (selectedTopicInstance) {
        case documentsTopicInstanceEnum.policyDocuments:
          return planMaterials.selectedTopicEnum.pensionerPolicyDocuments;
        case documentsTopicInstanceEnum.payslips:
          return planMaterials.selectedTopicEnum.pensionerPayslips;
        case documentsTopicInstanceEnum.p60s:
          return planMaterials.selectedTopicEnum.pensionerP60s;
        case documentsTopicInstanceEnum.pensionIncreaseLetters:
          return planMaterials.selectedTopicEnum.pensionerPensionIncreaseLetters;
        case documentsTopicInstanceEnum.confirmationOfPayment:
          return planMaterials.selectedTopicEnum.pensionerConfirmationOfPayment;
        default:
          throw new Error(`Documents tab topic instance ${selectedTopicInstance} is not supported`);
      }

    case tabInstanceEnum.planMaterials:
      switch (selectedTopicInstance) {
        case planMaterialsTopicInstanceEnum.planBooklets:
          return planMaterials.selectedTopicEnum.pensionerPlanBooklets;
        case planMaterialsTopicInstanceEnum.addendums:
          return planMaterials.selectedTopicEnum.pensionerAddendums;
        case planMaterialsTopicInstanceEnum.planInfo:
          return planMaterials.selectedTopicEnum.pensionerPlanInfo;
        case planMaterialsTopicInstanceEnum.announcements:
          return planMaterials.selectedTopicEnum.pensionerAnnouncements;
        case planMaterialsTopicInstanceEnum.newsletters:
          return planMaterials.selectedTopicEnum.pensionerNewsletters;
        case planMaterialsTopicInstanceEnum.forms:
          return planMaterials.selectedTopicEnum.pensionerForms;
        case planMaterialsTopicInstanceEnum.investmentGuides:
          return planMaterials.selectedTopicEnum.pensionerInvestmentGuides;
        case planMaterialsTopicInstanceEnum.fundFactsheets:
          return planMaterials.selectedTopicEnum.pensionerFundFactsheets;
        case planMaterialsTopicInstanceEnum.fundManagerInfo:
          return planMaterials.selectedTopicEnum.pensionerFundManagerInfo;
        default:
          throw new Error(`Plan materials tab topic instance ${selectedTopicInstance} is not supported`);
      }

    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }
}

async function pensionerGetExpectedCountOfTopics(selectedTabInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      return documentsTopicCountExpected;
    case tabInstanceEnum.planMaterials:
      return planMaterialsTopicCountExpected;
    default:
      fail(`Tab instance ${selectedTabInstance} is not supported`);
      return false;
  }
}

async function pensionerCheckSelectedTopicName(actualTabInstance, i) {
  const topicEnum = await pensionerGetSelectedTopicEnum(actualTabInstance, i);
  const topic = await planMaterialsTests.getTopic(planMaterials, i);
  await planMaterialsTests.checkTopicName(planMaterials, topicEnum, topic);
}

async function pensionerCheckAllTopicNames(selectedTabInstance) {
  const expectedCountOfTopics = await pensionerGetExpectedCountOfTopics(selectedTabInstance);
  const actualTopicCount = await planMaterials.getPlanMaterialsTopicCount();
  expect(actualTopicCount).toBe(
    expectedCountOfTopics,
    `${actualTopicCount} topic(s) shown on tab ${selectedTabInstance} when ${expectedCountOfTopics} expected`);

  let i;

  for (i = 0; i < expectedCountOfTopics; i += 1) {
    // using a function here as this also checks order of topics shown for other checks below
    await pensionerCheckSelectedTopicName(selectedTabInstance, i);
  }
}

async function pensionerCheckTopicNamesInTab(tab, selectedTabInstance, tabCount) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(planMaterials, tab, selectedTabInstance);

  if (tabLoaded) {
    if (tabCount > 1) {
      // 1 of multiple tabs
      await checkers.isMercerOsTabSelected(tab);
    }
    await pensionerCheckAllTopicNames(selectedTabInstance);
  }
}

async function pensionerCheckOnlyFirstTopicIsShownAsSelected(pensionerPlanMaterialsTab, selectedTabInstance) {
  await browser.wait(until.visibilityOf(pensionerPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not visible');
  await checkers.anyText(pensionerPlanMaterialsTab);
  await browser.wait(until.elementToBeClickable(pensionerPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not clickable');

  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, pensionerPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    const expectedCountOfTopics = await pensionerGetExpectedCountOfTopics(selectedTabInstance);
    await planMaterialsTests.checkOnlyFirstTopicSelected(planMaterials, expectedCountOfTopics);
  }
}

async function pensionerCheckLoneOrMultipleTopic(selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await pensionerGetSelectedTopicEnum(selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.clickTopicAndCheckTopicContent(
    planMaterials, selectedTopicEnum, topic, selectedTopicInstance);
}

async function pensionerCheckLoneOrMultipleTopics(selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple tabs
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = await planMaterials.planMaterialsMultipleTopic(t);
      await pensionerCheckLoneOrMultipleTopic(selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single tab
    const topic = await planMaterials.planMaterialsLoneTopic;
    await pensionerCheckLoneOrMultipleTopic(selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function pensionerCheckAllTopicContentForTab(planMaterialsTab, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, planMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await pensionerCheckLoneOrMultipleTopics(selectedTabInstance);
  }
}

describe(`${scenarioPrefix}Plan Materials full page view + Default view full page view`
  + ' + Pensioner Topic visibility + Media display (ALL tabs, ALL topics)', () => {
  /*
    common
    -----------------------------------------------------------------
    GIVEN Pensioner has navigated to [PENSIONER PLAN MATERIALS PAGE]

    Plan Materials full page view
    -----------------------------------------------------------------
    AND one or multiple [PENSIONER TOPICS] are available
    WHEN [PENSIONER PLAN MATERIALS PAGE] loads

    Default view full page view
    -----------------------------------------------------------------
    AND one or multiple [PENSIONER TOPICS] are available
    WHEN the [PENSIONER PLAN MATERIALS PAGE] loads

    Pensioner Topic visibility
    -----------------------------------------------------------------
    AND one or multiple [PENSIONER TOPICS] are available
    WHEN Pensioner selects a [PENSIONER TOPIC CATEGORY]

    Media display
    -----------------------------------------------------------------
    AND one or multiple [PENSIONER TOPIC LINKS] are available
    WHEN the Pensioner selects a [PENSIONER TOPIC LINK]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await pensionerPlanMaterialsTests.browseToPensionsPlanMaterialsPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerPlanMaterialsPage, standardParticipant, 0);
  });

  it('Plan Materials full page view: THEN based on available'
    + ' [PENSIONER TOPICS] show [PENSIONER TOPIC CATEGORIES]', async () => {
    await planMaterialsTests.checkPageContentHeaders(pensionerPlanMaterialsPage);

    // complex TE code required as lone tabs render in different way to multiple tabs
    const tabCount = await pensionerPlanMaterialsPage.header.getPageContentHeaderTabCount();
    expect(tabCount).toBe(
      tabInstanceCountExpected,
      `${tabCount} tab(s) shown when ${tabInstanceCountExpected} expected`);

    if (tabCount > 1) {
      // multiple tabs
      let t;

      for (t = 0; t < tabCount; t += 1) {
        const tab = await pensionerPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
        await pensionerCheckTabName(tab, t);
        await pensionerCheckTopicNamesInTab(tab, t, tabCount);
      }
    } else if (tabCount === 1) {
      // single tab
      const tab = pensionerPlanMaterialsPage.header.pageContentHeaderLoneTab;
      await pensionerCheckTabName(tab, 0);
      await pensionerCheckTopicNamesInTab(tab, 0, tabCount);
    }
  });

  it('Default view full page view: THEN show first [PENSIONER TOPIC CATEGORY] as expanded view'
    + ' AND show first [PENSIONER TOPIC] '
    + ' AND show all [MEDIA] related to first [PENSIONER TOPIC]', async () => {
    // note 'AND show all [MEDIA] related to first [PENSIONER TOPIC]' will be covered in 'Pensioner Topic visibility'
    await browser.wait(
      until.presenceOf(pensionerPlanMaterialsPage.header.pageContentHeader),
      commonConstants.shortBrowserWaitDelay, 'Pensioner plan materials page content header not present');
    expect(pensionerPlanMaterialsPage.header.pageContentHeader.isPresent()).toBe(true);

    // complex TE code required as lone tabs render in different way to multiple tabs
    const tabCount = await pensionerPlanMaterialsPage.header.getPageContentHeaderTabCount();

    if (tabCount > 1) {
      // multiple tabs
      let t;

      for (t = 0; t < tabCount; t += 1) {
        const tab = await pensionerPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
        await pensionerCheckOnlyFirstTopicIsShownAsSelected(tab, t);
      }
    } else if (tabCount === 1) {
      // single tab
      const tab = pensionerPlanMaterialsPage.header.pageContentHeaderLoneTab;
      await pensionerCheckOnlyFirstTopicIsShownAsSelected(tab, 0);
    }
  });

  it('Pensioner Topic visibility:'
      + ' THEN show all available [PENSIONER TOPIC LINKS]'
      + ' Media display:'
      + ' THEN show all available [MEDIA]'
      + ' AND for each [MEDIA] show [MEDIA TYPE ICON] i.e. video, pdf, link'
      + ' AND [MEDIA NAME] i.e. Q4 2017 Newsletter'
      + ' AND [MEDIA SIZE]'
      + ' AND [ACTION ICON] i.e. Play, Open, Download'
      + ' AND ordered by priority then date published (this phrase not TE coded)', async () => {
    // complex TE code required as lone tabs render in different way to multiple tabs
    const tabCount = await pensionerPlanMaterialsPage.header.getPageContentHeaderTabCount();

    if (tabCount > 1) {
      // multiple tabs
      let t;

      for (t = 0; t < tabCount; t += 1) {
        const tab = await pensionerPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
        await pensionerCheckAllTopicContentForTab(tab, t);
      }
    } else if (tabCount === 1) {
      // single tab
      const tab = pensionerPlanMaterialsPage.header.pageContentHeaderLoneTab;
      await pensionerCheckAllTopicContentForTab(tab, 0);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanMaterialsPage, loginPage);
  });
});

async function pensionerCheckUrlAndTooltipForLoneOrMultipleTopic(
  selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await pensionerGetSelectedTopicEnum(selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.checkActionUrlAndTooltipForTopic(
    pensionerPlanMaterialsPage, planMaterials, selectedTopicEnum, topic);
}

async function pensionerCheckUrlAndTooltipForLoneOrMultipleTopics(selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple tabs
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = planMaterials.planMaterialsMultipleTopic(t);
      await pensionerCheckUrlAndTooltipForLoneOrMultipleTopic(selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single tab
    const topic = planMaterials.planMaterialsLoneTopic;
    await pensionerCheckUrlAndTooltipForLoneOrMultipleTopic(selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function pensionerCheckDownloadUrlAndTooltipForTopicsInTab(pensionerPlanMaterialsTab, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, pensionerPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await pensionerCheckUrlAndTooltipForLoneOrMultipleTopics(selectedTabInstance);
  }
}

describe(`${scenarioPrefix}Action behaviour + Action hover (ALL tabs, ALL topics)`, () => {
  /*
    Action behaviour
    -----------------------------------------------------------------
    GIVEN Pensioner has navigated to [PENSIONER PLAN MATERIALS PAGE]
    AND one or multiple [MEDIA] is available
    WHEN [MEDIA] is selected

    Action hover
    -----------------------------------------------------------------
    GIVEN the Member is viewing a piece of [MEDIA]
    WHEN the Member hovers over an [ACTION ICON]
   */

  beforeAll(async () => {
    await pensionerPlanMaterialsTests.browseToPensionsPlanMaterialsPageFromLogin(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerPlanMaterialsPage, standardParticipant, 0);
  });

  it('Action behaviour: THEN [ACTION BEHAVIOUR] based on [MEDIA TYPE]'
    + ' Action hover: THEN display [ACTION ICON DESC] i.e. Download, Play, Open', async () => {
    // complex TE code required as lone tabs render in different way to multiple tabs
    const tabCount = await pensionerPlanMaterialsPage.header.getPageContentHeaderTabCount();

    if (tabCount > 1) {
      // multiple tabs
      let t;

      for (t = 0; t < tabCount; t += 1) {
        const tab = await pensionerPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
        await pensionerCheckDownloadUrlAndTooltipForTopicsInTab(tab, t);
      }
    } else if (tabCount === 1) {
      // single tab
      const tab = pensionerPlanMaterialsPage.header.pageContentHeaderLoneTab;
      await pensionerCheckDownloadUrlAndTooltipForTopicsInTab(tab, 0);
    }
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanMaterialsPage, loginPage);
  });
});
