// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DbPlanMaterialsPage = require('../../page-objects/db-plan-materials.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbPlanMaterialsTests = require('../_common/db-plan-materials.spec');
const PlanMaterialsTests = require('../_common/plan-materials.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbPlanMaterialsTests = new DbPlanMaterialsTests();
const planMaterialsTests = new PlanMaterialsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// other
let tabInstanceCountExpected;
let tabInstanceEnum;
let documentsTopicCountExpected;
let documentsTopicInstanceEnum;
let planMaterialsTopicCountExpected;
let planMaterialsTopicInstanceEnum;
const until = protractor.ExpectedConditions;

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

switch (ov3Environment) {
  // note we cannot easily use e.g. documentsTopicInstanceEnum.length because of the dreaded async problem
  // hence the specific *CountExpected variables
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    tabInstanceCountExpected = 2;
    tabInstanceEnum = {
      documents: 0,
      planMaterials: 1,
    };

    documentsTopicCountExpected = 1;
    documentsTopicInstanceEnum = {
      policyDocuments: 0
    };

    planMaterialsTopicCountExpected = 6;
    planMaterialsTopicInstanceEnum = {
      planBooklets: 0,
      addendums: 1,
      planInfo: 2,
      announcements: 3,
      newsletters: 4,
      forms: 5
    };

    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

// tests
const scenarioPrefix = `OUK-1065${commonConstants.bddScenarioPrefix}`;

async function dbCheckTabName(dbPlanMaterialsTab, selectedTabInstance) {
  let expectedTabName;

  const tabName = await dbPlanMaterialsTab.getText();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      expectedTabName = 'Documents';
      break;
    case tabInstanceEnum.planMaterials:
      expectedTabName = 'Materials';
      break;
    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }

  expect(tabName).toContain(expectedTabName);
  return tabName;
}

async function dbGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      switch (selectedTopicInstance) {
        case documentsTopicInstanceEnum.policyDocuments:
          return planMaterials.selectedTopicEnum.dbPolicyDocuments;
        default:
          throw new Error(`Documents tab topic instance ${selectedTopicInstance} is not supported`);
      }

    case tabInstanceEnum.planMaterials:
      switch (selectedTopicInstance) {
        case planMaterialsTopicInstanceEnum.planBooklets:
          return planMaterials.selectedTopicEnum.pensionerPlanBooklets;
        case planMaterialsTopicInstanceEnum.addendums:
          return planMaterials.selectedTopicEnum.pensionerAddendums;
        case planMaterialsTopicInstanceEnum.planInfo:
          return planMaterials.selectedTopicEnum.pensionerPlanInfo;
        case planMaterialsTopicInstanceEnum.announcements:
          return planMaterials.selectedTopicEnum.pensionerAnnouncements;
        case planMaterialsTopicInstanceEnum.newsletters:
          return planMaterials.selectedTopicEnum.pensionerNewsletters;
        case planMaterialsTopicInstanceEnum.forms:
          return planMaterials.selectedTopicEnum.pensionerForms;
        case planMaterialsTopicInstanceEnum.investmentGuides:
          return planMaterials.selectedTopicEnum.pensionerInvestmentGuides;
        case planMaterialsTopicInstanceEnum.fundFactsheets:
          return planMaterials.selectedTopicEnum.pensionerFundFactsheets;
        case planMaterialsTopicInstanceEnum.fundManagerInfo:
          return planMaterials.selectedTopicEnum.pensionerFundManagerInfo;
        default:
          throw new Error(`Plan materials tab topic instance ${selectedTopicInstance} is not supported`);
      }

    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }
}

async function dbGetExpectedCountOfTopics(selectedTabInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      return documentsTopicCountExpected;
    case tabInstanceEnum.planMaterials:
      return planMaterialsTopicCountExpected;
    default:
      fail(`Tab instance ${selectedTabInstance} is not supported`);
  }

  return false;
}

async function dbCheckSelectedTopicName(planMaterials, actualTabInstance, i) {
  const topicEnum = await dbGetSelectedTopicEnum(planMaterials, actualTabInstance, i);
  const topic = await planMaterialsTests.getTopic(planMaterials, i);
  await planMaterialsTests.checkTopicName(planMaterials, topicEnum, topic);
}

async function dbCheckAllTopicNames(planMaterials, selectedTabInstance) {
  const expectedCountOfTopics = await dbGetExpectedCountOfTopics(selectedTabInstance);
  const actualTopicCount = await planMaterials.getPlanMaterialsTopicCount();
  expect(actualTopicCount).toBe(
    expectedCountOfTopics,
    `${actualTopicCount} topic(s) shown on tab ${selectedTabInstance} when ${expectedCountOfTopics} expected`);

  let i;

  for (i = 0; i < expectedCountOfTopics; i += 1) {
    // using a function here as this also checks order of topics shown for other checks below
    await dbCheckSelectedTopicName(planMaterials, selectedTabInstance, i);
  }
}

async function dbCheckTopicNamesInTab(planMaterials, tab, selectedTabInstance, tabCount) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(planMaterials, tab, selectedTabInstance);

  if (tabLoaded) {
    if (tabCount > 1) {
      // 1 of multiple tabs
      await checkers.isMercerOsTabSelected(tab);
    }

    await dbCheckAllTopicNames(planMaterials, selectedTabInstance);
  }
}

async function dbCheckOnlyFirstTopicIsShownAsSelected(dbPlanMaterialsTab, planMaterials, selectedTabInstance) {
  await browser.wait(until.visibilityOf(dbPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not visible');
  await checkers.anyText(dbPlanMaterialsTab);
  await browser.wait(until.elementToBeClickable(dbPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not clickable');

  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, dbPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    const expectedCountOfTopics = await dbGetExpectedCountOfTopics(selectedTabInstance);
    await planMaterialsTests.checkOnlyFirstTopicSelected(planMaterials, expectedCountOfTopics);
  }
}

async function dbCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await dbGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.clickTopicAndCheckTopicContent(
    planMaterials, selectedTopicEnum, topic, selectedTopicInstance);
}

async function dbCheckLoneOrMultipleTopics(planMaterials, selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple topics
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = await planMaterials.planMaterialsMultipleTopic(t);
      await dbCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single topic
    const topic = await planMaterials.planMaterialsLoneTopic;
    await dbCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function dbCheckAllTopicContentForTab(planMaterialsTab, planMaterials, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, planMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await dbCheckLoneOrMultipleTopics(planMaterials, selectedTabInstance);
  }
}

function runTopicContentCheckScenarios(participantStatus, pos, serviceInstance) {
  describe(`${scenarioPrefix}Plan Materials full page view + Default view full page view`
    + ` + DB Topic visibility + Media display (${participantStatus} status, ALL tabs, ALL topics)`
    + ` - DB ${participantStatus}`, () => {
    /*
      common
      -----------------------------------------------------------------
      GIVEN Pensioner has navigated to [PENSIONER PLAN MATERIALS PAGE]

      Plan Materials full page view
      -----------------------------------------------------------------
      AND one or multiple [DB TOPICS] are available
      WHEN [DB PLAN MATERIALS PAGE] loads

      Default view full page view
      -----------------------------------------------------------------
      AND one or multiple [DB TOPIC CATEGORIES] are available
      WHEN the [DB PLAN MATERIALS PAGE] loads

      DB Topic visibility
      -----------------------------------------------------------------
      AND one or multiple [DB TOPIC CATEGORIES] are available
      WHEN Member selects a [DB TOPIC CATEGORY]

      Media display
      -----------------------------------------------------------------
      AND one or multiple [DB TOPIC LINKS] are available
      WHEN the Member selects a [DB TOPIC LINK]
    */

    const dbPlanSummaryPage = new DbPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const dbPlanMaterialsPage = new DbPlanMaterialsPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const planMaterials = dbPlanMaterialsPage.planMaterials;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await dbPlanMaterialsTests.browseToDbPlanMaterialsPageFromLogin(
        loginPage, dashboardPage, dbPlanSummaryPage, dbPlanMaterialsPage, standardParticipant, serviceInstance);
    });

    it('Plan Materials full page view: THEN based on available [DB TOPICS] show [DB TOPIC CATEGORIES]', async () => {
      await planMaterialsTests.checkPageContentHeaders(dbPlanMaterialsPage);

      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dbPlanMaterialsPage.header.getPageContentHeaderTabCount();
      expect(tabCount).toBe(
        tabInstanceCountExpected,
        `${tabCount} tab(s) shown when ${tabInstanceCountExpected} expected`);

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dbPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dbCheckTabName(tab, t);
          await dbCheckTopicNamesInTab(planMaterials, tab, t, tabCount);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dbPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dbCheckTabName(tab, 0);
        await dbCheckTopicNamesInTab(planMaterials, tab, 0, tabCount);
      }
    });

    it('Default view full page view: THEN show first [DB TOPIC CATEGORY]'
      + ' AND show first [DB TOPIC]'
      + ' AND show all [MEDIA] related to first [DB TOPIC]', async () => {
      // note 'AND show all [MEDIA] related to first [DB TOPIC]' will be covered in 'Topic visibility'
      await browser.wait(
        until.presenceOf(dbPlanMaterialsPage.header.pageContentHeader),
        commonConstants.shortBrowserWaitDelay, 'DB plan materials page content header not present');
      expect(dbPlanMaterialsPage.header.pageContentHeader.isPresent()).toBe(true);

      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dbPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dbPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dbCheckOnlyFirstTopicIsShownAsSelected(tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dbPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dbCheckOnlyFirstTopicIsShownAsSelected(tab, planMaterials, 0);
      }
    });

    it('DB Topic visibility:'
      + ' THEN show all available [DB TOPIC LINKS]'
      + ' Media display:'
      + ' THEN show all available [MEDIA]'
      + ' AND for each [MEDIA] show [MEDIA TYPE ICON] i.e. video, pdf, link'
      + ' AND [MEDIA NAME] i.e. Q4 2017 Newsletter'
      + ' AND [MEDIA SIZE]'
      + ' AND [ACTION ICON]'
      + ' AND ordered by priority then date published (this phrase not TE coded)', async () => {
      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dbPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dbPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dbCheckAllTopicContentForTab(tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dbPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dbCheckAllTopicContentForTab(tab, planMaterials, 0);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dbPlanMaterialsPage, loginPage);
    });
  });
}

runTopicContentCheckScenarios('active', standardParticipant.posDbActive, 0);
runTopicContentCheckScenarios('deferred', standardParticipant.posDbDeferred, 1);

async function dbCheckUrlAndTooltipForLoneOrMultipleTopic(
  dbPlanMaterialsPage, planMaterials, selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await dbGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.checkActionUrlAndTooltipForTopic(
    dbPlanMaterialsPage, planMaterials, selectedTopicEnum, topic);
}

async function dbCheckUrlAndTooltipForLoneOrMultipleTopics(dbPlanMaterialsPage, planMaterials, selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple tabs
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = await planMaterials.planMaterialsMultipleTopic(t);
      await dbCheckUrlAndTooltipForLoneOrMultipleTopic(
        dbPlanMaterialsPage, planMaterials, selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single tab
    const topic = await planMaterials.planMaterialsLoneTopic;
    await dbCheckUrlAndTooltipForLoneOrMultipleTopic(
      dbPlanMaterialsPage, planMaterials, selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function dbCheckDownloadUrlAndTooltipForTopicsInTab(
  dbPlanMaterialsPage, dbPlanMaterialsTab, planMaterials, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, dbPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await dbCheckUrlAndTooltipForLoneOrMultipleTopics(dbPlanMaterialsPage, planMaterials, selectedTabInstance);
  }
}

function runTopicDownloadUrlAndTooltipCheckScenarios(participantStatus, pos, serviceInstance) {
  describe(`${scenarioPrefix}Action behaviour`
    + ` + Action hover (${participantStatus} status, ALL tabs, ALL topics)`
    + ` - DB ${participantStatus}`, () => {
    /*
      Action behaviour
      -----------------------------------------------------------------
      GIVEN Member has navigated to [DB PLAN MATERIALS PAGE]
      AND one or multiple [MEDIA] is available
      WHEN [MEDIA] is selected

      Action hover
      -----------------------------------------------------------------
      GIVEN the Member is viewing a piece of [MEDIA]
      WHEN the Member hovers over an [ACTION ICON]
     */

    const dbPlanSummaryPage = new DbPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const dbPlanMaterialsPage = new DbPlanMaterialsPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const planMaterials = dbPlanMaterialsPage.planMaterials;

    beforeAll(async () => {
      await dbPlanMaterialsTests.browseToDbPlanMaterialsPageFromLogin(
        loginPage, dashboardPage, dbPlanSummaryPage, dbPlanMaterialsPage, standardParticipant, serviceInstance);
    });

    it('Action behaviour: THEN [ACTION BEHAVIOUR] based on [MEDIA TYPE]'
      + ' Action hover: THEN display [ACTION ICON DESC] i.e. Download, Play, Open', async () => {
      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dbPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dbPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dbCheckDownloadUrlAndTooltipForTopicsInTab(dbPlanMaterialsPage, tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dbPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dbCheckDownloadUrlAndTooltipForTopicsInTab(dbPlanMaterialsPage, tab, planMaterials, 0);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dbPlanMaterialsPage, loginPage);
    });
  });
}

runTopicDownloadUrlAndTooltipCheckScenarios('active', standardParticipant.posDbActive, 0);
runTopicDownloadUrlAndTooltipCheckScenarios('deferred', standardParticipant.posDbDeferred, 1);
