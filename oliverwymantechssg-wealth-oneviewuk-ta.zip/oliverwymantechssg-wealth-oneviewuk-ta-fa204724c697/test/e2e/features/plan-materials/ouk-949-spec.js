// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');
const DcPlanMaterialsPage = require('../../page-objects/dc-plan-materials.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DcPlanMaterialsTests = require('../_common/dc-plan-materials.spec.js');
const PlanMaterialsTests = require('../_common/plan-materials.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcPlanMaterialsTests = new DcPlanMaterialsTests();
const planMaterialsTests = new PlanMaterialsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// other
let tabInstanceCountExpected;
let tabInstanceEnum;
let documentsTopicCountExpected;
let documentsTopicInstanceEnum;
let planMaterialsTopicCountExpected;
let planMaterialsTopicInstanceEnum;
let investmentsTopicInstanceEnum;
let investmentsTopicCountExpected;
const until = protractor.ExpectedConditions;

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

switch (ov3Environment) {
  // note we cannot easily use e.g. documentsTopicInstanceEnum.length because of the dreaded async problem
  // hence the specific *CountExpected variables
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    tabInstanceCountExpected = 3;
    tabInstanceEnum = {
      documents: 0,
      planMaterials: 1,
      investments: 2
    };

    documentsTopicCountExpected = 1;
    documentsTopicInstanceEnum = {
      policyDocuments: 0
    };

    planMaterialsTopicCountExpected = 6;
    planMaterialsTopicInstanceEnum = {
      planBooklets: 0,
      addendums: 1,
      planInfo: 2,
      announcements: 3,
      newsletters: 4,
      forms: 5
    };

    investmentsTopicCountExpected = 3;
    investmentsTopicInstanceEnum = {
      investmentGuides: 0,
      fundFactsheets: 1,
      fundManagerInfo: 2
    };
    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

// tests
const scenarioPrefix = `OUK-949${commonConstants.bddScenarioPrefix}`;

async function dcCheckTabName(dcPlanMaterialsTab, selectedTabInstance) {
  let expectedTabName;

  const tabName = await dcPlanMaterialsTab.getText();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      expectedTabName = 'Documents';
      break;
    case tabInstanceEnum.planMaterials:
      expectedTabName = 'Materials';
      break;
    case tabInstanceEnum.investments:
      expectedTabName = 'Investments';
      break;
    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }

  expect(tabName).toContain(expectedTabName);
  return tabName;
}

async function dcGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      switch (selectedTopicInstance) {
        case documentsTopicInstanceEnum.policyDocuments:
          return planMaterials.selectedTopicEnum.dcPolicyDocuments;
        default:
          throw new Error(`Documents tab topic instance ${selectedTopicInstance} is not supported`);
      }

    case tabInstanceEnum.planMaterials:
      switch (selectedTopicInstance) {
        case planMaterialsTopicInstanceEnum.planBooklets:
          return planMaterials.selectedTopicEnum.pensionerPlanBooklets;
        case planMaterialsTopicInstanceEnum.addendums:
          return planMaterials.selectedTopicEnum.pensionerAddendums;
        case planMaterialsTopicInstanceEnum.planInfo:
          return planMaterials.selectedTopicEnum.pensionerPlanInfo;
        case planMaterialsTopicInstanceEnum.announcements:
          return planMaterials.selectedTopicEnum.pensionerAnnouncements;
        case planMaterialsTopicInstanceEnum.newsletters:
          return planMaterials.selectedTopicEnum.pensionerNewsletters;
        case planMaterialsTopicInstanceEnum.forms:
          return planMaterials.selectedTopicEnum.pensionerForms;
        case planMaterialsTopicInstanceEnum.investmentGuides:
          return planMaterials.selectedTopicEnum.pensionerInvestmentGuides;
        case planMaterialsTopicInstanceEnum.fundFactsheets:
          return planMaterials.selectedTopicEnum.pensionerFundFactsheets;
        case planMaterialsTopicInstanceEnum.fundManagerInfo:
          return planMaterials.selectedTopicEnum.pensionerFundManagerInfo;
        default:
          throw new Error(`Plan materials tab topic instance ${selectedTopicInstance} is not supported`);
      }

    case tabInstanceEnum.investments:
      switch (selectedTopicInstance) {
        case investmentsTopicInstanceEnum.investmentGuides:
          return planMaterials.selectedTopicEnum.pensionerInvestmentGuides;
        case investmentsTopicInstanceEnum.fundFactsheets:
          return planMaterials.selectedTopicEnum.pensionerFundFactsheets;
        case investmentsTopicInstanceEnum.fundManagerInfo:
          return planMaterials.selectedTopicEnum.pensionerFundManagerInfo;
        default:
          throw new Error(`Investments tab topic instance ${selectedTopicInstance} is not supported`);
      }

    default:
      throw new Error(`Tab instance ${selectedTabInstance} is not supported`);
  }
}

async function dcGetExpectedCountOfTopics(selectedTabInstance) {
  await commonTests.forceCallingFunctionToBeSynchronous();

  switch (selectedTabInstance) {
    case tabInstanceEnum.documents:
      return documentsTopicCountExpected;
    case tabInstanceEnum.planMaterials:
      return planMaterialsTopicCountExpected;
    case tabInstanceEnum.investments:
      return investmentsTopicCountExpected;
    default:
      fail(`Tab instance ${selectedTabInstance} is not supported`);
      return false;
  }
}

async function dcCheckSelectedTopicName(planMaterials, actualTabInstance, i) {
  const topicEnum = await dcGetSelectedTopicEnum(planMaterials, actualTabInstance, i);
  const topic = await planMaterialsTests.getTopic(planMaterials, i);
  await planMaterialsTests.checkTopicName(planMaterials, topicEnum, topic);
}

async function dcCheckAllTopicNames(planMaterials, selectedTabInstance) {
  const expectedCountOfTopics = await dcGetExpectedCountOfTopics(selectedTabInstance);
  const actualTopicCount = await planMaterials.getPlanMaterialsTopicCount();
  expect(actualTopicCount).toBe(
    expectedCountOfTopics,
    `${actualTopicCount} topic(s) shown on tab ${selectedTabInstance} when ${expectedCountOfTopics} expected`);

  let i;

  for (i = 0; i < expectedCountOfTopics; i += 1) {
    // using a function here as this also checks order of topics shown for other checks below
    await dcCheckSelectedTopicName(planMaterials, selectedTabInstance, i);
  }
}

async function dcCheckTopicNamesInTab(planMaterials, tab, selectedTabInstance, tabCount) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(planMaterials, tab, selectedTabInstance);

  if (tabLoaded) {
    if (tabCount > 1) {
      // 1 of multiple tabs
      await checkers.isMercerOsTabSelected(tab);
    }

    await dcCheckAllTopicNames(planMaterials, selectedTabInstance);
  }
}

async function dcCheckOnlyFirstTopicIsShownAsSelected(dcPlanMaterialsTab, planMaterials, selectedTabInstance) {
  await browser.wait(until.visibilityOf(dcPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not visible');
  await checkers.anyText(dcPlanMaterialsTab);
  await browser.wait(until.elementToBeClickable(dcPlanMaterialsTab), commonConstants.shortBrowserWaitDelay,
    'Plan materials tab is not clickable');

  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, dcPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    const expectedCountOfTopics = await dcGetExpectedCountOfTopics(selectedTabInstance);
    await planMaterialsTests.checkOnlyFirstTopicSelected(planMaterials, expectedCountOfTopics);
  }
}

async function dcCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await dcGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.clickTopicAndCheckTopicContent(
    planMaterials, selectedTopicEnum, topic, selectedTopicInstance);
}

async function dcCheckLoneOrMultipleTopics(planMaterials, selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple topics
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = await planMaterials.planMaterialsMultipleTopic(t);
      await dcCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single topic
    const topic = await planMaterials.planMaterialsLoneTopic;
    await dcCheckLoneOrMultipleTopic(planMaterials, selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function dcCheckAllTopicContentForTab(planMaterialsTab, planMaterials, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, planMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await dcCheckLoneOrMultipleTopics(planMaterials, selectedTabInstance);
  }
}

function runTopicContentCheckScenarios(participantStatus, pos, serviceInstance) {
  describe(`${scenarioPrefix}Plan Materials full page view + Default view full page view`
    + ` + DC Topic visibility + Media display (${participantStatus} status, ALL tabs, ALL topics)`
    + ` - DC ${participantStatus}`, () => {
    /*
      common
      -----------------------------------------------------------------
      GIVEN Member has navigated to [DC PLAN MATERIALS PAGE]

      DC Plan Materials full page view
      -----------------------------------------------------------------
      AND one or multiple [DC TOPICS] are available
      WHEN [DC PLAN MATERIALS PAGE] loads

      Default view full page view
      -----------------------------------------------------------------
      AND one or multiple [DC TOPIC CATEGORIES] are available
      WHEN the [DC PLAN MATERIALS PAGE] loads

      DC Topic visibility
      -----------------------------------------------------------------
      AND one or multiple [DC TOPIC CATEGORIES] are available
      WHEN Member selects a [DC TOPIC CATEGORY]

      Media display
      -----------------------------------------------------------------
      AND one or multiple [DC TOPIC LINKS] are available
      WHEN the Member selects a [DC TOPIC LINK]
    */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const dcPlanMaterialsPage = new DcPlanMaterialsPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const planMaterials = dcPlanMaterialsPage.planMaterials;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await dcPlanMaterialsTests.browseToDcPlanMaterialsPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, dcPlanMaterialsPage, standardParticipant, serviceInstance);
    });

    it('DC Plan Materials full page view: THEN based on available [DC TOPICS] show [DC TOPIC CATEGORIES]', async () => {
      await planMaterialsTests.checkPageContentHeaders(dcPlanMaterialsPage);

      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dcPlanMaterialsPage.header.getPageContentHeaderTabCount();
      expect(tabCount).toBe(
        tabInstanceCountExpected,
        `${tabCount} tab(s) shown when ${tabInstanceCountExpected} expected`);

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dcPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dcCheckTabName(tab, t);
          await dcCheckTopicNamesInTab(planMaterials, tab, t, tabCount);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dcPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dcCheckTabName(tab, 0);
        await dcCheckTopicNamesInTab(planMaterials, tab, 0, tabCount);
      }
    });

    it('Default view full page view: THEN show first [DC TOPIC CATEGORY]'
      + ' AND show first [DC TOPIC]'
      + ' AND show all [MEDIA] related to first [DC TOPIC]', async () => {
      // note 'AND show all [MEDIA] related to first [DC TOPIC]' will be covered in 'Topic visibility'
      await browser.wait(
        until.presenceOf(dcPlanMaterialsPage.header.pageContentHeader),
        commonConstants.shortBrowserWaitDelay, 'DC plan materials page content header not present');
      expect(dcPlanMaterialsPage.header.pageContentHeader.isPresent()).toBe(true);

      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dcPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dcPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dcCheckOnlyFirstTopicIsShownAsSelected(tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dcPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dcCheckOnlyFirstTopicIsShownAsSelected(tab, planMaterials, 0);
      }
    });

    it('DC Topic visibility:'
        + ' THEN show all available [DC TOPIC LINKS]'
        + ' Media display:'
        + ' THEN show all available [MEDIA]'
        + ' AND for each [MEDIA] show [MEDIA TYPE ICON] i.e. video, pdf, link'
        + ' AND [MEDIA NAME] i.e. Q4 2017 Newsletter'
        + ' AND [MEDIA SIZE]'
        + ' AND [ACTION ICON]', async () => {
      // note Gherkin phrase
      // 'AND ordered by priority then date published'
      // is not TE coded)

      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dcPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dcPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dcCheckAllTopicContentForTab(tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dcPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dcCheckAllTopicContentForTab(tab, planMaterials, 0);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dcPlanMaterialsPage, loginPage);
    });
  });
}

runTopicContentCheckScenarios('active', standardParticipant.posDcActive, 0);
runTopicContentCheckScenarios('deferred', standardParticipant.posDcDeferred, 1);

async function dcCheckUrlAndTooltipForLoneOrMultipleTopic(
  dcPlanMaterialsPage, planMaterials, selectedTabInstance, topic, selectedTopicInstance) {
  const selectedTopicEnum = await dcGetSelectedTopicEnum(planMaterials, selectedTabInstance, selectedTopicInstance);
  await planMaterialsTests.checkActionUrlAndTooltipForTopic(
    dcPlanMaterialsPage, planMaterials, selectedTopicEnum, topic);
}

async function dcCheckUrlAndTooltipForLoneOrMultipleTopics(dcPlanMaterialsPage, planMaterials, selectedTabInstance) {
  const topicCount = await planMaterials.getPlanMaterialsTopicCount();

  if (topicCount > 1) {
    // multiple topics
    let t;

    for (t = 0; t < topicCount; t += 1) {
      const topic = planMaterials.planMaterialsMultipleTopic(t);
      await dcCheckUrlAndTooltipForLoneOrMultipleTopic(
        dcPlanMaterialsPage, planMaterials, selectedTabInstance, topic, t);
    }
  } else if (topicCount === 1) {
    // single topic
    const topic = planMaterials.planMaterialsLoneTopic;
    await dcCheckUrlAndTooltipForLoneOrMultipleTopic(
      dcPlanMaterialsPage, planMaterials, selectedTabInstance, topic, 0);
  } else {
    fail(`The topicCount '${topicCount}' is not supported`);
  }
}

async function dcCheckDownloadUrlAndTooltipForTopicsInTab(
  dcPlanMaterialsPage, dcPlanMaterialsTab, planMaterials, selectedTabInstance) {
  const tabLoaded = await planMaterialsTests.clickTabAndWaitForTopicsToLoad(
    planMaterials, dcPlanMaterialsTab, selectedTabInstance);

  if (tabLoaded) {
    await dcCheckUrlAndTooltipForLoneOrMultipleTopics(dcPlanMaterialsPage, planMaterials, selectedTabInstance);
  }
}

function runTopicDownloadUrlAndTooltipCheckScenarios(participantStatus, pos, serviceInstance) {
  describe(`${scenarioPrefix}Action behaviour`
    + ` + Action hover (${participantStatus} status, ALL tabs, ALL topics)`
    + ` - DC ${participantStatus}`, () => {
    /*
      Action behaviour
      -----------------------------------------------------------------
      GIVEN Member has navigated to [DC PLAN MATERIALS PAGE]
      AND one or multiple [MEDIA] is available
      WHEN [MEDIA] is selected

      Action hover
      -----------------------------------------------------------------
      GIVEN the Member is viewing a piece of [MEDIA]
      WHEN the Member hovers over an [ACTION ICON]
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const dcPlanMaterialsPage = new DcPlanMaterialsPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);
    const planMaterials = dcPlanMaterialsPage.planMaterials;

    beforeAll(async () => {
      await dcPlanMaterialsTests.browseToDcPlanMaterialsPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, dcPlanMaterialsPage, standardParticipant, serviceInstance);
    });

    it('Action behaviour: THEN [ACTION BEHAVIOUR] based on [MEDIA TYPE]'
      + ' Action hover: THEN display [ACTION ICON DESC] i.e. Download, Play, Open', async () => {
      // complex TE code required as lone tabs render in different way to multiple tabs
      const tabCount = await dcPlanMaterialsPage.header.getPageContentHeaderTabCount();

      if (tabCount > 1) {
        // multiple tabs
        let t;

        for (t = 0; t < tabCount; t += 1) {
          const tab = await dcPlanMaterialsPage.header.pageContentHeaderMultipleTab(t);
          await dcCheckDownloadUrlAndTooltipForTopicsInTab(dcPlanMaterialsPage, tab, planMaterials, t);
        }
      } else if (tabCount === 1) {
        // single tab
        const tab = dcPlanMaterialsPage.header.pageContentHeaderLoneTab;
        await dcCheckDownloadUrlAndTooltipForTopicsInTab(dcPlanMaterialsPage, tab, planMaterials, 0);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dcPlanMaterialsPage, loginPage);
    });
  });
}

runTopicDownloadUrlAndTooltipCheckScenarios('active', standardParticipant.posDcActive, 0);
runTopicDownloadUrlAndTooltipCheckScenarios('deferred', standardParticipant.posDcDeferred, 1);
