// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ChangeBankAccountDetailsTests = require('../_common/pensioner-change-bank-account-details.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const PensionerChangeBankAccountDetailsPage
  = require('../../page-objects/pensioner-change-bank-account-details.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const changeBankAccountDetailsTests = new ChangeBankAccountDetailsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const pensionerChangeBankAccountDetailsPage = new PensionerChangeBankAccountDetailsPage();

// tests
const scenarioPrefix = `OUK-4259${commonConstants.bddScenarioPrefix}`;

async function inputSortCodeAndCheckShownAfterTabAway(sortCode) {
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
  await pensionerChangeBankAccountDetailsPage.bankSortCodeValue.sendKeys(sortCode);
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput);
  await checkers.inputExactText(pensionerChangeBankAccountDetailsPage.bankSortCodeValue, sortCode);
}

describe(`${scenarioPrefix}edit mode, valid sort code`, () => {
  /*
    GIVEN view is Bank Edit Modal
    AND the sort code provided is valid
    WHEN the Pensioner navigates away from the sort code fields
   */

  const participant = standardParticipant;
  const sortCode = '60-17-21';

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN retain sort code details provided ', async () => {
    await inputSortCodeAndCheckShownAfterTabAway(sortCode);
  });

  it('AND show [Bank Name] AND show [Branch]', async () => {
    // can check for specific text as you are inputting specific value
    await checkers.exactText(pensionerChangeBankAccountDetailsPage.currentBankInformationDetails,
      'NAT WEST BANK PLC, READING MARKET PLACE');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});

describe(`${scenarioPrefix}edit mode, invalid sort code`, () => {
  /*
    GIVEN view is Bank Edit Modal
    AND the sort code provided is invalid
    WHEN the Pensioner navigates away from the sort code fields
   */

  const participant = standardParticipant;
  const sortCode = '60-00-';

  beforeAll(async () => {
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN retain sort code details provided ', async () => {
    await inputSortCodeAndCheckShownAfterTabAway(sortCode);
  });

  it('AND show invalid sort code validation message ', async () => {
    await checkers.containingTextIgnoreCase(
      pensionerChangeBankAccountDetailsPage.bankAccountSortCodeRequiredErrorText, 'Invalid sort code');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
  });

  // 'AND highlight all sort code input fields' phrase cannot be tested easily so omitted

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});
