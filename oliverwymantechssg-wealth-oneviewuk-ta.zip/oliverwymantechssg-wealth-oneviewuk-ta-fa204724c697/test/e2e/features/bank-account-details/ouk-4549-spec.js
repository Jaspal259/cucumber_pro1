// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ChangeBankAccountDetailsTests = require('../_common/pensioner-change-bank-account-details.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const PensionerChangeBankAccountDetailsPage
  = require('../../page-objects/pensioner-change-bank-account-details.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const changeBankAccountDetailsTests = new ChangeBankAccountDetailsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const pensionerChangeBankAccountDetailsPage = new PensionerChangeBankAccountDetailsPage();

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-4549${commonConstants.bddScenarioPrefix}`;

async function editBankSortCode(sortCode) {
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
  await pensionerChangeBankAccountDetailsPage.bankSortCodeValue.sendKeys(sortCode);
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput);
}

async function editBankAccount(sortCode, acccNumber, refNumber, passcode) {
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(1));
  await pensionerChangeBankAccountDetailsPage.bankSortCodeValue.sendKeys(sortCode);
  await pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput.sendKeys(acccNumber);
  await pensionerChangeBankAccountDetailsPage.buildingSocietyRollNumberValueInput.sendKeys(refNumber);
  await pensionerChangeBankAccountDetailsPage.oneViewPasscodeField.sendKeys(passcode);
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsSaveButton);
}

async function editBankAccountNumber(accountNumber) {
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
  await pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput.sendKeys(accountNumber);
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.buildingSocietyRollNumberValueInput);
}

async function editPasscode(passcode) {
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
  await pensionerChangeBankAccountDetailsPage.oneViewPasscodeField.sendKeys('');
  await pensionerChangeBankAccountDetailsPage.oneViewPasscodeField.sendKeys(passcode);
  await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.buildingSocietyRollNumberValueInput);
}

describe(`${scenarioPrefix}Bank Account details, edit view`, () => {
  /*
    GIVEN view is Bank Account details page read view
    WHEN the Pensioner selects an edit bank account button
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN redirect Pensioner to bank account page edit view ', async () => {
    await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
    expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsCancelButton.isEnabled()).toBe(true);
    expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsSaveButton.isEnabled()).toBe(true);
  });

  it('AND show [bank account details fields]', async () => {
    await checkers.inputNoText(pensionerChangeBankAccountDetailsPage.bankSortCodeValue);
    await checkers.inputNoText(pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput);
    await checkers.inputNoText(pensionerChangeBankAccountDetailsPage.buildingSocietyRollNumberValueInput);
  });

  it('AND show OneView passcode field', async () => {
    await checkers.inputNoText(pensionerChangeBankAccountDetailsPage.oneViewPasscodeField);
  });

  it('AND enable Cancel button ', () => {
    expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsCancelButton.isEnabled()).toBe(true);
  });

  it('AND enable Save button (primary button)', () => {
    expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsSaveButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit view, valid sort code`, () => {
  /*
    GIVEN view is bank account page edit view
    AND the Pensioner has entered a valid sort code
    WHEN the Pensioner navigates to another field
   */

  const participant = standardParticipant;
  const sortCode = '601721';

  beforeAll(async () => {
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN format sort code', async () => {
    await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0));
    await pensionerChangeBankAccountDetailsPage.bankSortCodeValue.sendKeys(sortCode);
    await commonTests.clickElement(pensionerChangeBankAccountDetailsPage.bankAccountNumberValueInput);
    await checkers.inputExactText(pensionerChangeBankAccountDetailsPage.bankSortCodeValue, '60-17-21');
  });

  it('AND Show [Bank details]', async () => {
    await checkers.exactText(pensionerChangeBankAccountDetailsPage.currentBankInformationDetails,
      'NAT WEST BANK PLC, READING MARKET PLACE');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit view, validating fields`, () => {
  /*
    GIVEN view is bank account page edit view
    AND edits have been made to a <bank field>
    WHEN the Participant navigates to another field
   */

  const participant = standardParticipant;
  const sortCode = '6017';
  const accountNumber = '1234';
  const passcode = '1';

  beforeAll(async () => {
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN validate the [bank field]', async () => {
    await editBankSortCode(sortCode);
    await checkers.exactText(
      pensionerChangeBankAccountDetailsPage.bankAccountSortCodeRequiredErrorText,
      'Invalid sort code, please try again.');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
    await editBankAccountNumber(accountNumber);
    await checkers.exactText(
      pensionerChangeBankAccountDetailsPage.bankAccountNumberValueRequiredErrorText,
      'Account number is invalid');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
    await editPasscode(passcode);
    await checkers.exactText(
      pensionerChangeBankAccountDetailsPage.invalidPasscodeErrorText,
      'Passcode is invalid');
    await changeBankAccountDetailsTests.cancelBankAccountEditConfirmingLoseChanges(
      pensionerChangeBankAccountDetailsPage);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit view, successful update`, () => {
  /*
    GIVEN view is bank account page edit view
    WHEN the Pensioner submits valid bank account details and passcode
    AND the update is successful
   */

  const participant = standardParticipant;
  const passcode = participant.data.passcode();
  const sortCode = '601721';
  const maskedSortCode = `${sortCode.substr(0, 2)}-**-**`;
  const accountNumber = '11234522';
  const maskedAccountNumber = `****${accountNumber.substr(4, 7)}`;
  const refNumber = participant.data.userId;
  const maskedRefNumber = `******${refNumber.substr(6, 9)}`;

  beforeAll(async () => {
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN return Pensioner to bank account page read view', async () => {
    await editBankAccount(sortCode, accountNumber, refNumber, passcode);
    const present = await browser.wait(
      until.presenceOf(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0)),
      commonConstants.briefBrowserWaitDelay,
      'Bank account default page not shown after edit completion');

    if (present) {
      const recordCount = await pensionerChangeBankAccountDetailsPage.getBankAccountDetailsRecordCount();

      if (recordCount > 0) {
        let i;

        for (i = 0; i < recordCount; i += 1) {
          expect(pensionerChangeBankAccountDetailsPage.getBankSortCode(i).getTagName()).not.toBe('input');
        }
      } else {
        fail('Bank Details has no data');
      }

      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0).isDisplayed()).toBe(true);
    }
  });

  // note order of checking toast and update account details it() blocks has been swapped to ensure
  // temporarily shown toast is checked
  it('AND show successful toast alert', async () => {
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountToastText,
      'success');
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountToastText,
      'bank account');
  });

  it('AND show updated account details', async () => {
    /*
      we do not know where the edited record will end up in the data table and checking through all the rows
      individually will be too expensive in terms of time so instead we'll just check the table as a whole
      - little bit quick and dirty but should be enough
     */
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountDetailsTable,
      maskedSortCode);
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountDetailsTable,
      maskedAccountNumber);
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountDetailsTable,
      maskedRefNumber);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit screen, overseas account `, () => {
  /*
    GIVEN view is bank account page edit view
    WHEN the Pensioner submits valid bank details and passcode
    BUT the sort code is 20-32-53
    AND the Bank Account number is 43435563
   */

  const participant = standardParticipant;
  const sortCode = '203253';
  const accountNumber = '43435563';
  const refNumber = participant.data.userId;
  const passcode = participant.data.passcode();

  beforeAll(async () => {
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN show sort code field as invalid ', async () => {
    await editBankAccount(sortCode, accountNumber, refNumber, passcode);
    await browser.wait(until.visibilityOf(pensionerChangeBankAccountDetailsPage.bankAccountSortCodeRequiredErrorText),
      commonConstants.briefBrowserWaitDelay,
      'Error toast not shown after trying to save invalid sort code');
    await checkers.containingTextIgnoreCase(
      pensionerChangeBankAccountDetailsPage.bankAccountSortCodeRequiredErrorText, 'Invalid sort code');
  });

  it(' AND show Account number field as invalid', async () => {
    await checkers.containingTextIgnoreCase(
      pensionerChangeBankAccountDetailsPage.bankAccountNumberValueRequiredErrorText, 'Account number');
    await checkers.containingTextIgnoreCase(
      pensionerChangeBankAccountDetailsPage.bankAccountNumberValueRequiredErrorText, 'invalid');
  });

  it('AND show overseas toast alert', async () => {
    // toast at time of coding was:
    // "If you wish to change your bank account details to an overseas bank, please contact us"
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountToastText,
      'change');
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountToastText,
      'overseas bank');
    await checkers.containingTextIgnoreCase(pensionerChangeBankAccountDetailsPage.bankAccountToastText,
      'contact us');
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});
