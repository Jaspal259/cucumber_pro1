// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');
const regExConstants = require('../../utilities/regex-constants.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ChangeBankAccountDetailsTests = require('../_common/pensioner-change-bank-account-details.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const PensionerChangeBankAccountDetailsPage
  = require('../../page-objects/pensioner-change-bank-account-details.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const changeBankAccountDetailsTests = new ChangeBankAccountDetailsTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);
const pensionerChangeBankAccountDetailsPage = new PensionerChangeBankAccountDetailsPage();

// tests
const scenarioPrefix = `OUK-4548${commonConstants.bddScenarioPrefix}`;

async function checkBankAccountDetailsData(rowIndex) {
  await checkers.anyText(pensionerChangeBankAccountDetailsPage.getBankAccountDetailsColumn(0));
  await checkers.anyText(pensionerChangeBankAccountDetailsPage.getBankAccountDetailsColumn(1));
  await checkers.anyText(pensionerChangeBankAccountDetailsPage.getBankAccountDetailsColumn(2));

  const sortCode = await pensionerChangeBankAccountDetailsPage.getBankSortCode(rowIndex).getText();
  expect(sortCode).toMatch(regExConstants.regExBankSortCode, `Invalid Sort Code format. Actual: ${sortCode}`);

  const accNumber = await pensionerChangeBankAccountDetailsPage.getBankAccount(rowIndex).getText();
  expect(accNumber).toMatch(regExConstants.regExBankAccount, `Invalid Account Number format. Actual: ${accNumber}`);

  const refNumber = await pensionerChangeBankAccountDetailsPage.getReferenceNumber(rowIndex).getText();
  expect(refNumber).toMatch(regExConstants.regExBankReferenceNumber,
    `Invalid Reference Number format. Actual: ${refNumber}`);
}

describe(`${scenarioPrefix}default display`, () => {
  /*
    GIVEN Bank Account Details is available
    GIVEN <edit bank account is enabled>
    WHEN the Pensioner navigates to the Bank Account details page read view
   */

  const participant = standardParticipant;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await changeBankAccountDetailsTests.browseToChangeBankAccountDetailsPageViaPipPlanSummaryPage(
      loginPage, dashboardPage, pensionerPlanSummaryPage, pensionerChangeBankAccountDetailsPage, participant, 0);
  });

  it('THEN show all available bank account records'
    + ' AND for each record, mask the information as follows: \n'
    + ' *Sort Code - last 4 digits \n'
    + ' *Account Number - all except the last 4 digits \n'
    + ' *Building society reference - all except the last 4 digits ', async () => {
    const recordCount = await pensionerChangeBankAccountDetailsPage.getBankAccountDetailsRecordCount();

    if (recordCount === 1) {
      await checkBankAccountDetailsData(0);
    } else if (recordCount > 1 && recordCount < 3) {
      await checkBankAccountDetailsData(0);
      await checkBankAccountDetailsData(1);
    } else if (recordCount > 2) {
      const lastRow = recordCount - 1;
      const midRow = Math.round(recordCount / 2);
      await checkBankAccountDetailsData(0);
      await checkBankAccountDetailsData(midRow);
      await checkBankAccountDetailsData(lastRow);
    } else {
      fail('Bank Details has no data');
    }
  });

  it('AND [display actions column]', async () => {
    await checkers.exactText(pensionerChangeBankAccountDetailsPage.getBankAccountDetailsColumn(3),
      'Action');
  });

  it('AND enable edit account button ', async () => {
    const recordCount = await pensionerChangeBankAccountDetailsPage.getBankAccountDetailsRecordCount();

    if (recordCount === 1) {
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0).isEnabled()).toBe(true);
    } else if (recordCount > 1 && recordCount < 3) {
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0).isEnabled()).toBe(true);
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(1).isEnabled()).toBe(true);
    } else if (recordCount > 2) {
      const lastRow = recordCount - 1;
      const midRow = Math.round(recordCount / 2);
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(0).isEnabled()).toBe(true);
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(midRow).isEnabled()).toBe(true);
      expect(pensionerChangeBankAccountDetailsPage.bankAccountDetailsEditButton(lastRow).isEnabled()).toBe(true);
    } else {
      fail('Bank Details has no data');
    }
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerChangeBankAccountDetailsPage, loginPage);
  });
});
