// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load test(s)
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-456${commonConstants.bddScenarioPrefix}`;

/*
  Original OUK-456 story now meaningless as design has changed so updated TE code 28/01/2019 to reflect
  new design ... and now checks DC active and deferred
 */

function checkInvestmentsCard(pos, cardInstance, posDescription) {
  describe(`${scenarioPrefix}Investments card visibility (${posDescription})`, () => {
    /*
      GIVEN that the Member is on the [DC Plan Summary] Page
      AND [CURRENT INVESTMENTS] are enabled
      AND [FUTURE INVESTMENTS] are enabled
      WHEN the [DC PLAN SUMMARY] page loads
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${posDescription}`);
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, cardInstance);
    });

    it('THEN show [INVESTMENTS CARD]', () => {
      expect(dcPlanSummaryPage.investmentsCard.isDisplayed()).toBe(true);
    });

    it(`${commonConstants.bddAdditionalCheckAddedByTe}AND check content of investments card`, async () => {
      await checkers.containingTextIgnoreCase(dcPlanSummaryPage.investmentsCardLabel, 'Investments');
      await checkers.anyImage(dcPlanSummaryPage.investmentsCardIcon);
      await checkers.anyGbp(dcPlanSummaryPage.investmentsCardValue);
      await checkers.containingAnyUkDate(dcPlanSummaryPage.investmentsCardDate);
      await checkers.containingImage(dcPlanSummaryPage.investmentsCardInfoIcon,
        commonConstants.infoImageSource);
      await checkers.containingTextIgnoreCase(dcPlanSummaryPage.investmentsCardCTA, 'view investments');
    });

    afterAll(async () => {
      await commonTests.logOut(dcPlanSummaryPage, loginPage);
    });
  });
}

checkInvestmentsCard(standardParticipant.posDcActive, 0, 'DC active');
checkInvestmentsCard(standardParticipant.posDcDeferred, 1, 'DC deferred');
