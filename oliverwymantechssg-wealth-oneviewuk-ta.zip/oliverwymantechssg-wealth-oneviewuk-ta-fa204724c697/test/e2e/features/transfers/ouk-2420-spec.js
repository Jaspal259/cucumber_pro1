// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DbTransfersPage = require('../../page-objects/db-transfer.po.js');

// load tests
const DbTransferTests = require('../_common/db-transfer.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const dbTransferTests = new DbTransferTests();
const tooltipTests = new TooltipTests();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPageActive = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbTransfersPageActive = new DbTransfersPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryPageDeferred = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);
const dbTransfersPageDeferred = new DbTransfersPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);

// other
const ov3Environment = commonTests.getOv3Environment();
let isCalcStudioCalcSetUp;

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
    isCalcStudioCalcSetUp = true;
    break;
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    // TODO: remove once CS calc set up and working
    isCalcStudioCalcSetUp = false;
    break;
  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
}

// tests
const scenarioPrefix = `OUK-2420${commonConstants.bddScenarioPrefix}`;

async function login(participantStatus) {
  if (participantStatus === 'active') {
    await dbTransferTests.browseToDbTransferPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageActive, dbTransfersPageActive, standardParticipant, 0);
  } else {
    await dbTransferTests.browseToDbTransferPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPageDeferred, dbTransfersPageDeferred, standardParticipant, 1);
  }
}

function runDataGroupInfoIcon(dbTransfersPage, participantStatus) {
  describe(`${scenarioPrefix}Data group, info icon - ${participantStatus}`, () => {
    /*
      GIVEN DB Transfer Value is enabled
      GIVEN view is DBTV results page
      AND DBTV group info icon message is available
      WHEN Member selects a DBTV group info icon
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${participantStatus}`);
      await login(participantStatus);
    });

    it('THEN show information text for that DBTV group', async () => {
      await checkers.anyText(dbTransfersPage.infoText);
      const iconCount = dbTransfersPage.accordionInfoIcons.count();

      for (let i = 0; i < iconCount; i += 1) {
        await tooltipTests.checkTooltipIsElementWithAnyText(
          dbTransfersPage.accordionInfoIcons[i],
          dbTransfersPage.infoText,
          dbTransfersPage.tooltips.soleTooltip);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dbTransfersPage, loginPage);
    });
  });
}

if (isCalcStudioCalcSetUp) {
  // note DB active transfer calc is not working as yet as CalcStudio and / or Midas data not set up yet
  runDataGroupInfoIcon(dbTransfersPageDeferred, 'deferred');
}

function runModalCloseButton(dbTransfersPage, participantStatus) {
  describe(`${scenarioPrefix}DBTV modal, close button - ${participantStatus}`, () => {
    /*
      GIVEN DB Transfer Value is enabled
      GIVEN view is DBTV modal message
      WHEN Member selects Close button
     */

    beforeAll(async () => {
      await login(participantStatus);
    });

    it('THEN close modal message'
      + ' AND return Member to view they were viewing prior to navigating to the DBTV results page', async () => {
      await checkers.anyText(dbTransfersPage.transferValueContinueButton);
      await commonTests.clickElement(dbTransfersPage.transferValueContinueButton);
      await checkers.containingText(dbTransfersPage.infoModal.description, 'I have read');
      await checkers.containingTextIgnoreCase(dbTransfersPage.infoModal.cancelButton(global.deviceType),
        'Cancel');
      expect(dbTransfersPage.infoModal.cancelButton(global.deviceType).isEnabled()).toBe(true);
      await checkers.isMercerOsButtonUnselected(dbTransfersPage.infoModal.cancelButton(global.deviceType));
      await checkers.containingTextIgnoreCase(dbTransfersPage.infoModal.continueButton(global.deviceType),
        'Continue');
      expect(dbTransfersPage.infoModal.continueButton(global.deviceType).isEnabled()).toBe(true);
      await checkers.isMercerOsButtonSelected(dbTransfersPage.infoModal.continueButton(global.deviceType));

      await commonTests.clickElement(dbTransfersPage.infoModal.cancelButton(global.deviceType));
      expect(dbTransfersPage.infoModal.container.isPresent()).toBe(false);
    });

    afterAll(async () => {
      await commonTests.logOut(dbTransfersPage, loginPage);
    });
  });
}

if (isCalcStudioCalcSetUp) {
  // note DB active transfer calc is not working as yet as CalcStudio and / or Midas data not set up
  runModalCloseButton(dbTransfersPageDeferred, 'deferred');
}

function runReceivingArrangementInvalidInput(dbTransfersPage, participantStatus) {
  describe(`${scenarioPrefix}Receiving arrangement, invalid input - ${participantStatus}`, () => {
    /*
      GIVEN DB Transfer Value is enabled
      GIVEN view is DBTV results page
      AND produce a pack option is available
      WHEN Member enters invalid receiving arrangement details
     */

    beforeAll(async () => {
      await login(participantStatus);
    });

    it('THEN display error toast with error message and required field error message', async () => {
      await commonTests.clickElement(dbTransfersPage.transferValueContinueButton);
      await commonTests.clickElement(dbTransfersPage.infoModal.continueButton(global.deviceType));
      await dbTransfersPage.newPensionArrangementInput.clear();
      await dbTransfersPage.newPensionArrangementInput.sendKeys('');
      await commonTests.clickElement(dbTransfersPage.transferValueContinueButton);
      await checkers.anyText(dbTransfersPage.toast.message);
      await checkers.containingTextIgnoreCase(dbTransfersPage.fieldValidationErrorMsg, 'Required');
    });

    afterAll(async () => {
      await commonTests.logOut(dbTransfersPage, loginPage);
    });
  });
}

if (isCalcStudioCalcSetUp) {
  // note DB active transfer calc will  never be set up for OV1 (James Keene advised Matt Whittle decision 2019/09/18)
  runReceivingArrangementInvalidInput(dbTransfersPageDeferred, 'deferred');
}
