// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');
const DbTransferPage = require('../../page-objects/db-transfer.po');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbTransferTests = require('../_common/db-transfer.spec');
const TooltipTests = require('../_common/tooltips.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbTransferTests = new DbTransferTests();
const tooltipTests = new TooltipTests();

// other
const ov3Environment = commonTests.getOv3Environment();
let isCalcStudioCalcSetUp;

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
    isCalcStudioCalcSetUp = true;
    break;
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    // TODO: remove once CS calc set up and working
    isCalcStudioCalcSetUp = false;
    break;
  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
}

// tests
const scenarioPrefix = `OUK-1979${commonConstants.bddScenarioPrefix}`;

async function checkPersonalInfoAccordionContent(dbTransferPage, accordion) {
  let accordionContentLabel;
  let accordionContentValue;

  accordionContentLabel = await dbTransferPage.personalInfoQuoteDateLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date of Transfer Value Quotation');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.containingCurrentUkDate(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoTotalTransferValueLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Total Transfer Value');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoNormalContsLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'normal contribution');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoMemberAVCsLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'voluntary contributions');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoMemberAVCsPre87Label(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'AVC');
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Pre');
  await checkers.containingTextIgnoreCase(accordionContentLabel, '87');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoMemberAVCsPost87Label(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'AVC');
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Post');
  await checkers.containingTextIgnoreCase(accordionContentLabel, '87');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoCOutInTotalLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'Contracted Out Rights included in Total Transfer Value');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.noText(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoCOutInPre97Label(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'In respect of Pre April 1997');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoCOutInPost97Label(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'In respect of Post 1997');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoTVSubjectToIncreasesLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'Amount of Transfer Value that is subjected to increases at:');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.noText(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoTV5PctIncreaseLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    '5% or the rise in cost of living in the UK if less');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoTV2Point5PctIncreaseLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    '2.5% or the rise in the cost of living in the UK if less');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.personalInfoLrpLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'Amount of LRP included in Transfer Value (which in reclaimed if appropriate)');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);
}

async function checkTransferValueInfoAccordionContent(dbTransferPage, accordion) {
  let accordionContentLabel;
  let accordionContentValue;

  accordionContentLabel = await dbTransferPage.tvInfoMemberNameLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Member Name');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'Mr A Demonstration');

  accordionContentLabel = await dbTransferPage.tvInfoSchemeNameLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Scheme name');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'OVT Demo Pension Plan');

  accordionContentLabel = await dbTransferPage.tvInfoLastKnownAddressLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Last Known Address');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyText(accordionContentValue);

  accordionContentLabel = await dbTransferPage.tvInfoDateOfBirthLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date of Birth');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactUkDate(accordionContentValue, '04/08/1963');

  accordionContentLabel = await dbTransferPage.tvInfoDOBVerifiedLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'DOB Verified');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'Yes');

  accordionContentLabel = await dbTransferPage.tvInfoMaritalStatusLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Marital status');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'Married');

  accordionContentLabel = await dbTransferPage.tvInfoClassLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Class');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'Benefit Class 2');

  accordionContentLabel = await dbTransferPage.tvInfoNINumberLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'National Insurance Number');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactText(accordionContentValue, 'OV346336D');

  accordionContentLabel = await dbTransferPage.tvInfoDateJoinedCompanyLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date Employment Commenced');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactUkDate(accordionContentValue, '30/08/1994');

  accordionContentLabel = await dbTransferPage.tvInfoDateEmploymentStartedLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date CO Employment Commenced');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactUkDate(accordionContentValue, '30/08/1994');

  accordionContentLabel = await dbTransferPage.tvInfoDatePensionableServiceStartedLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date Pensionable Service Commenced');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactUkDate(accordionContentValue, '30/08/1994');

  accordionContentLabel = await dbTransferPage.tvInfodatePensionableServiceEndedLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Date Pensionable Service Ended');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.exactUkDate(accordionContentValue, '12/06/1998');
}

async function checkPensionSchemeDetailsAccordionContent(dbTransferPage, accordion) {
  let accordionContentLabel;
  let accordionContentValue;

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsDeferredPensionLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Deferred Pension at Leaving');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsOnDeathInServiceLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'On Death of Member Before the Pension Payment Date');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.noText(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsSpousesDISLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'Qualifying Spouse\'s/ Registered Civil Partner\'s pension');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsDependantsDISLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Member\'s Dependant');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsChildrensDISLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Member\'s Children');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsDeathInRetirementLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'On Death of Member After the Pension Payment Date');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.noText(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsSpousesDIRLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel,
    'Qualifying Spouse\'s/ Registered Civil Partner\'s pension');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsDependantsDIRLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Member\'s Dependant');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);

  accordionContentLabel = await dbTransferPage.pensionSchemeDetailsChildrensDIRLabel(accordion, global.deviceType);
  await checkers.containingTextIgnoreCase(accordionContentLabel, 'Member\'s Children');
  accordionContentValue = await dbTransferPage.accordionContentValue(accordionContentLabel);
  await checkers.anyGbp(accordionContentValue);
}

async function checkAccordionIconIsNotPresent(dbTransferPage, accordion, accordionLabelText) {
  const present = await browser.isElementPresent(dbTransferPage.getAccordionIcon(accordion));

  if (present) {
    fail(`No icon expected for '${accordionLabelText}' accordion`);
  }
}

async function checkAccordionContent(dbTransferPage, accordion) {
  await checkers.anyTextOf20CharsPlus(dbTransferPage.getAccordionContent(accordion));
  const labelText = await dbTransferPage.getAccordionLabel(accordion).getText();
  let present;

  switch (labelText) {
    case 'Personal Information':
      await checkPersonalInfoAccordionContent(dbTransferPage, accordion);
      await checkAccordionIconIsNotPresent(dbTransferPage, accordion, labelText);
      break;
    case 'Transfer value Information':
      await checkTransferValueInfoAccordionContent(dbTransferPage, accordion);
      await checkAccordionIconIsNotPresent(dbTransferPage, accordion, labelText);
      break;
    case 'Pension Scheme Details':
      await checkPensionSchemeDetailsAccordionContent(dbTransferPage, accordion);
      await checkAccordionIconIsNotPresent(dbTransferPage, accordion, labelText);
      break;
    case 'Important Notes':
      // no IDs and just general text so previous check is enough for text, just check icon

      break;
    case 'Notes About This Statement':
      // no IDs and just general text so previous check is enough for text, just check icon

      break;
    default:
      fail(`Label text "${labelText}" is not supported`);
      present = await browser.isElementPresent(dbTransferPage.getAccordionIcon(accordion));

      if (present) {
        await checkers.containingImage(dbTransferPage.getAccordionIcon(accordion),
          commonConstants.warningImageSource);
      } else {
        fail(`Icon expected for '${labelText}' accordion`);
      }
  }
}

async function checkSpecificAccordion(dbTransferPage, s) {
  const accordion = await dbTransferPage.accordion(s);
  await checkers.anyText(dbTransferPage.getAccordionInformationLabel(accordion));
  const present = await browser.isElementPresent(dbTransferPage.getAccordionInfoIcon(accordion));

  if (present) {
    await checkers.containingImage(dbTransferPage.getAccordionInfoIcon(accordion),
      commonConstants.infoImageSource);
    await tooltipTests.checkTooltipIsElementWithAnyText(
      dbTransferPage.getAccordionInfoIcon(accordion),
      dbTransferPage.getAccordionInformationLabel(accordion),
      dbTransferPage.tooltips.soleTooltip
    );
  }

  const iconPresent = await browser.isElementPresent(dbTransferPage.getAccordionVectorIcon(accordion));

  if (iconPresent) {
    await checkers.containingImage(dbTransferPage.getAccordionVectorIcon(accordion),
      'mercer-assets/icons/vector-icon-defs.svg');
  }


  // note this check will fail for all but QA currently because of bug 8438
  if (s === 0) {
    await checkAccordionContent(dbTransferPage, accordion);
  } else {
    await commonTests.clickElement(dbTransferPage.getAccordionExpandButton(accordion));
    await checkAccordionContent(dbTransferPage, accordion);
  }
}

if (isCalcStudioCalcSetUp) {
  describe(`${scenarioPrefix}Access via DB Plan Summary + Feature navigation`
    + ' + DBTV guidance text + Default page view + DBTV, data view + DBTV, notes', () => {
    /*
      Access via DB Plan Summary
      --------------------------------------------------------
      GIVEN view is DB Plan summary
      AND view Transfer Value link is available
      WHEN the Member selects the view Transfer Value link

      Feature navigation
      --------------------------------------------------------
      GIVEN Member has navigated to DBTV results page
      WHEN DBTV results page loads

      DBTV guidance text
      --------------------------------------------------------
      GIVEN Member has navigated to DBTV results page
      AND DBTV intro text has been published in CMS
      WHEN DBTV results page loads

      Default page view
      --------------------------------------------------------
      GIVEN Member has navigated to DBTV results page
      WHEN the DBTV results page loads

      DBTV, data view
      --------------------------------------------------------
      GIVEN view is DBTV results page
      WHEN Member expands a draw in the accordion

      DBTV, notes
      --------------------------------------------------------
      GIVEN view is DBTV results page
      WHEN Member expands notes draw in the accordion
    */

    const participant = standardParticipant;
    const loginPage = new LoginPage(participant);
    const dashboardPage = new DashboardPage(participant);
    const dbPlanSummaryPage = new DbPlanSummaryPage(
      participant,
      participant.posDbDeferred.scheme.data.midasSchemeCode,
      participant.posDbDeferred.data.periodOfServicePrimaryKey);
    const dbTransferPage = new DbTransferPage(
      participant,
      participant.posDbDeferred.scheme.data.midasSchemeCode,
      participant.posDbDeferred.data.periodOfServicePrimaryKey);
    let accordionCount = 0;

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
      await dbTransferTests.browseToDbTransferPageFromLogin(
        loginPage, dashboardPage, dbPlanSummaryPage, dbTransferPage, participant, 1);
    });

    // Access via DB Plan Summary
    it('(Access via DB Plan Summary) THEN redirect Member to DBTV results page in same browser window', () => {
      expect(browser.getCurrentUrl()).toContain(dbTransferPage.url);
    });

    // Feature navigation
    it('(Feature navigation) THEN show DBTV transaction ID', async () => {
      await checkers.anyTextOf20CharsPlus(dbTransferPage.transactionId);
      await checkers.containingTextIgnoreCase(dbTransferPage.transactionId, 'Transaction ID');
      await checkers.containingAnyNumber(dbTransferPage.transactionId);
    });

    // DBTV guidance text
    it('(DBTV guidance text) THEN show DBTV guidance text', async () => {
      await checkers.anyText(dbTransferPage.infoText);
    });

    // Default page view
    it('(Default page view) THEN show first draw in accordion as expanded draw', async () => {
      const transfersCount = await dbTransferPage.accordions.count();

      if (transfersCount === 0) {
        fail('No accordions shown');
      } else {
        accordionCount = transfersCount;
        for (let s = 0; s < accordionCount; s += 1) {
          const accordion = dbTransferPage.accordion(s);

          if (s === 0) {
            await commonTests.checkAccordionStatus(accordion, true);
          } else {
            await commonTests.checkAccordionStatus(accordion, false);
          }
        }
      }
    });

    it('(Default page view) AND show return to top of page floating icon', () => {
      expect(dbTransferPage.footer.goToTopOfPageIcon.isPresent()).toBe(true);
    });

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.uat:
      case commonConstants.appEnvironmentEnum.staging:
      case commonConstants.appEnvironmentEnum.prod:
        // TODO: re-enable when CS calcs set up in UAT, STAGING and PROD
        /*
          will fail on this test for the moment until PRD Calc Studio is set up, any necessary TE code tweaks are
          made and the CS formulae are freshed back into STAGE, UAT and QA.
         */
        break;
      case commonConstants.appEnvironmentEnum.qa:
        // DBTV, data view + DBTV, notes
        it('(DBTV, data view + DBTV, notes) THEN show available DBTV notes'
          + ' [*** PLEASE NOTE will fail for all but QA due to bug 8438 ***]', async () => {
          if (accordionCount > 0) {
            for (let s = 0; s < accordionCount; s += 1) {
              await checkSpecificAccordion(dbTransferPage, s);
            }
          }
        });
        break;

      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
    }

    afterAll(async () => {
      await commonTests.logOut(dbTransferPage, loginPage);
    });
  });
}
