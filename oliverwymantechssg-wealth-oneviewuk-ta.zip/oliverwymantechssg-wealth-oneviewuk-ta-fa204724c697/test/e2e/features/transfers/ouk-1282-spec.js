// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load participant(s)
const ParticipantOuk1282P001
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');
const ParticipantOuk1282P002
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participantOuk1282P001 = new ParticipantOuk1282P001();
const participantOuk1282P002 = new ParticipantOuk1282P002();
const dbPlanSummaryTests = new DbPlanSummaryTests();

// tests
const scenarioPrefix = `OUK-1282${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Visibility`, () => {
  /*
    GIVEN that the Member is on the [DB Plan Summary] page
    WHEN the [DB Plan Summary] page loads
  */

  const participant = participantOuk1282P001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, participant, 0);
  });

  it('THEN [DISPLAY DBTV CARD] based on [DBTV AVAIL]', () => {
    expect(dbPlanSummaryPage.transferCard.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(dbPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}TV content`, () => {
  /*
    GIVEN that the Member is on the [DB Plan Summary] page
    AND [CURRENT DBTV] SERVICE does not return either [CS FATAL] or [CS ERROR]
    WHEN the SERVICE returns [CS RESULTS]
  */

  const participant = participantOuk1282P001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, participant, 0);
  });

  it('THEN show [DBTV LABEL] i.e. Transfer Value*'
    + ' AND show [TOTAL DBTV] i.e. £101,700.00'
    + ' AND show [DBTV CALC DATE] i.e. as at 03/05/2017'
    + ' AND show [DBTV FOOTNOTE] i.e. *Not guaranteed'
    + ' AND show [DBTV CTA LINK] i.e. Obtain transfer value', async () => {
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.transferCardLabel, 'Transfer value*');
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.transferCardValue, '£101,700.00');
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.transferCardTerm, '03/05/2017');
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.transferCardNote, '*Not guaranteed');
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.transferCardCTA, 'Obtain a transfer value');
  });

  afterAll(async () => {
    await commonTests.logOut(dbPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}CTA behaviour`, () => {
  /*
    GIVEN that the Member is on the [DB Plan Summary] page
    AND the [DBTV CARD] has loaded
    WHEN the Member selects the [DBTV CTA LINK]
  */

  const participant = participantOuk1282P001;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, participant, 0);
  });

  it('THEN redirect Member to [DBTV PAGE] within same browser window', async () => {
    expect(dbPlanSummaryPage.transferCard.isDisplayed()).toBe(true);
    await commonTests.clickElement(dbPlanSummaryPage.transferCardCTA);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(dbPlanSummaryPage);
    expect(browser.getCurrentUrl()).toContain(dbPlanSummaryPage.ctaUrl);
  });

  afterAll(async () => {
    await commonTests.logOut(dbPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Error handling`, () => {
  /*
    GIVEN that the Member is on the [DB Plan Summary] page
    AND [CURRENT DBTV] SERVICE returns [CS ERROR]
    WHEN [DB TV CARD] loads
  */

  const participant = participantOuk1282P002;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dbPlanSummaryPage = new DbPlanSummaryPage(
    participant,
    participant.posDbActive.scheme.data.midasSchemeCode,
    participant.posDbActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dbPlanSummaryPage, participant, 0);
  });

  it('THEN show [DBTV LABEL]'
    + 'AND show [CS ERROR MESSAGE] i.e. Sorry, this feature is currently unavailable.'
    + ' Please try again, or alternatively, contact us.'
    + ' AND hide [TOTAL DBTV]'
    + ' AND hide [DBTV CALC DATE]'
    + ' AND hide [DBTV FOOTNOTE]'
    + ' AND hide [DBTV CTA LINK]', async () => {
    expect(dbPlanSummaryPage.transferCard.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(dbPlanSummaryPage.viewDetailsError1Label,
      'Sorry, this feature is currently '
      + 'unavailable. Please try again, or alternatively, contact us.');
    expect(dbPlanSummaryPage.transferCardLabel.isDisplayed()).toBe(true);
    expect(dbPlanSummaryPage.transferCardValue.isDisplayed()).toBe(false);
    expect(dbPlanSummaryPage.transferCardTerm.isDisplayed()).toBe(false);
    expect(dbPlanSummaryPage.transferCardNote.isDisplayed()).toBe(false);
    expect(dbPlanSummaryPage.transferCardCTA.isDisplayed()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(dbPlanSummaryPage, loginPage);
  });
});
