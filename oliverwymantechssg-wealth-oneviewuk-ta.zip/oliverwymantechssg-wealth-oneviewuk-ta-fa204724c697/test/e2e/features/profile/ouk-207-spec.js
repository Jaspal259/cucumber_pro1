// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load test(s)
const DashboardTests = require('../_common/dashboard.spec.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dcPlanSummaryPage = new DcPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDcActive.scheme.data.midasSchemeCode,
  standardParticipant.posDcActive.data.periodOfServicePrimaryKey);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-207${commonConstants.bddScenarioPrefix}`;

async function loginAndSelectProfileIcon() {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  await commonTests.clickElement(dashboardPage.header.userProfileIcon);
}

async function checkUserNameShown(participant, dashboardPageHeader) {
  await checkers.containingTextIgnoreCase(dashboardPageHeader.userNameLabel,
    `${participant.data.userInitials} ${participant.data.userSurname}`);
}

describe(`${scenarioPrefix}Placement + Enable Profile content`, () => {
  /*
    Placement
    -----------------------------------------------------
    GIVEN that the Participant [AUTHENTICATION STATUS] is [AUTHENTICATED]
    WHEN they view a page in OneView
    BUT they are not viewing the [EMPLOYER SELECT] page

    Enable Profile content
    -----------------------------------------------------
    GIVEN that the Participant is viewing the [PAGE HEADER]
    WHEN they select the [PROFILE ICON]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Placement
  it('(Placement) THEN show [PROFILE ICON] from CMS in top right hand corner of [PAGE HEADER]', () => {
    expect(dashboardPage.header.userProfileIcon.isDisplayed()).toBe(true);
    expect(dashboardPage.header.userDropDown.isDisplayed()).toBe(true);
  });

  // Enable Profile content
  it('(Enable Profile content) THEN display [FORENAME] [SURNAME] from SERVICE', async () => {
    await commonTests.clickElement(dashboardPage.header.userDropDown);
    await checkUserNameShown(standardParticipant, dashboardPage.header);
  });

  it('(Enable Profile content) AND [VIEW PROFILE LINK]', () => {
    expect(dashboardPage.header.viewProfileLink.isDisplayed()).toBe(true);
  });

  it('(Enable Profile content) AND [VIEW PROFILE LINK DESC] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dashboardPage.header.viewProfileLink, 'Profile');
  });

  afterAll(async () => {
    await commonTests.clickElement(dashboardPage.header.userProfileIcon);
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

describe(`${scenarioPrefix}Disable Profile content`, () => {
  /*
    GIVEN that the Participant is viewing the [PAGE HEADER]
    AND they have selected the [PROFILE ICON]
    WHEN they select the [PROFILE ICON] again or navigate to another area of the site
   */

  beforeAll(async () => {
    await loginAndSelectProfileIcon(loginPage, dashboardPage, dashboardPage.header, standardParticipant);
  });

  function checkProfileDropdownClosed(pageHeader) {
    expect(pageHeader.userProfileIcon.isDisplayed()).toBe(true);
    expect(pageHeader.userDropDown.isDisplayed()).toBe(true);
    expect(pageHeader.userNameLabel.isPresent()).toBe(false);
    expect(pageHeader.viewProfileLink.isPresent()).toBe(false);
    expect(pageHeader.logoutLink.isPresent()).toBe(false);
  }

  it('THEN show [PROFILE ICON] only (select profile icon again)', async () => {
    await commonTests.clickElement(dashboardPage.header.userDropDown);
    await browser.wait(until.stalenessOf(dashboardPage.header.userNameLabel),
      commonConstants.shortBrowserWaitDelay, 'User name label is still shown');
    checkProfileDropdownClosed(dashboardPage.header);
  });

  it('THEN show [PROFILE ICON] only (navigate to another area of the site)', async () => {
    await commonTests.clickElement(dashboardPage.header.userDropDown);
    expect(dashboardPage.header.userNameLabel.isPresent()).toBe(true);
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromDashboard(
      dashboardPage, dcPlanSummaryPage, 0);
    checkProfileDropdownClosed(dcPlanSummaryPage.header);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

describe(`${scenarioPrefix}Pensioner and Member`, () => {
  /*
    GIVEN that the Participant has selected the [PROFILE ICON]
    AND [PARTICIPANT TYPE] is [PENSIONER] and [MEMBER]
    AND Participant has multiple [POS]
    WHEN determining which [FORENAME] [SURNAME] to show
   */

  /*
    note participantMemAndPen set up so forename different in DC/DB and pensioner
    - in DC/DB - "Andrew"
    - in pensioner - "A"
   */

  beforeAll(async () => {
    await loginAndSelectProfileIcon(loginPage, dashboardPage, dashboardPage.header, standardParticipant);
  });

  it('THEN show [FORENAME] [SURNAME] from SERVICE based on [PARTICIPANT TYPE] is [PENSIONER] AND [MAIN POS]',
    async () => {
      await checkUserNameShown(standardParticipant, dashboardPage.header);
    });

  afterAll(async () => {
    await commonTests.clickElement(dashboardPage.header.userProfileIcon);
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
