// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ProfileInformationTests = require('../_common/profile.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');

// create new objects
const standardParticipant = new StandardParticipant();
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const profileInformationTests = new ProfileInformationTests();
const tooltipTests = new TooltipTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const profilePage = new ProfilePage(standardParticipant);

// other
const until = protractor.ExpectedConditions;
const testEmail = standardParticipant.data.emailAddress;    // using actual e-mail so not 'corrupting' participant

// tests
const scenarioPrefix = `OUK-5252${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await profileInformationTests.browseToProfileInformationPageFromLogin(
    loginPage, dashboardPage, profilePage, participant);
}

async function logoutAfterCancel() {
  await unsavedChangesModalTests.cancelUnsavedChangesIncludingCancelCancel(
    profilePage,
    profilePage.editSecurityEmailCancelButton,
    profilePage.unsavedChangesModal,
    profilePage.editSecurityEmailUrl,
    profilePage,
    true);

  await commonTests.logOut(profilePage, loginPage);
}

async function clickOnEditButton() {
  await browser.isElementPresent(profilePage.contactDetailsEditButton);
  await commonTests.clickElement(profilePage.securityEmailEditButton);
  await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
}

describe(`${scenarioPrefix}Profile, Email address, read view + Profile, email address - info icon`, () => {
  /*
    Profile, Email address, read view
    -----------------------------------------------------------
    GIVEN Participant has successfully logged in
    WHEN the Participant navigates to Profile page read view

    Profile, email address - info icon
    -----------------------------------------------------------
    GIVEN email address guidance text is available
    AND view is Profile page read view
    WHEN the Participant selects the email address details info icon
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  // Profile, Email address, read view
  it('THEN display current email address', async () => {
    await checkers.containingTextIgnoreCase(profilePage.securityEmailTitle, 'Forgot');
    await checkers.containingTextIgnoreCase(profilePage.securityEmailLabel, 'E-mail');
    await checkers.anyText(profilePage.securityEmailLabel);
  });

  it('AND enable Edit email address button', async () => {
    await checkers.containingTextIgnoreCase(profilePage.securityEmailEditButton, 'EDIT');
    await checkers.isMercerOsButtonSelected(profilePage.securityEmailEditButton);
  });

  //  Profile, email address - info icon
  it('THEN show email address guidance text', async () => {
    await tooltipTests.checkTooltipIsElementWithAnyText(
      profilePage.securityEmailInfoIcon,
      profilePage.securityEmailTitle,
      profilePage.tooltips.firstRightTooltip
    );
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Profile, email address, edit page view`, () => {
  /*
    GIVEN view is Profile page read view
    WHEN the Participant selects the Edit email address button
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN direct Participant to Profile email address edit view', async () => {
    await clickOnEditButton();
    expect(browser.getCurrentUrl()).toContain(profilePage.editSecurityEmailUrl);
  });

  it('AND display current email address', async () => {
    await checkers.inputAnyText(profilePage.editSecurityEmailInputValue);
    await checkers.containingTextIgnoreCase(profilePage.editSecurityEmailLabel, 'mail');
    await checkers.containingImage(profilePage.editSecurityEmailIcon,
      commonConstants.emailOutlineImageSource);
    await checkers.anyText(profilePage.editSecurityEmailBottomLink);
  });

  it('AND enable edits to email address', async () => {
    await profilePage.editSecurityEmailInputValue.clear();
    await profilePage.editSecurityEmailInputValue.sendKeys(testEmail);
    await checkers.inputExactText(profilePage.editSecurityEmailInputValue, testEmail);
  });

  it('AND enable Cancel button', async () => {
    expect(profilePage.editSecurityEmailCancelButton.isEnabled()).toBe(true);
    await checkers.isMercerOsButtonUnselected(profilePage.editSecurityEmailCancelButton);
  });

  it('AND enable Save changes button (primary button)', async () => {
    expect(profilePage.editSecurityEmailSaveButton.isEnabled()).toBe(true);
    await checkers.isMercerOsButtonSelected(profilePage.editSecurityEmailSaveButton);
  });

  afterAll(async () => {
    await logoutAfterCancel();
  });
});

async function checkInvalidEmailRejected(invalidEmail) {
  await profilePage.editSecurityEmailInputValue.clear();
  await profilePage.editSecurityEmailInputValue.sendKeys(invalidEmail);
  await commonTests.clickElement(profilePage.editSecurityEmailIcon);
  await browser.wait(
    until.visibilityOf(profilePage.editSecurityEmailRequiredError),
    commonConstants.briefBrowserWaitDelay,
    'No error displayed to state e-mail is blank');
  await checkers.containingTextIgnoreCase(profilePage.editSecurityEmailRequiredError, 'must contain @ and .');
}

describe(`${scenarioPrefix}Profile, email address, edit, validations on navigation away`, () => {
  /*
    GIVEN view is Profile email address edit view
    WHEN the Participant attempts to navigate away from the email address field and the email
    is <invalid email address>
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN highlight invalid field', async () => {
    await clickOnEditButton();
    await checkInvalidEmailRejected('#@%^%#$@#$@#.com');
    await checkInvalidEmailRejected('@test.com');
    await checkInvalidEmailRejected('email.test.com');
    await checkInvalidEmailRejected('email@test..com');
  });

  afterAll(async () => {
    await logoutAfterCancel();
  });
});

describe(`${scenarioPrefix}Profile, email address, edit, successful update`, () => {
  /*
    GIVEN view is Profile email address edit view
    WHEN the Participant submits valid email address
    AND the update is successful
   */
  let currentEmail;

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN return Participant to Profile page read view', async () => {
    await clickOnEditButton();

    // save e-mail before change
    currentEmail = await profilePage.editSecurityEmailInputValue.getAttribute('value');

    await profilePage.editSecurityEmailInputValue.clear();
    await profilePage.editSecurityEmailInputValue.sendKeys(testEmail);

    await commonTests.clickElement(profilePage.editSecurityEmailSaveButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
    expect(browser.getCurrentUrl()).toContain(profilePage.url);
  });

  it('AND display updated email address', async () => {
    await checkers.containingTextIgnoreCase(profilePage.securityEmailValue, testEmail);
  });

  it('AND show confirmation toast alert,'
    + 'AND update Participant account', async () => {
    // note the back end updates will not be tested by the TE code, only what is seen through the OV3 UI

    // message only shown if e-mail changed
    if (currentEmail !== testEmail) {
      await checkers.containingTextIgnoreCase(profilePage.toast.message, 'successfully submitted');
    }
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});
