// load common
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const DashboardTests = require('../_common/dashboard.spec');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ViewProfilePage = require('../../page-objects/view-profile.po.js');

// create new objects
const standardParticipant = new StandardParticipant();
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const viewProfilePage = new ViewProfilePage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-4624${commonConstants.bddScenarioPrefix}`;

async function loginDashboard(participant) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
}

describe(`${scenarioPrefix}Display Participant identifier`, () => {
  /*
    GIVEN <forename> is available
    AND <surname> is available
    WHEN the Participant navigates to a page available to authenticated Participants
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginDashboard(standardParticipant);
  });

  it('THEN display Profile [Participant identifier]', async () => {
    await commonTests.clickElement(viewProfilePage.profileDropDown);
    const userName = await viewProfilePage.userNameLabel.getText();
    const splitStr = await userName.split(' ');
    const firstNameChar1 = await splitStr[0].charAt(0);
    const lastNameChar1 = await splitStr[1].charAt(0);
    const participantIdentifier = await viewProfilePage.profileDropDown.getText();
    expect(participantIdentifier).toEqual(firstNameChar1 + lastNameChar1);

    // close the dropdown so the logout will work in Jenkins consistently
    await commonTests.clickElement(viewProfilePage.profileDropDown);
    await browser.wait(until.invisibilityOf(viewProfilePage.userNameLabel), commonConstants.briefBrowserWaitDelay,
      'User name label still shown');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
