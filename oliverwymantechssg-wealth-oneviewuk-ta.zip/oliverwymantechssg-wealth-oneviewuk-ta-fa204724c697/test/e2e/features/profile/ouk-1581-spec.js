// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ViewProfilePage = require('../../page-objects/view-profile.po.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ViewProfilePageTests = require('../_common/view-profile.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const viewProfilePageTests = new ViewProfilePageTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const viewProfilePage = new ViewProfilePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-1581${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await viewProfilePageTests.browseToViewProfilePageFromLogin(
    loginPage, dashboardPage, viewProfilePage, participant);
}

describe(`${scenarioPrefix}User ID read view `, () => {
  /*
    GIVEN Participant has successfully logged in

    GIVEN Participant has navigated to Profile page
    WHEN User ID is displayed
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show current User ID in read view'
    + ' AND enable edit User ID button ', async () => {
    await checkers.anyText(viewProfilePage.currentUserIdTitle);
    await checkers.exactText(viewProfilePage.userIdLabel, 'User ID');
    await checkers.anyText(viewProfilePage.userIdValue);
    expect(viewProfilePage.userIdValue.getTagName()).not.toBe('input');
    expect(viewProfilePage.userIdEditButton.isEnabled()).toBe(true);
    await checkers.anyText(viewProfilePage.userIdEditButton);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Edit page view`, () => {
  /*
GIVEN Participant has successfully logged in

GIVEN view is Profile page
WHEN Participant selects the User ID Edit button
  */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN open User ID edit page view'
    + ' AND enable edits to User ID'
    + ' AND enable Cancel button'
    + ' AND enable Save changes button (primary button) ', async () => {
    await checkers.anyText(viewProfilePage.userIdEditButton);
    await commonTests.clickElement(viewProfilePage.userIdEditButton);

    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await viewProfilePage.userIdInput.clear();
    await viewProfilePage.userIdInput.sendKeys('userId1');
    await checkers.containingTextIgnoreCase(viewProfilePage.userIdCancelButton, 'Cancel');
    await checkers.containingTextIgnoreCase(viewProfilePage.userIdSaveButton, 'Save');
    expect(viewProfilePage.userIdCancelButton.isEnabled()).toBe(true);
    expect(viewProfilePage.userIdSaveButton.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});
