// load common
const genericCommonTests = require('../../utilities/generic-common.helper.js');
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participants
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ProfileInformationTests = require('../_common/profile.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');
const UnsavedChangesModalTests = require('../_common/unsaved-changes-modal.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ProfilePage = require('../../page-objects/profile.po.js');

// create new objects
const standardParticipant = new StandardParticipant();
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const profileInformationTests = new ProfileInformationTests();
const tooltipTests = new TooltipTests();
const unsavedChangesModalTests = new UnsavedChangesModalTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const profilePage = new ProfilePage(standardParticipant);

// tests
const scenarioPrefix = `OUK-130${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await profileInformationTests.browseToProfileInformationPageFromLogin(
    loginPage, dashboardPage, profilePage, participant);
}

describe(`${scenarioPrefix}Profile - Alternate name visibility + Info icon`, () => {
  /*
   GIVEN the Participant has navigated to the Profile page
   AND manage alternate name is enabled
   WHEN the Profile page loads
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('Profile - Alternate name visibility: THEN show greeting preferences feature', async () => {
    await checkers.containingTextIgnoreCase(profilePage.greetingPreferencesTitle, 'Greeting');
    expect(profilePage.greetingPreferencesInfoIcon.isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(profilePage.greetingAlternativeNameLabel, 'Current Greeting');
  });

  it('Profile - Alternate name visibility: AND show current alternate name in read state', async () => {
    await checkers.anyText(profilePage.greetingAlternativeNameValue);
    await checkers.readOnly(profilePage.greetingAlternativeNameValue);
  });

  it('Profile - Alternate name visibility: AND show edit personalised greeting button in active state', async () => {
    await checkers.exactText(profilePage.greetingPreferencesEditButton, 'EDIT');
    expect(profilePage.greetingPreferencesEditButton.isEnabled()).toBe(true);
  });

  it('Info icon: THEN show greetings preferences guidance text', async () => {
    await tooltipTests.checkTooltipIsElementWithAnyText(
      profilePage.greetingPreferencesInfoIcon,
      profilePage.greetingAlternativeNameLabel,
      profilePage.tooltips.firstRightTooltip);
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

describe(`${scenarioPrefix}enable edit mode`, () => {
  /*
    GIVEN the Participant has navigated to the Profile page
    AND manage alternate name is enabled
    WHEN they select edit
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN open Personalised greeting edit view'
    + ' AND enable updates to alternate name'
    + ' AND enable Cancel button'
    + ' AND enable Save button (primary button)', async () => {
    const existingAltName = await profilePage.greetingAlternativeNameValue.getText();
    await commonTests.clickElement(profilePage.greetingPreferencesEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
    expect(browser.getCurrentUrl()).toContain(profilePage.editGreetingAlternateUrl);

    // check common elements
    await checkers.containingTextIgnoreCase(profilePage.header.pageCategoryHeader(global.deviceType), 'PROFILE');
    await checkers.containingTextIgnoreCase(profilePage.header.pageHeader(global.deviceType), 'Greeting');
    await checkers.anyText(profilePage.header.pageContent);

    // check buttons
    expect(profilePage.greetingPreferencesCancelButton.isEnabled()).toBe(true);
    await checkers.isMercerOsButtonUnselected(profilePage.greetingPreferencesCancelButton);
    expect(profilePage.greetingPreferencesSaveButton.isEnabled()).toBe(true);
    await checkers.isMercerOsButtonSelected(profilePage.greetingPreferencesSaveButton);

    // check greeting-specific content
    await checkers.containingImage(profilePage.greetingAlternativeNameInput,
      commonConstants.accountCircleImageSource);
    await checkers.inputAnyText(profilePage.greetingAlternativeNameInputValueInput);

    const newAltName = genericCommonTests.reverseString(existingAltName);

    await profilePage.greetingAlternativeNameInputValueInput.clear();
    await profilePage.greetingAlternativeNameInputValueInput.sendKeys(newAltName);

    await unsavedChangesModalTests.cancelUnsavedChangesIncludingCancelCancel(
      profilePage,
      profilePage.greetingPreferencesCancelButton,
      profilePage.unsavedChangesModal,
      profilePage.editGreetingAlternateUrl,
      profilePage,
      true);

    await checkers.exactText(profilePage.greetingAlternativeNameValue, existingAltName);
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});

describe(`${scenarioPrefix}successful update`, () => {
  /*
    GIVEN the Participant has navigated to the Profile page
    AND greeting preferences is in edit page view
    AND edits have been made
    AND alternate name meets permitted format
    WHEN the Save button is selected
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  async function editAndSaveAltName(newAltName, oldAltName) {
    await commonTests.clickElement(profilePage.greetingPreferencesEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
    expect(browser.getCurrentUrl()).toContain(profilePage.editGreetingAlternateUrl);

    await profilePage.greetingAlternativeNameInputValueInput.clear();
    await profilePage.greetingAlternativeNameInputValueInput.sendKeys(newAltName);
    await commonTests.clickElement(profilePage.greetingPreferencesSaveButton);

    await commonTests.checkPageLoadsAndContainsStandardElements(profilePage);
    expect(browser.getCurrentUrl()).toContain(profilePage.url);

    await checkers.exactText(profilePage.greetingAlternativeNameValue, newAltName);
    await checkers.notContainingText(profilePage.greetingAlternativeNameValue, oldAltName);
    await checkers.containingTextIgnoreCase(profilePage.toast.message,
      commonConstants.editSuccessToastMessage);
  }

  it('THEN update alternate name for participant and that client'
    + ' AND close edit page view'
    + ' AND return Participant to read view'
    + ' AND show greeting preferences confirmation message', async () => {
    const altNameElement = await profilePage.greetingAlternativeNameValue;
    const existingAltName = await altNameElement.getText();

    // change existing alt name by reversing it
    const newAltName = genericCommonTests.reverseString(existingAltName);
    await editAndSaveAltName(newAltName, existingAltName);

    // re-instate existing alt name to be polite
    await editAndSaveAltName(existingAltName, newAltName);
  });

  afterAll(async () => {
    await commonTests.logOut(profilePage, loginPage);
  });
});
