// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const ViewProfilePage = require('../../page-objects/view-profile.po.js');

// load participant(s)
const ParticipantOuk4384P001
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const ViewProfilePageTests = require('../_common/view-profile.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participantOuk4384P001 = new ParticipantOuk4384P001();
const loginPage = new LoginPage(participantOuk4384P001);
const dashboardPage = new DashboardPage(participantOuk4384P001);
const viewProfilePage = new ViewProfilePage(participantOuk4384P001);
const viewProfilePageTests = new ViewProfilePageTests();

// tests
const scenarioPrefix = `OUK-4384${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await viewProfilePageTests.browseToViewProfilePageFromLogin(loginPage, dashboardPage, viewProfilePage, participant);
}

describe(`${scenarioPrefix}Personalised greeting - edit view `, () => {
  /*
    GIVEN manage alternate name is enabled
    AND view is Profile page read view
    WHEN the Participant selects the Personalised Greeting edit button
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(participantOuk4384P001);
  });

  it('THEN direct Participant to Profile Personalised Greeting edit view', async () => {
    await checkers.anyText(viewProfilePage.greetingPreferencesEditButton);
    await commonTests.clickElement(viewProfilePage.greetingPreferencesEditButton);

    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await checkers.anyText(viewProfilePage.greetingPreferencesCancelButton);
    await checkers.anyText(viewProfilePage.greetingPreferencesSaveButton);
    await checkers.anyText(viewProfilePage.greetingAlternativeNameInput);
  });

  it('AND show current alternate name ', async () => {
    await checkers.anyText(viewProfilePage.greetingAlternativeNameInput);
  });

  it('AND enable edits to alternate name', async () => {
    await viewProfilePage.greetingAlternativeNameInput.sendKeys('123');
    await commonTests.clickElement(viewProfilePage.greetingPreferencesCancelButton);
    await commonTests.clickElement(viewProfilePage.loseChangesConfirmButton);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}User ID - info icon `, () => {
  /*
    GIVEN User ID guidance text is available
    AND view is Profile page read view
    WHEN Participant selects User ID info icon
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN show User ID guidance text', async () => {
    await commonTests.clickElement(viewProfilePage.userIdInformationTooltip);
    await checkers.anyText(viewProfilePage.userIdInformationTooltip);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}User ID - edit view`, () => {
  /*
    GIVEN view is Profile page read view
    WHEN the Participant selects the User ID Edit button
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN direct Participant to Profile User ID edit view', async () => {
    await commonTests.clickElement(viewProfilePage.userIdEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await checkers.anyText(viewProfilePage.userIdCancelButton);
    await checkers.anyText(viewProfilePage.userIdSaveButton);
  });

  it('AND show current User ID', async () => {
    await checkers.inputAnyText(viewProfilePage.userIdInput);
  });

  it('AND enable edits to User ID', async () => {
    await viewProfilePage.userIdInput.sendKeys('mercerdemo2');
  });

  it('AND enable Cancel Button', async () => {
    await checkers.anyText(viewProfilePage.userIdCancelButton);
    expect(viewProfilePage.userIdCancelButton.isEnabled()).toBe(true);
  });

  it('AND enable Save Button', async () => {
    await checkers.anyText(viewProfilePage.userIdSaveButton);
    expect(viewProfilePage.userIdSaveButton.isEnabled()).toBe(true);
    await commonTests.clickElement(viewProfilePage.userIdCancelButton);
    await commonTests.clickElement(viewProfilePage.loseChangesConfirmButton);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Passcode - info icon `, () => {
  /*
    GIVEN Passcode guidance text is available
    AND view is Profile page read view
    WHEN Participant selects Passcode info icon
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN show Passcode guidance text', async () => {
    await commonTests.clickElement(viewProfilePage.passcodeInformationTooltip);
    await checkers.anyText(viewProfilePage.passcodeInformationTooltip);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Profile, edit mode, no edits, cancel button  `, () => {
  /*
    GIVEN view is <profile feature> edit page view
    AND no edits have been made
    WHEN the Participant selects the cancel button
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN return Participant to Profile page read view ', async () => {
    await commonTests.clickElement(viewProfilePage.userIdEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await checkers.anyText(viewProfilePage.userIdCancelButton);
    await checkers.anyText(viewProfilePage.userIdSaveButton);

    await commonTests.clickElement(viewProfilePage.userIdCancelButton);
    await checkers.anyText(viewProfilePage.userIdEditButton);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Profile, edit mode, cancel through navigating away, no edits`, () => {
  /*
    GIVEN view is <profile feature> edit page view
    AND no edits have been made
    WHEN the Participant attempts to navigate away
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN navigate Participant to page selected ', async () => {
    await commonTests.clickElement(viewProfilePage.userIdEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await checkers.anyText(viewProfilePage.userIdCancelButton);
    await checkers.anyText(viewProfilePage.userIdSaveButton);

    await commonTests.clickElement(viewProfilePage.backButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    expect(browser.getCurrentUrl()).toContain(viewProfilePage.url);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});

describe(`${scenarioPrefix}Profile, edit mode, no edits, save button`, () => {
  /*
    GIVEN view is <profile feature> edit page view
    AND no edits have been made
    WHEN the Participant selects the save button
  */

  beforeAll(async () => {
    await login(participantOuk4384P001);
  });

  it('THEN return Participant to Profile page read view', async () => {
    await commonTests.clickElement(viewProfilePage.userIdEditButton);
    await commonTests.checkPageLoadsAndContainsStandardElements(viewProfilePage);
    await checkers.anyText(viewProfilePage.userIdCancelButton);
    await checkers.anyText(viewProfilePage.userIdSaveButton);

    await commonTests.clickElement(viewProfilePage.userIdSaveButton);
    await checkers.anyText(viewProfilePage.userIdEditButton);
  });

  afterAll(async () => {
    await commonTests.logOut(viewProfilePage, loginPage);
  });
});
