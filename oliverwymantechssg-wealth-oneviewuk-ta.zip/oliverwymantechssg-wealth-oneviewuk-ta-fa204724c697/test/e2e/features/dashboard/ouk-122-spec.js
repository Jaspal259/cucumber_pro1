// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const PlanHeaderTests = require('../_common/plan-header.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const planHeaderTests = new PlanHeaderTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);


// tests
const scenarioPrefix = `OUK-122${commonConstants.bddScenarioPrefix}`;

/*
  NOTE most scenarios in this story cannot be automated as not happy path - have simplified this down to
  what is available using standard participant in OV1 client and settings of CC items in OV1 MIDAS scheme
  ... but have added test for DC deferred as well as DC active now

  Midas CC items for showing / hiding TRD and NRD for scheme are CCDisplayTRD and CCDisplayDCNRD
 */

describe(`${scenarioPrefix}DC, TRD enabled, NRD enabled, NRD and TRD set, show TRD + Pensioner`, () => {
  /*
   DC, TRD enabled, NRD enabled, NRD and TRD set, show TRD
   --------------------------------------------------------------------
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [Member]
   AND [PLAN DESIGN] is [DC]
   AND Target Retirement date is enabled for the Plan
   AND Normal Retirement date is enabled for the Plan
   AND Target Retirement Date is recorded in MIDAS
   AND Normal Retirement Date is recorded in MIDAS
   WHEN the member views their DC Dashboard Summary Card

   Pensioner
   --------------------------------------------------------------------
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [Pensioner]
   WHEN the pensioner views their Pensions In Payment Dashboard Summary Card
   */

  const dcActivePos = standardParticipant.posDcActive;
  const dcActiveCard = dashboardTests.getSelectedDashboardSummaryCard(
    dashboardPage, dcActivePos.data.planType, 0);
  const dcDeferredPos = standardParticipant.posDcDeferred;
  const dcDeferredCard = dashboardTests.getSelectedDashboardSummaryCard(
    dashboardPage, dcDeferredPos.data.planType, 1);
  const pensionerCard = dashboardTests.getSelectedDashboardSummaryCard(
    dashboardPage, standardParticipant.posPensioner.data.planType, 0);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  function checkDcCard(selectedCard, selectedPos, selectedPosDescription) {
    it(`(DC, TRD enabled ...) THEN show [RETIREMENT DATE DESCRIPTION] from CMS (${selectedPosDescription})`,
      async () => {
        expect(selectedCard.card(global.deviceType).isDisplayed()).toBe(true);
        await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
        await planHeaderTests.isRetirementDateLabelShown(
          selectedCard.dateOfRetirementLabel(global.deviceType),
          selectedCard.dateOfRetirementInfoIcon(global.deviceType), selectedPos);
      });

    it(`(DC, TRD enabled ...) AND show [TARGET RETIREMENT DATE] from SERVICE (${selectedPosDescription})`,
      async () => {
        await checkers.exactUkDate(selectedCard.dateOfRetirementValue(global.deviceType), selectedPos.data.trdValue);
      });
  }

  // DC, TRD enabled, NRD enabled, NRD and TRD set, show TRD
  checkDcCard(dcActiveCard, dcActivePos, 'DC active');
  checkDcCard(dcDeferredCard, dcDeferredPos, 'DC deferred');

  // Pensioner
  it('(Pensioner) THEN hide [RETIREMENT DATE DESCRIPTION] from CMS', async () => {
    expect(pensionerCard.card(global.deviceType).isDisplayed()).toBe(true);
    await commonTests.clickExpandMoreButtonIfMobile(pensionerCard.mobileExpandMore(global.deviceType));
    expect(pensionerCard.dateOfRetirementLabel(global.deviceType).isPresent()).toBe(false);
  });

  it('(Pensioner) AND hide [TARGET RETIREMENT DATE] from SERVICE', () => {
    expect(pensionerCard.dateOfRetirementValue(global.deviceType).isPresent()).toBe(false);
  });

  it('(Pensioner) AND hide [NORMAL RETIREMENT DATE] from SERVICE', () => {
    expect(pensionerCard.dateOfRetirementValue(global.deviceType).isPresent()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
