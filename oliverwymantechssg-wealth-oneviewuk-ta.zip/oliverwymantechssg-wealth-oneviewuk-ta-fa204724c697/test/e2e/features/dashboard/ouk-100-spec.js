// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();

// tests
const scenarioPrefix = `OUK-100${commonConstants.bddScenarioPrefix}`;

function checkDashboardCardsAreShown(dashboardPage, planType) {
  switch (planType) {
    case 'DC':
      expect(dashboardPage.dcCard0.card(global.deviceType).isDisplayed()).toBe(true);
      expect(dashboardPage.dcCard1.card(global.deviceType).isDisplayed()).toBe(true);
      break;
    case 'DB':
      expect(dashboardPage.dbCard0.card(global.deviceType).isDisplayed()).toBe(true);
      expect(dashboardPage.dbCard1.card(global.deviceType).isDisplayed()).toBe(true);
      break;
    case 'Pensioner':
      expect(dashboardPage.pensionerCard0.card(global.deviceType).isDisplayed()).toBe(true);
      break;
    default:
      throw new Error(`The planType '${planType}' is not supported`);
  }
}

function checkNoDashboardCardsShown(dashboardPage, planType) {
  // card visibility disabled
  // note only card0 needs to be checked as this will always be first card shown
  switch (planType) {
    case 'DC':
      expect(dashboardPage.dcCard0.card(global.deviceType).isPresent()).toBe(false);
      break;
    case 'DB':
      expect(dashboardPage.dbCard0.card(global.deviceType).isPresent()).toBe(false);
      break;
    case 'Pensioner':
      expect(dashboardPage.pensionerCard0.card(global.deviceType).isPresent()).toBe(false);
      break;
    default:
      throw new Error(`The planType '${planType}' is not supported`);
  }
}

function visibilityRulesScenario(
  planType, cardVisibilityEnabled, numberOfPeriodsOfService, showSummaryCard, participant) {
  const scenarioSuffix = ` (${planType}, card visibility ${
    cardVisibilityEnabled.toString().toLowerCase()}, ${numberOfPeriodsOfService
  } POS)`;

  describe(`${scenarioPrefix}Visibility Rules${scenarioSuffix}`, () => {
    /*
      GIVEN that the Participant is on the Dashboard
      WHEN the Participant views the Dashboard
     */

    const thenLabel
      = `THEN ${showSummaryCard} [SUMMARY CARD] based on ${planType} [PLAN DESIGN], ${
        cardVisibilityEnabled} [VISIBILITY] and ${numberOfPeriodsOfService
      } [POS] (periods of service)`;

    const loginPage = new LoginPage(participant);
    const dashboardPage = new DashboardPage(participant);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planType}`);
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
    });

    // data driven version of
    // THEN show or hide [SUMMARY CARD] based on [PLAN DESIGN], [VISIBILITY]
    // and [POS] (periods of service)
    it(thenLabel, () => {
      if (cardVisibilityEnabled === 'Enabled' && numberOfPeriodsOfService === '1+') {
        checkDashboardCardsAreShown(dashboardPage, planType);
      } else {
        checkNoDashboardCardsShown(dashboardPage, planType);
      }
    });

    afterAll(async () => {
      await commonTests.logOut(dashboardPage, loginPage);
    });
  });
}


/*
 NOTE:
 Scheme level enabling / disabling viewing benefits (the cardVisibilityEnabled argument
 in the visibilityRulesScenario() function within this test) is set by:

 DC - CanSeeMyPensions in 'MIDAS scheme apps > OneView > Conditional Content (DC and LOB Rights)
 DB - CanSeeMyPensions in 'MIDAS scheme apps > OneView > Conditional Content (DB and LOB Rights)
 pensioner - 'MIDAS global applications > Strategic Web > Client Details > [scheme] > Set Pensioner Eligibility'
 */

visibilityRulesScenario('DC', 'Enabled', '1+', 'Show for each [POS]', standardParticipant);
visibilityRulesScenario('DB', 'Enabled', '1+', 'Show for each [POS]', standardParticipant);
visibilityRulesScenario('Pensioner', 'Enabled', '1+', 'Show for each [POS]', standardParticipant);

describe(`${scenarioPrefix}Grouping`, () => {
  /*
   GIVEN that the Participant is on the Dashboard
   AND multiple Dashboard Summary Cards are show
   WHEN the Participant views the Dashboard
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);

  beforeAll(async () => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
  });

  it('THEN group Dashboard Summary Cards by [PLAN DESIGN] and show in the following order:', async () => {
    const cards = await element.all(by.css('plan-summary-card'));
    const cardCount = await cards.length;
    expect(cardCount).toBe(5);
    expect(cards[0].getAttribute('id')).toContain('DCCard-0');
    expect(cards[1].getAttribute('id')).toContain('DCCard-1');
    expect(cards[2].getAttribute('id')).toContain('DBCard-0');
    expect(cards[3].getAttribute('id')).toContain('DBCard-1');
    expect(cards[4].getAttribute('id')).toContain('PIPCard-0');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

describe(`${scenarioPrefix}Members, Card Order (for userId ${standardParticipant.data.userId})`, () => {
  /*
     GIVEN that the Participant is on the Dashboard
     AND [PARTICIPANT TYPE] is [MEMBER]
     AND [PLAN DESIGN] is [DC] or [DB]
     AND member has multiple [POS]
     WHEN the member views the dashboard
     */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);

  beforeAll(async () => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  it('THEN show Dashboard Summary Cards by Grouping (DC/DB) AND in the following priority order:', async () => {
    await dashboardTests.expandMobileCardsForStandardParticipant(dashboardPage, global.deviceType);

    // DC
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard0.typeLabel(global.deviceType), 'DC');
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard1.typeLabel(global.deviceType), 'DC');
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard0.posStatusValue(global.deviceType), 'ACTIVE');
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard1.posStatusValue(global.deviceType), 'DEFERRED');
    await checkers.containingUkDate(dashboardPage.dcCard0.dateJoinedSchemeValue(global.deviceType), '01/02/2002');
    await checkers.containingUkDate(dashboardPage.dcCard1.dateOfExitValue(global.deviceType), '12/06/1998');

    // DB
    await checkers.containingTextIgnoreCase(dashboardPage.dbCard0.typeLabel(global.deviceType), 'DB');
    await checkers.containingTextIgnoreCase(dashboardPage.dbCard1.typeLabel(global.deviceType), 'DB');
    await checkers.containingTextIgnoreCase(dashboardPage.dbCard0.posStatusValue(global.deviceType), 'ACTIVE');
    await checkers.containingTextIgnoreCase(dashboardPage.dbCard1.posStatusValue(global.deviceType), 'DEFERRED');
    await checkers.containingUkDate(dashboardPage.dbCard0.dateJoinedSchemeValue(global.deviceType), '01/02/2002');
    await checkers.containingUkDate(dashboardPage.dbCard1.dateOfExitValue(global.deviceType), '12/06/1998');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
