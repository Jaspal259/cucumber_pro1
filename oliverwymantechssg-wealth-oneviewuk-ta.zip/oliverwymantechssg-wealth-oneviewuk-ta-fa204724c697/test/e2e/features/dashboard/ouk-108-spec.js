// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s) - note re-using participants set up for ouk-122
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// other
const until = protractor.ExpectedConditions;

// tests
const scenarioPrefix = `OUK-108${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}DJP enabled`, () => {
  /*
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [Member]
   AND Date Joined Plan is enabled for the Plan
   AND Date Joined Plan is recorded in MIDAS
   WHEN the member views either their DC or DB Dashboard Summary Card
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  function checkDjp(planType, participantStatus, pos, cardInstance) {
    const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planType, cardInstance);

    it(`THEN show [DATE JOINED PLAN DESCRIPTION] from CMS (${planType} ${participantStatus})`, async () => {
      await dashboardTests.checkCardIsDisplayed(
        selectedCard, `${planType} ${participantStatus.toLowerCase()}`);
      await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
      await checkers.containingTextIgnoreCase(selectedCard.dateJoinedSchemeLabel(global.deviceType),
        'DATE JOINED');
    });

    it(`AND show [DATE JOINED PLAN] from SERVICE (${planType} ${participantStatus})`, async () => {
      await checkers.exactUkDate(selectedCard.dateJoinedSchemeValue(global.deviceType),
        pos.data.dateJoinedSchemeValue);
    });
  }

  checkDjp('DC', 'active', standardParticipant.posDcActive, 0);
  checkDjp('DC', 'deferred', standardParticipant.posDcDeferred, 1);
  checkDjp('DB', 'active', standardParticipant.posDbActive, 0);
  checkDjp('DB', 'deferred', standardParticipant.posDbDeferred, 1);

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});


function checkDjpHidden(selectedCard) {
  it('AND hide [DATE JOINED PLAN] from SERVICE', () => {
    expect(selectedCard.dateJoinedSchemeValue(global.deviceType).isPresent()).toBe(false);
  });
}

function checkParticipantStatusIs2Or4(status) {
  if (status === 2 || status === 4) {
    // correct
  } else {
    fail(`Participant status is ${status} not the expected 2 or 4`);
  }
}

function runDOEEnabledScenario(planType, cardInstance, participantStatus, participant, pos) {
  describe(`${scenarioPrefix}DOE enabled (${planType}, status = ${participantStatus})`, () => {
    /*
     GIVEN that the Participant is on the Dashboard
     AND [PARTICIPANT TYPE] is [Member]
     AND [PARTICIPANT STATUS] is [2] or [4]
     AND Date of Exit is enabled for the Plan
     AND Date of Exit is recorded in MIDAS
     WHEN the member views either their DC or DB Dashboard Summary Card
     */

    const status = pos.data.posStatusValueAsNumber;
    const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planType, cardInstance);

    beforeAll(async () => {
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
    });

    it('THEN show [DATE OF EXIT DESCRIPTION]  from CMS', async () => {
      await checkParticipantStatusIs2Or4(status);
      await dashboardTests.checkCardIsDisplayed(selectedCard, `${planType} deferred`);
      await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
      await checkers.containingTextIgnoreCase(selectedCard.dateOfExitLabel(global.deviceType), 'EXIT');
      await checkers.containingTextIgnoreCase(selectedCard.dateOfExitLabel(global.deviceType), 'DATE');
    });

    it('AND show [DATE OF EXIT] from SERVICE', async () => {
      await checkers.exactUkDate(selectedCard.dateOfExitValue(global.deviceType), pos.data.dateOfExitValue);
    });

    afterAll(async () => {
      await commonTests.logOut(dashboardPage, loginPage);
    });
  });
}

runDOEEnabledScenario(
  'DC', 1, 4, standardParticipant,
  standardParticipant.posDcDeferred);
runDOEEnabledScenario(
  'DB', 1, 4, standardParticipant,
  standardParticipant.posDbDeferred);

function checkDateOfExitHidden(selectedCard) {
  it('AND hide [DATE OF EXIT] from SERVICE', async () => {
    await browser.wait(until.visibilityOf(selectedCard.card(global.deviceType)),
      commonConstants.briefBrowserWaitDelay, resultMessaging.passTestWithCustomMessage('No DC / DB card to check'));
    expect(selectedCard.dateOfExitValue(global.deviceType).isPresent()).toBe(false);
  });
}

describe(`${scenarioPrefix}Member, other statuses, DOE + Pensioner`, () => {
  /*
   Member, other statuses, DOE
   ----------------------------------------------------------------
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [MEMBER]
   AND [PARTICIPANT STATUS] is not [2] or [4]
   WHEN the member views either their DC or DB Dashboard Summary Card

   Pensioner
   ----------------------------------------------------------------
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [PENSIONER]
   WHEN the pensioner views their Pensions In Payment Dashboard Summary Card
   */

  beforeAll(async () => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Member, other statuses, DOE scenario
  function checkDjpHiddenForNonDeferredDcDbParticipants(planType, participantStatus, pos) {
    const status = pos.data.posStatusValueAsNumber;
    const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planType, 0);

    if (status === 2 || status === 4) {
      throw new Error(`Participant status is ${status} when we were expecting anything but 2 or 4`);
    }

    it(`THEN hide [DATE OF EXIT DESCRIPTION] from CMS (${planType}, status = ${participantStatus})`, async () => {
      await browser.wait(until.visibilityOf(selectedCard.card(global.deviceType)),
        commonConstants.briefBrowserWaitDelay,
        resultMessaging.passTestWithCustomMessage(`No ${planType} card to check`));
      await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
      expect(selectedCard.dateOfExitLabel(global.deviceType).isPresent()).toBe(false);
    });

    checkDateOfExitHidden(selectedCard);
  }

  // only test status 1
  // note: statuses 3, 7 and 8 do not need testing as these statuses never have OV3 access
  checkDjpHiddenForNonDeferredDcDbParticipants('DC', 1, standardParticipant.posDcActive);
  checkDjpHiddenForNonDeferredDcDbParticipants('DB', 1, standardParticipant.posDbActive);

  // Pensioner scenario
  function checkDjpHiddenForPensioners() {
    const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'Pensioner', 0);

    it('(Pensioner) THEN hide [DATE JOINED PLAN DESCRIPTION] from CMS', async () => {
      expect(selectedCard.card(global.deviceType).isDisplayed()).toBe(true);
      await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
      expect(selectedCard.dateJoinedSchemeLabel(global.deviceType).isPresent()).toBe(false);
    });

    it('(Pensioner) AND hide [DATE OF EXIT DESCRIPTION] from CMS] from CMS ', () => {
      expect(selectedCard.dateOfExitLabel(global.deviceType).isPresent()).toBe(false);
    });

    checkDjpHidden(selectedCard);
    checkDateOfExitHidden(selectedCard);
  }

  checkDjpHiddenForPensioners();

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
