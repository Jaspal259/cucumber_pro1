// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-235${commonConstants.bddScenarioPrefix}`;

function runCTABehaviourScenario(planDesignAndStatus, dbServiceInstance, pos) {
  describe(`${scenarioPrefix}CTA behaviour (${planDesignAndStatus})`, () => {
    /*
      GIVEN that the Participant is on the dashboard
      AND one or multiple DB Summary Cards are showing
      WHEN they select the [DB SUMMARY CARD CTA BUTTON]
     */

    const dbPlanSummaryPage = new DbPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${planDesignAndStatus}`);
      await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
    });

    it('THEN direct Member to corresponding [DB Plan Summary] page based on [POS] chosen ', async () => {
      /*
        Example:
        Member A has 2 DB records - an active and a deferred.  If they select [View Details] on the Active [POS]
        then they should be directed to the 'DB Plan Summary' page relating to their Active [POS]
       */

      await dbPlanSummaryTests.browseToDbPlanSummaryPageFromDashboard(
        dashboardPage, dbPlanSummaryPage, dbServiceInstance);

      /*
        note if page loads this is enough to check correct page has been found as
        url used includes primary key of POS (other data on this page will be checked
        for subsequent user stories)
       */
    });

    afterAll(async () => {
      await commonTests.logOut(dashboardPage, loginPage);
    });
  });
}

runCTABehaviourScenario('DB Active', 0, standardParticipant.posDbActive);
runCTABehaviourScenario('DB Deferred', 1, standardParticipant.posDbDeferred);
