// load common code
const CommonConstants = require('../../utilities/common-constants.js');
const CommonTests = require('../../utilities/common-tests.js');
const checkers = require('../../utilities/checkers.helper.js');
const regExConstants = require('../../utilities/regex-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();

// tests
const scenarioPrefix = `OUK-102${commonConstants.bddScenarioPrefix}`;

async function checkForMultipleSummaryCards(dashboardPage) {
  it('check one or multiple Dashboard Summary Cards are shown', async () => {
    // note did try creating isElementDisplayedOrNot() common function for visibilityOf() calls
    // but promises were not being evaluated and it the code was no simpler than here

    // cannot use isDisplayed() as this needs a promise so instead use protractor.ExpectedConditions
    const until = protractor.ExpectedConditions;
    let cardCount = 0;
    let currentCardShown;

    currentCardShown = await browser.wait(until.visibilityOf(dashboardPage.dcCard0.card(global.deviceType)),
      commonConstants.briefBrowserWaitDelay,
      'DC card instance 0 not shown');

    if (currentCardShown) {
      cardCount += 1;
    }

    currentCardShown = await browser.wait(until.visibilityOf(dashboardPage.dbCard0.card(global.deviceType)),
      commonConstants.briefBrowserWaitDelay,
      'DB card instance 0 not shown');

    if (currentCardShown) {
      cardCount += 1;
    }

    currentCardShown = await browser.wait(until.visibilityOf(dashboardPage.pensionerCard0.card(global.deviceType)),
      commonConstants.briefBrowserWaitDelay,
      'Pensioner card instance 0 not shown');

    if (currentCardShown) {
      cardCount += 1;
    }

    if (cardCount === 0) {
      throw new Error('No dashboard summary cards are shown');
    }
  });
}

describe(`${scenarioPrefix}Member Plan name available + Pensioner Plan name available`, () => {
  /*
     GIVEN that the Participant is on the Dashboard
     AND one or multiple Dashboard Summary Cards are shown
     AND Member Plan name available
     AND [PARTICIPANT TYPE] is [MEMBER]
     */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
    await checkForMultipleSummaryCards(dashboardPage);
  });

  function checkPlanName(planType, cardTypeDescription) {
    it(`THEN show [PLAN NAME] from SERVICE beneath Plan Description (${planType})`, async () => {
      const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planType, 0);
      await dashboardTests.checkCardIsDisplayed(selectedCard, cardTypeDescription);
      await checkers.anyText(selectedCard.longSchemeNameValue(global.deviceType));
    });
  }

  checkPlanName('DC', 'DC active');
  checkPlanName('DB', 'DB active');
  checkPlanName('Pensioner', 'Pensioner');

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

describe(`${scenarioPrefix}Special Characters`, () => {
  /*
   GIVEN that the Participant is on the Dashboard
   AND one or multiple Dashboard Summary Cards are shown
   AND [PLAN NAME] contains [SPECIAL CHARACTERS]
   WHEN the Participant views their Dashboard Summary Card
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const pos = participant.posDcActive;
  const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, pos.data.planType, 0);

  beforeAll(async () => {
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
    await checkForMultipleSummaryCards(dashboardPage);
  });

  it('THEN show [PLAN NAME]', async () => {
    await dashboardTests.checkCardIsDisplayed(selectedCard, 'DC active');
    await checkers.anyText(selectedCard.longSchemeNameValue(global.deviceType));
    const longSchemeNameValue = await selectedCard.longSchemeNameValue(global.deviceType).getText();
    expect(longSchemeNameValue).toMatch(regExConstants.regExForValidSpecialCharacters);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
