// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

const dashboardTests = new DashboardTests();

// tests
const scenarioPrefix = `OUK-103${commonConstants.bddScenarioPrefix}`;

/*
  NOTE most scenarios in this story cannot be automated as not happy path - have simplified this down to
  what is available using standard participant in OV1 client ... but have made execution speed 5x faster by
  amalgamating scenarios
 */

function checkDcOrDcCard(planDesign, status, memberStatus, pos) {
  let selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planDesign, 0);

  if (status === 4) {
    selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planDesign, 1);
  }

  it(`(Member show status) THEN show [STATUS DESCRIPTION] from CMS (${memberStatus})`, async () => {
    await dashboardTests.checkCardIsDisplayed(
      selectedCard, `${planDesign} ${memberStatus.toLowerCase()}`);
    await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
    await checkers.containingTextIgnoreCase(selectedCard.posStatusLabel(global.deviceType), pos.data.posStatusLabel);
  });

  // AND based on [STATUS] from Service, show [MEMBER STATUS] from CMS
  it(`(Member show status) AND based on [STATUS] = ${status}`
    + ` from Service show [MEMBER STATUS] = ${memberStatus} from CMS `, async () => {
    await checkers.containingTextIgnoreCase(selectedCard.posStatusValue(global.deviceType), pos.data.posStatusValue);
  });
}

describe(`${scenarioPrefix}Member show status + Pensioner`, () => {
  /*
     Member show status
     -----------------------------------------------------------
     GIVEN that the Participant is on the Dashboard
     AND [PARTICIPANT TYPE] is [MEMBER]
     AND show status is enabled
     WHEN the member views either their DC or DB summary card

     Pensioner
     -----------------------------------------------------------
     GIVEN that the Participant is on the Dashboard
     WHEN the pensioner views their Pensions In Payment summary card
   */

  const pensionerCard = dashboardTests.getSelectedDashboardSummaryCard(
    dashboardPage, standardParticipant.posPensioner.data.planType, 0);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Member show status
  checkDcOrDcCard('DC', 1, 'Active', standardParticipant.posDcActive);
  checkDcOrDcCard('DC', 4, 'Deferred', standardParticipant.posDcDeferred);
  checkDcOrDcCard('DB', 1, 'Active', standardParticipant.posDbActive);
  checkDcOrDcCard('DB', 4, 'Deferred', standardParticipant.posDbDeferred);

  // Pensioner
  it('(Pensioner) THEN hide [STATUS DESCRIPTION] from CMS', async () => {
    expect(pensionerCard.card(global.deviceType).isDisplayed()).toBe(true);
    await commonTests.clickExpandMoreButtonIfMobile(pensionerCard.mobileExpandMore(global.deviceType));
    expect(pensionerCard.posStatusLabel(global.deviceType).isPresent()).toBe(false);
  });

  it('(Pensioner) AND [STATUS] from Service and [MEMBER STATUS] from CMS', () => {
    // note [STATUS] is never displayed on card - BDD is wrong - so just check [MEMBER STATUS]
    expect(pensionerCard.posStatusValue(global.deviceType).isPresent()).toBe(false);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
