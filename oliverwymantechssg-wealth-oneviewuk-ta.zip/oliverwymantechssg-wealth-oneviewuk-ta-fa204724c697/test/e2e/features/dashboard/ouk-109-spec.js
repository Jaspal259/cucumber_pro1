// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const Participant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new Participant();
const dashboardTests = new DashboardTests(participant);
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);

// tests
const scenarioPrefix = `OUK-109${commonConstants.bddScenarioPrefix}`;

function checkArticleContent(selectedArticle) {
  it('(Card content) THEN show [ARTICLE HEADLINE] from CMS'
  + ` (article instance ${selectedArticle.articleInstance})`, async () => {
    expect(selectedArticle.article.isDisplayed()).toBe(true);
    await checkers.anyText(selectedArticle.headline);
  });

  it(`(Card content) AND [ARTICLE MEDIA] from CMS (article instance ${selectedArticle.articleInstance})`,
    async () => {
      await checkers.anyImage(selectedArticle.icon);
    });

  it('(Card content) AND [ARTICLE DESCRIPTION] from CMS'
  + ` (article instance ${selectedArticle.articleInstance})`, async () => {
    await checkers.anyTextOf20CharsPlus(selectedArticle.articleDesc);
  });

  it(`(Card content) AND [CALL TO ACTION] from CMS (article instance ${selectedArticle.articleInstance})`, async () => {
    await checkers.containingTextIgnoreCase(selectedArticle.callToAction, 'read more');
  });
}

describe(`${scenarioPrefix}Layout + Card content`, () => {
  /*
    Layout
    ----------------------------------------------------------
    GIVEN that the Participant is on the Dashboard
    WHEN they look beneath the Dashboard Summary Cards

    Card content
    ----------------------------------------------------------
    GIVEN that the Participant is on the Dashboard
    WHEN they are viewing a [DASHBOARD ARTICLE CARD]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
  });

  // Layout
  it('(Layout) THEN show [DASHBOARD ARTICLE CARD 1]', () => {
    expect(dashboardPage.article0.article.isDisplayed()).toBe(true);
  });

  it('(Layout) AND [DASHBOARD ARTICLE CARD 2]', () => {
    expect(dashboardPage.article1.article.isDisplayed()).toBe(true);
  });

  it('(Layout) AND [DASHBOARD ARTICLE CARD 3]', () => {
    expect(dashboardPage.article2.article.isDisplayed()).toBe(true);
  });

  // Card content
  checkArticleContent(dashboardPage.article0);
  checkArticleContent(dashboardPage.article1);
  checkArticleContent(dashboardPage.article2);

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
