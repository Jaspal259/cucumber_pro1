// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-217${commonConstants.bddScenarioPrefix}`;

async function checkAmountLabel(selectedCard, pos) {
  await checkers.containingTextIgnoreCase(selectedCard.amountLabelDc(global.deviceType), pos.data.amountLabelDb);
}

async function checkAmountDateLabel(selectedCard) {
  await checkers.anyText(selectedCard.amountDateLabel(global.deviceType));
}

async function checkDateWithinAmountDateLabel(selectedCard, pos) {
  await checkers.containingUkDate(selectedCard.amountDateLabel(global.deviceType), pos.data.amountDate);
}

async function checkAmountValue(selectedCard) {
  // note precise pension benefit figure cannot be checked as it will change depending on today's date etc
  await checkers.anyGbp(selectedCard.amountValue(global.deviceType));
}

describe(`${scenarioPrefix}Status Active + Status Deferred`, () => {
  /*
    Status Active
    -------------------------------------------------------
    GIVEN that the Participant is on the Dashboard
    AND [PARTICIPANT TYPE] is [MEMBER]
    AND [PLAN DESIGN] is [DB]
    AND [STATUS] =  1
    WHEN the Member views their DB Dashboard Summary Card(s)

    Status Deferred
    -------------------------------------------------------
    GIVEN that the Participant is on the Dashboard
    AND [PARTICIPANT TYPE] is [MEMBER]
    AND [PLAN DESIGN] is [DB]
    AND [STATUS] =  4
    WHEN the Member views their DB Dashboard Summary Card(s)
   */

  const dbActiveCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'DB', 0);
  const dbActivePos = standardParticipant.posDbActive;
  const dbDeferredCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'DB', 1);
  const dbDeferredPos = standardParticipant.posDbDeferred;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  // Status Active
  it('(Status Active) THEN show [PENSION BENEFIT DESCRIPTION] from CMS', async () => {
    await checkAmountLabel(dbActiveCard, dbActivePos);
  });

  it('(Status Active) AND [ACTIVE PENSION BENEFIT] from SERVICE (service to determine format)', async () => {
    await checkAmountValue(dbActiveCard);
  });

  it('(Status Active) AND [AS AT DESCRIPTION] from CMS', async () => {
    await checkAmountDateLabel(dbActiveCard);
  });

  it('(Status Active) AND nested within [AS AT DESCRIPTION] show'
    + ' [ACTIVE AS AT DATE] in the format dd/mm/yyyy', async () => {
    await checkDateWithinAmountDateLabel(dbActiveCard, dbActivePos);
  });

  // Status Deferred
  it('(Status Deferred) THEN show [PENSION BENEFIT DESCRIPTION] from CMS', async () => {
    await checkAmountLabel(dbDeferredCard, dbDeferredPos);
  });

  it('(Status Deferred) AND [DEFERRED PENSION BENEFIT] from SERVICE (service to determine format)', async () => {
    await checkAmountValue(dbDeferredCard);
  });

  it('(Status Deferred) AND [AS AT DESCRIPTION] from CMS', async () => {
    await checkAmountDateLabel(dbDeferredCard);
  });

  it('(Status Deferred) AND nested within [AS AT DESCRIPTION] show'
    + ' [DEFERRED AS AT DATE] in the format dd/mm/yyyy', async () => {
    await checkDateWithinAmountDateLabel(dbDeferredCard, dbDeferredPos);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
