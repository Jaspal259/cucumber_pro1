// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// load participant(s)
const StandardParticipant
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// create new objects
const commonTests = new CommonTests();
const dashboardTests = new DashboardTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const selectedCard = dashboardPage.pensionerCard0;

// tests
const scenarioPrefix = `OUK-222${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
}


describe(`${scenarioPrefix}Dashboard guidance + Pensioner client defined ID`, () => {
  /*
    Dashboard guidance
    ----------------------------------------------------------------
    GIVEN the Participant has navigated to the Dashboard
    AND Dashboard guidance text is available
    WHEN the Dashboard page loads

    Pensioner client defined ID
    ----------------------------------------------------------------
    GIVEN the Participant has navigated to the Dashboard
    AND Participant type is Pensioner
    AND one or multiple Pensioner cards are visible
    AND Client Def ID is enabled
    AND Client Def ID is recorded in MIDASPAY
    WHEN the Dashboard page loads
  */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  // Dashboard guidance
  it('THEN show Dashboard guidance message i.e. "Welcome to your pensions dashboard"', async () => {
    await checkers.containingTextIgnoreCase(dashboardPage.welcomeMessageLabel(global.deviceType), 'Dashboard');
  });

  it('THEN show Client Def ID', async () => {
    await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
    await checkers.containingTextIgnoreCase(selectedCard.memberReferenceValue(global.deviceType), 'TEST558635');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
