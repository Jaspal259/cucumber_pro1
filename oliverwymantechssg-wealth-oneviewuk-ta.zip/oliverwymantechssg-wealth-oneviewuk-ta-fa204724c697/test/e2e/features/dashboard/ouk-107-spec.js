// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
    = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// additional
const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'Pensioner', 0);

// tests
const scenarioPrefix = `OUK-107${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
}

function checkCardDisplayed(card) {
  expect(card.card(global.deviceType).isDisplayed()).toBe(true);
}

describe(`${scenarioPrefix}Pension Number enabled`, () => {
  /*
    GIVEN that the Participant is on the dashboard
    AND [PARTICIPANT TYPE] is [PENSIONER]
    AND Pension Number is enabled
    WHEN the Pensioner views their Pensions In Payment Dashboard Summary Card
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show [PENSION NUMBER DESCRIPTION] from CMS', async () => {
    checkCardDisplayed(selectedCard);
    await commonTests.clickExpandMoreButtonIfMobile(selectedCard.mobileExpandMore(global.deviceType));
    await checkers.containingTextIgnoreCase(selectedCard.clientDefinedIDLabel(global.deviceType),
      'PENSION NUMBER');
  });

  it('AND [PENSION NUMBER] SERVICE', async () => {
    await checkers.exactText(selectedCard.clientDefinedIDValue(global.deviceType),
      standardParticipant.posPensioner.data.pensionNumberValue);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
