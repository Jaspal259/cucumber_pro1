// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();

// tests
const scenarioPrefix = `OUK-214${commonConstants.bddScenarioPrefix}`;

function checkPeriodDescription(participant, pos, selectedCard) {
  it('AND [PERIOD DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(selectedCard.grossPensionDateLabel(global.deviceType), 'A year');
  });
}

describe(`${scenarioPrefix}Display Gross Pension enabled`, () => {
  /*
    GIVEN that the Participant is on the Dashboard
    AND [PARTICIPANT TYPE] is 'PENSIONER'
    WHEN the Pensioner views their PIP Dashboard Summary Card
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'Pensioner', 0);
  const pos = participant.posPensioner;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
  });

  it('THEN show [GROSS PENSION DESCRIPTION] from CMS', async () => {
    expect(selectedCard.card(global.deviceType).isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(selectedCard.grossPensionLabel(global.deviceType), pos.data.amountLabelDc);
  });

  it('AND [GROSS PENSION] from SERVICE', async () => {
    await checkers.exactGbp(selectedCard.grossPensionValue(global.deviceType), pos.data.amountValue);
  });

  checkPeriodDescription(participant, pos, selectedCard);

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
