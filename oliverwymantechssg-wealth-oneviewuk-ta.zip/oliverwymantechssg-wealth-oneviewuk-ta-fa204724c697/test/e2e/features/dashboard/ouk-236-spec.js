// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-236${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}CTA behaviour`, () => {
  /*
    GIVEN that the Participant is on the Dashboard
    AND one or multiple  PIP Summary Cards are showing
    WHEN they select the [PIP SUMMARY CARD CTA BUTTON]
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  it('THEN direct Member to corresponding [PIP Plan Summary] page based on [POS] chosen', async () => {
    await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromDashboard(
      dashboardPage, pensionerPlanSummaryPage, 0);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
