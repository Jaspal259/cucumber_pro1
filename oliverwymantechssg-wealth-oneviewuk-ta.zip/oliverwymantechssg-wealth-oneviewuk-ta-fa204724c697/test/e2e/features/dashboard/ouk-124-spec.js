// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant
  = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests(standardParticipant);
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-124${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
}

describe(`${scenarioPrefix}Pension Start Date enabled`, () => {
  /*
   GIVEN that the Participant is on the Dashboard
   AND [PARTICIPANT TYPE] is [PENSIONER]
   AND [PENSION START DATE] is enabled
   WHEN the Pensioner views their PIP Dashboard Summary Card
   */

  const pos = standardParticipant.posPensioner;
  const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, pos.data.planType, 0);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show [PENSION START DATE DESCRIPTION] from CMS', async () => {
    await dashboardTests.expandCardForMobileOnly(dashboardPage.pensionerCard0, global.deviceType, 'Pensioner');
    expect(selectedCard.card(global.deviceType).isDisplayed()).toBe(true);
    await checkers.exactText(selectedCard.pensionStartDateLabel(global.deviceType),
      pos.data.pensionStartDateLabel);
  });

  it('AND [PENSION START DATE] SERVICE', async () => {
    await checkers.exactUkDate(selectedCard.pensionStartDateValue(global.deviceType),
      pos.data.pensionStartDateValue);
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

function andHidePensionStartDate(selectedCard) {
  it('AND [PENSION START DATE] SERVICE', () => {
    expect(selectedCard.pensionStartDateValue(global.deviceType).isPresent()).toBe(false);
  });
}

// 'Pension Start Date' scenario not TE coded as requires CC item changes

function runMembersScenario(planType, cardInstance) {
  describe(`${scenarioPrefix}Members (${planType})`, () => {
    /*
     GIVEN that the Participant is on the Dashboard
     AND [PARTICIPANT TYPE] is [MEMBER]
     WHEN the member views either their DC or DB Dashboard Summary Card
     */

    const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, planType, cardInstance);

    beforeAll(async () => {
      await login(standardParticipant);
    });

    it('THEN hide [PENSION START DATE DESCRIPTION] from CMS', async () => {
      await dashboardTests.checkCardIsDisplayed(selectedCard, `${planType} active`);
      expect(selectedCard.pensionStartDateLabel(global.deviceType).isPresent()).toBe(false);
    });

    andHidePensionStartDate(selectedCard);

    afterAll(async () => {
      await commonTests.logOut(dashboardPage, loginPage);
    });
  });
}

runMembersScenario('DC', 0);
runMembersScenario('DB', 0);
