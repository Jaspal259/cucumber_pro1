// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-234${commonConstants.bddScenarioPrefix}`;

async function login() {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
}

describe(`${scenarioPrefix}CTA content`, () => {
  /*
    GIVEN that the Participant is on the Dashboard
    AND one or multiple DC Summary Cards are showing
    WHEN the Participant views a DC Summary Card
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it('THEN show [DC SUMMARY CARD CTA BUTTON]', () => {
    expect(dashboardPage.dcCard0.card(global.deviceType).isDisplayed()).toBe(true);
    expect(dashboardPage.dcCard1.card(global.deviceType).isDisplayed()).toBe(true);
    expect(dashboardPage.dcCard0.detailsButton(global.deviceType).isDisplayed()).toBe(true);
    expect(dashboardPage.dcCard1.detailsButton(global.deviceType).isDisplayed()).toBe(true);
  });

  it('AND [DC SUMMARY CARD CTA DESC] i.e. View Details', async () => {
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard0.detailsButton(global.deviceType),
      'View Details');
    await checkers.containingTextIgnoreCase(dashboardPage.dcCard1.detailsButton(global.deviceType),
      'View Details');
  });

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});

function runCTABehaviourScenario(planTypeAndStatus, dcServiceInstance, pos) { // pos unused
  describe(`${scenarioPrefix}CTA behaviour (${planTypeAndStatus})`, () => {
    /*
      GIVEN that the Participant is on the Dashboard
      AND one or multiple DC Summary Cards are showing
      WHEN they select [DC SUMMARY CARD CTA BUTTON]
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await login();
    });

    it('THEN direct Member to corresponding [DC Plan Summary] page based on [POS] chosen', async () => {
      /*
        Example:
        Member A has 2 DC records - an active and a deferred.  If they select [View Details] on the Active [POS]
        then they should be directed to the 'DC Plan Summary' page relating to their Active [POS]
       */

      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromDashboard(
        dashboardPage, dcPlanSummaryPage, dcServiceInstance);

      /*
        note if page loads this is enough to check correct page has been found as
        url used includes primary key of POS (other data on this page will be checked
        for subsequent user stories)
       */
    });

    afterAll(async () => {
      await commonTests.logOut(dashboardPage, loginPage);
    });
  });
}

runCTABehaviourScenario('DC Active', 0, standardParticipant.posDcActive);
runCTABehaviourScenario('DC Deferred', 1, standardParticipant.posDcDeferred);
