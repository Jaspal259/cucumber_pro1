// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-216${commonConstants.bddScenarioPrefix}`;

function checkDcDashboardSummaryCard(pos, posDescription, cardInstance) {
  const selectedCard = dashboardTests.getSelectedDashboardSummaryCard(dashboardPage, 'DC', cardInstance);

  // Display Total Current Fund Value
  it(`(Display Total ...) THEN show [FUND VALUE DESC] from CMS (DC ${posDescription})`, async () => {
    expect(selectedCard.card(global.deviceType).isDisplayed()).toBe(true);
    await checkers.containingTextIgnoreCase(selectedCard.amountLabelDc(global.deviceType), pos.data.amountLabelDc);
  });

  it(`(Display Total ...) AND [TOTAL FUND VALUE] to 2dp from SERVICE (DC ${posDescription})`, async () => {
    // cannot check value itself as value changes constantly
    await checkers.anyGbp(selectedCard.amountValue(global.deviceType));
  });

  it(`(Display Total ...) AND [PERIOD DESCRIPTION] from CMS (DC ${posDescription})`, async () => {
    await checkers.anyText(selectedCard.grossPensionDateLabel(global.deviceType));
  });

  it(`(Display Total ...) AND nested within [PERIOD DESC] show [CURRENT DATE] (DC ${posDescription})`,
    async () => {
      await checkers.containingCurrentUkDate(selectedCard.amountDateLabel(global.deviceType));
    });

  it(`(Display Total ...) AND [DC FV INFO ICON] from CMS (DC ${posDescription})`, () => {
    if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      expect(selectedCard.amountDateInfoIcon(global.deviceType).isDisplayed()).toBe(true);
    } else {
      // date does not have icon in mobile so do not test
      resultMessaging.passTestAsNotApplicable();
    }
  });

  // Info icon + Hide info
  it('(Info icon + Hide info) THEN show [DV FV INFO TEXT] + THEN hide [DV FV INFO TEXT]'
      + ` (WHEN they select the option to hide it) (DC ${posDescription})`, async () => {
    if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      await tooltipTests.checkTooltipIsElementWithAnyText(
        selectedCard.amountDateInfoIcon(global.deviceType),
        selectedCard.typeLabel(global.deviceType),
        dashboardPage.tooltips.simpleSoleTooltip);
    } else {
      // date does not have icon in mobile so do not test
      resultMessaging.passTestAsNotApplicable();
    }
  });
}

describe(`${scenarioPrefix}Display Total Current Fund Value + Info icon + Hide info`, () => {
  /*
    Display Total Current Fund Value
    --------------------------------------------------------------
    GIVEN that the Participant is on the Dashboard
    AND [PARTICIPANT TYPE] is 'MEMBER'
    AND [PLAN DESIGN] is 'DC'
    WHEN the Member views their DC Dashboard Summary Card(s)

    Scenario - Info icon
    --------------------------------------------------------------
    GIVEN that member is viewing a DC Dashboard Summary Card
    WHEN they select the [DC FV INFO ICON]

    Scenario - hide info
    --------------------------------------------------------------
    GIVEN that the member is viewing [DV FC INFO TEXT]
    WHEN they select the option to hide it
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
  });

  checkDcDashboardSummaryCard(standardParticipant.posDcActive, 'active', 0);
  checkDcDashboardSummaryCard(standardParticipant.posDcDeferred, 'deferred', 1);

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
