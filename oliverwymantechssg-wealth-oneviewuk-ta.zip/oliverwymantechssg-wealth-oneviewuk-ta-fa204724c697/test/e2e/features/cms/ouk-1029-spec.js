// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');
const ParticipantOuk1029P001 = require('../../data/participants/participant-ouk-1029-001-incorrect-credentials.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');

// load tests
const DashboardTests = require('../_common/dashboard.spec.js');
const LoginTests = require('../_common/authentication-login.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const loginTests = new LoginTests();
const standardParticipant = new StandardParticipant();
const participantOuk1029P001 = new ParticipantOuk1029P001();
// note even though 2 participants we can use standardParticipant to define pages as both are in same client
const dashboardPage = new DashboardPage(standardParticipant);
const dashboardTests = new DashboardTests(standardParticipant);

// other
const until = protractor.ExpectedConditions;
const schemePageRootUrl = `${browser.params.ov3RootUrl}${standardParticipant.client.data.clientCode}/`;

// get hashed scheme codes and POS primary key
const dcActiveSchemeAndParticipantCodes
  = `${standardParticipant.posDcActive.scheme.data.midasSchemeCode}`
  + `/${standardParticipant.posDcActive.data.periodOfServicePrimaryKey}`;
const dcDeferredSchemeAndParticipantCodes
  = `${standardParticipant.posDcDeferred.scheme.data.midasSchemeCode}`
  + `/${standardParticipant.posDcDeferred.data.periodOfServicePrimaryKey}`;
const dbActiveSchemeAndParticipantCodes
  = `${standardParticipant.posDbActive.scheme.data.midasSchemeCode}`
  + `/${standardParticipant.posDbActive.data.periodOfServicePrimaryKey}`;
const dbDeferredSchemeAndParticipantCodes
  = `${standardParticipant.posDbDeferred.scheme.data.midasSchemeCode}`
  + `/${standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey}`;
const pensionerSchemeAndParticipantCodes
  = `${standardParticipant.posPensioner.scheme.data.midasSchemeCode}`
  + `/${standardParticipant.posPensioner.data.periodOfServicePrimaryKey}`;

// define article IDs
let loginArticleIdEnum;
let dcActivePlanSummaryArticleIdEnum;

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
    loginArticleIdEnum = {
      left: 2840,
    };

    dcActivePlanSummaryArticleIdEnum = {
      left: 2852,
    };

    break;

  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    loginArticleIdEnum = {
      left: 60,
    };

    dcActivePlanSummaryArticleIdEnum = {
      left: 15,
    };
    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

// run all batches of page URLs?
let testAllBatchesOfPageUrls;

// TODO: are all environments working now? before UAT and PROD had to have: testAllBatchesOfPageUrls = true;
switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    testAllBatchesOfPageUrls = true;
    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

let testDownloadUrls;

switch (ov3Environment) {
  // note switch had been needed whilst bug 9195 was active
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    testDownloadUrls = true;
    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}


const educationCentreUrlRoot = `${schemePageRootUrl}education-centre/`;
const dashboardArticleLeftUrl = `${educationCentreUrlRoot}${loginArticleIdEnum.left}`;
const dcActivePlanSummaryArticleLeftUrl = `${educationCentreUrlRoot}${dcActivePlanSummaryArticleIdEnum.left}`;

// urls to test - should represent most of site

/*
   NOTE page URLs to test have been broken into smaller batches since investigations for bug OUK-9146
   revealed:
   - OUK-1029 is failing on Jenkins QA and UAT on 24th instance of requesting page URL directly after a login
   - All tests after this point fail - so points to another weakness in OV3 ...
   - ... but a weakness real users are unlikely to expose (a user unlikely to browse to OV3 URL directly in 1 session)
   - Coding in workaround to break stories into batches so less than 24 requests made during each TE login session

   Note new bug OUK-9169 raised for clarity
 */

const pageUrlsBatch01 = [
  /*
    pages purposefully omitted as are available without authorisation
    help-and-contacts/help
    help-and-contacts/contact-us/online
    help-and-contacts/contact-us/phone
    help-and-contacts/contact-us/post
    terms-of-use
    cookie-policy
    accessibility-policy
   */

  // header
  // --------------------------------------
  `${schemePageRootUrl}profile`,
  `${schemePageRootUrl}profile/passcode`,
  `${schemePageRootUrl}profile/security-email`,

  // footer
  // --------------------------------------
  // none

  // home
  // --------------------------------------
  `${schemePageRootUrl}dashboard`,

  // these are set up with constants as they need special treatment
  dashboardArticleLeftUrl,
];

const pageUrlsBatch02 = [
  // DC active
  // --------------------------------------
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/summary`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/investment/current`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/investment/select-strategy`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/contributions/total`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/transaction_history`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/plan_materials`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/contact_details`,
];

const pageUrlsBatch03 = [
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/beneficiaries/lump_sum`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/allowances/annual`,

  // these are set up with constants as they need special treatment
  dcActivePlanSummaryArticleLeftUrl,

  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/transfer_value`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/retirement_planner`,
  `${schemePageRootUrl}dc-plan-summary/${dcActiveSchemeAndParticipantCodes}/set-budget`,
];

const pageUrlsBatch04 = [

  // DC deferred
  // --------------------------------------
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/summary`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/investment/current`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/contributions/total`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/transaction_history`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/plan_materials`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/contact_details`,
];

const pageUrlsBatch05 = [
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/beneficiaries/lump_sum`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/allowances/annual`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/transfer_value`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/budgeting`,
  `${schemePageRootUrl}dc-plan-summary/${dcDeferredSchemeAndParticipantCodes}/set-budget`,
];

const pageUrlsBatch06 = [
  // DB active
  // --------------------------------------
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/summary`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/annual_benefit_statement`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/plan_materials`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/contact_details`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/beneficiaries/lump_sum`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/allowances/annual`,
];

const pageUrlsBatch07 = [
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/allowances/annual`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/transfer_value`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/db_modeller`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/earnings_history`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/budgeting`,
  `${schemePageRootUrl}db-plan-summary/${dbActiveSchemeAndParticipantCodes}/set-budget`,
];

const pageUrlsBatch08 = [
  // DB deferred
  // --------------------------------------
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/summary`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/deferred_statement`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/annual_benefit_statement`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/plan_materials`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/contact_details`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/beneficiaries/lump_sum`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/allowances/annual`,
];

const pageUrlsBatch09 = [
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/allowances/lifetime`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/transfer_value`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/db_modeller`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/earnings_history`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/budgeting`,
  `${schemePageRootUrl}db-plan-summary/${dbDeferredSchemeAndParticipantCodes}/set-budget`,
];

const pageUrlsBatch10 = [
  // PIP summary
  // --------------------------------------
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/summary`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/pension-breakdown/current`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/plan_materials`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/historical_pension`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/contact_details`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/beneficiaries/dependants`,
];

const pageUrlsBatch11 = [
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/bank_account_details`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/allowances/annual`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/allowances/lifetime`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/budgeting`,
  `${schemePageRootUrl}pip-plan-summary/${pensionerSchemeAndParticipantCodes}/set-budget`,
];

const numberOfPageUrlsBatches = 11;

const planInformationDownloadFilePath = 'files/plans-materials/OV1_PlanMaterial_planinformation.pdf';
let planInformationDownloadUrl;

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
    planInformationDownloadUrl
      = `${browser.params.ov3RootDownloadUrl}resources/${planInformationDownloadFilePath}`;
    break;
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    planInformationDownloadUrl
      = `${browser.params.ov3RootDownloadUrl}oneview-caas/${planInformationDownloadFilePath}`;
    break;

  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this spec`);
}

// note only 1 download link check - did try to get rest working but nothing static enough / easy enough to automate
// so just a single link here will have to do
const downloadUrls = [
  planInformationDownloadUrl,
];

// additional
let p;
let d;

// tests
const scenarioPrefix = `OUK-1029${commonConstants.bddScenarioPrefix}`;

async function loginStandardParticipant(loginPage) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, standardParticipant);
}

async function checkUrlIsLoaded(url, ov3UrlType) {
  switch (ov3UrlType) {
    case commonConstants.appUrlTypeEnum.page:
      // ensure Angular waiting is switched back on
      try {
        await browser.waitForAngularEnabled(true);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      try {
        await browser.get(url);
      } catch (e) {
        resultMessaging.publishFailWithException(
          `Browse to URL ${url} failed`, e);
      }

      try {
        await browser.wait(until.urlContains(url), commonConstants.mediumBrowserWaitDelay,
          `The URL ${url} was not loaded within ${commonConstants.mediumBrowserWaitDelay} ms`);
      } catch (e) {
        resultMessaging.publishFailWithException(
          `Check that URL ${url} loaded failed`, e);
      }

      break;

    case commonConstants.appUrlTypeEnum.download:
      // assume media page is not Angular
      try {
        await browser.waitForAngularEnabled(false);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      try {
        await browser.get(url);
      } catch (e) {
        resultMessaging.publishFailWithException(
          `Browse to URL ${url} failed`, e);
      }

      try {
        // can't check for download itself so instead ...
        const pageAsElement = element(by.tagName('html'));

        // ... check something loads ...
        await browser.wait(until.presenceOf(pageAsElement),
          commonConstants.shortBrowserWaitDelay,
          `The URL ${url} was not loaded within ${commonConstants.shortBrowserWaitDelay} ms`);

        // ... then check unauthorised message is NOT shown
        await browser.wait(
          until.not(until.textToBePresentInElement(pageAsElement, commonConstants.unauthorisedAccessMessageStatus)),
          commonConstants.momentaryBrowserWaitDelay,
          `Unauthorised access message status ${commonConstants.unauthorisedAccessMessageStatus} shown`);
        await browser.wait(
          until.not(until.textToBePresentInElement(pageAsElement, commonConstants.unauthorisedAccessMessageText)),
          commonConstants.momentaryBrowserWaitDelay,
          `Unauthorised access message text ${commonConstants.unauthorisedAccessMessageText} shown`);
      } catch (error) {
        fail(error);
      } finally {
        // ensure Angular waiting is switched back on
        try {
          await browser.waitForAngularEnabled(true);
        } catch (e) {
          resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
        }
      }

      break;

    default:
      fail(`The ov3UrlType [${ov3UrlType}] is not supported`);
  }

  // if fail reported true return will be irrelevant
  return true;
}

async function checkUrlIsNotLoaded(url, ov3UrlType, loginPage) {
  switch (ov3UrlType) {
    case commonConstants.appUrlTypeEnum.page:
      // ensure Angular waiting is switched back on
      try {
        await browser.waitForAngularEnabled(true);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      await browser.get(url);

      try {
        await commonTests.checkUnauthPageLoadsAndContainsStandardElements(loginPage, true);
        const failDelay = commonConstants.shortBrowserWaitDelay;
        const failMessageSuffix = ` control is not shown when URL requested with login (URL: ${url})`;

        // look for elements specific to the login page to ensure we are on the login page
        await browser.wait(until.visibilityOf(loginPage.userIdLabel),
          failDelay,
          `The loginPage.userIdLabel${failMessageSuffix}`);

        await browser.wait(until.visibilityOf(loginPage.passcodeLabel),
          failDelay,
          `The loginPage.passcodeLabel${failMessageSuffix}`);

        await browser.wait(until.visibilityOf(loginPage.loginBtn),
          failDelay,
          `The loginPage.loginBtn${failMessageSuffix}`);

        // check some elements specific to the login page to ensure we are on the login page
        await checkers.anyText(loginPage.userIdLabel);
        await checkers.anyText(loginPage.passcodeLabel);
        await checkers.anyText(loginPage.loginBtn);
      } catch (error) {
        fail(error);
      }

      break;

    case commonConstants.appUrlTypeEnum.download:
      // assume media page is not Angular
      try {
        await browser.waitForAngularEnabled(false);
      } catch (e) {
        resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
      }

      await browser.get(url);

      try {
        await browser.wait(until.urlContains(url), commonConstants.briefBrowserWaitDelay,
          `URL does not contain ${url}`);

        // check page returns unauthorised message
        const pageAsElement = element(by.tagName('html'));
        await browser.wait(
          until.textToBePresentInElement(pageAsElement, commonConstants.unauthorisedAccessMessageStatus),
          commonConstants.momentaryBrowserWaitDelay,
          `No unauthorised access message status ${commonConstants.unauthorisedAccessMessageStatus} shown`);
        await browser.wait(
          until.textToBePresentInElement(pageAsElement, commonConstants.unauthorisedAccessMessageText),
          commonConstants.momentaryBrowserWaitDelay,
          `No unauthorised access message text ${commonConstants.unauthorisedAccessMessageText} shown`);
      } catch (error) {
        fail(error);
      }

      break;

    default:
      fail(`The ov3UrlType [${ov3UrlType}] is not supported`);
  }

  // if fail reported true return will be irrelevant
  return true;
}

async function checkAfterUrlRequested(url, isUrlAllowed, ov3UrlType, loginPage) {
  if (isUrlAllowed) {
    await checkUrlIsLoaded(url, ov3UrlType);
  } else {
    await checkUrlIsNotLoaded(url, ov3UrlType, loginPage);
  }

  // if fail reported true return will be irrelevant
  return true;
}

async function checkAfterDownloadUrlRequested(url, isUrlAllowed, loginPage) {
  // check download URL
  const hasLoaded
    = await checkAfterUrlRequested(url, isUrlAllowed, commonConstants.appUrlTypeEnum.download, loginPage);

  if (hasLoaded === true) {
    // URL loaded
  } else {
    fail(`The URL ${url} has not loaded`);
  }
}

async function checkAfterPageOrDownloadUrlRequested(url, isUrlAllowed, ov3UrlType, loginPage) {
  let isPageUrlAllowed = isUrlAllowed;

  if (isUrlAllowed === false && url.indexOf(educationCentreUrlRoot) !== -1) {
    // bug 7776 revealed that education centre pages can always load regardless of auth
    isPageUrlAllowed = true;
  }

  switch (ov3UrlType) {
    case commonConstants.appUrlTypeEnum.page:
      await checkAfterUrlRequested(url, isPageUrlAllowed, ov3UrlType, loginPage);
      break;

    case commonConstants.appUrlTypeEnum.download:
      await checkAfterDownloadUrlRequested(url, isUrlAllowed, loginPage);
      break;

    default:
      throw new Error(`The ov3UrlType [${ov3UrlType}] is not supported`);
  }
}

async function browseToDashboardPageAndLogOut(loginPage) {
  await browser.get(dashboardPage.url);
  await browser.wait(until.urlContains(dashboardPage.url), commonConstants.mediumBrowserWaitDelay,
    `Current page is not dashboard ${dashboardPage.url}`);
  await commonTests.logOut(dashboardPage, loginPage);
}

function runAuthenticatedUserScenario(batchNumber, pageUrlsBatch) {
  if (testAllBatchesOfPageUrls === true || (testAllBatchesOfPageUrls === false && batchNumber === 1)) {
    describe(`${scenarioPrefix}Authenticated user (batch ${batchNumber} of ${numberOfPageUrlsBatches})`, () => {
      /*
        GIVEN that required URL has been entered by user
        WHEN correct login details are entered
       */
      const loginPage = new LoginPage(standardParticipant);

      beforeAll(async () => {
        await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}Authenticated user - ${batchNumber}`);
        await loginStandardParticipant(loginPage);
      });

      function checkUrlHasLoaded(url, ov3UrlType) {
        it(`THEN access to URL [${url}] will be permitted online`, async () => {
          await checkAfterPageOrDownloadUrlRequested(url, true, ov3UrlType, loginPage);
        });
      }

      for (p = 0; p < pageUrlsBatch.length; p += 1) {
        checkUrlHasLoaded(pageUrlsBatch[p], commonConstants.appUrlTypeEnum.page);
      }

      // the number of download URLs is so small that we do not need to break into batches
      if (batchNumber === 1 && testDownloadUrls) {
        for (d = 0; d < downloadUrls.length; d += 1) {
          checkUrlHasLoaded(downloadUrls[d], commonConstants.appUrlTypeEnum.download);
        }
      }

      afterAll(async () => {
        await browseToDashboardPageAndLogOut(loginPage);
      });
    });
  }
}

runAuthenticatedUserScenario(1, pageUrlsBatch01);
runAuthenticatedUserScenario(2, pageUrlsBatch02);
runAuthenticatedUserScenario(3, pageUrlsBatch03);
runAuthenticatedUserScenario(4, pageUrlsBatch04);
runAuthenticatedUserScenario(5, pageUrlsBatch05);
runAuthenticatedUserScenario(6, pageUrlsBatch06);
runAuthenticatedUserScenario(7, pageUrlsBatch07);
runAuthenticatedUserScenario(8, pageUrlsBatch08);
runAuthenticatedUserScenario(9, pageUrlsBatch09);
runAuthenticatedUserScenario(10, pageUrlsBatch10);
runAuthenticatedUserScenario(11, pageUrlsBatch11);

function runIncorrectLoginScenario(batchNumber, pageUrlsBatch) {
  if (testAllBatchesOfPageUrls === true || (testAllBatchesOfPageUrls === false && batchNumber === 1)) {
    describe(`${scenarioPrefix}Incorrect login (batch ${batchNumber} of ${numberOfPageUrlsBatches})`, () => {
      /*
        GIVEN that required URL has been entered by user
        WHEN incorrect login details are entered
       */
      const loginPage = new LoginPage(participantOuk1029P001);

      beforeAll(async () => {
        await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}Incorrect login - ${batchNumber}`);
      });

      it('(pt1) THEN access to URL will be denied online', async () => {
        // note login attempt not wrapped in beforeAll() as we need to check login fails first
        await loginTests.attemptLogin(loginPage, participantOuk1029P001);
        await commonTests.checkLoginFailedMessageDisplayed(loginPage);
      });

      function checkUrlAfterIncorrectLogin(url, ov3UrlType) {
        it(`(pt2) THEN access to URL [${url}] will be denied online`, async () => {
          // now check urls
          await checkAfterPageOrDownloadUrlRequested(url, false, ov3UrlType, loginPage);
        });
      }

      for (p = 0; p < pageUrlsBatch.length; p += 1) {
        checkUrlAfterIncorrectLogin(pageUrlsBatch[p], commonConstants.appUrlTypeEnum.page);
      }

      // the number of download URLs is so small that we do not need to break into batches
      if (batchNumber === 1 && testDownloadUrls) {
        for (d = 0; d < downloadUrls.length; d += 1) {
          checkUrlAfterIncorrectLogin(downloadUrls[d], commonConstants.appUrlTypeEnum.download);
        }
      }

      afterAll(async () => {
        await commonTests.clearBrowserCacheAndCookies();
      });
    });
  }
}

runIncorrectLoginScenario(1, pageUrlsBatch01);
runIncorrectLoginScenario(2, pageUrlsBatch02);
runIncorrectLoginScenario(3, pageUrlsBatch03);
runIncorrectLoginScenario(4, pageUrlsBatch04);
runIncorrectLoginScenario(5, pageUrlsBatch05);
runIncorrectLoginScenario(6, pageUrlsBatch06);
runIncorrectLoginScenario(7, pageUrlsBatch07);
runIncorrectLoginScenario(8, pageUrlsBatch08);
runIncorrectLoginScenario(9, pageUrlsBatch09);
runIncorrectLoginScenario(10, pageUrlsBatch10);
runIncorrectLoginScenario(11, pageUrlsBatch11);

function runLoggedOutScenario(batchNumber, pageUrlsBatch) {
  if (testAllBatchesOfPageUrls === true || (testAllBatchesOfPageUrls === false && batchNumber === 1)) {
    describe(`${scenarioPrefix}Logged out (batch ${batchNumber} of ${numberOfPageUrlsBatches})`, () => {
      /*
        GIVEN that required URL has been entered by user
        WHEN a user has logged out of the site
       */
      const loginPage = new LoginPage(standardParticipant);

      beforeAll(async () => {
        await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}Logged out - ${batchNumber}`);

        // assume participant already logged out (all auth tests include logout in afterAll()
        await loginTests.checkLoginPageLoads(loginPage);
      });

      // check pages and downloads when logged out, then when logged in
      function checkUrlsWhenLoggedOut(url, ov3UrlType) {
        it(`(pt1) THEN correct login details will need to be entered again to regain access to URL [${url}]`,
          async () => {
            await checkAfterPageOrDownloadUrlRequested(url, false, ov3UrlType, loginPage);
          });
      }

      /*
         NOTE for this scenario we have to break the page URLs even further down for avoid the issue raised in
         bug OUK-9169 - here we just test the first 3 page URLs out of each batch
       */
      checkUrlsWhenLoggedOut(pageUrlsBatch[0], commonConstants.appUrlTypeEnum.page);
      checkUrlsWhenLoggedOut(pageUrlsBatch[1], commonConstants.appUrlTypeEnum.page);
      checkUrlsWhenLoggedOut(pageUrlsBatch[2], commonConstants.appUrlTypeEnum.page);

      // the number of download URLs is so small that we do not need to break into batches
      if (batchNumber === 1 && testDownloadUrls) {
        for (d = 0; d < downloadUrls.length; d += 1) {
          checkUrlsWhenLoggedOut(downloadUrls[d], commonConstants.appUrlTypeEnum.download);
        }
      }

      it('(pt2) THEN correct login details will need to be entered again to regain access to URL', async () => {
        // ensure Angular waiting is switched back on
        try {
          await browser.waitForAngularEnabled(true);
        } catch (e) {
          resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
        }

        await loginStandardParticipant(loginPage);
      });

      function checkUrlsWhenLoggedBackIn(url, ov3UrlType) {
        it(`(pt3) THEN correct login details will need to be entered again to regain access to URL [${url}]`,
          async () => {
            await checkAfterPageOrDownloadUrlRequested(url, true, ov3UrlType, loginPage);
          });
      }

      // again we just test the first 3 page URLs out of each batch because of bug OUK-9169
      checkUrlsWhenLoggedBackIn(pageUrlsBatch[0], commonConstants.appUrlTypeEnum.page);
      checkUrlsWhenLoggedBackIn(pageUrlsBatch[1], commonConstants.appUrlTypeEnum.page);
      checkUrlsWhenLoggedBackIn(pageUrlsBatch[2], commonConstants.appUrlTypeEnum.page);

      // the number of download URLs is so small that we do not need to break into batches
      if (batchNumber === 1 && testDownloadUrls) {
        for (d = 0; d < downloadUrls.length; d += 1) {
          checkUrlsWhenLoggedBackIn(downloadUrls[d], commonConstants.appUrlTypeEnum.download);
        }
      }

      afterAll(async () => {
        await browseToDashboardPageAndLogOut(loginPage);
      });
    });
  }
}

runLoggedOutScenario(1, pageUrlsBatch01);
runLoggedOutScenario(2, pageUrlsBatch02);
runLoggedOutScenario(3, pageUrlsBatch03);
runLoggedOutScenario(4, pageUrlsBatch04);
runLoggedOutScenario(5, pageUrlsBatch05);
runLoggedOutScenario(6, pageUrlsBatch06);
runLoggedOutScenario(7, pageUrlsBatch07);
runLoggedOutScenario(8, pageUrlsBatch08);
runLoggedOutScenario(9, pageUrlsBatch09);
runLoggedOutScenario(10, pageUrlsBatch10);
runLoggedOutScenario(11, pageUrlsBatch11);
