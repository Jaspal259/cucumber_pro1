// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// other
const ov3Environment = commonTests.getOv3Environment();
let checkContributionCardInfoIcon;

switch (ov3Environment) {
  case commonConstants.appEnvironmentEnum.qa:
  case commonConstants.appEnvironmentEnum.uat:
    checkContributionCardInfoIcon = true;
    break;
  case commonConstants.appEnvironmentEnum.staging:
  case commonConstants.appEnvironmentEnum.prod:
    // bug OUK-9283 clarified that, "Label has been set to null" by Matt Whittle for STAGING and PROD
    checkContributionCardInfoIcon = false;
    break;
  default:
    throw new Error(`OV3 environment '${ov3Environment}' not supported by this participant`);
}

// tests
const scenarioPrefix = `OUK-254${commonConstants.bddScenarioPrefix}`;

async function checkCardsShown(dcPlanSummaryPage) {
  expect(dcPlanSummaryPage.fundValueCard.isDisplayed()).toBe(true);
  expect(dcPlanSummaryPage.contributionsCard.isDisplayed()).toBe(true);
}

async function checkCardLabels(dcPlanSummaryPage) {
  await checkers.containingTextIgnoreCase(dcPlanSummaryPage.fundValueCardLabel, 'Investments');
  await checkers.containingTextIgnoreCase(dcPlanSummaryPage.contributionsCardLabel, 'Contributions');
}

async function checkCardIcons(dcPlanSummaryPage) {
  await checkers.anyImage(dcPlanSummaryPage.fundValueCardIcon);
  await checkers.anyImage(dcPlanSummaryPage.contributionsCardIcon);
}

async function checkCardValues(dcPlanSummaryPage) {
  await checkers.isGbpGreaterThan(dcPlanSummaryPage.fundValueCardValue, '0');
  await checkers.isGbpGreaterThan(dcPlanSummaryPage.contributionsCardValue, '0');
}

async function checkCardDateLabels(dcPlanSummaryPage) {
  await checkers.anyText(dcPlanSummaryPage.fundValueCardDate);
  await checkers.containingTextIgnoreCase(dcPlanSummaryPage.contributionsCardDate, 'Total Contributions');
}

async function checkCardDates(dcPlanSummaryPage) {
  await checkers.containingCurrentUkDate(dcPlanSummaryPage.fundValueCardDate);
  // note no date for conts card
}

async function checkCardHelpIcons(dcPlanSummaryPage) {
  await checkers.containingImage(dcPlanSummaryPage.fundValueCardHelpIcon,
    commonConstants.infoImageSource);

  if (checkContributionCardInfoIcon) {
    await checkers.containingImage(dcPlanSummaryPage.contributionsCardHelpIcon,
      commonConstants.infoImageSource);
  }
}

async function checkCardCTAs(dcPlanSummaryPage) {
  await checkers.containingTextIgnoreCase(dcPlanSummaryPage.fundValueCardCTA, 'View Investments');
  expect(dcPlanSummaryPage.fundValueCardCTA.isEnabled()).toBe(true);
  await checkers.containingTextIgnoreCase(dcPlanSummaryPage.contributionsCardCTA, 'View Contributions');
  expect(dcPlanSummaryPage.contributionsCardCTA.isEnabled()).toBe(true);
}

async function checkCardsShownWithContent(dcPlanSummaryPage) {
  await checkCardsShown(dcPlanSummaryPage);
  await checkCardLabels(dcPlanSummaryPage);
  await checkCardIcons(dcPlanSummaryPage);
  await checkCardValues(dcPlanSummaryPage);
  await checkCardDates(dcPlanSummaryPage);
  await checkCardHelpIcons(dcPlanSummaryPage);
  await checkCardCTAs(dcPlanSummaryPage);
}

describe(`${scenarioPrefix}Feature display + Content (as per OUK-216) + Info icon + Hide info`, () => {
  /*
     Feature display
     ---------------------------------------------------
     GIVEN that the Member is on the [DC PLAN SUMMARY] page
     WHEN they view their [DC PLAN SUMMARY] page

     Content (as per OUK-216)
     ---------------------------------------------------
     GIVEN that the Member is on the [DC PLAN SUMMARY] page
     WHEN the Member views the [CURRENT FUND VALUE CARD]

     Info icon + Hide info
     ---------------------------------------------------
     GIVEN that the Member is on the [DC PLAN SUMMARY] page
     AND they are viewing the [CURRENT FUND VALUE CARD]
     WHEN they select the [DC FV INFO ICON]
   */

  const pos = standardParticipant.posDcActive;
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    standardParticipant,
    pos.scheme.data.midasSchemeCode,
    pos.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, 0);
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}Check number of snapshot cards`, async () => {
    const cardCount = await dcPlanSummaryPage.getSnapshotCardCount();
    expect(cardCount).toBe(2);
  });

  // Feature display
  it('(Feature display) THEN show [CURRENT FUND VALUE CARD] before [CURRENT DCTV CARD]'
    + ' and [DC RETIREMENT AT NRD CARD]', async () => {
    // we can only check existence of cards, not relative position
    await checkCardsShown(dcPlanSummaryPage);
  });

  // Content (as per OUK-216)
  it('(Content) THEN show [FUND VALUE DESCRIPTION] from CMS (plus conts card)', async () => {
    await checkCardLabels(dcPlanSummaryPage);
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}Check main icon on both cards`, async () => {
    await checkCardIcons(dcPlanSummaryPage);
  });

  it('(Content) AND [CURRENT FUND VALUE] to 2dp from SERVICE (plus conts value)', async () => {
    await checkCardValues(dcPlanSummaryPage);
  });

  it('(Content) AND [PERIOD DESCRIPTION] from CMS (inc. conts card)', async () => {
    await checkCardDateLabels(dcPlanSummaryPage);
  });

  it('(Content) AND nested within [PERIOD DESCRIPTION] show [CURRENT DATE] (inc. conts card)', async () => {
    await checkCardDates(dcPlanSummaryPage);
  });

  it('(Content) AND [DC FV INFO ICON] from CMS (inc. conts card)', async () => {
    await checkCardHelpIcons(dcPlanSummaryPage);
  });

  it(`${commonConstants.bddAdditionalCheckAddedByTe}Check action button on both cards`, async () => {
    await checkCardCTAs(dcPlanSummaryPage);
  });

  // TODO: get tooltips check working in mobile

  // Info icon + Hide info
  it(`${commonConstants.bddNotCheckedForMobileYet}(Info icon + Hide info) THEN show [DV FV INFO TEXT]`
    + ' AND the option to hide it'
    + ' THEN hide [DV FV INFO TEXT] (WHEN they select the option to hide it)', async () => {
    await tooltipTests.checkTooltipIsElementWithText(
      dcPlanSummaryPage.fundValueCardHelpIcon,
      dcPlanSummaryPage.fundValueCardValue,
      dcPlanSummaryPage.tooltips.firstRightTooltip,
      'This is your total fund value as at today, based on your current unit holdings and the most recently'
      + ' available unit prices. Your total fund value is subject to change.');
  });

  if (checkContributionCardInfoIcon) {
    it(`${commonConstants.bddNotCheckedForMobileYet}${commonConstants.bddAdditionalCheckAddedByTe}`
    + 'Check contributions card tooltip', async () => {
      await tooltipTests.checkTooltipIsElementWithText(
        dcPlanSummaryPage.contributionsCardHelpIcon,
        dcPlanSummaryPage.contributionsCardValue,
        dcPlanSummaryPage.tooltips.firstRightTooltip,
        'Contributions card tooltip text.');
    });
  }

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

function runMultiplePosScenario(participantStatus, pos, dcServiceInstance) {
  describe(`${scenarioPrefix}Multiple Periods of Service [POS] (${participantStatus})`, () => {
    /*
     GIVEN that the Member is on the [DC PLAN SUMMARY] page
     AND the Member has multiple [POS]
     WHEN the Member views [CURRENT FUND VALUE CARD]
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, dcServiceInstance);
    });

    it(`${commonConstants.bddAdditionalCheckAddedByTe}Check number of snapshot cards`, async () => {
      const cardCount = dcPlanSummaryPage.getSnapshotCardCount();
      expect(cardCount).toBe(2);
    });

    it('THEN show [CARD CONTENT] relevant to [POS] selected from Dashboard', async () => {
      await checkCardsShownWithContent(dcPlanSummaryPage);
    });

    afterAll(async () => {
      await commonTests.logOut(dcPlanSummaryPage, loginPage);
    });
  });
}

// active already checked
runMultiplePosScenario('deferred', standardParticipant.posDcDeferred, 1);
