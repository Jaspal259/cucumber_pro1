// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);

// tests
const scenarioPrefix = `OUK-233${commonConstants.bddScenarioPrefix}`;

function runScenarios(posDescription, pos, cardInstance) {
  describe(`${scenarioPrefix}Max articles to show + Card content (${posDescription})`, () => {
    /*
      Max articles to show
      ------------------------------------------------
      GIVEN that the Participant is viewing the [DC Plan Summary] page
      WHEN they scroll to the bottom of the page

      Card content
      ------------------------------------------------
      GIVEN that the Participant is viewing the [DC Plan Summary] page
      WHEN they are viewing a [DC ARTICLE]
     */

    const dcPlanSummaryPage = new DcPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${posDescription}`);
      await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
        loginPage, dashboardPage, dcPlanSummaryPage, standardParticipant, cardInstance);
    });

    // Max articles to show
    it('(Max articles to show) THEN show 3 articles [DC ARTICLE 1], [DC ARTICLE 2], [DC ARTICLE 3]', () => {
      expect(dcPlanSummaryPage.article0.article.isDisplayed()).toBe(true);
      expect(dcPlanSummaryPage.article1.article.isDisplayed()).toBe(true);
      expect(dcPlanSummaryPage.article2.article.isDisplayed()).toBe(true);
    });

    // Card content
    function checkSelectedArticle(selectedArticle, articleDescription) {
      it('(Card content) THEN show [DC ARTICLE HEADLINE], [DC ARTICLE MEDIA] and [DC ARTICLE CTA DESC]'
        + ` from CMS with [DC ARTICLE CTA] (${articleDescription})`, async () => {
        await checkers.anyText(selectedArticle.headline);
        await checkers.anyImage(selectedArticle.icon);
        await checkers.containingTextIgnoreCase(selectedArticle.callToAction, 'READ MORE');
        await checkers.containingLink(selectedArticle.callToAction, dcPlanSummaryPage.articleUrlOnPageRoot);
        await checkers.anyTextOf20CharsPlus(selectedArticle.articleDesc);
      });
    }

    checkSelectedArticle(
      dcPlanSummaryPage.article0, 'DC ARTICLE 1');
    checkSelectedArticle(
      dcPlanSummaryPage.article1, 'DC ARTICLE 2');
    checkSelectedArticle(
      dcPlanSummaryPage.article2, 'DC ARTICLE 3');

    afterAll(async () => {
      await commonTests.logOut(dcPlanSummaryPage, loginPage);
    });
  });
}

runScenarios('DC active', standardParticipant.posDcActive, 0);
runScenarios('DC deferred', standardParticipant.posDcDeferred, 1);
