// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load test(s)
const DashboardTests = require('../_common/dashboard.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const UsefulInfoTermsOfUsePage = require('../../page-objects/useful-info-terms-of-use.po.js');
const UsefulInfoCookiePolicyPage = require('../../page-objects/useful-info-cookie-policy.po.js');
const UsefulInfoAccessibilityPolicyPage = require('../../page-objects/useful-info-accessibility-policy.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dashboardTests = new DashboardTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const usefulInfoTermsOfUsePage = new UsefulInfoTermsOfUsePage(standardParticipant);
const usefulInfoCookiePolicyPage = new UsefulInfoCookiePolicyPage(standardParticipant);
const usefulInfoAccessibilityPolicyPage = new UsefulInfoAccessibilityPolicyPage(standardParticipant);
const dashboardPageFooter = dashboardPage.footer;

// other
const pageCategoryHeaderValue = 'IMPORTANT INFORMATION';

// tests
const scenarioPrefix = `OUK-1025${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await dashboardTests.checkDashboardShownAfterLogin(loginPage, dashboardPage, participant);
}

function clickBackLink(commonContent) {
  it('THEN return Participant to previous page (WHEN [BACK LINK] is selected)', async () => {
    await commonTests.clickElement(commonContent.backButton(global.deviceType));
    await dashboardTests.checkDashboardPageLoadsWithCards(dashboardPage, standardParticipant);
  });
}

async function checkPageCategoryHeaderIfDesktop(header) {
  if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
    await checkers.containingTextIgnoreCase(header.pageCategoryHeader(global.deviceType),
      pageCategoryHeaderValue);
  }
}

describe(`${scenarioPrefix}Terms of Use link + Cookie policy link + Accessibility link + Back link`, () => {
  /*
    Terms of Use link
    --------------------------------------------
    GIVEN that the [PARTICIPANT AUTHENTICATION STATE] is either [GUEST], [TRANSITIONAL] or [AUTHENTICATED]
    WHEN the Participant clicks on the [TERMS OF USE] link

    Cookie policy link + Back link
    --------------------------------------------
    GIVEN that the [PARTICIPANT AUTHENTICATION STATE] is either [GUEST], [TRANSITIONAL] or [AUTHENTICATED]
    WHEN the Participant clicks on the [COOKIE POLICY] link

    Accessibility link + Back link
    --------------------------------------------
    GIVEN that the [PARTICIPANT AUTHENTICATION STATE] is either [GUEST], [TRANSITIONAL] or [AUTHENTICATED]
    WHEN the Participant clicks on the [ACCESSIBILITY] link
   */

  const termsPageHeader = usefulInfoTermsOfUsePage.header;
  const cookiePolicyHeader = usefulInfoCookiePolicyPage.header;
  const accessibilityPolicyHeader = usefulInfoAccessibilityPolicyPage.header;

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  // Terms of Use link + Back link
  it('(Terms of Use link ...) THEN show [TERMS OF USE] approved by Mercer legal', async () => {
    await commonTests.clickElement(dashboardPageFooter.termsOfUseLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(usefulInfoTermsOfUsePage);
    await checkPageCategoryHeaderIfDesktop(termsPageHeader);
    await checkers.containingTextIgnoreCase(termsPageHeader.pageHeader(global.deviceType), 'Terms');
    await checkers.containingTextIgnoreCase(termsPageHeader.pageHeader(global.deviceType), 'Use');
    await checkers.containingTextIgnoreCase(termsPageHeader.pageContentHeader, 'Mercer');
    await checkers.containingTextIgnoreCase(termsPageHeader.pageContentHeader, 'Terms');
    await checkers.containingTextIgnoreCase(termsPageHeader.pageContentHeader, 'Use');
    await checkers.anyText(termsPageHeader.pageContent);
  });

  clickBackLink(termsPageHeader);

  // Cookie policy link + Back link
  it('(Cookie policy link ...) THEN show [COOKIES POLICY] approved by Mercer legal', async () => {
    await commonTests.clickElement(dashboardPageFooter.cookiePolicyLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(usefulInfoCookiePolicyPage);
    await checkPageCategoryHeaderIfDesktop(cookiePolicyHeader);
    await checkers.containingTextIgnoreCase(cookiePolicyHeader.pageHeader(global.deviceType), 'Cookies');
    await checkers.containingTextIgnoreCase(cookiePolicyHeader.pageHeader(global.deviceType), 'Privacy');
    await checkers.containingTextIgnoreCase(cookiePolicyHeader.pageContentHeader, 'Mercer');
    await checkers.containingTextIgnoreCase(cookiePolicyHeader.pageContentHeader, 'Cookies');
    await checkers.containingTextIgnoreCase(cookiePolicyHeader.pageContentHeader, 'Privacy');
    await checkers.anyText(cookiePolicyHeader.pageContent);
  });

  clickBackLink(cookiePolicyHeader);

  // Accessibility link + Back link
  it('(Accessibility link ...) THEN show [ACCESSIBILITY] approved by Mercer legal', async () => {
    await commonTests.clickElement(dashboardPageFooter.accessibilityStatementLink);
    await commonTests.checkPageLoadsAndContainsStandardElements(usefulInfoAccessibilityPolicyPage);
    await checkPageCategoryHeaderIfDesktop(accessibilityPolicyHeader);
    await checkers.containingTextIgnoreCase(accessibilityPolicyHeader.pageHeader(global.deviceType),
      'Accessibility');
    await checkers.containingTextIgnoreCase(accessibilityPolicyHeader.pageContentHeader,
      'Accessibility Statement');
    await checkers.anyText(accessibilityPolicyHeader.pageContent);
  });

  clickBackLink(accessibilityPolicyHeader);

  afterAll(async () => {
    await commonTests.logOut(dashboardPage, loginPage);
  });
});
