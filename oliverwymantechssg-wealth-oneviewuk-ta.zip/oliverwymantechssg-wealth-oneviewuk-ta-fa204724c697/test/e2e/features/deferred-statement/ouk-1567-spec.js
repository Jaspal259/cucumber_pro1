// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DeferredStatementPage = require('../../page-objects/db-deferred-statement.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner.js');

// load tests
const DeferredStatementTests = require('../_common/db-deferred-statement.spec.js');
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec.js');
const TooltipTests = require('../_common/tooltips.spec.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const deferredStatementTests = new DeferredStatementTests();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const tooltipTests = new TooltipTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPage = new DbPlanSummaryPage(
  standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const deferredStatementPage = new DeferredStatementPage(
  standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-1567${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await deferredStatementTests.browseToDbDeferredStatementPageFromLogin(
    loginPage, dashboardPage, deferredStatementPage, participant, 1);
}

async function loginToDbPlanSummaryPage(dbSummaryPageParticipant) {
  await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
    loginPage, dashboardPage, dbPlanSummaryPage, dbSummaryPageParticipant, 1);
}

describe(`${scenarioPrefix}Deferred statement access via sub nav `, () => {
  /*
    GIVEN Member is viewing DB Plan Summary page
    WHEN they select Deferred Statement link
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await loginToDbPlanSummaryPage(standardParticipant);
  });

  it('THEN redirect Member to Deferred Statement page in same browser window ', async () => {
    await deferredStatementPage.planHeader.deferredStatementLink.isEnabled();
    await commonTests.clickElement(deferredStatementPage.planHeader.deferredStatementLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(deferredStatementPage);
    expect(browser.getCurrentUrl()).toContain(deferredStatementPage.url);
  });

  afterAll(async () => {
    await commonTests.logOut(dbPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Deferred statement card + Deferred statement page intro text +
             Deferred Statement,pre-amble  + Deferred data groups`, () => {
  /*
    GIVEN Deferred Statement feature is enabled
    AND Member is viewing DB Plan Summary page
    WHEN Member selects view statement link in Deferred statement card
   */

  /*
    GIVEN deferred statement intro text has been published in CMS
    WHEN Member views Deferred Statement page
 */

  /*
    GIVEN Deferred statement pre-amble text has been published in CMS
    WHEN Member views Deferred Statement page
   */

  /*
    GIVEN DOE is available for POS
    AND deferred data is available for POS
    AND the deferred data is permitted for viewing online
    WHEN Member views Deferred Statement page
   */
  beforeAll(async () => {
    await loginToDbPlanSummaryPage(standardParticipant);
  });

  it('THEN redirect Member to Deferred Statement page in same browser window ', async () => {
    await commonTests.clickElement(deferredStatementPage.deferredStatementViewLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(deferredStatementPage);
    expect(browser.getCurrentUrl()).toContain(deferredStatementPage.url);
  });

  it('THEN show Deferred statement intro text ', async () => {
    await checkers.containingTextIgnoreCase(deferredStatementPage.dbDeferredBenefitStatementContent,
      'The statement issued to you is a personal record sent on behalf of the Trustee to show'
      + ' your potential benefits under the plan. It is for information purposes only. The following'
      + ' personal details are held by the Trustee.');
  });

  it('THEN show Deferred Statement pre-amble draw as first draw in accordion ', async () => {
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupLabel(0),
      'Your Annual Statement');
  });

  it('THEN show one draw for each Deferred Statement group'
    + ' AND order Deferred Statement groups as per group sequence in MIDAS', () => {
    expect(deferredStatementPage.preAmbleDrawIcon(0).isDisplayed()).toBe(true);
    expect(deferredStatementPage.preAmbleDrawIcon(1).isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});

describe(`${scenarioPrefix}Group icons `, () => {
  /*
      GIVEN one or more deferred statement groups are available
      AND an icon has been published for that group
      WHEN Members view Deferred Statement page
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show deferred statement group icon for each draw where an icon is available ', () => {
    expect(deferredStatementPage.preAmbleDrawIcon(0).isDisplayed()).toBe(true);
    expect(deferredStatementPage.preAmbleDrawIcon(1).isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});

describe(`${scenarioPrefix}Deferred data view `, () => {
  /*
    GIVEN DOE is available for POS
    AND deferred data is available for POS
    AND the deferred data is permitted for viewing online
    AND view is Deferred Statement page
    WHEN Member expands a Deferred Statement group draw containing deferred data
  */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show deferred data for that deferred statement group'
    + ' AND order data as per field sequence in MIDAS ', async () => {
    await commonTests.clickElement(deferredStatementPage.preAmbleDrawIcon(1));
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupLabel(1),
      'PENSION BENEFITS AT EXIT');
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupDataLabel(1, 0),
      'Post 88 GMP');
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupDataLabel(1, 1),
      'Post 97 pension');
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupDataLabel(1, 2),
      'Total pension');
    await checkers.containingTextIgnoreCase(deferredStatementPage.deferredStatementGroupDataLabel(1, 3),
      'Current revalued pension');
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});

describe(`${scenarioPrefix}Deferred benefits, Field info icons `, () => {
  /*
    GIVEN DOE is available for POS
    AND deferred data is available for POS
    AND the deferred data is available for viewing online
    AND view is Deferred statement page
    AND Deferred statement field icon text is populated for one or multiple deferred data items available
    WHEN Member selects the info icon
  */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show info icon message for that data item ', async () => {
    await commonTests.clickElement(deferredStatementPage.preAmbleDrawIcon(1));
    await tooltipTests.checkTooltipIsElementContainingText(
      deferredStatementPage.deferredStatementGroupDataInfoIcon(1, 0),
      deferredStatementPage.header.clientLogo,
      deferredStatementPage.tooltips.firstRightTooltip,
      'Total Initial Pension at Date of Exit');
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});

describe(`${scenarioPrefix}Deferred Statement, post-amble `, () => {
  /*
    GIVEN Deferred statement post-amble text has been published in CMS
    WHEN Member views Deferred Statement summary page
  */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show deferred statement post-amble draw as final draw in accordion', async () => {
    await commonTests.clickElement(deferredStatementPage.postAmbleDrawIcon(2));
    await checkers.containingTextIgnoreCase(deferredStatementPage.postAmbleDrawIcon(2), 'Test');
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});
