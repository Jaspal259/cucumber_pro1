// TODO: this is code created by Sanjana (LTI) which needs checking

// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DeferredStatementPage = require('../../page-objects/db-deferred-statement.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ovt-p001-dc-db-pensioner.js');

// load tests
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const dbPlanSummaryPage = new DbPlanSummaryPage(standardParticipant,
  standardParticipant.posDbActive.scheme.data.midasSchemeCode,
  standardParticipant.posDbActive.data.periodOfServicePrimaryKey);
const dbPlanSummaryTests = new DbPlanSummaryTests();
const deferredStatementPage = new DeferredStatementPage(standardParticipant,
  standardParticipant.posDbDeferred.scheme.data.midasSchemeCode,
  standardParticipant.posDbDeferred.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-2376${commonConstants.bddScenarioPrefix}`;

async function login(participant) {
  await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(loginPage, dashboardPage, dbPlanSummaryPage,
    participant, 0);
}

describe(`${scenarioPrefix}Deferred statement, draw info icon`, () => {
  /*
   GIVEN DOE is available for POS
   AND deferred data is available for POS
   AND the deferred data is available for viewing online
   AND Deferred statement group info icon text is populated for one or multiple deferred statement groups available
   AND view is Deferred statement page
   WHEN Member selects Deferred Statement Group info icon
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login(standardParticipant);
  });

  it('THEN show info icon message for that Deferred Statement group', async () => {
    await checkers.containingTextIgnoreCase(deferredStatementPage.statusValue, 'Deferred');
    expect(deferredStatementPage.deferredStatementLink.isDisplayed()).toBe(true);

    await commonTests.clickElement(deferredStatementPage.deferredStatementLink);
    expect(deferredStatementPage.introTextForDeferredStatement.isDisplayed()).toBe(true);
    expect(deferredStatementPage.yourAnnualStatementLabel.isDisplayed()).toBe(true);
    expect(deferredStatementPage.descForAnnualStatement.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});

describe(`${scenarioPrefix}Deferred benefits, frequency`, () => {
  /*
   GIVEN DOE is available for POS
   AND deferred data is available for POS
   AND the deferred data is available for viewing online
   AND monetary deferred data types have the frequency populated
   AND the frequency label is published in CMS
   WHEN Member views monetary data items
   */

  beforeAll(async () => {
    await login(standardParticipant);
  });

  it('THEN show frequency next to data value', async () => {
    await checkers.containingTextIgnoreCase(deferredStatementPage.statusValue, 'Deferred');
    expect(deferredStatementPage.deferredStatementLink.isDisplayed()).toBe(true);

    await commonTests.clickElement(deferredStatementPage.deferredStatementLink);
    expect(deferredStatementPage.pensionBenefitsAtExitLabel.isDisplayed()).toBe(true);

    await commonTests.clickElement(deferredStatementPage.pensionBenefitsAtExitLabel);
    expect(deferredStatementPage.deferredStatementGroupDataLabel.isDisplayed()).toBe(true);
    expect(deferredStatementPage.deferredStatementGroupDataValue.isDisplayed()).toBe(true);
  });


  afterAll(async () => {
    await commonTests.logOut(deferredStatementPage, loginPage);
  });
});
