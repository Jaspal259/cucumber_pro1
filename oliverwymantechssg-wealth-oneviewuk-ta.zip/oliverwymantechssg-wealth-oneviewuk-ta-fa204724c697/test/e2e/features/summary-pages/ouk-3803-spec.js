// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const DbPlanSummaryTests = require('../_common/db-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DbPlanSummaryPage = require('../../page-objects/db-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const dbPlanSummaryTests = new DbPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);


// tests
const scenarioPrefix = `OUK-3803${commonConstants.bddScenarioPrefix}`;

async function login(dbPlanSummaryPage, dbServiceInstance) {
  await dbPlanSummaryTests.browseToDbPlanSummaryPageFromLogin(
    loginPage, dashboardPage, dbPlanSummaryPage, standardParticipant, dbServiceInstance);
}

function runPensionBenefitCardScenarios(posDescription, pos, dbServiceInstance) {
  describe(`${scenarioPrefix}Pension Benefit card + Pension benefit card, deferred statement`
    + `Pension benefit card, annual statement, actives (${posDescription})`, () => {
    /*
        Pension Benefit card
        --------------------------------------------------------------
        GIVEN <pension benefit> is available
        WHEN the Member navigates to the DB Summary page

        Pension benefit card, deferred statement
        --------------------------------------------------------------
        GIVEN DB deferred statement is enabled
        WHEN the Member navigates to the DB Summary page

        Pension benefit card, annual statement, actives
        --------------------------------------------------------------
        GIVEN DB active Annual Statement feature is enabled
        WHEN member navigates to DB Summary page
     */

    const dbPlanSummaryPage = new DbPlanSummaryPage(
      standardParticipant,
      pos.scheme.data.midasSchemeCode,
      pos.data.periodOfServicePrimaryKey);

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(`${scenarioPrefix}${posDescription}`);
      await login(dbPlanSummaryPage, dbServiceInstance);
    });

    it(`${commonConstants.bddAdditionalCheckAddedByTe}Check number of snapshot cards`, async () => {
      const cardCount = await dbPlanSummaryPage.getSnapshotCardCount();
      expect(cardCount).toBe(1);
    });

    // Pension Benefit card
    it('(Pension Benefit card) THEN show [pension benefit]', async () => {
      const cardCount = dbPlanSummaryPage.getSnapshotCardCount();
      expect(cardCount).toBe(1);
      expect(dbPlanSummaryPage.fundValueCard.isDisplayed()).toBe(true);
      await checkers.isGbpGreaterThan(dbPlanSummaryPage.fundValueCardValue, '0');
    });

    it('(Pension Benefit card) AND show [as at date]', async () => {
      await checkers.anyText(dbPlanSummaryPage.fundValueCardDate);
      await checkers.containingAnyUkDate(dbPlanSummaryPage.fundValueCardDate);
    });

    it(`${commonConstants.bddAdditionalCheckAddedByTe}Check rest of Pension Benefit card content`, async () => {
      // note did check for 'pension benefit' then 'deferred benefit' but manual testers kept flipping text
      await checkers.containingTextIgnoreCase(dbPlanSummaryPage.fundValueCardLabel, 'benefit');
      await checkers.containingImage(dbPlanSummaryPage.fundValueCardIcon,
        commonConstants.piggyBankImageSource);
    });

    // Pension benefit card, deferred statement
    it('(... deferred statement) THEN enable deferred statement link in Pension benefit card', async () => {
      await checkers.containingTextIgnoreCase(dbPlanSummaryPage.fundValueCardCTADeferred,
        'View deferred statement');
      expect(dbPlanSummaryPage.fundValueCardCTADeferred.isEnabled()).toBe(true);
    });

    it('(... deferred statement) AND enable deferred statement link in sub-navigation bar', async () => {
      await checkers.containingTextIgnoreCase(dbPlanSummaryPage.planHeader.deferredStatementLink,
        'Deferred statement');
    });

    // Pension benefit card, annual statement, actives
    it('(... annual statement, actives) THEN enable annual statement link in Pension benefit card', async () => {
      if (posDescription === 'DB active') {
        await checkers.containingTextIgnoreCase(dbPlanSummaryPage.fundValueCardCTAAnnual,
          'View annual statement');
        expect(dbPlanSummaryPage.fundValueCardCTAAnnual.isEnabled()).toBe(true);
      } else {
        expect(dbPlanSummaryPage.fundValueCardCTAAnnual.isPresent()).toBe(false);
      }
    });

    it('(... annual statement, actives) AND enable annual statement link in sub-nav', async () => {
      await checkers.containingTextIgnoreCase(dbPlanSummaryPage.planHeader.annualBenefitStatementLink,
        'Annual statement');
    });

    afterAll(async () => {
      await commonTests.logOut(dbPlanSummaryPage, loginPage);
    });
  });
}

runPensionBenefitCardScenarios('DB active', standardParticipant.posDbActive, 0);
runPensionBenefitCardScenarios('DB deferred', standardParticipant.posDbDeferred, 1);
