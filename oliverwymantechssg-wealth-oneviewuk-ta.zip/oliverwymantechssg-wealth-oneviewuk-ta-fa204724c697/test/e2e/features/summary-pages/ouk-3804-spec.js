// load common
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');
const PlanMaterials = require('../../page-objects/pensioner-plan-materials.po.js');
const AnnualAllowancePage = require('../../page-objects/allowances-annual-allowance.po.js');
const LifeTimeAllowancePage = require('../../page-objects/allowances-lifetime-allowance.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(standardParticipant);
const dashboardPage = new DashboardPage(standardParticipant);
const planMaterials = new PlanMaterials(standardParticipant);
const annualAllowancePage = new AnnualAllowancePage(standardParticipant);
const lifeTimeAllowancePage = new LifeTimeAllowancePage(standardParticipant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  standardParticipant,
  standardParticipant.posPensioner.scheme.data.midasSchemeCode,
  standardParticipant.posPensioner.data.periodOfServicePrimaryKey);

// tests
const scenarioPrefix = `OUK-3804${commonConstants.bddScenarioPrefix}`;

async function login() {
  await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
    loginPage, dashboardPage, pensionerPlanSummaryPage, standardParticipant, 0);
}

describe(`${scenarioPrefix}Tax office address `, () => {
  /*
   GIVEN the Pensioner has navigated to the PIP Summary page
   WHEN they select the view tax office address option
   */

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await login();
  });

  it(' THEN display tax office address modal+AND enable close option', async () => {
    expect(pensionerPlanSummaryPage.taxYtdAction.isDisplayed()).toBe(true);
    await commonTests.clickElement(pensionerPlanSummaryPage.taxYtdAction);
    expect(pensionerPlanSummaryPage.taxOfficeAddressDetailsLabel.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Tax office address modal, close option`, () => {
  /*
   GIVEN the view is tax office address modal
   WHEN the Pensioner selects close
   */

  beforeAll(async () => {
    await login();
  });

  it('THEN dismiss tax office address modal+AND return Pensioner to PIP Summary page', async () => {
    expect(pensionerPlanSummaryPage.taxYtdAction.isDisplayed()).toBe(true);
    await commonTests.clickElement(pensionerPlanSummaryPage.taxYtdAction);
    expect(pensionerPlanSummaryPage.taxOfficeAddressDetailsLabel.isDisplayed()).toBe(true);

    await commonTests.clickElement(pensionerPlanSummaryPage.uniqueIDForOkButton);
    expect(pensionerPlanSummaryPage.taxYtdAction.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Plan Materials visibility`, () => {
  /*
   GIVEN view Pensioner Plan Materials is enabled
   WHEN the Pensioner navigates to the PIP Summary page
   */

  beforeAll(async () => {
    await login();
  });

  it('THEN enable Plan Materials link in sub-navigation bar+AND enable Plan Materials feature in carousel', () => {
    expect(pensionerPlanSummaryPage.taxYtdAction.isDisplayed()).toBe(true);
    expect(planMaterials.planHeader.planMaterialsLink.isEnabled()).toBe(true);
    expect(pensionerPlanSummaryPage.planMaterialsDesc.isDisplayed()).toBe(true);
    expect(pensionerPlanSummaryPage.viewPlanMaterials.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Historical Pension visibility`, () => {
  /*
   GIVEN view Historical Pension is enabled
   WHEN the Pensioner navigates to the PIP Summary page
   */

  beforeAll(async () => {
    await login();
  });

  it(' THEN enable Historical Pension link in sub-navigation bar+\n'
    + '   AND enable Historical Pension feature in carousel', () => {
    expect(pensionerPlanSummaryPage.planHeader.historicalPensionLink.isEnabled()).toBe(true);
    expect(pensionerPlanSummaryPage.pensionPaymentsDesc.isDisplayed()).toBe(true);
    expect(pensionerPlanSummaryPage.planHeader.historicalPensionLink.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Dependants Pension visibility`, () => {
  /*
   GIVEN view dependants pension is enabled
   AND pensioner type is member
   AND at least one dependants contingent pension is available
   AND the sum of the INCLUSIVE contingent pension elements for
    at least one contingent pension equals the total contingents pension
   AND the total contingents pension is greater than £0.00
   AND the dependants contingent pension relationship type is available from the types permitted for the Plan
   WHEN the Pensioner navigates to the PIP Summary page
   */

  beforeAll(async () => {
    await login();
  });

  it('THEN enable Dependants Pension link in sub-navigation bar+\n'
    + 'AND enable Dependants Pension feature in carousel', () => {
    expect(pensionerPlanSummaryPage.planHeader.dependantsLink.isEnabled()).toBe(true);
    expect(pensionerPlanSummaryPage.dependantsDesc.isDisplayed()).toBe(true);
    expect(pensionerPlanSummaryPage.planHeader.dependantsLink.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Beneficiaries visibility`, () => {
  /*
   GIVEN Pensioner Dependants is enabled
   AND Pensioner Type is member
   WHEN the Pensioner navigates to the PIP Summary page
   */

  beforeAll(async () => {
    await login();
  });

  it('THEN enable Beneficiaries link in sub-navigation bar+\n'
    + ' AND enable Beneficiaries feature in carousel', () => {
    expect(pensionerPlanSummaryPage.planHeader.beneficiariesLink(global.deviceType).isEnabled()).toBe(true);
    expect(pensionerPlanSummaryPage.descForBeneficiaries.isDisplayed()).toBe(true);
    expect(pensionerPlanSummaryPage.viewBeneficiaries.isEnabled()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Allowances visibility`, () => {
  /*
   GIVEN at least one <Pensioner Allowance feature> is enabled
   AND Allowance data is available for that feature(s)
   WHEN the Pensioner navigates to the PIP Plan Summary page
   */

  beforeAll(async () => {
    await login();
  });

  it('THEN enable Allowances link in sub-navigation bar+\n'
    + 'AND enable Allowances feature in carousel', async () => {
    expect(pensionerPlanSummaryPage.planHeader.allowancesLink.isEnabled()).toBe(true);
    expect(pensionerPlanSummaryPage.descForAllowances.isDisplayed()).toBe(true);
    expect(pensionerPlanSummaryPage.viewAllowances.isEnabled()).toBe(true);
    await commonTests.clickElement(pensionerPlanSummaryPage.planHeader.allowancesLink);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(pensionerPlanSummaryPage);
    expect(browser.getCurrentUrl()).toContain(pensionerPlanSummaryPage.allowances.url);
    expect(annualAllowancePage.annualAllowanceTab.isDisplayed()).toBe(true);
    expect(lifeTimeAllowancePage.lifetimeTab.isDisplayed()).toBe(true);
    expect(annualAllowancePage.planLabel.isDisplayed()).toBe(true);
    expect(annualAllowancePage.planValue.isDisplayed()).toBe(true);

    await commonTests.clickElement(lifeTimeAllowancePage.lifetimeTab);
    await commonTests.checkPlanPageLoadsAndContainsPlanHeader(lifeTimeAllowancePage);
    expect(lifeTimeAllowancePage.planLabel.isDisplayed()).toBe(true);
    expect(lifeTimeAllowancePage.planValue.isDisplayed()).toBe(true);
  });

  afterAll(async () => {
    await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
  });
});
