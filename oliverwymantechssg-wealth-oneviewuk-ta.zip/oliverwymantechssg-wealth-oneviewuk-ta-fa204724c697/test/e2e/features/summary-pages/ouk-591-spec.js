// load common
const genericCommonTests = require('../../utilities/generic-common.helper.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const Participant = require('../../data/participants/ov1-p001-dc-db-pensioner');

// load tests
const PensionerPlanSummaryTests = require('../_common/pensioner-plan-summary.spec');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const PensionerPlanSummaryPage = require('../../page-objects/pensioner-plan-summary.po');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const participant = new Participant();
const pensionerPlanSummaryTests = new PensionerPlanSummaryTests();
const loginPage = new LoginPage(participant);
const dashboardPage = new DashboardPage(participant);
const pensionerPlanSummaryPage = new PensionerPlanSummaryPage(
  participant,
  participant.posPensioner.scheme.data.midasSchemeCode,
  participant.posPensioner.data.periodOfServicePrimaryKey);

// environments are set up slightly differently
const ov3Environment = commonTests.getOv3Environment();

// run tests?
let testArticles = true;

if (ov3Environment === commonConstants.appEnvironmentEnum.staging
|| ov3Environment === commonConstants.appEnvironmentEnum.prod) {
  // test bypassed for STAGE and PROD as Matt confirmed n/a to these environments in bug OUK-9197
  testArticles = false;
}

// tests
const scenarioPrefix = `OUK-591${commonConstants.bddScenarioPrefix}`;

async function login() {
  await pensionerPlanSummaryTests.browseToPensionerPlanSummaryPageFromLogin(
    loginPage, dashboardPage, pensionerPlanSummaryPage, participant, 0);
}

function checkArticleContent(selectedArticleDescription, selectedArticle, headline) {
  it(`(Card content) THEN show [PIP PS ARTICLE HEADLINE] (${selectedArticleDescription})`, async () => {
    await genericCommonTests.scrollToBottomOfPage();
    await checkers.exactText(selectedArticle.headline, headline);
    await checkers.anyText(selectedArticle.articleDesc);
  });

  it(`(Card content) AND [PIP PS ARTICLE MEDIA] (${selectedArticleDescription})`, async () => {
    await checkers.containingImage(selectedArticle.icon, '/files/articles/article');
  });

  it(`(Card content) AND [PIP PS ARTICLE CTA LINK] (${selectedArticleDescription})`, async () => {
    await checkers.exactText(selectedArticle.callToAction, 'READ MORE');
  });
}

if (testArticles) {
  describe(`${scenarioPrefix}Max articles to show + Card content`, () => {
    /*
      Max articles to show
      -------------------------------------------------

      GIVEN that the Pensioner is viewing the [PIP PLAN SUMMARY PAGE]
      WHEN the [PIP PLAN SUMMARY PAGE] loads

      Card content
      -------------------------------------------------
      GIVEN that the Pensioner is viewing the [PIP PLAN SUMMARY PAGE]
      WHEN they are viewing a [PIP PS ARTICLE]
     */

    beforeAll(async () => {
      await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
      await login();
    });

    // Max articles to show
    it('(Max articles to show) THEN show 3 articles [PIP PS ARTICLE 1]', async () => {
      await genericCommonTests.scrollToBottomOfPage();
      expect(pensionerPlanSummaryPage.article0.article.isDisplayed()).toBe(true);
    });

    it('(Max articles to show) AND [PIP PS ARTICLE 2]', () => {
      expect(pensionerPlanSummaryPage.article1.article.isDisplayed()).toBe(true);
    });

    it('(Max articles to show) AND [PIP PS ARTICLE 3]', () => {
      expect(pensionerPlanSummaryPage.article2.article.isDisplayed()).toBe(true);
    });

    // Card content
    checkArticleContent(
      'article 1', pensionerPlanSummaryPage.article0, 'Working after retirement');
    checkArticleContent(
      'article 2', pensionerPlanSummaryPage.article1, 'Understanding Tax and Pensions');
    checkArticleContent(
      'article 3', pensionerPlanSummaryPage.article2, 'Change the Way Your Think About Ageing');

    afterAll(async () => {
      await commonTests.logOut(pensionerPlanSummaryPage, loginPage);
    });
  });
}
