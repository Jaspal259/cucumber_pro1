// load common
const resultMessaging = require('../../utilities/result-messaging.js');
const genericCommonTests = require('../../utilities/generic-common.helper.js');
const CommonTests = require('../../utilities/common-tests.js');
const CommonConstants = require('../../utilities/common-constants.js');
const checkers = require('../../utilities/checkers.helper.js');

// load participant(s)
const StandardParticipant = require('../../data/participants/ov1-p001-dc-db-pensioner');
const NoTransParticipant = require('../../data/participants/participant-ouk-249-002-no-trans-data');

// load tests
const DcPlanSummaryTests = require('../_common/dc-plan-summary.spec');
const TooltipTests = require('../_common/tooltips.spec.js');

// load page object(s)
const LoginPage = require('../../page-objects/authentication-login.po.js');
const DashboardPage = require('../../page-objects/dashboard.po.js');
const DcPlanSummaryPage = require('../../page-objects/dc-plan-summary.po.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();
const standardParticipant = new StandardParticipant();
const noTransParticipant = new NoTransParticipant();
const dcPlanSummaryTests = new DcPlanSummaryTests();
const tooltipTests = new TooltipTests();

// tests
const scenarioPrefix = `OUK-249${commonConstants.bddScenarioPrefix}`;

describe(`${scenarioPrefix}Enabled`, () => {
  /*
    GIVEN that the Member is viewing the [DC Plan Summary] page
    AND [TRANSACTION HISTORY] is enabled
    AND their [TOTAL TRANSACTIONS] from [TRANSACTION HISTORY] for the [DEFAULT TH PERIOD] is equal to or greater than 1
    WHEN they scroll to the bottom of the page (above education articles)
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await commonTests.printToConsoleLogWithStartAndDateTime(scenarioPrefix);
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  // TODO: headers still need checking
  it('THEN show [TRANSACTION HISTORY DESCRIPTION] FROM CMS', async () => {
    await genericCommonTests.bringElementIntoView(dcPlanSummaryPage.transactionHistory);
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transactionHistoryLabel, 'TRANSACTION HISTORY');
    expect(dcPlanSummaryPage.transInfoIcon.isDisplayed()).toBe(true);
    await browser.actions().mouseMove(dcPlanSummaryPage.transInfoIcon).perform();
  });

  it('AND [TRADE DATE DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transDateLabel, 'Trade Date');
  });

  it('AND [TRANSACTION DATE] from SERVICE', async () => {
    await checkers.anyUkDate(dcPlanSummaryPage.getTransactionHistoryTradeDateValue(0));
  });

  it('AND [TRANSACTION TYPE DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transactionLabe, 'Transaction Type');
  });

  it('AND [TRANSACTION TYPE] from SERVICE', async () => {
    await checkers.anyText(dcPlanSummaryPage.getTransactionHistoryTransactionType(0));
  });

  it('AND [FUND NAME DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.fundDescLabel, 'Fund Name');
  });

  it('AND [FUND NAME] from SERVICE', async () => {
    await checkers.anyText(dcPlanSummaryPage.getTransactionHistoryFundName(0));
  });

  it('AND [VALUE DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transValueLabel, 'Value');
  });

  it('AND [VALUE] from SERVICE', async () => {
    await checkers.anyGbp(dcPlanSummaryPage.getTransactionHistoryFundValue(0));
  });

  it(' AND [TRADED UNITS DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.tradeUnitLabel, 'Traded Units');
  });

  it('AND [TRADED UNITS] from SERVICE', async () => {
    const units = await dcPlanSummaryPage.getTransactionHistoryTradedUnits(0);
    await checkers.anyNumberToSpecifiedDp(units, 6);
  });

  it('AND [TRADE PRICE DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.tradeUnitPrice, 'Trade Price');
  });

  it('AND [TRADE PRICE] from SERVICE', async () => {
    await checkers.anyGbp(dcPlanSummaryPage.getTransactionHistoryTradedPrice(0));
  });

  it('AND [SWITCH NO. DESCRIPTION] from CMS', async () => {
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transSwitchLabel, 'Switch No.');
  });

  it('AND [SWITCH NUMBER] from SERVICE', async () => {
    await checkers.anyText(dcPlanSummaryPage.getTransactionHistorySwitchNumber(0));
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

// TODO: needs to be completed
describe(`${scenarioPrefix}Multiple Periods of Service [POS]`, () => {
  /*
    GIVEN that the Member is viewing the [DC Plan Summary] page
    AND [TRANSACTION HISTORY] is enabled
    AND the Member has multiple <POS>
    WHEN the Member views [TRANSACTION HISTORY]
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  it('THEN show [TRANSACTION HISTORY] relevant to [POS] selected', () => {
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

describe(`${scenarioPrefix}Default Period`, () => {
  /*
    GIVEN that the Member is viewing the [DC Plan Summary] page
    AND [TRANSACTION HISTORY] is enabled
    WHEN they view their [TRANSACTION HISTORY]
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  // TODO: is this statement true? - this case is difficult to check by script
  it('THEN show [TRANSACTION HISTORY] from SERVICE for [DEFAULT TH PERIOD] which '
    + 'is [CURRENT DATE] less 12 months subject to [PLAN EARLIEST TH DATE] and [MEMBER EARLIEST TH DATE]', () => {
    resultMessaging.failStubTest();
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

// manual test
xdescribe(`${scenarioPrefix}Default View`, () => {
  /*
    Scenario - Default View
    AND their [TOTAL TRANSACTIONS] from [TRANSACTION HISTORY] for the [DEFAULT TH PERIOD] is equal to or greater than 1
    WHEN they view their [TRANSACTION HISTORY]
    THEN show [MAX TRANSACTIONS] per page based on [TOTAL TRANSACTIONS] for [DEFAULT TH PERIOD]
    from [TRANSACTION HISTORY]
    AND [PAGINATION CONTROL] (see OUK-252)
   */
});

// TODO: needs completion
describe(`${scenarioPrefix}show guidance text + hide guidance text`, () => {
  /*
    GIVEN that the Member is viewing the [DC Plan Summary] page
    AND [TRANSACTION HISTORY] is enabled
    WHEN they view their [TRANSACTION HISTORY]
   */

  const participant = standardParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  it('THEN show [TH INFO ICON] next to [TRANSACTION HISTORY DESCRIPTION]'
    + ' AND if selected, show [TH INFO TEXT] from CMS'
    + ' AND nested within [TH INFO TEXT] show [PLAN EARLIEST TH DATE]'
    + ' AND option to hide [TH INFO TEXT]'
    + ' THEN hide [TH INFO TEXT] (WHEN they select the option to hide [TH INFO TEXT])', async () => {
    await tooltipTests.checkTooltipIsElementContainingText(
      dcPlanSummaryPage.transInfoIcon,
      dcPlanSummaryPage.header.clientLogo,
      dcPlanSummaryPage.tooltips.firstRightTooltip,
      'define');
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});

// TODO set up participant without transactions
describe(`${scenarioPrefix}No Data`, () => {
  /*
    GIVEN that the Member is viewing the [DC Plan Summary] page
    AND [TRANSACTION HISTORY] is enabled
    AND their [TOTAL TRANSACTIONS] from [TRANSACTION HISTORY] for the [DEFAULT TH PERIOD] is NULL
    WHEN they scroll to the bottom of the page (above education articles)
   */

  const participant = noTransParticipant;
  const loginPage = new LoginPage(participant);
  const dashboardPage = new DashboardPage(participant);
  const dcPlanSummaryPage = new DcPlanSummaryPage(
    participant,
    participant.posDcActive.scheme.data.midasSchemeCode,
    participant.posDcActive.data.periodOfServicePrimaryKey);

  beforeAll(async () => {
    await dcPlanSummaryTests.browseToDcPlanSummaryPageFromLogin(
      loginPage, dashboardPage, dcPlanSummaryPage, participant, 0);
  });

  it('THEN show [TRANSACTION HISTORY DESCRIPTION] FROM CMS', async () => {
    await genericCommonTests.bringElementIntoView(dcPlanSummaryPage.transactionHistory);
    await checkers.containingTextIgnoreCase(dcPlanSummaryPage.transactionHistoryLabel, 'TRANSACTION HISTORY');
  });

  it(' AND [NULL TH DATA MESSAGE] from CMS', async () => {
    await checkers.exactText(dcPlanSummaryPage.transactionHistoryPage,
      'There are no transactions currently available. '
      + 'If you have a transaction in progress then you will be able to view it here once it is completed.');
  });

  afterAll(async () => {
    await commonTests.logOut(dcPlanSummaryPage, loginPage);
  });
});
