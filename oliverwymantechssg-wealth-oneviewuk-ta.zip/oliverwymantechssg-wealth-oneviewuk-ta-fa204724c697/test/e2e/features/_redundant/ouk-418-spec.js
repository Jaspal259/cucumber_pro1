/*
  All TE code removed from this redundant story so no conflicts occur when page objects etc updated but file
  kept as a record of story's existence
 */

/*
  This has been superseded by 3805 as current Zeplin very different from what this story's Gherkin describes.
 */
