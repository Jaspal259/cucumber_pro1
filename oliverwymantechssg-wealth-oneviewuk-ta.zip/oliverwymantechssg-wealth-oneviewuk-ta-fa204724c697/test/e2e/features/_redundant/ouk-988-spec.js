/*
  All TE code removed from this redundant story so no conflicts occur when page objects etc updated but file
  kept as a record of story's existence
 */

/*
  This story is now covered better by newer stories (from UI re-design) which are in
  regression test suite so TE code for this story retired 21/05/2018.
 */
