/*
  All TE code removed from this redundant story so no conflicts occur when page objects etc updated but file
  kept as a record of story's existence
 */

/*
     This story no longer requires TE code as OV3 UI re-design has meant functionality previous TE coded under the
     separate stories 1075, 1077, 1078, 1079 and 1080 is now TE coded under the single 1075 story only.
 */
