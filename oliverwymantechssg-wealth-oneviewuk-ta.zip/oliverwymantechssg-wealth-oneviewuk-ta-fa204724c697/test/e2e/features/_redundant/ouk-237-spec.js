/*
  All TE code removed from this redundant story so no conflicts occur when page objects etc updated but file
  kept as a record of story's existence.

  Enabling the TV card on DC plan summary (as required for OUK-237) makes the summary page very slow to load
  and this will unduly affect any other DC test - TV card has thus been disabled for OV1 TE-only client and
  therefore TE code is no longer applicable and has been retired.
 */
