/*
  All TE code removed from this redundant story so no conflicts occur when page objects etc updated but file
  kept as a record of story's existence

  Note bug 8884 advised that dependant's page now only shown if contingents pension exists (this is a change
  from OneView 2). Have confirmed OV1 client participant mercerdemo has no contingent's pension and that this
  data would take too long to set up so have simply removed test 1694 from test suite
 */
