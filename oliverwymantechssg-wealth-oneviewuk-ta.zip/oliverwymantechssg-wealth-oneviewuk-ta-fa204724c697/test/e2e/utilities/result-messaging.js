// load common
const genericCommonConstants = require('./generic-common-constants.js');

// tests
module.exports = {
  // private functions


  // private properties


  // exposed properties


  // exposed functions

  getUtcDateTimeAsString() {
    const now = new Date();
    return `${now.toUTCString()}${genericCommonConstants.messageSeparator}`;
  },

  async checkJavaScriptBrowserLogs() {
    // references
    // http://www.webdriverjs.com/identifying-javascript-errors-in-a-webpage-using-protractor/
    // https://ngmilk.rocks/2014/10/17/detecting-console-errors-while-testing-angularjs-with-protractor/
    const browserLog = await browser.manage().logs().get('browser');

    if (browserLog.length !== 0) {
      const currentDateTime = this.getUtcDateTimeAsString();
      fail(`${currentDateTime}JavaScript browser log error(s)`
        + `${genericCommonConstants.messageSeparator}${JSON.parse(JSON.stringify(browserLog))[0].message}`);
    }
  },

  publishFailBasic(failMessage) {
    const currentDateTime = this.getUtcDateTimeAsString();
    const fullMessage = `${currentDateTime}${failMessage}`;
    fail(fullMessage);
    return false;
  },

  publishFailWithException(failMessage, exception) {
    const currentDateTime = this.getUtcDateTimeAsString();
    const fullMessage
      = `${currentDateTime}${failMessage}`
      + `${genericCommonConstants.messageSeparator}Exception: ${exception}`;
    fail(fullMessage);
    return false;
  },

  /**
   * @example
   * process.on('unhandledRejection', (e) => {
   *   resultMessaging.publishUnhandledPromiseException(e);
   * });
   * @param unhandledPromiseRejectionException: element to be checked
   * @description
   * this function is required to handle otherwise unhandled promise rejections
   * BUT is only called from at the top level of testing i.e. in the conf.js file ONLY
   *
   * an example of an unhandled promise rejection would be not handling clicking
   * on an element which does not exist
   *
   * without the function in conf.js the test will report UnhandledPromiseRejectionWarning
   * and in the near future unhandled promise rejections will terminate the Node.js
   * process with a non-zero exit code and with no warning (which would be very difficult
   * to debug
   */
  publishUnhandledPromiseException(unhandledPromiseRejectionException) {
    return this.publishFailWithException(
      'Unhandled promise rejection', unhandledPromiseRejectionException);
  },


  async getElementDescription(element) {
    let elementDescription = `${genericCommonConstants.messageSeparator}Element`;

    const elementTagName = await element.getTagName();
    elementDescription += ` tagName: '${elementTagName}'`;

    const elementId = await element.getAttribute('id');

    if (elementId !== '') {
      elementDescription += `, id: '${elementId}'`;
    }

    const elementClass = await element.getAttribute('class');

    if (elementClass !== '') {
      elementDescription += `, class: '${elementClass}'`;
    }

    const elementHref = await element.getAttribute('href');

    if (elementHref !== '' && elementHref !== null) {
      elementDescription += `, href: '${elementHref}'`;
    }

    if (elementId === '' && elementClass === '' && elementHref === '') {
      const elementText = await element.getText();

      if (elementText !== '') {
        elementDescription += `, text: '${elementText}'`;
      }
    }

    return elementDescription;
  },

  async publishFailWithElement(element, failMessage) {
    const currentDateTime = this.getUtcDateTimeAsString();
    const elementDescription = await this.getElementDescription(element);
    const fullMessage = `${currentDateTime}${failMessage}${elementDescription}`;
    fail(fullMessage);
    await this.checkJavaScriptBrowserLogs();
    return false;
  },

  failStubTest() {
    // this test is designed always to fail - will be used to ensure all test stubs default to failure
    // this is only 1 line of code but it ensures all stub tests fail in the same way
    expect('1').toEqual('write test');
  },

  failAsIncompleteTest() {
    // this test is designed always to fail
    // this is only 1 line of code but it ensures all incomplete tests fail in the same way
    expect('1').toEqual('complete test');
  },

  passTestAsNotATest() {
    // use this when tests can be passed as the phrase has already been effectively passed earlier in the script
    // this is only 1 line of code but it ensures all such tests pass in the same way
    const v = 'not a test so always passes';
    expect(v).toEqual(v);
  },

  passTestAsNotApplicable() {
    // use this when tests can be passed as do not apply to certain condition - e.g. testing mobile
    // and a test only applies to desktop
    const v = 'test is not applicable';
    expect(v).toEqual(v);
  },

  passTestAsLayoutTest() {
    // layout / aesthetics / specific data test so always passes as should not be tested by automation
    // this is only 1 line of code but it ensures all such tests pass in the same way
    const v = 'layout / aesthetics / specific data test so always passes';
    expect(v).toEqual(v);
  },

  passTestWithCustomMessage(message) {
    expect(message).toEqual(message);
  },

  failTestAsReworkPending() {
    // review highlighted work to do
    // this is only 1 line of code but it ensures all such tests fail in the same way
    expect('1').toEqual('QA review highlighted work to do');
  },

  failTestWithCustomMessage(message) {
    // review highlighted work to do as per custom message
    expect('1').toEqual(message);
  },
};
