const Fecha = require('fecha');

module.exports = {
  /**
   * Create a Date object in UTC timezone
   *
   * @method create
   * @param {string} dateStr Date string in YYYY-MM-DD format
   * @return {Date|boolean}
   */
  create(dateStr) {
    return Fecha.parse(`${dateStr} Z`, 'YYYY-MM-DD ZZ');
  },

  /**
   * Parse a date string into an object in UK timezone date object
   *
   * @method parseUkDate
   * @param {string} dateStr Date string
   * @return {Date|boolean}
   */
  parseUkDate(dateStr) {
    if (!(typeof dateStr === 'string' && dateStr.length > 0)) {
      fail('parseUkDate() function requires a non-null string of 1 or more characters in length');
    }

    return Fecha.parse(`${dateStr} Z`, `${Fecha.masks.ukDate} ZZ`);
  },

  /**
   * Parse a date string into UK timezone date string
   *
   * @method parseUkDateString
   * @param {string} dateStr Date string
   * @return {string}
   */
  parseUkDateString(dateStr) {
    if (!(typeof dateStr === 'string' && dateStr.length > 0)) {
      fail('parseUkDateString() function requires a non-null string of 1 or more characters in length');
    }

    const ukDateObj = Fecha.parse(`${dateStr} Z`, `${Fecha.masks.ukDate} ZZ`);
    return this.formatDateAsUkDateString(ukDateObj);
  },

  /**
   * Format a date in string with UK date format DD/MM/YYYY
   *
   * @method formatDateAsUkDateString
   * @param {Date|number} dateObj
   * @return {string}
   */
  formatDateAsUkDateString(dateObj) {
    return Fecha.format(dateObj, 'ukDate');
  },

  /**
   * Format a date in string in UK date time format DD/MM/YYYY HH:mm:ss.SSS
   *
   * @method formatDateAsUkDateTimeString
   * @param {Date|number} dateObj
   * @return {string}
   */
  formatDateAsUkDateTimeString(dateObj) {
    return Fecha.format(dateObj, 'ukDateTime');
  },

  /**
   * Get a date object in UTC timezone with the current date
   *
   * @method getCurrentUtcDate
   * @return {Date}
   */
  getCurrentUtcDate() {
    const now = new Date();
    return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  },

  /**
   * Get a date object in UTC timezone with the current datetime
   *
   * @method getCurrentUtcDateTime
   * @return {Date}
   */
  getCurrentUtcDateTime() {
    const now = new Date();
    return new Date(
      Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(),
        now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds()));
  },

  /**
   * Get the current datetime in UK datetime format string DD/MM/YYYY HH:mm:ss.SSS
   *
   * @method getCurrentUkDateTimeString
   * @return {string}
   */
  getCurrentUkDateTimeString() {
    const now = this.getCurrentUtcDateTime();
    return Fecha.format(now, 'ukDateTime');
  },

  /**
   * Get the current datetime in UK date format string DD/MM/YYYY
   *
   * @method getCurrentUkDateString
   * @return {string}
   */
  getCurrentUkDateString() {
    const now = this.getCurrentUtcDate();
    return Fecha.format(now, 'ukDate');
  },
};
