/*
 * custom checkers
 *
 * these replace the previous custom matchers as very annoyingly Jasmine does not seem to support async / await
 * in custom matchers
 */

// load common
const regExConstants = require('./regex-constants.js');
const dateHelper = require('./date.helper');

// load tests
const resultMessaging = require('./result-messaging.js');


// private functions

async function isElementDisplayed(element) {
  let displayed;

  try {
    displayed = await element.isDisplayed();
  } catch (e) {
    resultMessaging.publishFailWithException(
      'Calling .isDisplayed() on element failed (perhaps element does not exist?)', e);
  }

  if (!displayed) {
    await resultMessaging.publishFailWithElement(element, 'Element is not displayed');
    return false;
  }

  return true;
}

/**
 * @param element: element to be checked
 * @param element: subElement to be checked
 * @description check for SVG image - using XLINK:HREF for image source
 */
async function anySvgImageWithXlinkHrefAsSource(element, subElement) {
  // check for SVG image - using XLINK:HREF for image source
  let result = true;
  const xlinkHref = await subElement.getAttribute('xlink:href');

  if (xlinkHref.length === 0) {
    await resultMessaging.publishFailWithElement(element,
      'Element \'xlink:href\' attribute is zero length');
    result = false;
  } else {
    const matches = await xlinkHref.match(regExConstants.regExContainsValidUrl);

    if (!matches) {
      await resultMessaging.publishFailWithElement(element,
        `Element 'xlinkHref:href' attribute is not in in expected format: xlinkHref:href = "${xlinkHref}"`);
      result = false;
    }
  }

  return result;
}

/**
 * @param element: element to be checked
 * @param href: href to be checked
 * @description check for SVG image - using HREF for image source
 */
async function anySvgImageWithHrefAsSource(element, href) {
  let result = true;

  if (href.length === 0) {
    await resultMessaging.publishFailWithElement(element,
      'Element \'href\' attribute is zero length');
    result = false;
  } else {
    const matches = await href.match(regExConstants.regExContainsValidUrl);

    if (!matches) {
      await resultMessaging.publishFailWithElement(element,
        `Element 'href' attribute is not in in expected format: href = "${href}"`);
      result = false;
    }
  }

  return result;
}

async function getSvgImageSubElement(element) {
  const svgImageSubElement = await element.element(by.tagName('svg')).element(by.tagName('use'));
  const present = await browser.isElementPresent(svgImageSubElement);

  if (!present) {
    await resultMessaging.publishFailWithElement(element,
      'Element is not an SVG image as required \'svg > use\' sub-element is not present');
    return false;
  }

  return svgImageSubElement;
}

/**
 * @param element: element to be checked
 * @description check for SVG image
 */
async function anySvgImage(element) {
  let result = true;
  const svgImageSubElement = await getSvgImageSubElement(element);

  if (!svgImageSubElement) {
    // note error already raised
    return false;
  }

  const href = await svgImageSubElement.getAttribute('href');

  if (href === null) {
    result = await anySvgImageWithXlinkHrefAsSource(element, svgImageSubElement);
  } else {
    result = await anySvgImageWithHrefAsSource(element, href);
  }

  return result;
}

/**
 * @param element: element to be checked
 * @param imageSource: image source to be checked
 * @description check for traditional HTML image
 */
async function anyHtmlImage(element, imageSource) {
  let result = true;

  if (imageSource.length === 0) {
    await resultMessaging.publishFailWithElement(element,
      'Element \'src\' attribute is zero length');
    result = false;
  } else {
    const matches = await imageSource.match(regExConstants.regExContainsValidUrl);

    if (!matches) {
      await resultMessaging.publishFailWithElement(element,
        `Element 'src' attribute is not in in expected format: src = "${imageSource}"`);
      result = false;
    }
  }

  return result;
}

/**
 * @example
 * const value = await element.getAttribute('value');
 * await checkers.isInputElement(footer.marshLink, value);
 * @param element: element to be checked
 * @param elementValueAttribute: 'value' attribute of element
 */
async function isInputElement(element, elementValueAttribute) {
  if (elementValueAttribute === null) {
    await resultMessaging.publishFailWithElement(element,
      'Element is not an input element (no \'value\' attribute)');
    return false;
  }

  return true;
}

function getStringToCheckDescription(isElementInputElement) {
  if (isElementInputElement) {
    return 'Input element \'value\' attribute';
  }

  return 'Element text';
}

/**
 * @example
 * const href = await element.getAttribute('href');
 * await checkers.containsValidUrl(footer.marshLink, href);
 * @param element: element to be checked
 * @param stringToCheck: 'href' attribute' element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function containsValidUrl(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);

  if (stringToCheck === null) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} is not a link (it has no 'href' attribute)`);
    result = false;
  } else if (stringToCheck.length === 0) {
    await resultMessaging.publishFailWithElement(element,
      'Element \'href\' attribute contains no text');
    result = false;
  } else {
    const matches = stringToCheck.match(regExConstants.regExContainsValidUrl);

    if (!matches) {
      await resultMessaging.publishFailWithElement(element,
        `${stringDescription} 'href' attribute "${stringToCheck}" does not contain a valid URL`);
      result = false;
    }
  }

  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.isValidUkDate(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function isValidUkDate(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExEqualToUkDate);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" is not in UK date format`);
    result = false;
  } else if (dateHelper.parseUkDate(matches[0]) === false) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" is not valid UK date`);
    result = false;
  }

  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.containsValidUkDate(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function containsValidUkDate(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExContainsUkDate);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" does not contain string in UK date format`);
    result = false;
  } else if (dateHelper.parseUkDate(matches[0]) === false) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" does not contain valid UK date`);
    result = false;
  }

  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.isValidGbp(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function isValidGbp(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExEqualToGbp);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" is not a value in GBP format`);
    result = false;
  } else {
    const indexOfDot = await stringToCheck.indexOf('.');

    if (indexOfDot > 0) {
      if (stringToCheck.substr(indexOfDot + 1).length !== 2) {
        await resultMessaging.publishFailWithElement(element,
          `${stringDescription} "${stringToCheck}" is not a value in GBP format as not to 2 decimal places`);
        result = false;
      }
    }
  }
  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.isValidPercent(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function isValidPercent(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExEqualToPercent);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" is not a value in a valid percentage format`);
    result = false;
  } else {
    const indexOfDot = await stringToCheck.indexOf('.');

    if (indexOfDot > 0) {
      if (stringToCheck.substr(indexOfDot + 1).length !== 3) {
        await resultMessaging.publishFailWithElement(element,
          `${stringDescription} "${stringToCheck}" is not formatted to 2 decimal places`);
        result = false;
      }
    }
  }
  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.isValidNumber(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function isValidNumber(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExEqualToNumber);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" is not a valid number`);
    result = false;
  }
  return result;
}

/**
 * @example
 * const text = await element.getText();
 * await checkers.containsValidNumber(footer.marshLink, text);
 * @param element: element to be checked
 * @param stringToCheck: text of element / 'value' attribute of input element
 * @param isElementInputElement: true / false
 */
async function containsValidNumber(element, stringToCheck, isElementInputElement) {
  let result = true;
  const stringDescription = getStringToCheckDescription(isElementInputElement);
  const matches = await stringToCheck.match(regExConstants.regExContainsNumber);

  if (!matches) {
    await resultMessaging.publishFailWithElement(element,
      `${stringDescription} "${stringToCheck}" does not contain a valid number`);
    result = false;
  }
  return result;
}


// public functions


module.exports = {

  /**
   * @example
   * await checkers.noText(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementWithNoText
   */
  async noText(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      if (text.length !== 0) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element contains text where none expected: text = "${text}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyText(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementWithAnyText
   */
  async anyText(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      if (text.length === 0) {
        result = await resultMessaging.publishFailWithElement(element, 'Element contains no text');
      } else {
        const matches = await text.match(regExConstants.regExForAnyAlphanumericString);

        if (!matches) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text does not contain alphanumeric characters: text = "${text}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyTextOf20CharsPlus(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementWithAnyTextOf20CharactersPlus
   */
  async anyTextOf20CharsPlus(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      if (text.length < 20) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text contains less than 20 characters: text = "${text}"`);
      } else {
        const matches = await text.match(regExConstants.regExForAnyAlphanumericString);

        if (!matches) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text does not contain alphanumeric characters: text = "${text}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactText(footer.marshLink, 'Marsh');
   * @param element: element to be checked
   * @param expected: text to be checked (exact match)
   * @description replaces old Jasmine custom matcher toBeElementWithText
   */
  async exactText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      if (text !== expected) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" does not equal expected "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingText(footer.marshLink, 'Marsh');
   * @param element: element to be checked
   * @param expected: text to be checked (contains match)
   * @description replaces old Jasmine custom matcher toBeElementContainingText
   */
  async containingText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      if (text.indexOf(expected) === -1) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" does not contain expected "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingTextIgnoreCase(footer.marshLink, 'Marsh');
   * @param element: element to be checked
   * @param expected: text to be checked (contains match, will ignore case)
   * @description replaces old Jasmine custom matcher toBeElementContainingTextIgnoreCase
   */
  async containingTextIgnoreCase(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      // note use of toString() to ensure toLowerCase() always works
      // otherwise it can fail stating '.toLowerCase is not a function' e.g. if expected is a number
      if (text.toString().toLowerCase().indexOf(expected.toString().toLowerCase()) === -1) {
        result = await resultMessaging.publishFailWithElement(element,
          `Ignoring case, element text "${text}" does not contain expected "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.notContainingText(footer.marshLink, 'Marshy bogs');
   * @param element: element to be checked
   * @param expected: text to be checked (NOT contains match)
   * @description replaces old Jasmine custom matcher toBeElementNotContainingText
   */
  async notContainingText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();

      if (text.indexOf(expected) !== -1) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" should not contain "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyUkDate(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementWithAnyUkDate
   */
  async anyUkDate(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidUkDate(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyUkDateOrNA(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementWithAnyUkDateOrNA
   */
  async anyUkDateOrNA(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      const matches = await text.match(regExConstants.regExEqualToUkDateOrNA);

      if (!matches) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" is not in UK date format or "N/A" or "--"`);
      } else if (dateHelper.parseUkDate(matches[0]) === false && matches[0] !== 'N/A' && matches[0] !== '--') {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" does not contain UK date or "N/A" or "--"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactUkDate(footer.marshLink, '30/06/2019');
   * @param element: element to be checked
   * @param expected: date to be checked (exact match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithUkDate
   * note [expected] argument must be in UK date format dd/mm/yyyy
   */
  async exactUkDate(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidUkDate(element, text, false);

      if (result) {
        const actualDateString = dateHelper.parseUkDateString(text);
        const expectedDateString = dateHelper.parseUkDateString(expected);

        if (actualDateString !== expectedDateString) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" does not equal expected date "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingAnyUkDate(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementContainingAnyUkDate
   */
  async containingAnyUkDate(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await containsValidUkDate(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingUkDate(footer.marshLink, '30/06/2019');
   * @param element: element to be checked
   * @param expected: date to be checked (contains match)
   * @description
   * replaces old Jasmine custom matcher toBeElementContainingUkDate
   * note [expected] argument must be in UK date format dd/mm/yyyy
   */
  async containingUkDate(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await containsValidUkDate(element, text, false);

      if (result) {
        const matches = await text.match(regExConstants.regExContainsUkDate);
        const actualDateString = dateHelper.parseUkDateString(matches[0]);
        const expectedDateString = dateHelper.parseUkDateString(expected);

        if (actualDateString !== expectedDateString) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" does not contain expected date "${expectedDateString}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingCurrentUkDate(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementContainingCurrentUkDate
   */
  async containingCurrentUkDate(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await containsValidUkDate(element, text, false);

      if (result) {
        const matches = await text.match(regExConstants.regExContainsUkDate);
        const actualDateString = dateHelper.parseUkDateString(matches[0]);
        const currentDateString = dateHelper.getCurrentUkDateString();

        if (actualDateString !== currentDateString) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" does not contain current date "${currentDateString}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyUkYear(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWithAnyUkYear
   */
  async anyUkYear(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      const potentialUkDate = `01/01/${text}`;
      const matches = await potentialUkDate.match(regExConstants.regExEqualToUkDate);

      if (!matches) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" is not in UK year format`);
      } else if (dateHelper.parseUkDate(matches[0]) === false) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element text "${text}" does not contain UK year`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyGbp(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWithAnyGbp
   */
  async anyGbp(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidGbp(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactGbp(footer.marshLink);
   * @param element: element to be checked
   * @param expected: GBP UK currency amount to be checked (exact match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithGbp
   * note [expected] argument must be in UK GBP format £n.nn
   */
  async exactGbp(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidGbp(element, text, false);

      if (result) {
        const amount = await Number(text.replace(regExConstants.regExToExtractGbpSymbols, ''));
        const expectedAsNumber = await Number(expected.replace(regExConstants.regExToExtractGbpSymbols, ''));

        if (amount !== expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not expected GBP amount "£${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isGbpGreaterThan(footer.marshLink, '£100,00.10');
   * @param element: element to be checked
   * @param expected: GBP UK currency amount to be checked (greater than match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithGbpGreaterThan
   * note [expected] argument must be in UK GBP format £n.nn
   */
  async isGbpGreaterThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidGbp(element, text, false);

      if (result) {
        const amount = await Number(text.replace(regExConstants.regExToExtractGbpSymbols, ''));
        const expectedAsNumber = await Number(expected.replace(regExConstants.regExToExtractGbpSymbols, ''));

        if (amount <= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not greater than GBP amount "£${expectedAsNumber}`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isGbpLessThan(footer.marshLink, '£100,00.10');
   * @param element: element to be checked
   * @param expected: GBP UK currency amount to be checked (less than match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithGbpLessThan
   * note [expected] argument must be in UK GBP format £n.nn
   */
  async isGbpLessThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidGbp(element, text, false);

      if (result) {
        const amount = await Number(text.replace(regExConstants.regExToExtractGbpSymbols, ''));
        const expectedAsNumber = await Number(expected.replace(regExConstants.regExToExtractGbpSymbols, ''));

        if (amount >= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not less than GBP amount "£${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyImage(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWithAnyImage
   *
   * Checks whether an element contains an image (looks for the 'src' attribute
   * OR the 'href' attribute within an <svg><use> tagged element OR the 'xlink:href' attribute
   * within an <svg><use> tagged element)
   */
  async anyImage(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const imageSource = await element.getAttribute('src');

      if (imageSource === null) {
        // check for SVG image
        result = await anySvgImage(element);
      } else {
        // check for traditional HTML image
        result = await anyHtmlImage(element, imageSource);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactImage(footer.marshLink
   *   , 'https://v218-dal-qa-merceros.mercer.com:10491/resources/files/pages/mercer_client_logo.png');
   * @param element: element to be checked
   * @param expected: 'src' / 'href' attribute value as appropriate (exact match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithImage
   *
   * Checks whether an element contains an image (looks for the 'src' attribute
   * OR the 'href' attribute within an <svg><use> tagged element OR the 'xlink:href' attribute
   * within an <svg><use> tagged element)
   */
  async exactImage(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const imageSource = await element.getAttribute('src');

      if (imageSource === null) {
        // check for SVG image
        const svgImageSubElement = await getSvgImageSubElement(element);

        if (!svgImageSubElement) {
          // note error already raised
          return false;
        }

        const href = await svgImageSubElement.getAttribute('href');

        if (href === null) {
          const xlinkHref = await svgImageSubElement.getAttribute('xlink:href');

          // check for SVG image - using XLINK:HREF for image source
          if (xlinkHref !== expected) {
            result = await resultMessaging.publishFailWithElement(element,
              `Element 'xlink:href' attribute "${xlinkHref}" is not expected "${expected}"`);
          }
        // check for SVG image - using HREF for image source
        } else if (href !== expected) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'href' attribute "${href}" is not expected "${expected}"`);
        }
      } else if (imageSource !== expected) {
        // check for traditional HTML image fails
        result = await resultMessaging.publishFailWithElement(element,
          `Element 'src' attribute "${imageSource}" is not expected "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingImage(footer.marshLink, '/files/pages/product_logo_white');
   * @param element: element to be checked
   * @param expected: 'src' / 'href' attribute value as appropriate (contains match)
   * @description
   * replaces old Jasmine custom matcher toBeElementContainingImageSource
   *
   * Checks whether an element contains an image where the 'src' attribute contains the [expected] argument
   * OR the 'href' attribute within an <svg><use> tagged element OR the 'xlink:href' attribute
   * within an <svg><use> tagged element)
   */
  async containingImage(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const imageSource = await element.getAttribute('src');

      if (imageSource === null) {
        // check for SVG image
        const svgImageSubElement = await getSvgImageSubElement(element);

        if (!svgImageSubElement) {
          // note error already raised
          return false;
        }

        const href = await svgImageSubElement.getAttribute('href');

        if (href === null) {
          const xlink = await svgImageSubElement.getAttribute('xlink:href');

          // check for SVG image - using XLINK:HREF for image source
          if (xlink.indexOf(expected) === -1) {
            result = await resultMessaging.publishFailWithElement(element,
              `Element 'xlink:href' attribute "${xlink}" does not contain expected image source link "${expected}"`);
          }
        // check for SVG image - using HREF for image source
        } else if (href.indexOf(expected) === -1) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'href' attribute "${href}" does not contain expected image source link "${expected}"`);
        }
      } else if (imageSource.indexOf(expected) === -1) {
        // check for traditional HTML image fails
        result = await resultMessaging.publishFailWithElement(element,
          `Element 'src' attribute "${imageSource}" does not contain expected image source link "${expected}"`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.readOnly(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWhichIsReadOnly
   */
  async readOnly(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');

      if (value !== null) {
        if (value.length !== 0) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element is not read only as it has a 'value' attribute: 'value' = "${value}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputNoText(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeInputWithNoText
   */
  async inputNoText(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        if (value.length !== 0) {
          result = await resultMessaging.publishFailWithElement(element,
            `Input element is not read only as it has a 'value' attribute: 'value' = "${value}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputAnyText(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeInputWithAnyText
   */
  async inputAnyText(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        const matches = await value.match(regExConstants.regExForAnyAlphanumericString);

        if (!matches) {
          result = await resultMessaging.publishFailWithElement(element,
            `Input element 'value' attribute is not in in expected alphanumeric format: 'value' = "${value}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputAnyText(changeBankAccountDetailsPage.bankSortCodeValue, '60-17-21');
   * @param element: element to be checked
   * @param expected: input text (exact match)
   * @description
   * replaces old Jasmine custom matcher toBeInputWithText
   */
  async inputExactText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        if (value !== expected) {
          result = await resultMessaging.publishFailWithElement(element,
            `Input element 'value' attribute "${value}" is not expected "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputContainingText(changeBankAccountDetailsPage.bankSortCodeValue, '60-17');
   * @param element: element to be checked
   * @param expected: input text (contains match)
   * @description
   * replaces old Jasmine custom matcher toBeInputContainingText
   */
  async inputContainingText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        if (value.indexOf(expected) === -1) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'value' attribute "${value}" does not contain expected "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputNotContainingText(changeBankAccountDetailsPage.bankSortCodeValue, '60-17-DUMMY');
   * @param element: element to be checked
   * @param expected: input text (not contains match)
   * @description
   * replaces old Jasmine custom matcher toBeInputNotContainingText
   */
  async inputNotContainingText(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        if (value.indexOf(expected) !== -1) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'value' attribute "${value}" should not contain "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.inputAnyGbpNumberFormat(changeBankAccountDetailsPage.bankSortCodeValue);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeInputWithAnyNumberInGbpFormat
   *
   * Note this tests for numerical values in input field in GBP format without the GBP '£' symbol
   * e.g. '123.45' not '£123.45'
   * as it assume the '£' will be shown as a label outside the input field
   */
  async inputAnyGbpNumberFormat(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const value = await element.getAttribute('value');
      const elementIsInput = await isInputElement(element, value);

      if (elementIsInput) {
        const matches = await value.match(regExConstants.regExEqualToNumberInGbpFormat);

        if (!matches) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'value' attribute "${value}" is not in GBP format`);
        }

        const indexOfDot = await value.indexOf('.');

        if (indexOfDot > 0) {
          if (value.substr(indexOfDot + 1).length !== 2) {
            result = await resultMessaging.publishFailWithElement(element,
              `Element 'value' attribute "${value}" is not formatted to 2 decimal places`);
          }
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyPercent(changeBankAccountDetailsPage.bankSortCodeValue);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWithAnyPercent
   */
  async anyPercent(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidPercent(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactPercent(changeBankAccountDetailsPage.bankSortCodeValue, '4.99%');
   * @param element: element to be checked
   * @param expected: element text as percentage e.g. '4.99%' (exact match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithPercent
   */
  async exactPercent(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidPercent(element, text, false);

      if (result) {
        const percentageAmount
            = await Number(text.replace(regExConstants.regExToExtractPercentSymbols, ''));
        const expectedAsNumber
            = await Number(expected.replace(regExConstants.regExToExtractPercentSymbols, ''));

        if (percentageAmount !== expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not expected "${expectedAsNumber}%`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isPercentGreaterThan(changeBankAccountDetailsPage.bankSortCodeValue, '4.99%');
   * @param element: element to be checked
   * @param expected: element text as percentage e.g. '4.99%' (greater than match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithPercentGreaterThan
   */
  async isPercentGreaterThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidPercent(element, text, false);

      if (result) {
        const percentageAmount
            = await Number(text.replace(regExConstants.regExToExtractPercentSymbols, ''));
        const expectedAsNumber
            = await Number(expected.replace(regExConstants.regExToExtractPercentSymbols, ''));

        if (percentageAmount <= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not greater than "${expectedAsNumber}%`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isPercentLessThan(changeBankAccountDetailsPage.bankSortCodeValue, '4.99%');
   * @param element: element to be checked
   * @param expected: element text as percentage e.g. '4.99%' (less than match)
   * @description
   * replaces old Jasmine custom matcher toBeElementWithPercentLessThan
   */
  async isPercentLessThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidPercent(element, text, false);

      if (result) {
        const percentageAmount
            = await Number(text.replace(regExConstants.regExToExtractPercentSymbols, ''));
        const expectedAsNumber
            = await Number(expected.replace(regExConstants.regExToExtractPercentSymbols, ''));

        if (percentageAmount >= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not less than "${expectedAsNumber}%`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyNumber(footer.marshLink);
   * @param element: element to be checked
   * @description
   * replaces old Jasmine custom matcher toBeElementWithAnyNumber
   */
  async anyNumber(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidNumber(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingTextIgnoreCase(footer.marshLink, 2);
   * @param element: element to be checked
   * @param numberOfDecimalPlacesRequired: number of decimal places for number
   * @description replaces old function resultMessaging.isElementDisplayedContainingNumber
   */
  async anyNumberToSpecifiedDp(element, numberOfDecimalPlacesRequired) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)

      // safety check for ridiculous DPs
      const dpAsInteger = parseInt(numberOfDecimalPlacesRequired, 10);

      // eslint-disable-next-line no-restricted-globals
      if (isNaN(dpAsInteger) || dpAsInteger < -10 || dpAsInteger > 10) {
        result = await resultMessaging.publishFailWithElement(element,
          'The anyNumberToSpecifiedDp() function must be called with numberOfDecimalPlacesRequired'
        + ' as an integer between -10 and 10');
      } else {
        const text = await element.getText();
        result = await isValidNumber(element, text, false);

        if (result) {
          const textAsNumber = text;
          const textAsNumberToDp = textAsNumber.toFixed(dpAsInteger);

          if (textAsNumber !== textAsNumberToDp) {
            result = await resultMessaging.publishFailWithElement(element,
              `Element text "${text}" is not a number rounded to the expected`
              + ` ${dpAsInteger} decimal places`);
          }
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactNumber(footer.marshLink, 223);
   * @param element: element to be checked
   * @param expected: element text as number e.g. '213' (exact match)
   * @description replaces old Jasmine custom matcher toBeElementWithNumber
   */
  async exactNumber(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidNumber(element, text, false);

      if (result) {
        const amount = await Number(text);
        const expectedAsNumber = await Number(expected);

        if (amount !== expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not expected number "${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isNumberGreaterThan(footer.marshLink, 223);
   * @param element: element to be checked
   * @param expected: element text as number e.g. '213' (greater than match)
   * @description replaces old Jasmine custom matcher toBeElementWithNumberGreaterThan
   */
  async isNumberGreaterThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidNumber(element, text, false);

      if (result) {
        const amount = await Number(text);
        const expectedAsNumber = await Number(expected);

        if (amount <= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not a number greater than "${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isNumberLessThan(footer.marshLink, 223);
   * @param element: element to be checked
   * @param expected: element text as number e.g. '213' (less than match)
   * @description replaces old Jasmine custom matcher toBeElementWithNumberLessThan
   */
  async isNumberLessThan(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await isValidNumber(element, text, false);

      if (result) {
        const amount = await Number(text);
        const expectedAsNumber = await Number(expected);

        if (amount >= expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" is not a number less than "${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingAnyNumber(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementContainingAnyNumber
   */
  async containingAnyNumber(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await containsValidNumber(element, text, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingNumber(footer.marshLink, 223);
   * @param element: element to be checked
   * @param expected: element text as number e.g. '213' (contains match)
   * @description replaces old Jasmine custom matcher toBeElementContainingNumber
   */
  async containingNumber(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const text = await element.getText();
      result = await containsValidNumber(element, text, false);

      if (result) {
        const amount = await Number(text);
        const expectedAsNumber = await Number(expected);

        if (amount !== expectedAsNumber) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element text "${text}" does not contain expected number "${expectedAsNumber}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.anyLink(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeElementContainingAnyLink
   */
  async anyLink(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const href = await element.getAttribute('href');
      result = await containsValidUrl(element, href, false);
    }

    return result;
  },

  /**
   * @example
   * await checkers.exactLink(footer.marshLink, 'https://www.marsh.com/');
   * @param element: element to be checked
   * @param expected: expected link e.g. 'https://www.marsh.com/' (exact match)
   * @description replaces old Jasmine custom matcher toBeElementWithLink
   */
  async exactLink(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const href = await element.getAttribute('href');
      result = await containsValidUrl(element, href, false);

      if (result) {
        if (href !== expected) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'href' attribute "${href}" is not expected link "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.containingLink(footer.marshLink, 'https://www.marsh');
   * @param element: element to be checked
   * @param expected: expected link e.g. 'https://www.marsh.com/' (exact match)
   * @description replaces old Jasmine custom matcher toBeElementContainingLink
   */
  async containingLink(element, expected) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      const href = await element.getAttribute('href');
      result = await containsValidUrl(element, href, false);

      if (result) {
        if (href.indexOf(expected) === -1) {
          result = await resultMessaging.publishFailWithElement(element,
            `Element 'href' attribute  "${href}" does not contain expected link "${expected}"`);
        }
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isMercerOsButtonSelected(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeMercerOSButtonSelected
   *
   * Please see contents in function for how MercerOS buttons have to be rendered for this to work
   */
  async isMercerOsButtonSelected(element) {
    let result = true;
    let mosButtonStyle;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      let isSelectedMosButton = true;
      const value = await element.getAttribute('class');

      if (value === null || value === '') {
        isSelectedMosButton = false;
      } else if (value.indexOf('mos-c-button') === -1) {
        // not a button at all
        isSelectedMosButton = false;
      } else if (value.indexOf('sub-category-button') === -1) {
        mosButtonStyle = 'new';

        if (value.indexOf('mos-c-button--flat') !== -1) {
          /*
           * not new-style selected MOS button
           * e.g. where selected button:
           *   class="mos-c-button--md mos-c-button--expanded-small-down mos-c-button"
           * and unselected button
           *   class="mos-c-button--md mos-c-button--expanded-small-down mos-c-button mos-c-button--flat"
           */
          isSelectedMosButton = false;
        }
      } else {
        mosButtonStyle = 'old';

        if (value.indexOf('mos-c-button--flat') !== -1 && value.indexOf('mos-c-button--active') === -1) {
        /*
         * not old-style selected MOS button
         * e.g. where selected button:
         *   class="sub-category-button mos-c-button--md mos-c-button mos-c-button--flat mos-c-button--active"
         * and unselected button
         *   class="sub-category-button mos-c-button--md mos-c-button mos-c-button--flat"
         */
          isSelectedMosButton = false;
          mosButtonStyle = 'old';
        }
      }

      if (!isSelectedMosButton) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element is not a selected MercerOS button (${mosButtonStyle}-style)`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isMercerOsButtonUnselected(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeMercerOSButtonUnselected
   *
   * Please see contents in function for how MercerOS buttons have to be rendered for this to work
   */
  async isMercerOsButtonUnselected(element) {
    let result = true;
    let mosButtonStyle;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      let isUnselectedMosButton = true;
      const value = await element.getAttribute('class');

      if (value === null || value === '') {
        isUnselectedMosButton = false;
      } else if (value.indexOf('mos-c-button') === -1) {
        // not a button at all
        isUnselectedMosButton = false;
      } else if (value.indexOf('mos-c-button--active') !== -1) {
        isUnselectedMosButton = false;
      } else if (value.indexOf('sub-category-button') === -1) {
        mosButtonStyle = 'new';

        if (value.indexOf('mos-c-button--flat') === -1) {
        /*
         * not new-style unselected MOS button
         * e.g. where selected button:
         *   class="mos-c-button--md mos-c-button--expanded-small-down mos-c-button"
         * and unselected button
         *   class="mos-c-button--md mos-c-button--expanded-small-down mos-c-button mos-c-button--flat"
         */
          isUnselectedMosButton = false;
          mosButtonStyle = 'new';
        }
      } else {
        mosButtonStyle = 'old';

        if (value.indexOf('mos-c-button--flat') !== -1 && value.indexOf('mos-c-button--active') !== -1) {
        /*
         * not old-style unselected MOS button
         * e.g. where selected button:
         *   class="sub-category-button mos-c-button--md mos-c-button mos-c-button--flat mos-c-button--active"
         * and unselected button
         *   class="sub-category-button mos-c-button--md mos-c-button mos-c-button--flat"
         */
          isUnselectedMosButton = false;
          mosButtonStyle = 'old';
        }
      }

      if (!isUnselectedMosButton) {
        result = await resultMessaging.publishFailWithElement(element,
          `Element is not an unselected MercerOS button (${mosButtonStyle}-style)`);
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isMercerOsTabSelected(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeMercerOSTabSelected
   *
   * This will work with MercerOS tabs shown as selected rendered with HTML like the following:
   *   <div _ngcontent-c45="" class="ov-content-card-tab ov-content-card-tab-active">
   *     <a _ngcontent-c45="" class="mos-u-text-overflow" id="tab-0">Help</a>
   *   </div>
   */
  async isMercerOsTabSelected(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      let isSelectedMosTab = true;
      const value = await element.getAttribute('class');

      if (value === null || value === '') {
        isSelectedMosTab = false;
      } else if (value.indexOf('ov-content-card-tab-active') === -1) {
        isSelectedMosTab = false;
      }

      if (!isSelectedMosTab) {
        result = await resultMessaging.publishFailWithElement(element,
          'Element is not a selected MercerOS tab');
      }
    }

    return result;
  },

  /**
   * @example
   * await checkers.isMercerOsTabUnselected(footer.marshLink);
   * @param element: element to be checked
   * @description replaces old Jasmine custom matcher toBeMercerOSTabUnselected
   *
   * This will only work with MercerOS tabs shown as unselected rendered with HTML like the following:
   *   <div _ngcontent-c45="" class="ov-content-card-tab">
   *     <a _ngcontent-c45="" class="mos-u-text-overflow" id="tab-1">Contact Us</a>
   *   </div>
   * where selected tabs are shown with HTML like:
   *   <div _ngcontent-c45="" class="ov-content-card-tab ov-content-card-tab-active">
   *     <a _ngcontent-c45="" class="mos-u-text-overflow" id="tab-0">Help</a>
   *   </div>
   */
  async isMercerOsTabUnselected(element) {
    let result = true;
    result = await isElementDisplayed(element);

    if (result && !global.ov3TestIsRunOnSauceLabs) {
      // only run full matcher when not run on Sauce Labs (SL will not support network speed required)
      let isUnselectedMosTab = true;
      const value = await element.getAttribute('class');

      if (value === null || value === '') {
        isUnselectedMosTab = false;
      } else if (value.indexOf('ov-content-card-tab-active') !== -1) {
        isUnselectedMosTab = false;
      }

      if (!isUnselectedMosTab) {
        result = await resultMessaging.publishFailWithElement(element,
          'Element is not an unselected MercerOS tab');
      }
    }

    return result;
  },
};
