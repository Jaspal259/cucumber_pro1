// tests
module.exports = {
  // private functions


  // private properties


  // exposed properties


  // exposed functions

  async bringElementIntoView(el) {
    await browser.executeScript('arguments[0].scrollIntoView();', el.getWebElement());
  },

  reverseString(str) {
    let reversedString = '';
    let i = str.length;

    while (i > 0) {
      reversedString += str.substr(i - 1, 1);
      i -= 1;
    }

    return reversedString;
  },

  getRandomNumber(min, max, numberOfDecimalPlaces) {
    if (max < min) {
      throw new Error(`The max argument [${max} must be greater than the min [${min}]]`);
    }

    return ((Math.random() * (max - min)) + min).toFixed(numberOfDecimalPlaces);
  },

  async scrollToBottomOfPage() {
    await browser.actions().sendKeys(protractor.Key.TAB).perform();
  },
};
