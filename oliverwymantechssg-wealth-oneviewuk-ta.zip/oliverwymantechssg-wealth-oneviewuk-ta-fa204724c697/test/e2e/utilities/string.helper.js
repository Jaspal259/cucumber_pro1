module.exports = {

  /**
   * Create random text with the specified length from the set of characters.
   *
   * @param characterLength
   * @returns {string}
   */
  getRandomString(characterLength) {
    let randomText = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < characterLength; i += 1) {
      randomText += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return randomText;
  }
};
