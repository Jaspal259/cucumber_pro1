/*
 * regular expressions
 *
 * note to use these in a regular expression you have to use: new RegExp()
 */


// REGULAR EXPRESSION STRINGS - components for use in regex objects
// -------------------------------------------------------------------------------

/*
  g modifier: global. All matches (don't return after first match)
  m modifier: multi line. Causes ^ and $ to match the begin/end of each line (not only begin/end of string)
  i modifier: insensitive. Case insensitive match (ignores case of [a-zA-Z])
 */
const regExGlobalPatternFlagsForCaseInsensitive = 'gmi';


// UK character set - note these are strings not RegEx objects
// ----------------------------------------------------------------------------
// note includes underscores, dots and dashes to support words like 'Dr.', 're-use', 'client_login'
const regExUkLetters = 'a-zA-Z';
const regExNumbers = '0-9';
const regExDot = '\\.';                    // is.
const regExDotAsWord = '[\\.]';            // is .
const regExDash = '\\-';                   // is -
const regExForwardSlash = '\\/';           // is /
const regExBrackets = '\\(\\)\\[\\]{}';    // is ()[]{}
const regExPunctuation = `_${regExDot}${regExDash}:`;   // note dot has to come before dash to work

// for use in names in sentences etc - note no space character
const regExExtendedPunctuation = `${regExPunctuation},!"'${regExBrackets}`;

// for use in names in sentences etc - note no space character
const regExExtendedPunctuationAndSpace = `${regExExtendedPunctuation} `;

const regExUkWordLettersOnly = `[${regExUkLetters}]+`;
const regExUkWordWithNumbers = `[${regExUkLetters}${regExNumbers}]+`;
const regExUkWordWithNumbersAndPunctuation
    = `[${regExUkLetters}${regExNumbers}${regExPunctuation}]+`;
const regExUkWordWithNumbersAndExtendedPunctuation
    = `[${regExUkLetters}${regExNumbers}${regExExtendedPunctuation}]+`;
const regExUkSentence
    = `[${regExUkLetters}${regExNumbers}${regExExtendedPunctuationAndSpace}]+`;


// for URLs, websites names, email addresses

/*
  this RegEx string should resolve to the RegEx
  [a-zA-Z0-9_\-]+([\.][a-zA-Z]+){1,2}

  which will pass, for instance
    'Mercer-test_01.co.UK'
  and
    'View Mercer-test_01.co.UK for further details'
 */
const regExUkWebsiteName
    = `[${regExUkLetters}${regExNumbers}_${regExDash}]`
    + `(${regExDotAsWord}${regExUkLetters}){1,2}}`;

const regExWww = `www${regExDot}`;
const regExHttpOrHttps = `(http)s?:${regExForwardSlash}{2}`;
const regExOptionalHttpOrHttpsWithWww = `(${regExHttpOrHttps})?(${regExWww})?`;

/*
    this RegEx string should resolve to the RegEx
    ((http)s?:\/\/)?(www[\.])?[a-zA-Z0-9_\-]+([\.][a-zA-Z]+){1,2}

    which will pass, for instance
      'Mercer-test_01.co.UK'
      'www.Mercer-test_01.co.UK'
      'https://www.Mercer-test_01.co.UK'
      'http://Mercer-test_01.co.UK'
    and
      'View Mercer-test_01.co.UK for further details'
   */
const regExUkWebsiteNameFull = `${regExOptionalHttpOrHttpsWithWww}${regExUkWebsiteName}`;

/*
    this RegEx string should resolve to the RegEx
    ((http)s?:\/\/)?(www[\\.])?[a-zA-Z0-9_\-\/\.:']+

    which will pass, for instance
      'localhost:4444/wd/hub/static/resource/hub.html'
      'Mercer-test_01.co.UK'
      'www.Mercer-test_01.co.UK'
      'https://www.Mercer-test_01.co.UK'
      'http://Mercer-test_01.co.UK'
    and
      'View Mercer-test_01.co.UK for further details'
   */
const regExUkUrl = `${regExOptionalHttpOrHttpsWithWww}`
    + `[${regExUkLetters}${regExNumbers}${regExPunctuation}${regExForwardSlash}]+`;

/*
    this RegEx string should resolve to the RegEx
    [a-zA-Z0-9_\.\-]+@[a-zA-Z0-9_\-]+([\.][a-zA-Z]+){1,2}

    which will pass, for instance
      'Deutschland-Großbritannien@Mercer-test_01.co.UK'
    and
      'Contact Deutschland-Großbritannien@Mercer-test_01.co.UK for further details'
   */
const regExUkEmailAddress = `${regExUkWordWithNumbersAndPunctuation}@${regExUkWebsiteName}`;


// REGULAR EXPRESSION OBJECTS
// -------------------------------------------------------------------------------

module.exports = {

  // RegExp objects:
  // for checking strings
  // ----------------------------------------------------------------------------
  regExForAnyAlphanumericString: new RegExp(regExUkSentence),

  // regExForAnyAlphanumericString: new RegExp('[a-zA-Z]'),

  // regExForAnyAlphanumericString: new RegExp(`[${aZTest}]`),

  // note \ escape character usage e..g \( not just (
  regExForValidSpecialCharacters: new RegExp(/[&<>().-/|\\]*/),


  // RegExp objects:
  // for UK date
  // ----------------------------------------------------------------------------
  regExEqualToUkDate: new RegExp(/^(\d{1,2}\/\d{1,2}\/\d{4})$/),
  regExContainsUkDate: new RegExp(/(\d{1,2}\/\d{1,2}\/\d{4})/),
  regExEqualToUkDateOrNA: new RegExp(/^(\d{1,2}\/\d{1,2}\/\d{4}|(N\/A)|(--))$/),


  // RegExp objects:
  // for GBP - UK currency
  // ----------------------------------------------------------------------------
  regExEqualToGbp: new RegExp(/^[-+]?(£[\d,]+(.\d*))$/),

  /*
   * Note this tests for numerical values in input field in GBP format without the GBP '£' symbol
   * e.g. '123.45' not '£123.45'
   * as it assume the '£' will be shown as a label outside the input field
   */
  regExEqualToNumberInGbpFormat: new RegExp(/^[-+]?([\d,]*.[\d]+|[\d]+)$/),
  regExToExtractGbpSymbols: new RegExp(/[£,]*/g),


  // RegExp objects:
  // for percentage
  // ----------------------------------------------------------------------------
  regExEqualToPercent: new RegExp(/^[\d,]+(\.\d*)?%$/),
  regExToExtractPercentSymbols: new RegExp(/[%,]*/g),


  // RegExp objects:
  // for number
  // ----------------------------------------------------------------------------
  regExEqualToNumber: new RegExp(/^[-+]?([\d]*.[\d]+|[\d]+)$/),
  regExContainsNumber: new RegExp(/[-+]?([\d]*.[\d]+|[\d]+)/),


  // RegExp objects:
  // for URLs, websites names, email addresses
  // ----------------------------------------------------------------------------
  regExContainsValidUrl: new RegExp(`${regExUkUrl}`),
  regExContainsValidWebsiteUrl: new RegExp(`${regExUkWebsiteNameFull}`),
  regExContainsValidEmailAddress: new RegExp(`${regExUkEmailAddress}`),


  // RegExp objects:
  // for bank accounts
  // ----------------------------------------------------------------------------
  regExBankSortCode: new RegExp(/^((\d+)-(\*\*)-(\*\*))$/),
  regExBankAccount: new RegExp(/^(\*+)[a-zA-Z0-9]*$/),
  regExBankReferenceNumber: new RegExp(/^((\*+)[a-zA-Z0-9]*$)|(^Not(\s)Applicable)$/),
};
