// load common
const resultMessaging = require('./result-messaging.js');
const CommonConstants = require('./common-constants.js');
const DateHelper = require('./date.helper.js');
const checkers = require('./checkers.helper.js');

// create new objects
const commonConstants = new CommonConstants();

// other
const until = protractor.ExpectedConditions;

// tests
const commonTests = function commonTests() {
  // private functions

  // private properties

  const self = this;


  // exposed properties


  // exposed functions

  this.getOv3Environment = () => {
    switch (global.ov3TestEnvironment) {
      case 'dev':
        return commonConstants.appEnvironmentEnum.dev;
      case 'qa':
        return commonConstants.appEnvironmentEnum.qa;
      case 'uat':
        return commonConstants.appEnvironmentEnum.uat;
      case 'staging':
        return commonConstants.appEnvironmentEnum.staging;
      case 'prod':
        return commonConstants.appEnvironmentEnum.prod;
      default:
        throw new Error(`OV3 environment ${global.ov3TestEnvironment} not supported by this spec`);
    }
  };

  this.isPageOV3Page = async () => {
    expect(browser.getCurrentUrl()).toContain(browser.params.ov3RootUrl);
  };

  this.checkUnauthorisedHeaderElements = async (header) => {
    if (header === undefined) {
      throw new Error('The header is undefined');
    }

    await browser.wait(
      until.presenceOf(header.clientLogoImage),
      commonConstants.mediumMediumBrowserWaitDelay,
      'Client logo in header is not present');
  };

  this.checkHeaderElementsCommonToDesktopAndMobile = async (header) => {
    expect(header.commonHeader.isDisplayed()).toBe(true);
    await checkers.anyText(header.userProfileIcon);
    expect(header.userDropDown.isDisplayed()).toBe(true);
    await checkers.containingImage(header.userDropDownIcon, commonConstants.dropdownImageSource);
  };

  this.checkCommonHeader = async (header) => {
    if (header === undefined) {
      throw new Error('The header is undefined');
    }

    await self.checkUnauthorisedHeaderElements(header);

    if (!global.ov3TestIsRunOnSauceLabs) {
      switch (global.deviceType) {
        case commonConstants.appDeviceTypeEnum.desktop:
          await checkers.anyImage(header.commonHeaderBarMercerLogo);
          expect(header.commonHeaderBarLeft.isDisplayed()).toBe(true);
          expect(header.commonHeaderBarRight.isDisplayed()).toBe(true);
          await checkers.containingTextIgnoreCase(header.commonHeaderMenuHome, 'Home');
          await checkers.containingTextIgnoreCase(header.commonHeaderMenuHelpAndContacts(true), 'Help');
          await checkers.containingTextIgnoreCase(header.commonHeaderMenuHelpAndContacts(true), 'Contacts');
          await this.checkHeaderElementsCommonToDesktopAndMobile(header);
          break;

        case commonConstants.appDeviceTypeEnum.mobile:
          await checkers.containingImage(header.mobileHeaderBurgerMenu.burgerMenuButton,
            commonConstants.burgerMenuImageSource);
          await this.checkHeaderElementsCommonToDesktopAndMobile(header);
          break;

        default:
          throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
      }
    }
  };

  this.checkEvenIfInOutageFooterElements = async (footer) => {
    if (footer === undefined) {
      throw new Error('The footer is undefined');
    }

    await browser.wait(
      until.visibilityOf(footer.commonFooter),
      commonConstants.mediumShortBrowserWaitDelay,
      'Footer not shown');

    if (!global.ov3TestIsRunOnSauceLabs) {
      await checkers.containingImage(footer.mercerFooterLogoImage,
        '/mercer-assets/img/logos/mmc/mmc_logo_rgb.png'
      );

      // external MMC links
      await checkers.exactText(footer.marshLink, 'Marsh');
      expect(footer.marshLink.getAttribute('href')).toContain('https://www.marsh.com');
      await checkers.exactText(footer.guyCarpenterLink, 'Guy Carpenter');
      expect(footer.guyCarpenterLink.getAttribute('href')).toContain(
        'http://www.guycarp.com/content/guycarp/en/home.html');
      await checkers.exactText(footer.mercerLink, 'Mercer');
      expect(footer.mercerLink.getAttribute('href')).toContain('https://www.mercer.com');
      await checkers.exactText(footer.oliverWymanLink, 'Oliver Wyman');
      expect(footer.oliverWymanLink.getAttribute('href')).toContain('http://www.oliverwyman.com/index.html');

      // internal footer links are not shown when site in outage

      // brand bar (footer of footer)
      await checkers.containingImage(footer.mercerBrandBarLogoImage,
        '/mercer-assets/img/logos/mercer/mercer_mtt_horizontal_rgb.png');

      await self.doesCommonFooterShowCopyrightSymbol(footer);
      await self.doesCommonFooterShowCopyrightLabel(footer);
      await self.doesCommonFooterShowCopyrightYear(footer);
      await self.doesCommonFooterShowMercerMissionStatementLogo(footer);
    }
  };

  this.checkUnauthorisedFooterElements = async (footer) => {
    if (footer === undefined) {
      throw new Error('The footer is undefined');
    }

    // note footer internal links are not shown when site in outage
    await self.checkEvenIfInOutageFooterElements(footer);

    if (!global.ov3TestIsRunOnSauceLabs) {
      // internal footer links
      await checkers.containingTextIgnoreCase(footer.termsOfUseLink, 'Terms');
      expect(footer.termsOfUseLink.getAttribute('href')).toContain('terms-of-use');
      await checkers.containingTextIgnoreCase(footer.cookiePolicyLink, 'Cookie');
      expect(footer.cookiePolicyLink.getAttribute('href')).toContain('cookie-policy');
      await checkers.containingTextIgnoreCase(footer.accessibilityStatementLink, 'Accessibility');
      expect(footer.accessibilityStatementLink.getAttribute('href')).toContain('accessibility-policy');
    }
  };

  this.checkCommonFooter = async (footer) => {
    if (footer === undefined) {
      throw new Error('The footer is undefined');
    }

    // note footer appears the same now whether authorised or unauthorised page
    await self.checkUnauthorisedFooterElements(footer);
  };

  this.doesCommonFooterShowCopyrightSymbol = async (footer) => {
    await checkers.containingText(footer.copyrightLabel, '©');
  };

  this.doesCommonFooterShowCopyrightLabel = async (footer) => {
    await checkers.containingTextIgnoreCase(footer.copyrightLabel, 'MERCER LLC, ALL RIGHTS RESERVED');
  };

  this.doesCommonFooterShowCopyrightYear = async (footer) => {
    expect(footer.copyrightLabel.isDisplayed()).toBe(true);

    const copyright = await footer.copyrightLabel.getText();
    const d = new Date();
    const copyrightYear = parseInt(copyright.substr(2, 4), 10);
    expect(copyrightYear).toEqual(d.getFullYear());
  };

  this.doesCommonFooterShowMercerMissionStatementLogo = async (footer) => {
    await checkers.containingImage(footer.mercerBrandBarLogoImage,
      '/mercer-assets/img/logos/mercer/mercer_mtt_horizontal_rgb.png'
    );
  };

  this.printToConsoleLogWithStartAndDateTime = async (message) => {
    await this.printToConsoleLogWithDateTime(`${message} started`);
  };

  this.printToConsoleLogWithDateTime = async (message) => {
    // eslint-disable-next-line no-console
    await console.log(`${message} at ${DateHelper.getCurrentUkDateTimeString()}`);
  };

  this.printToConsoleLogWithDateTimeAndMemoryUsage = async (message) => {
    await this.printToConsoleLogWithDateTime(message);
    await this.debugBrowserMemoryUsage();
  };

  this.debugBrowserMemoryUsage = async () => {
    const result = await browser.driver.executeScript('return window.performance.memory');

    // eslint-disable-next-line no-console
    await console.log(`Browser memory: jsHeapSizeLimit : ${result.jsHeapSizeLimit}`);

    // eslint-disable-next-line no-console
    await console.log(`Browser memory: usedJSHeapSize : ${result.usedJSHeapSize}`);

    // eslint-disable-next-line no-console
    await console.log(`Browser memory: totalJSHeapSize : ${result.totalJSHeapSize}`);
  };

  // note this function is designed to be called directly or indirectly in the afterAll() block of each describe()
  this.clearBrowserCacheAndCookies = async () => {
    if (global.ov3ClearCacheAndCookiesAfterEachDescribeBlock) {
      // as suggested by July 9 2018 comment https://github.com/timgrossmann/InstaPy/issues/2379
      await browser.manage().deleteAllCookies();

      // cache
      await browser.executeScript('window.sessionStorage.clear();');
      await browser.executeScript('window.localStorage.clear();');
    }

    await this.openNewBrowserTabAndCloseOtherTabs();
  };

  this.checkLoginPageShownAfterLogout = async (loginPage) => {
    await this.checkUnauthPageLoadsAndContainsStandardElements(loginPage);
    const userIdInputPresent = await browser.isElementPresent(loginPage.userIdInput);

    if (userIdInputPresent !== true) {
      await this.clearBrowserCacheAndCookies();
      throw new Error('Login page not shown after logout');
    } else {
      await this.clearBrowserCacheAndCookies();
    }
  };

  this.clickRelevantLogoutButton = async (header, loginPage) => {
    // note logging out can use the log out or log out (losing changes) button, whichever is present
    const logoutButton = await header.logoutModal.logoutButton(global.deviceType);
    const logoutLosingChangesButton = await header.logoutModal.logoutLosingChangesButton(global.deviceType);
    const logoutButtonPresent = await browser.isElementPresent(logoutButton);

    if (logoutButtonPresent) {
      await this.clickElement(logoutButton);
      await this.checkLoginPageShownAfterLogout(loginPage);
    } else {
      const logoutLosingChangesButtonPresent = await browser.isElementPresent(logoutLosingChangesButton);

      if (logoutLosingChangesButtonPresent) {
        await this.clickElement(logoutLosingChangesButton);
        await this.checkLoginPageShownAfterLogout(loginPage);
      } else {
        await this.clearBrowserCacheAndCookies();
        throw new Error('No logout or logout (losing changes) button present');
      }
    }
  };

  this.logOutUsingHeader = async (header, loginPage) => {
    const dropdownPresent = await browser.isElementPresent(header.userDropDown);

    if (dropdownPresent) {
      await this.clickElement(header.userDropDown);
      const logOutLinkPresent = await browser.isElementPresent(header.logoutLink);

      if (logOutLinkPresent) {
        await this.clickElement(header.logoutLink);
        const logoutModalPresent
          = await browser.isElementPresent(header.logoutModal.footerContainer(global.deviceType));

        if (logoutModalPresent) {
          await this.clickRelevantLogoutButton(header, loginPage);
        } else {
          await this.clearBrowserCacheAndCookies();
          fail('No logout modal present');
        }
      } else {
        await this.clearBrowserCacheAndCookies();
        fail('No logout link present');
      }
    } else {
      await this.clearBrowserCacheAndCookies();
      fail('No header dropdown present');
    }
  };

  this.logOut = async (page, loginPage) => {
    await self.logOutUsingHeader(page.header, loginPage);
  };

  this.checkLoginFailedMessageDisplayed = async (loginPage) => {
    expect(browser.getCurrentUrl()).toContain(loginPage.url);
    await checkers.containingImage(loginPage.toast.infoIcon, commonConstants.toastErrorIconImageSource);
    await checkers.containingTextIgnoreCase(loginPage.toast.heading, 'Access denied');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'forgotten');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'ID');
    await checkers.containingTextIgnoreCase(loginPage.toast.message, 'passcode');
    await checkers.containingImage(loginPage.toast.closeIcon, commonConstants.toastCloseIconImageSource);
  };

  this.checkPageHeroImage = async () => {
    // not ideal to define element here rather than in a page component object but since
    // here element definition and images differ quite substantially and since it
    // is only 1 element it was not worth creating a new page component object and adding
    // it to every page object
    const heroElement = await element(by.tagName('mercer-hero'));
    const heroElementPresenceWait = commonConstants.shortBrowserWaitDelay;
    await browser.wait(until.presenceOf(heroElement),
      heroElementPresenceWait,
      `No hero image is present (waited ${heroElementPresenceWait}ms)`);
    const heroElementPresent = await heroElement.isPresent();

    // probably don't really need heroElementPresent check but being bulletproof as used for many tests
    if (heroElementPresent) {
      const heroImageElement = await heroElement.element(by.className('mos-c-hero__blend-mode--hue'));
      const heroImageVisibilityWait = commonConstants.shortBrowserWaitDelay;
      await browser.wait(
        until.visibilityOf(heroImageElement),
        heroImageVisibilityWait,
        `No hero image is displayed (waited ${heroImageVisibilityWait}ms)`);
      const heroImageDisplayed = await heroImageElement.isDisplayed();

      // probably don't really need heroImageDisplayed check but being bulletproof as used for many tests
      if (heroImageDisplayed) {
        expect(heroImageElement.getAttribute('style')).toContain('background-image');
        expect(heroImageElement.getAttribute('style')).toContain('/files/pages');
        expect(heroImageElement.getAttribute('style')).toContain('gradient');

        // check for expected image extension e.g. 'jpg', 'png'
        const style = await heroImageElement.getAttribute('style');
        let isImage = false;

        for (let i = 0; i < commonConstants.ov3RasterImageSourceExtensions.length; i += 1) {
          if (style.indexOf(commonConstants.ov3RasterImageSourceExtensions[i]) !== -1) {
            isImage = true;
            break;
          }
        }

        if (isImage === false) {
          fail('Hero image element does not contain expected image extension e.g. jpg');
        }
      }
    }
  };

  this.checkUnauthPageLoadsAndContainsStandardElements = async (page, pageHasHeroImage) => {
    if (page.url === undefined) {
      throw new Error('The page.url property is undefined');
    }

    await browser.wait(
      until.urlContains(page.url),
      commonConstants.mediumBrowserWaitDelay,
      `Current page does not have URL containing ${page.url}`);
    expect(browser.getCurrentUrl()).toContain(page.url);
    await self.checkUnauthorisedHeaderElements(page.header);
    await self.checkUnauthorisedFooterElements(page.footer);

    if (!global.ov3TestIsRunOnSauceLabs) {
      await self.isPageOV3Page();

      if (pageHasHeroImage) {
        await self.checkPageHeroImage();
      }
    }
  };

  this.checkPageLoadsAndContainsStandardElements = async (page) => {
    if (page.url === undefined) {
      throw new Error('The page.url property is undefined');
    }

    await browser.wait(
      until.urlContains(page.url),
      commonConstants.mediumBrowserWaitDelay,
      `Current page does not have URL containing ${page.url}`);
    expect(browser.getCurrentUrl()).toContain(page.url);
    await self.checkCommonHeader(page.header);
    await self.checkCommonFooter(page.footer);

    if (!global.ov3TestIsRunOnSauceLabs) {
      await self.isPageOV3Page();
      await self.checkPageHeroImage();
    }
  };

  this.checkPlanPageLoadsAndContainsPlanHeader = async (planPage) => {
    await this.checkPageLoadsAndContainsStandardElements(planPage);

    // additional wait required to ensure page has actually loaded
    const summaryLink = element(by.id('summaryLink'));
    await browser.wait(
      until.visibilityOf(summaryLink),
      commonConstants.mediumMediumBrowserWaitDelay,
      'Plan summary page header summary link is not shown (and so page has probably not fully loaded');

    if (global.deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      const navigationMenuLinksScroller = element(by.tagName('ov-nav-bar'));
      const moreButton = navigationMenuLinksScroller.element(by.tagName('mercer-dropdown'));
      await browser.wait(
        until.visibilityOf(moreButton),
        commonConstants.mediumMediumBrowserWaitDelay,
        'Plan summary page header more... link is not shown (and so page has probably not fully loaded');
    }
  };

  /**
   * @param mediaLink             - element which needs to be clicked to obtain linked URL
   * @param mediaLinkDescription  - text description of element
   * @example
   * const mediaUrl = await commonTests.getUrlOfMediaLink(
   *   planMaterials.planMaterialsAction(rowIndex),
   *   `planMaterials.planMaterialsAction(${rowIndex})`,
   *   false);
   * console.log(`mediaUrl in checkPlanMaterialsTypeSizeAndActionData [${mediaUrl}]`);
   * this.checkIconIsCorrectForMediaLinkType(mediaUrl, planMaterials, rowIndex);
   */
  this.getUrlOfMediaLink = async (mediaLink, mediaLinkDescription) => {
    // note this function is for when an element azcts as a link to another URL but that URL
    // is not contained within the rendered HTML for the element so the only easier way to obtain the
    // link is to click the element and then check the URL of the new browser window opened

    let result = commonConstants.notYetDefined;
    let mediaUrl;

    if (global.isHeadlessChrome) {
      /*
        if headless Chrome runs the code in the else block below you get Chrome cache population errors

        e.g.
        [0903/182048.291:ERROR:in_progress_cache_impl.cc(191)] Cache is not initialized, cannot RetrieveEntry.
        [0903/182048.291:ERROR:in_progress_cache_impl.cc(175)] Cache is not initialized, cannot AddOrReplaceEntry.
        [0903/182048.292:ERROR:in_progress_cache_impl.cc(191)] Cache is not initialized, cannot RetrieveEntry.
       */
      return commonConstants.notSupportedYet;
    }

    if (global.browserName === 'chrome') {
      /*
        This has had to be disabled for Chrome at the moment

        MGTI have switched on and locked the 'Ask where to save each file before downloading' option
        in Chrome which means an OS dialogue box opens up when downloading any download file which will not open
        in the browser itself (such as a .docx file).

        it should be possible to fix this by setting the following chromeOptions.prefs in
        capabilities-defaults.conf.js but unfortunately MGTI have locked the option (even when using a Mercer machine
        in admin so this does not work

          download: {
            prompt_for_download: false,
          }

        ref: https://github.com/angular/protractor/issues/5269
       */
      return commonConstants.notSupportedYet;
    }

    // check link element exists (also helps with firing this function in correct order)
    expect(mediaLink.isDisplayed()).toBe(true);

    // check we can use link element
    await browser.wait(
      until.elementToBeClickable(mediaLink),
      commonConstants.shortBrowserWaitDelay,
      `${mediaLinkDescription} element is not clickable`);
    await this.clickElement(mediaLink);

    // assume media page is not Angular
    try {
      await browser.waitForAngularEnabled(false);
    } catch (e) {
      resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
    }

    // let the URL load (and if a download let the 2nd window auto-close)
    await browser.sleep(commonConstants.momentaryBrowserWaitDelay);
    const handles = await browser.getAllWindowHandles();
    const siteWindowHandle = handles[0];
    const mediaWindowHandle = handles[1];

    switch (handles.length) {
      case 2:
        // a separate window has opened so this must be a link to an external site
        // or an internal site page or a download which can be opened in the browser (e.g. PDF)
        await browser.switchTo().window(mediaWindowHandle);
        mediaUrl = await browser.getCurrentUrl();

        // close the media window
        await browser.close();

        // switch back to the OV3 site
        await browser.switchTo().window(siteWindowHandle);

        // ensure Angular waiting is switched back on
        try {
          await browser.waitForAngularEnabled(true);
        } catch (e) {
          resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
        }

        expect(mediaLink.isDisplayed()).toBe(true);
        result = mediaUrl;
        break;

      case 1:
        // no separate window has opened (and stayed open) so this must be a download

        // ensure Angular waiting is switched back on
        try {
          await browser.waitForAngularEnabled(true);
        } catch (e) {
          resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
        }

        expect(mediaLink.isDisplayed()).toBe(true);

        // we have no easy way of determining what the download was so just fix the returned URL
        // to the base download URL of the site
        result = browser.params.ov3RootDownloadUrl;

        break;

      default:
        // ensure Angular waiting is switched back on
        try {
          await browser.waitForAngularEnabled(true);
        } catch (e) {
          resultMessaging.publishFailWithException('Calling browser.waitForAngularEnabled failed', e);
        }

        fail(`A setting of handles.length of [${handles.length}] is not supported`);
    }


    return result;
  };

  this.getParticipantStatusFromNumber = (participantStatusValueAsNumber) => {
    let participantStatusValue;

    switch (participantStatusValueAsNumber) {
      case 0:
        participantStatusValue = 'NO STATUS';
        break;
      case 1:
        participantStatusValue = 'ACTIVE';
        break;
      case 2:
        participantStatusValue = 'LEAVER - OPTIONS PENDING';
        break;
      case 3:
        participantStatusValue = 'EXIT-NO FURTHER LIABILITY';
        break;
      case 4:
        participantStatusValue = 'DEFERRED';
        break;
      case 5:
        participantStatusValue = 'RETIREMENT';
        break;
      case 6:
        participantStatusValue = 'DEPENDANT PENSIONER';
        break;
      case 7:
        participantStatusValue = 'DEATH';
        break;
      case 8:
        participantStatusValue = 'ACTIVE-LIFE ASSURANCE ONLY';
        break;
      default:
        throw new Error(`The participantStatusValueAsNumber of [${participantStatusValueAsNumber}] is not supported`);
    }

    return participantStatusValue;
  };

  this.checkAccordionStatus = async (accordion, expectedToBeOpen) => {
    const icon = await accordion.all(by.tagName('mercer-icon')).get(0);
    const expandedContent = accordion.element(by.tagName('mercer-accordion-expanded'));

    if (expectedToBeOpen) {
      await checkers.containingImage(icon, commonConstants.keyboardArrowUpImageSource);
      await checkers.anyTextOf20CharsPlus(expandedContent);
    } else {
      await checkers.containingImage(icon, commonConstants.keyboardArrowDownImageSource);
      expect(expandedContent.isDisplayed()).toBe(false);
    }
  };

  this.getParentElement = async el => el.element(by.xpath('..'));

  this.getMobileOrDesktopLocator = (locatorSeed, deviceType) => {
    let fullLocator = locatorSeed;

    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        // e.g. id - "DCCard-0"
        fullLocator = locatorSeed;
        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        // e.g. id - "mobileDCCard-0"
        fullLocator = `${commonConstants.mobileName}${locatorSeed}`;
        break;
      default:
        throw new Error(
          `The deviceType '${deviceType}' is not supported.`
        + ' Please ensure no tests are switched off using xdescribe.');
    }

    return fullLocator;
  };

  this.clickElement = async (el) => {
    const failMessage = 'Clicking element failed';

    /*
      always wait for element to be clickable (needed as Jenkins so slow, particularly in UAT
      note that this will slow down test execution a little but the reliability improvement makes this worthwhile
     */
    await browser.wait(
      until.elementToBeClickable(el),
      commonConstants.shortBrowserWaitDelay,
      'Element is not clickable');

    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        try {
          await el.click();
        } catch (e) {
          resultMessaging.publishFailWithException(failMessage, e);
        }

        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        if (!global.ov3TestIsRunUsingChromeMobileEmulation) {
          try {
            await el.click();
          } catch (e) {
            resultMessaging.publishFailWithException(failMessage, e);
          }
        } else {
          /*
            use direct JS command
            this is required because there is a known issue with el.click() for Chrome mobile emulation
            https://github.com/SeleniumHQ/selenium/issues/4075
           */
          try {
            await browser.executeScript(
              'arguments[0].click();',
              el);
          } catch (e) {
            resultMessaging.publishFailWithException(failMessage, e);
          }
        }

        break;
      default:
        throw new Error(
          `The deviceType '${global.deviceType}' is not supported.`
          + ' Please ensure no tests are switched off using xdescribe.');
    }
  };

  this.getDesktopCommonHeaderLinkElement = async (header, commonHeaderLinkRequired, isAuthPage) => {
    await this.forceCallingFunctionToBeSynchronous;
    let el;

    switch (commonHeaderLinkRequired) {
      case header.commonHeaderLinkEnum.home:
        el = header.commonHeaderMenuHome;
        break;
      case header.commonHeaderLinkEnum.help:
        el = header.commonHeaderMenuHelpAndContacts(isAuthPage);
        break;
      case header.commonHeaderLinkEnum.contactUs:
        el = header.commonHeaderMenuHelpAndContacts(isAuthPage);
        break;
      case header.commonHeaderLinkEnum.notifications:
        el = header.commonHeaderNotificationsIcon;
        break;
      case header.commonHeaderLinkEnum.viewProfile:
        el = header.viewProfileLink;
        break;
      case header.commonHeaderLinkEnum.logOut:
        el = header.logoutLink;
        break;
      default:
        fail(`The common header link '${commonHeaderLinkRequired}' requested is not supported`);
    }

    return el;
  };

  this.getMobileCommonHeaderLinkElement = async (header, commonHeaderLinkRequired) => {
    await this.forceCallingFunctionToBeSynchronous();
    let el;

    switch (commonHeaderLinkRequired) {
      case header.commonHeaderLinkEnum.home:
        el = header.mobileHeaderBurgerMenu.homeLink;
        break;
      case header.commonHeaderLinkEnum.help:
        el = header.mobileHeaderBurgerMenu.helpLink;
        break;
      case header.commonHeaderLinkEnum.contactUs:
        el = header.mobileHeaderBurgerMenu.contactUsLink;
        break;
      case header.commonHeaderLinkEnum.notifications:
        el = header.mobileHeaderBurgerMenu.notificationsLink;
        break;
      case header.commonHeaderLinkEnum.viewProfile:
        el = header.mobileHeaderBurgerMenu.viewProfileLink;
        break;
      case header.commonHeaderLinkEnum.logOut:
        el = header.mobileHeaderBurgerMenu.logoutLink;
        break;
      default:
        fail(`The common header link '${commonHeaderLinkRequired}' requested is not supported`);
    }

    return el;
  };

  this.clickCommonHeaderLink = async (header, commonHeaderLinkRequired, isAuthPage) => {
    let linkElement;

    if (header === undefined) {
      fail('The header is undefined');
    } else {
      switch (global.deviceType) {
        case commonConstants.appDeviceTypeEnum.desktop:
          linkElement = await this.getDesktopCommonHeaderLinkElement(header, commonHeaderLinkRequired, isAuthPage);

          switch (commonHeaderLinkRequired) {
            case header.commonHeaderLinkEnum.viewProfile:
            case header.commonHeaderLinkEnum.logOut:
              // use dropdown at top right
              await this.clickElement(header.userDropDown);
              await this.clickElement(linkElement);
              break;
            default:
              await this.clickElement(linkElement);
          }
          break;

        case commonConstants.appDeviceTypeEnum.mobile:
          linkElement = await this.getMobileCommonHeaderLinkElement(header, commonHeaderLinkRequired);
          await this.clickElement(header.mobileHeaderBurgerMenu.burgerMenuButton);
          await this.clickElement(linkElement);
          break;

        default:
          fail(`global.deviceType '${global.deviceType}' is not supported`);
      }
    }
  };

  this.clickExpandMoreButtonIfMobile = async (mobileExpandMoreElement) => {
    switch (global.deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        // do nothing
        return;

      case commonConstants.appDeviceTypeEnum.mobile:
        await this.clickElement(mobileExpandMoreElement);
        break;

      default:
        fail(`global.deviceType '${global.deviceType}' is not supported`);
    }
  };

  async function closeBrowserTab(specificBrowserTabHandle) {
    await browser.switchTo().window(specificBrowserTabHandle);
    await browser.close();
  }

  async function closeAllBrowserTabsExceptSpecified(browserTabHandles, tabIndexToLeaveOpen) {
    for (let i = 0; i < browserTabHandles.length; i += 1) {
      if (i !== tabIndexToLeaveOpen) {
        await closeBrowserTab(browserTabHandles[i]);
      }
    }
  }

  this.openNewBrowserTabAndCloseOtherTabs = async () => {
    // open a new blank browser tab
    await browser.executeScript('window.open("")');
    const handles = await browser.getAllWindowHandles();
    const newTabIndex = handles.length - 1;

    // close the old tab(s)
    await closeAllBrowserTabsExceptSpecified(handles, newTabIndex);

    // focus on the browser tab left open
    await browser.switchTo().window(handles[newTabIndex]);
  };

  this.forceCallingFunctionToBeSynchronous = async () => {
    // await here forces this function to be synchronous
    await browser.sleep(commonConstants.blipBrowserWaitDelayUsedOnlyToForceAsyncFunctionToWait);
  };
};
module.exports = commonTests;
