/*
 * generic common constants
 */

module.exports = {

  // for messages
  messageSeparator: ' | ',
};
