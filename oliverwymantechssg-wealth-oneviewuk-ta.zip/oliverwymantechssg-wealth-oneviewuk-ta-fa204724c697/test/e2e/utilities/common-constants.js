const commonConstants = function commonConstants() {
  this.appEnvironmentEnum = {
    dev: 0,
    qa: 1,
    uat: 2,
    staging: 3,
    prod: 4
  };

  this.appDeviceTypeEnum = {
    // note number also refers to index of element where desktop and mobile versions of element on page
    // e.g. desktop = 0 = .first() of element duplicates
    // use this enum when resetting global.deviceType for mobile testing / resetting for desktop testing
    desktop: 0,       // includes tablet if desktop resolution
    mobile: 1         // includes tablet if phone resolution
  };

  this.appUrlTypeEnum = {
    page: 0,    // e.g. `${browser.params.ov3RootUrl}wealth-snapshot/OVTL/17150/summary`
    download: 1, // e.g. `${browser.params.ov3RootDownloadUrl}api/plans/pip/OVTL/920/materials/payslips/download?id=60`
  };

  this.ov3RasterImageSourceExtensions = [
    'jpg', 'jpeg', 'png', 'bmp', 'gif'
  ];

  // for BDD
  this.bddScenarioPrefix = ': Scenario - ';
  this.bddScenarioSuffixTestManually = ' - test manually';
  this.bddAdditionalCheckAddedByTe = '[TE test] ';
  this.bddNotCheckedForMobileYet = '***NOT YET FULLY TESTED FOR MOBILE*** ';

  // for messages
  this.messageSeparator = ' - | - ';

  // for use with value initialisation
  this.notYetDefined = 'not yet defined';

  // OV3
  this.dcTypeLabel = 'DEFINED CONTRIBUTION (DC) PLAN';
  this.dbTypeLabel = 'DEFINED BENEFIT (DB) PLAN';
  this.pensionerTypeLabel = 'PENSIONS IN PAYMENT (PIP)';
  this.posStatusLabel = 'Status';
  this.beneficiaryTabLumpSum = 'lump sum';
  this.beneficiaryTabDependants = 'dependants';
  this.desktopName = 'desktop';
  this.mobileName = 'mobile';
  this.notSupportedYet = 'not supported yet';

  // image folders
  this.mercerIconFolder = '#';
  this.otherMercerIconFolder = '/mercer-assets/icons/symbol-defs.svg#';

  // MercerOS image prefixes
  this.mosIconPrefixNoBadge = `${this.mercerIconFolder}mos-icon-`;
  this.mosIconPrefixWithBadge = `${this.mercerIconFolder}mos-badge-`;
  this.mosVectorIconPrefix = `${this.mercerIconFolder}mos-vector-icon`;   // note this prefix has no dash at end

  // Mercer OS images
  this.dropdownImageSource = `${this.mosIconPrefixNoBadge}expand_more`;
  this.toastErrorIconImageSource = `${this.mosIconPrefixNoBadge}error_outline`;
  this.toastCloseIconImageSource = `${this.mosIconPrefixNoBadge}close`;
  this.sorterImageSourceUpward = `${this.mosIconPrefixNoBadge}arrow_upward`;
  this.sorterImageSourceDownward = `${this.mosIconPrefixNoBadge}arrow_downward`;
  this.personImageSource = `${this.mosIconPrefixNoBadge}person`;
  this.emailOutlineImageSource = `${this.mosIconPrefixNoBadge}mail_outline`;
  this.keyboardArrowLeftImageSource = `${this.mosIconPrefixNoBadge}keyboard_arrow_left`;
  this.keyboardArrowUpImageSource = `${this.mosIconPrefixNoBadge}keyboard_arrow_up`;
  this.keyboardArrowDownImageSource = `${this.mosIconPrefixNoBadge}keyboard_arrow_down`;
  this.checkImageSource = `${this.mosIconPrefixNoBadge}check`;
  this.folderSharedImageSource = `${this.mosIconPrefixNoBadge}folder_shared`;
  this.dateRangeImageSource = `${this.mosIconPrefixNoBadge}date_range`;
  this.infoImageSource = `${this.mosIconPrefixNoBadge}info`;
  this.warningImageSource = `${this.mosIconPrefixNoBadge}warning`;
  this.accountCircleImageSource = `${this.mosIconPrefixNoBadge}account_circle`;
  this.currencyImageSource = `${this.mosVectorIconPrefix}currency`;
  this.piggyBankImageSource = `${this.mosVectorIconPrefix}piggy-bank`;
  this.piggyBank2ImageSource = `${this.mosVectorIconPrefix}piggybank2`;
  this.calculatorImageSource = `${this.mosVectorIconPrefix}calculator2`;
  this.presentationImageSource = `${this.mosVectorIconPrefix}presentation`;
  this.presentation2ImageSource = `${this.mosVectorIconPrefix}presentation2`;
  this.burgerMenuImageSource = `${this.mosIconPrefixNoBadge}menu`;

  // MercerOS data table images
  this.actionEditImageSource = `${this.mosIconPrefixNoBadge}mode_edit`;
  this.actionDeleteImageSource = `${this.mosIconPrefixNoBadge}delete`;
  this.actionPrintImageSource = `${this.mosIconPrefixNoBadge}print`;
  this.actionDownloadImageSource = `${this.mosIconPrefixNoBadge}get_app`;
  this.actionOpenPublicLinkImageSource = `${this.mosIconPrefixNoBadge}public`;
  this.pdfImageSource = `${this.mosIconPrefixNoBadge}picture_as_pdf`;
  this.zipImageSource = `${this.mosIconPrefixNoBadge}description`;
  this.linkImageSource = `${this.mosIconPrefixNoBadge}link`;

  // downloads
  // e.g. https://dal-uat-merceroneview.mercer.com/v1/oneview-be/resources/files
  this.unsecuredContentDownloadUrlRoot = `${browser.params.ov3RootDownloadUrl}resources/files`;
  this.downloadUrlSuffix = '/download?id=';

  // timeouts
  this.blipBrowserWaitDelayUsedOnlyToForceAsyncFunctionToWait = 10;
  this.momentaryBrowserWaitDelay = 1000;
  this.briefBrowserWaitDelay = 2000;
  this.shortBrowserWaitDelay = 5000;
  this.mediumShortBrowserWaitDelay = 10000;
  this.mediumMediumBrowserWaitDelay = 20000;
  this.mediumBrowserWaitDelay = 40000;
  this.longBrowserWaitDelay = 60000;

  // toast messages
  this.editSuccessToastMessage = 'You have successfully submitted your changes';

  // MercerOS (MOS) class names
  this.mosCssTableHeaderLabelRoot = 'mos-c-table__header--container';
  this.mosCssResponsiveImage = '.mos-u-responsive-img';
  this.mosCssModalContentWrapper = 'mos-c-modal__content-wrapper';

  // OV snapshot card
  this.ovSnapshotCssCardLeftTextGroup = 'columns small-6 mos-u-spacer--padding-left-none';
  this.ovSnapshotCssCardRightTextGroup = 'columns small-6 mos-u-spacer--padding-right-none';

  // unauthorised access messages
  this.unauthorisedAccessMessageText = 'Unauthorized';
  this.unauthorisedAccessMessageStatus = '401';
};
module.exports = commonConstants;
