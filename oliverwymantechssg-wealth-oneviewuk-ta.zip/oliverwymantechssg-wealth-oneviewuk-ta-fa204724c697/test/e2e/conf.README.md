# how the test execution config works

- To run tests you need to know:
  - The environment to run against - which is one of:
    - dev                   (the default if none specified)
    - qa
    - uat
    - staging               (aka CAT)
    - prod
  - The machine to run the test - which is one of:
    - local                 (your local machine)
    - jenkins               (Jenkins CI server)
  - How to run the test - which is one of:
    - Selenium Server       (for local only: run using Selenium Server)
    - directConnect         (run on a headless Chrome browser on the Jenkins server)
    - Sauce Labs            (run on 1 or more browsers on the Sauce Labs cloud service)
  - The suite you want to run e.g.:
    - debug                 (from your automator.conf.js when developing QA tests)
    - regression            (from the default.conf.js to run a full suite of all working tests as a regression test)
    - smoke                 (from the default.conf.js to run a subset of the regression suite as a smoke test)
- The config files work together in this order with the later files overriding the first:
    - default.conf.js         (contains most config)
    - [environment].conf.js   (contains environment-specific config e.g. qa-environment.js)
    - [run-type].conf.js      (contains config on how to run the test e.g. jenkins-direct-connect.conf.js)
    - automator.conf.js       (contains automator-specific config - most useful when developing tests)
- The deepmerge NPM package is used to amalgamate the above configurations


# how to setup your own automator.conf.js file (for developing / debugging tests)

- Navigate to the automation/test/e2e/config directory and create a file called automator.conf.js
  (note the automator.conf.js file is excluded from Bitbucket version control)
- Setup params, suites and other needed options. Please refer to automator.conf.example.js as an example of how to 
  set your local configuration up

  
# how to start Selenium server (only used for local testing and not using directConnect in config just yet because of error)
- In a separate command window (i.e. do *NOT* use the terminal integrated in the code editor 
  but instead use - for instance - **cmd.exe**) run the following commands:
  
    - `webdriver-manager update`
    - `webdriver-manager start`
    
  Please note the aobve relies on a global install of webdriver-manager. If this has not been done please execute:
  
  `npm install -g webdriver-manager`
  
  This command should be re-run every time the versions of the packages in package.json are updated to ensure 
  a current version is being used. 

- Check that the Selenium server starts without errors or warnings - the last line in the 
  command window should state:
  
    - `INFO - Selenium Server is up and running`
  
- You can kill dead sessions by using the Selenium server UI at:
  [http://localhost:4444/wd/hub](http://localhost:4444/wd/hub)


# how to run tests using Protractor (only suitable when running on local machine)

- Note this only applies when running locally as an automator
- Launch a command prompt (or use the integrated terminal window in WebStorm)
- Ensure you are in the root folder e.g.
  C:/Git/wealth-oneviewuk-ta
- Run: `protractor test/e2e/conf.js --params.env=[environment] --params.run-type=[run-type] --suite=[name of suite from conf.js]`
 
For instance, to run selected tests while developing / debugging on your local machine against QA:
  
`protractor test/e2e/conf.js --params.env=qa --params.run-type=local --suite=debug`  
  
For instance, to run the regression test suite on the Jenkins server against QA using directConnect:
  
`protractor test/e2e/conf.js --params.env=qa --params.run-type=jenkins-direct-connect --suite=regression`  
  
For instance, to run the smoke test suite on the Jenkins server against UAT using Sauce Labs:
  
`protractor test/e2e/conf.js --params.env=uat --params.run-type=sauce-labs-jenkins --suite=smoke`


# how to run tests using NPM (required for Jenkins)

- Jenkins cannot run Protractor directly (as no global Protractor install)
- Instead the necessary Protractor commands and arguments are wrapped in NPM packages  (see package.json)
- Launch a command prompt (or use the integrated terminal window in WebStorm)
- Ensure you are in the root folder e.g.
  C:/Git/wealth-oneviewuk-ta
- Run: `npm run [name of relevant te* script in automation package.json]`

For instance, to run selected tests while developing / debugging on your local machine against QA:
  
`npm run te-qa-local-debug`  
  
For instance, to run the regression test suite on the Jenkins server against QA using directConnect:
  
`npm run te-qa-jenkins-dc-regression`
  
For instance, to run the smoke test suite on the Jenkins server against UAT using Sauce Labs:
  
`npm run te-uat-jenkins-sl-smoke`


# note on running tests

- At the moment (Feb 2018) running a test will report this error in the integrated console:

  > (node:14196) [DEP0022] DeprecationWarning: os.tmpDir() is deprecated. Use os.tmpdir() instead.

  This has been reported for Protractor in the following issue but this has obviously not affected day to day
  running of tests as it has been closed without being resolved:
  [https://github.com/angular/protractor/issues/3799](https://github.com/angular/protractor/issues/3799)
  
- Running the tests using headless Chrome will report the following errors in the console ...
  
    - > "ERROR:gpu_process_transport_factory.cc(1009)] Lost UI shared context."
    - > "ERROR:instance.cc(49)] Unable to locate service manifest for metrics"
    - > "ERROR:service_manager.cc(890)] Failed to resolve service name: metrics"
  
  ... but these are really warnings which can be ignored according to:
  
    - [https://github.com/GoogleChrome/puppeteer/issues/1547](https://github.com/GoogleChrome/puppeteer/issues/1547)
    - [https://github.com/GoogleChrome/puppeteer/issues/1543](https://github.com/GoogleChrome/puppeteer/issues/1543)

- Running the tests using Sauce Labs requires a valid Sauce Labs user ID and password to be set in the following 
  Windows environment variables:
  
    - `ONEVIEW3_SAUCE_USERNAME`
    - `ONEVIEW3_SAUCE_ACCESS_KEY`
    
# how to detect whether suite of tests run has failed

- If failed the console will state:

  > Process exited with error code 1

- If run from an NPM package the console will also state: 

  > Exit status 1 
    
# how to view report after suite of tests run
- Open **\reports\TestAutomationReport.html**