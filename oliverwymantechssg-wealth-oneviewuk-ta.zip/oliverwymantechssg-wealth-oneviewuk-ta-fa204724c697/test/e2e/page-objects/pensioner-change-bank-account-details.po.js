// load common
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const PensionerPlanHeader = require('../page-component-objects/pensioner-plan-header.co');

// create new objects
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const pensionerChangeBankAccountDetailsPage = function pensionerChangeBankAccountDetailsPage() {
  // note full url will include client, plan type, Midas scheme code and POS primary key
  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/pip-plan-summary/OVTL/920/bank_account_details
  // but it is easier to check the bulk of the url using the relevant plan summary page and then just use the partial
  // url here to complete the check
  this.partialUrl = '/bank_account_details';

  // note also need to set something for this.url as used by the function used to check standard content on each page:
  // commonTests.checkPageLoadsAndContainsStandardElements(page);
  this.url = this.partialUrl;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new PensionerPlanHeader();

  // elements
  this.bankAccountDetailsLink = element(by.id('bank_account_detailsLink'));
  this.produceStatementButton = element(by.id('produceStatementButton'));
  this.bankAccountNumberValue = element(by.id('bankAccountNumberValue'));
  this.bankSortCodeValid = element(by.id('bankSortCodeValid'));
  this.bankAccountSortCodeRequiredErrorText = element(by.id('bankAccountSortCodeRequiredErrorText'));
  this.bankAccountNumberValueRequiredErrorText = element(by.id('bankAccountNumberValueRequiredErrorText'));
  this.invalidPasscodeErrorText = element(by.id('ctlIDRequiredErrorText'));
  this.bankAccountNumberValueInput = element(by.id('bankAccountNumberValueInput'));
  this.currentBankInformationDetails = element(by.id('currentBankInformationDetails'));
  this.bankSortCodeValue = element(by.id('bankAccountSortCodeInput'));
  this.bankAccountDetailsCancelButton = element(by.id('bankAccountDetailsCancelButton'));
  this.bankAccountDetailsSaveButton = element(by.id('bankAccountDetailsSaveButton'));
  this.loseChangesConfirmButton = deviceType => element.all(by.id('loseChangesConfirmButton')).get(deviceType);

  this.oneViewPasscodeField = element(by.id('ctlIDInput'));
  this.buildingSocietyRollNumberValueInput = element(by.id('buildingSocietyRollNumberValueInput'));
  this.bankAccountDetailsTable = element(by.className('mos-c-table mos-u-table--bordered mos-u-table--responsive'));
  this.bankAccountToastText = element(by.className('mos-c-toast__content mos-c-toast__content-close'));

  this.getBankSortCode = index => element(by.id(`bankSortCode-${index}`));
  this.getBankAccount = index => element(by.id(`bankAccountNumber-${index}`));
  this.getReferenceNumber = index => element(by.id(`buildingSocietyRollNumber-${index}`));
  this.bankAccountDetailsEditButton = index => element(by.id(`bankAccountDetailsEditButton-${index}`));

  this.getBankAccountDetailsColumn
    = index => element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(index);

  this.getBankAccountDetailsRecordCount = async () => {
    const rowCount = await this.bankAccountDetailsTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };
};

module.exports = pensionerChangeBankAccountDetailsPage;
