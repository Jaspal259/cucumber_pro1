// load common
const CommonConstants = require('../utilities/common-constants.js');
const CommonTests = require('../utilities/common-tests.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const PensionerPlanHeader = require('../page-component-objects/pensioner-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const Carousel = require('../page-component-objects/carousel.co.js');
const CarouselSlide = require('../page-component-objects/carousel-slide.co.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// page object
// note this uses a constructor format as the URL is data driven
const pensionerPlanSummaryPage = function pensionerPlanSummaryPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/pip-plan-summary/OVTL/920
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/pip-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2829';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '5';
        break;
      case commonConstants.appEnvironmentEnum.stage:
        articleId = '999 - TBA';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  // elements
  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.planHeader = new PensionerPlanHeader();

  // articles
  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);

  // carousel
  this.carousel = new Carousel();
  this.carouselBudgetPlannerSlide = new CarouselSlide(
    'Budget Planner',
    'pip_budgetingLabel',
    'pip_budgetingLink');

  // wealth snapshot cards
  this.snapshotCard = element.all(by.tagName('ov-snapshot-card'));

  this.getSnapshotCardCount = async () => {
    const cardCount = await this.snapshotCard.count();
    return cardCount;
  };

  this.grossPensionCard = element(by.id('GrossPenCard'));
  this.grossYtdCard = element(by.id('GrossYTDCard'));
  this.taxYtdCard = element(by.id('TaxYTDCard'));

  // details for wealth snapshot cards

  // Gross Pension Card
  this.grossPensionDesc = this.grossPensionCard.element(by.id('GrossPenLabel'));
  this.grossPensionContent = this.grossPensionCard.element(by.id('GrossPenContent'));
  this.grossPensionIcon = this.grossPensionContent.element(by.tagName('mercer-vector-icon'));
  this.grossPensionAmount = this.grossPensionContent.element(by.id('GrossPenAmount'));
  this.grossPensionAmountTerm = this.grossPensionContent.element(by.id('GrossPenYear'));
  this.grossPenAction = this.grossPensionCard.element(by.id('GrossPenAction'));

  // Gross YTD Card
  this.grossYtdDesc = this.grossYtdCard.element(by.id('GrossYTDLabel'));
  this.grossYtdContent = this.grossYtdCard.element(by.id('GrossYTDContent'));
  this.grossYtdIcon = this.grossYtdContent.element(by.tagName('mercer-vector-icon'));
  this.grossYtdAmount = this.grossYtdContent.element(by.id('GrossYTDAmount'));
  this.grossYtdFreqGroup = this.grossYtdContent.element(by.className(commonConstants.ovSnapshotCssCardLeftTextGroup));
  this.grossYtdPayFreqLabel = this.grossYtdFreqGroup.all(by.tagName('div')).get(0);
  this.grossYtdFreqAmount = this.grossYtdFreqGroup.all(by.tagName('div')).get(1);
  this.grossYtdNextGroup = this.grossYtdContent.element(by.className(commonConstants.ovSnapshotCssCardRightTextGroup));
  this.grossYtdNextPayDateLabel = this.grossYtdNextGroup.all(by.tagName('div')).get(0);
  this.grossYtdNextPayDateValue = this.grossYtdNextGroup.all(by.tagName('div')).get(1);

  // Tax YTD Card
  this.taxYtdDesc = this.taxYtdCard.element(by.id('TaxYTDLabel'));
  this.taxYtdContent = this.taxYtdCard.element(by.id('TaxYTDContent'));
  this.taxYtdIcon = this.taxYtdCard.element(by.tagName('mercer-vector-icon'));
  this.taxYtdAmount = this.taxYtdContent.element(by.id('TaxYTDAmount'));
  this.taxYtdTaxCodeGroup = this.taxYtdContent.element(by.className(commonConstants.ovSnapshotCssCardLeftTextGroup));
  this.taxYtdTaxCodeBasisLabel = this.taxYtdTaxCodeGroup.all(by.tagName('div')).get(0);
  this.taxYtdTaxCodeBasisValue = this.taxYtdTaxCodeGroup.all(by.tagName('div')).get(1);
  this.taxYtdTaxOfficeGroup = this.taxYtdContent.element(by.className(commonConstants.ovSnapshotCssCardRightTextGroup));
  this.taxYtdTaxOfficeRefLabel = this.taxYtdTaxOfficeGroup.all(by.tagName('div')).get(0);
  this.taxYtdTaxOfficeRefValue = this.taxYtdTaxOfficeGroup.all(by.tagName('div')).get(1);
  this.taxYtdAction = this.taxYtdCard.element(by.id('TaxYTDAction'));

  // tax modal
  this.taxModalHeader = element(by.tagName('mercer-modal-header'));
  this.taxModalContent = element(by.tagName('mercer-modal-content'));
  this.taxModalFooter = deviceType => element.all(by.tagName('mercer-modal-footer')).get(deviceType);
  this.taxModalContinue = deviceType => this.taxModalFooter(deviceType).element(by.id('continueButton'));

  this.taxOfficeAddressDetailsLabel = this.taxYtdCard.element(by.id('taxOfficeAddressDetailsLabel'));
  this.officeDistrictLabel = this.taxYtdCard.element(by.id('officeDistrictLabel'));
  this.taxOfficeDistrictAddressLabel = this.taxYtdCard.element(by.id('taxOfficeDistrictAddressLabel'));
  this.planMaterialsDesc = this.taxYtdCard.element(by.id('planMaterialsDesc'));
  this.pensionPaymentsDesc = this.taxYtdCard.element(by.id('pensionPaymentsDesc'));
  this.dependantsDesc = this.taxYtdCard.element(by.id('dependantsDesc'));
  this.bankAccountDetailsDesc = this.taxYtdCard.element(by.id('bankAccountDetailsDesc'));
  this.viewPlanMaterials = this.taxYtdCard.element(by.id('viewPlanMaterials'));
  this.viewPayments = this.taxYtdCard.element(by.id('viewPayments'));
  this.viewDependants = this.taxYtdCard.element(by.id('viewDependants'));
  this.uniqueIDForArrows = this.taxYtdCard.element(by.id('uniqueIDForArrows'));
  this.uniqueIDForOkButton = this.taxYtdCard.element(by.id('uniqueIDForOkButton'));
  this.descForBeneficiaries = this.taxYtdCard.element(by.id('descForBeneficiaries'));
  this.viewBeneficiaries = this.taxYtdCard.element(by.id('viewBeneficiaries'));
  this.descForAllowances = this.taxYtdCard.element(by.id('descForAllowances'));
  this.viewAllowances = this.taxYtdCard.element(by.id('viewAllowances'));

  // exposed functions
  // none yet
};
module.exports = pensionerPlanSummaryPage;
