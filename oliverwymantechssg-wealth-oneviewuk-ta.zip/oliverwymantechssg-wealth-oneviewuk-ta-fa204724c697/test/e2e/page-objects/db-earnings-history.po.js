// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');

// page object
// note this uses a constructor format as the URL is data driven
const dbEarningsHistoryPage = function dbEarningsHistoryPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  const self = this;

  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/db-plan-summary/OVTL/17150/earnings_history
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/db-plan-summary`
    + `/${midasSchemeCode}/${periodOfServicePrimaryKey}/earnings_history`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new DbPlanHeader();

  // top of screen
  // -----------------------------------------------------------------
  this.dbEarningsHistoryLabel = element(by.id('dbEarningsHistoryLabel'));
  this.dbEarningsHistoryHeaderLabel = element(by.id('dbEarningsHistoryHeaderLabel'));
  this.dbEarningsHistoryContent = element(by.id('dbEarningsHistoryContent'));
  this.dbEarningHistoryActionsButton = element(by.id('earningHistoryActionsButton'));
  this.dbEarningHistoryPrintButton = element(by.id('earningHistoryPrintButton'));
  this.dbEarningsHistoryBackButton = element(by.id('dbEarningsHistoryBackButton'));
  this.dbEarningsHistoryTab = element(by.id('earnings_historyTab'));
  this.earningHistorySalaryTypeDropdown = element(by.id('earningHistorySalaryTypeDropdown'));
  this.pensionableSalaryLink = element(by.linkText('PENSIONABLE SALARY'));
  this.annualEarningsLink = element(by.linkText('ANNUAL EARNINGS'));
  this.grossEarningsLink = element(by.linkText('GROSS EARNINGS'));

  // card header
  this.cardHeader = element(by.tagName('mercer-card-header'));

  // salaries tabs
  // -----------------------------------------------------------------
  this.salariesTabs = element.all(by.css('.ov-content-card-tab-container [id^=tab]'));
  this.salariesTab = index => this.salariesTabs.get(index);

  this.dropdownLabel = this.cardHeader.element(by.className('ov-content-card-tab-label'));
  this.dropdownSelection = this.cardHeader.element(by.className('ov-content-card-tab-selection'));
  this.dropdownSelectionValue = this.dropdownSelection.all(by.tagName('span')).get(1);
  this.dropdownOptions = this.cardHeader.all(by.css('mos-c-dropdown > a'));
  this.dropdownOption = index => this.dropdownOptions.get(index);

  // tabs to switch between different earnings (a.k.a. salaries)
  // -----------------------------------------------------------------
  this.salaryTypeTab = function salaryTypeTab(index) {
    return element(by.id(`salaryTypeTab-${index}`));
  };

  // earnings table
  // -----------------------------------------------------------------
  this.dbEarningsTable = element(by.tagName('ov-earning-history-table'));
  this.dbEarningsTableHeaderRow = self.dbEarningsTable.element(by.tagName('thead'));

  this.getCountOfDataTableHeaderColumns = async () => {
    const count = await self.dbEarningsTableHeaderRow.all(by.tagName('th')).count();
    return count;
  };

  this.getDataTableHeaderByIndex = index => self.dbEarningsTable
    .element(by.className(`mos-c-table__header-label-${index}`));

  this.getDataTableRows = () => self.dbEarningsTable.all(by.css('tbody > tr'));

  this.getDataTableDateElementByIndex = index => self.dbEarningsTable.element(by.id(`dateValue-${index}`));
  this.getDataTableAmountElementByIndex = index => self.dbEarningsTable.element(by.id(`amountValue-${index}`));

  this.getCountOfDataTableHeaderSorters = async () => {
    const count = await self.dbEarningsTableHeaderRow.all(by.tagName('mercer-icon')).count();
    return count;
  };

  this.getEarningHistoryRecordCount = async () => {
    const rowCount = await self.dbEarningsTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };

  this.dateValue = function dateValue(index) {
    return self.dbEarningsTable.element(by.id(`dateValue-${index}`));
  };

  this.amountValue = function amountValue(index) {
    return self.dbEarningsTable.element(by.id(`amountValue-${index}`));
  };

  // exposed functions
};
module.exports = dbEarningsHistoryPage;
