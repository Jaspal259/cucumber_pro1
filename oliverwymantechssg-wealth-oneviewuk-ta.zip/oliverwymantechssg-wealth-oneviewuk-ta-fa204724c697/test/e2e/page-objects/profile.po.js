// TODO: suspect view-profile.js has been superseded by profile.js but no current budget to amalgamate to profile.js

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const UnsavedChangesModal = require('../page-component-objects/unsaved-changes-modal.co.js');
const Toast = require('../page-component-objects/toast.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const profilePage = function profilePage(participant) {
  // NOTE ideally this would be split into a profile-default page and profile-edit-N pages but for speed
  // we will keep this as is for now

  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/profile
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/profile`;

  // edit URLs
  this.editGreetingAlternateUrl = `${this.url}/greeting-alternate`;
  this.editUserIdUrl = `${this.url}/user-id`;
  this.editPasscodeUrl = `${this.url}/passcode`;
  this.editSecurityEmailUrl = `${this.url}/security-email`;
  this.editContactDetailsUrl = `${this.url}/contact-details`;
  this.editElectronicCommunicationUrl = `${this.url}/electronic-communication`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.unsavedChangesModal = new UnsavedChangesModal();
  this.toast = new Toast();

  // default page - greeting preferences section
  this.greetingPreferencesTitle = element(by.id('greetingPreferencesTitle'));
  this.greetingPreferencesInfoIcon = element(by.id('greetingPreferencesInfoIcon'));
  this.greetingPreferencesEditButton = element(by.id('greetingPreferencesEditButton'));
  this.greetingAlternativeNameLabel = element(by.id('greetingAlternativeNameLabel'));
  this.greetingAlternativeNameValue = element(by.id('greetingAlternativeNameValue'));
  this.greetingPreferencesCancelButton = element(by.id('greetingPreferencesCancelButton'));
  this.greetingPreferencesSaveButton = element(by.id('greetingPreferencesSaveButton'));
  this.greetingAlternativeNameInput = element(by.id('greetingAlternativeNameInput'));
  this.greetingAlternativeNameInputValueInput = element(by.id('greetingAlternativeNameInputValueInput'));

  // default page - common elements to all sections
  this.disclaimer = element(by.tagName('ov-disclaimer-text'));

  // default page - user ID section
  // TBA

  // edit page - user ID
  // TBA

  // default page - passcode section
  // TBA

  // edit page - passcode
  // TBA

  // default page - security e-mail section
  this.securityEmailTitle = element(by.id('securityEmailTitle'));
  this.securityEmailInfoIcon = element(by.id('securityEmailInformationTooltip'));
  this.securityEmailEditButton = element(by.id('securityEmailEditButton'));
  this.securityEmailLabel = element(by.id('securityEmailLabel'));
  this.securityEmailValue = element(by.id('securityEmailValue'));

  // edit page - security e-mail details
  this.editSecurityEmailInput = element(by.id('securityEmailInput'));
  this.editSecurityEmailInputValue = element(by.id('securityEmailInputValueInput'));
  this.editSecurityEmailIcon = this.editSecurityEmailInput.element(by.tagName('mercer-icon'));
  this.editSecurityEmailLabel = this.editSecurityEmailInput.element(by.tagName('label'));
  this.editSecurityEmailBottomLink = this.editSecurityEmailInput.element(by.className('mos-u-color-text--tertiary'));
  this.editSecurityEmailCancelButton = element(by.id('cancel'));
  this.editSecurityEmailSaveButton = element(by.id('submit'));
  this.editSecurityEmailRequiredError = element(by.id('securityEmailInputValueRequiredErrorText'));

  // default page - contact details section
  this.contactDetailsTitle = element(by.id('contactDetailsTitle'));
  this.contactDetailsInfoIcon = element(by.id('contactDetailsInformationTooltip'));
  this.contactDetailsEditButton = element(by.id('contactDetailsEditButton'));
  this.postalAddressLabel = element(by.id('contactDetailsPostalAddressLabel'));
  this.postalAddressValue = element(by.id('contactDetailsPostalAddressValue'));
  this.phoneNumberLabel = element(by.id('contactDetailsPhoneNumberLabel'));
  this.phoneNumberValue = element(by.id('contactDetailsPhoneNumberValue'));
  this.residencyLabel = element(by.id('contactDetailsResidencyLabel'));
  this.residencyValue = element(by.id('contactDetailsResidencyValue'));
  this.emailAddressLabel = element(by.id('contactDetailsEmailAddressLabel'));
  this.emailAddressValue = element(by.id('contactDetailsEmailAddressValue'));

  // edit page - contact details

  // content
  this.editContactDetailsCardHeader = element(by.tagName('mercer-card-header'));
  this.editContactDetailsContantContainer = element(by.tagName('mercer-card-content'));
  this.editContactDetailsDescription = this.editContactDetailsContantContainer.all(by.tagName('p')).first();
  this.editContactDetailsCancelButton = element(by.id('cancelButton'));
  this.editContactDetailsSaveButton = element(by.id('saveButton'));

  // address line 1
  this.addressLine1 = element(by.id('addressLine1Input'));
  this.addressLine1RequiredError = element(by.id('addressLine1RequiredErrorText'));

  // address line 2
  this.addressLine2 = element(by.id('addressLine2Input'));
  this.addressLine2RequiredError = element(by.id('addressLine2RequiredErrorText'));

  // address line 3
  this.addressLine3 = element(by.id('addressLine3Input'));
  this.addressLine3RequiredError = element(by.id('addressLine2RequiredErrorText'));

  // post code
  this.postCodeValue = element(by.id('postCodeInput'));
  this.postCodeLabel = element(by.css('#postCodeInput+label'));
  this.postCodeValueRequiredError = element(by.id('postCodeRequiredErrorText'));

  // residency
  this.residencySelectValue = element(by.id('residencySelectValue'));

  // phone
  this.phoneNumberInput = element(by.id('phoneNumberInput'));
  this.phoneNumberSelectValue = element(by.id('phoneNumberSelectValue'));
  this.phoneTypeSelectValue = element(by.id('phoneTypeSelectValue'));
  this.phoneNumberRequiredError = element(by.id('phoneNumberRequiredErrorText'));
  this.contactDetailsTooltip = element(by.id('contactDetailsTooltip'));

  // email
  this.emailAddressInput = element(by.id('emailAddressInput'));
  this.emailAddressInputRequiredError = element(by.id('emailAddressRequiredErrorText'));

  // default page - electronic communication section
  // TBA

  // edit page - electronic communication
  // TBA
};
module.exports = profilePage;
