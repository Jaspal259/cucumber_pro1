// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const CookiePolicy = require('../page-component-objects/cookie-policy.co.js');
const UnsavedChangesModal = require('../page-component-objects/unsaved-changes-modal.co.js');
const Toast = require('../page-component-objects/toast.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const registrationPage = function registrationPage(participant) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/registration/contact-details
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/registration/verify-identity`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.cookiePolicy = new CookiePolicy();
  this.unsavedChangesModal = new UnsavedChangesModal();
  this.toast = new Toast();

  // elements
  this.registrationLabel = element(by.id('registrationLabel'));
  this.registrationHeaderLabel = deviceType => element.all(by.id('registrationHeaderLabel')).get(deviceType);
  this.helpAndContactUsLink = element(by.id('helpAndContactUsLink'));

  // stepper
  this.mercerStepperDesktop = element(by.tagName('mercer-stepper'));
  this.mercerStepperBarDesktop = element(by.className('mos-c-stepper__bar'));

  this.registrationStepDesktop
    = index => this.mercerStepperDesktop.all(by.className('mos-c-stepper__step')).get(index);
  this.registrationStepNumberDesktop
    = index => this.registrationStepDesktop(index).element(by.className('mos-c-stepper--num'));
  this.registrationStepIconDesktop
    = index => this.registrationStepDesktop(index).element(by.className('mos-c-stepper--circle'));
  this.registrationStepTitleDesktop
    = index => this.registrationStepDesktop(index).element(by.className('mos-c-stepper--title'));

  this.mercerStepperMobile = element(by.tagName('ov-stepper'));
  this.registrationStepTitleMobile = this.mercerStepperMobile.element(by.tagName('h3'));

  // card content
  this.registrationCardContent = element(by.tagName('mercer-card-content'));
  this.registrationStepImage = this.registrationCardContent.element(by.tagName('form'));
  this.registrationStepHeading = this.registrationCardContent.element(by.tagName('h2'));
  this.registrationStepDescription = this.registrationCardContent.element(by.tagName('p'));

  this.defaultUserIdControl = this.registrationCardContent.element(by.css('ov-input[icon="person"]'));
  this.defaultUserIdIcon = this.defaultUserIdControl.element(by.tagName('mercer-icon'));
  this.defaultUserIdLabel = this.defaultUserIdControl.element(by.css('label[for="ctlIDInput"]'));
  this.defaultUserIdInput = this.defaultUserIdControl.element(by.id('ctlIDInput'));
  this.defaultUserIdFieldError = element(by.id('ctlIDRequiredErrorText'));
  this.forgotDefaultUserIdLink = deviceType => element.all(by.tagName('a')).get(deviceType);

  this.niNumberControl = this.registrationCardContent.element(by.css('ov-input[icon="folder_shared"]'));
  this.niNumberIcon = this.niNumberControl.element(by.tagName('mercer-icon'));
  this.niNumberLabel = this.niNumberControl.element(by.css('label[for="ctlIDInput"]'));
  this.niNumberInput = this.niNumberControl.element(by.id('ctlIDInput'));
  this.niNumberFieldError = this.niNumberControl.element(by.id('ctlIDRequiredErrorText'));

  this.dateOfBirthControl = this.registrationCardContent.element(by.tagName('ov-datepicker-new'));
  this.dateOfBirthIcon = this.dateOfBirthControl.element(by.tagName('mercer-icon'));
  this.dateOfBirthLabel = this.dateOfBirthControl.element(by.css('label[data-mos-invalid-text=""]'));
  this.dateOfBirthInputText = this.dateOfBirthControl.element(by.css('input[type="text"]'));
  this.dateOfBirthInputDatePicker = this.dateOfBirthControl.element(by.className('mos-c-datepicker__input'));
  this.dateOfBirthFieldError = this.dateOfBirthControl.element(by.id('ctlIDRequiredErrorText'));

  // card footer
  this.registrationCardFooter = element(by.tagName('mercer-card-footer'));
  this.registrationCardFooterRight = this.registrationCardFooter.element(by.className('columns mos-u-text-right'));
  this.getFooterRightButton = index => this.registrationCardFooterRight.all(by.tagName('button')).get(index);
  this.cancelButton = this.getFooterRightButton(0);
  this.continueButton = this.getFooterRightButton(1);

  // define back button which should NOT be found (ouk-6213) - added as Dev are having problems removing
  this.getFooterButtons = this.registrationCardFooter.all(by.tagName('button'));
  this.backButton = this.registrationCardFooter.element(by.partialButtonText('Back'));
};
module.exports = registrationPage;
