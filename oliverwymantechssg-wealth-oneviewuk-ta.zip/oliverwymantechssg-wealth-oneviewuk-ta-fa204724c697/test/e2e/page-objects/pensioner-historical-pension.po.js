// load common
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const PensionerPlanHeader = require('../page-component-objects/pensioner-plan-header.co.js');

// create new objects
const commonConstants = new CommonConstants();

// page object
const pensionsHistoricalPensionPage = function pensionsHistoricalPensionPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  const self = this;
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/`
    + `pip-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/historical_pension`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new PensionerPlanHeader();

  // top elements
  this.pageContent = element(by.tagName('ov-main-content'));
  this.headerLabel = deviceType => this.pageContent.all(by.id('dashboardHeaderLabel')).get(deviceType);
  this.contentCard = this.pageContent.element(by.tagName('ov-content-card'));
  this.contentCardHeader = this.contentCard.element(by.tagName('mercer-card-header'));
  this.cardHeaderLabel = this.contentCardHeader.element(by.tagName('h3'));
  this.printButton = deviceType => this.contentCardHeader.all(by.id('dropdownPrintButton')).get(deviceType);
  this.downloadButton = deviceType => this.contentCardHeader.all(by.id('dropdownDownloadButton')).get(deviceType);
  this.historicalPensionTableDescription = this.contentCard.element(by.id('HistoricalPensionTableDescription'));

  // historical pension table
  // -----------------------------------------------------------------
  this.historicalPensionTable = element(by.css('mercer-table > table.mos-c-table'));

  this.getDataTableColumnsCount = async () => {
    const count = await self.historicalPensionTable.all(by.tagName('th')).count();
    return count;
  };

  this.getDataTableRowsCount = async () => {
    const count = await self.historicalPensionTable.all(by.css('tbody > tr')).count();
    return count;
  };

  // period
  this.periodLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(0);
  this.periodSorter = this.periodLabel.element(by.css('[icon=arrow_downward]'));

  this.periodValue = function periodValue(index) {
    return self.historicalPensionTable.element(by.id(`PenPeriod-${index}`));
  };

  // gross pension
  this.grossPensionLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(1);
  this.grossPensionSorter = this.grossPensionLabel.element(by.css('[icon=arrow_upward]'));

  this.grossPensionValue = function grossPensionValue(index) {
    return self.historicalPensionTable.element(by.id(`GrossPenAmt-${index}`));
  };

  // pre adjustments
  this.preAdjustmentsLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.preAdjustmentsSorter = this.preAdjustmentsLabel.element(by.css('[icon=arrow_upward]'));

  this.preAdjustmentsValue = function preAdjustmentsValue(index) {
    return self.historicalPensionTable.element(by.id(`PenPreTaxAdjust-${index}`));
  };

  // tax paid
  this.taxPaidLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(3);
  this.taxPaidSorter = this.taxPaidLabel.element(by.css('[icon=arrow_upward]'));

  this.taxPaidValue = function taxPaidValue(index) {
    return self.historicalPensionTable.element(by.id(`PenTaxAmt-${index}`));
  };

  // tax code
  this.taxCodeLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(4);
  this.taxCodeSorter = this.taxCodeLabel.element(by.css('[icon=arrow_upward]'));

  this.taxCodeValue = function taxCodeValue(index) {
    return self.historicalPensionTable.element(by.id(`PenTaxCode-${index}`));
  };

  // post adjustments
  this.postAdjustmentsLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(5);
  this.postAdjustmentsSorter = this.postAdjustmentsLabel.element(by.css('[icon=arrow_upward]'));

  this.postAdjustmentsValue = function postAdjustmentsValue(index) {
    return self.historicalPensionTable.element(by.id(`PenPostTaxAdjust-${index}`));
  };

  // other payee
  this.otherPayeeLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(6);
  this.otherPayeeSorter = this.otherPayeeLabel.element(by.css('[icon=arrow_upward]'));

  this.otherPayeeValue = function otherPayeeValue(index) {
    return self.historicalPensionTable.element(by.id(`PenOthPayeeAmt-${index}`));
  };

  // net payment
  this.netPaymentLabel
    = this.historicalPensionTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(7);
  this.netPaymentSorter = this.netPaymentLabel.element(by.css('[icon=arrow_upward]'));

  this.netPaymentValue = function netPaymentValue(index) {
    return self.historicalPensionTable.element(by.id(`PenNetPayAmt-${index}`));
  };
};
module.exports = pensionsHistoricalPensionPage;
