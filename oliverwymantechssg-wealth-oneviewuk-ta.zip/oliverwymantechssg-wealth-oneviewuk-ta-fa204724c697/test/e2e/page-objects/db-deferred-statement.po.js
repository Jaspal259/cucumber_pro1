// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');

// page object
// note this uses a constructor format as the URL is data driven
const dbDeferredStatementPage = function deferredStatementPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/db-plan-summary/OVTL/17160/deferred_statement
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/
    db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/deferred_statement`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new DbPlanHeader();

  // top of screen
  // -----------------------------------------------------------------
  this.deferredStatementViewLink = element(by.id('deferred_statementViewLink'));
  this.dbDeferredBenefitStatementContent = element(by.id('deferredBenefitStatementContent'));
  this.dbDeferredPreAmbleStatementLabel = element(by.id('deferredPreAmbleStatementLabel'));
  this.deferredStatementGroupDataLabel = element(by.id('deferredStatementGroupDataLabel'));
  this.deferredStatementLink = element(by.id('deferred_statementLink'));
  this.deferredStatementGroupDataValue = element(by.id('deferredStatementGroupDataValue'));
  this.yourAnnualStatementLabel = element(by.id('yourAnnualStatementLabel'));
  this.descForAnnualStatement = element(by.id('descForAnnualStatement'));
  this.introTextForDeferredStatement = element(by.id('introTextForDeferredStatement'));
  this.pensionBenefitsAtExitLabel = element(by.id('pensionBenefitsAtExitLabel'));
  this.statusLabel = element(by.id('statusLabel'));
  this.statusValue = element(by.id('statusValue'));

  this.preAmbleDrawIcon = function preAmbleDrawIcon(index) {
    return element(by.id(`preAmbleDrawIcon-${index}`));
  };
  this.postAmbleDrawIcon = function postAmbleDrawIcon(index) {
    return element(by.id(`preAmbleDrawIcon-${index}`));
  };
  this.deferredStatementGroupLabel = function deferredStatementGroupLabel(i) {
    return element(by.id(`deferredStatementGroupLabel(${i})`));
  };
  this.deferredStatementGroupDataLabel = function deferredStatementGroupDataLabel(i, y) {
    return element(by.id(`deferredStatementGroupDataLabel(${i}${y})`));
  };
  this.deferredStatementGroupDataValue = function deferredStatementGroupDataValue(i, y) {
    return element(by.id(`deferredStatementGroupDataValue(${i}${y})`));
  };
  this.deferredStatementGroupDataInfoIcon = function deferredStatementGroupDataInfoIcon(i, y) {
    return element(by.id(`deferredStatementGroupDataInfoIcon(${i}${y})`));
  };
};

module.exports = dbDeferredStatementPage;
