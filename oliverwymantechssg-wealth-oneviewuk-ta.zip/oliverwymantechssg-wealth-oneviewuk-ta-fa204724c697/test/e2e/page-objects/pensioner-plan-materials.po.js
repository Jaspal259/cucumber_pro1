// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const PensionerPlanHeader = require('../page-component-objects/pensioner-plan-header.co.js');
const PlanMaterials = require('../page-component-objects/plan-materials.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const pensionsPlanMaterialsPage = function pensionsPlanMaterialsPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/pip-plan-summary/OVTL/920/plan_materials
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/pip-plan-summary`
    + `/${midasSchemeCode}/${periodOfServicePrimaryKey}/plan_materials`;

  // e.g. https://v218-dal-qa-merceros.mercer.com:10491/api/plans/pip/OVTL/920/materials
  // note unsecured content url is held in commonConstants.unsecuredContentDownloadUrlRoot
  this.securedContentDownloadUrlRoot = `${browser.params.ov3RootDownloadUrl}api/plans/pip`
    + `/${midasSchemeCode}/${periodOfServicePrimaryKey}/materials`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new PensionerPlanHeader();
  this.planMaterials = new PlanMaterials();
};
module.exports = pensionsPlanMaterialsPage;
