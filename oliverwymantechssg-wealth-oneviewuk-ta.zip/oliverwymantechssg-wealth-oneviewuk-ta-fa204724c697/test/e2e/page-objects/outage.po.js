// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');

// page object
const outagePage = function outagePage() {
  this.url = `${browser.params.ov3RootUrl}OUTAGECLIENT/login`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();

  // elements
  this.container = element(by.tagName('ov-outage'));
  this.outageHeader = this.container.element(by.tagName('h2'));
  this.outageDescription = deviceType => this.container.all(by.tagName('h4')).get(deviceType);
};
module.exports = outagePage;
