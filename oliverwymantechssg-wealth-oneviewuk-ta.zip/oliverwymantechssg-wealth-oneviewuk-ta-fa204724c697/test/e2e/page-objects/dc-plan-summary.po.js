// load common
const CommonConstants = require('../utilities/common-constants.js');
const CommonTests = require('../utilities/common-tests.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DcPlanHeader = require('../page-component-objects/dc-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const Carousel = require('../page-component-objects/carousel.co.js');
const CarouselSlide = require('../page-component-objects/carousel-slide.co.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// page object
// note this uses a constructor format as the URL is data driven
const dcPlanSummaryPage = function dcPlanSummaryPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/OVTDEMO/dc-plan-summary/OVTL/17150/summary
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
      + `/dc-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}`;

  // note this retrieves the ID for article instance 1 - this is the URL once the article is clicked
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2837';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '17';
        break;
      case commonConstants.appEnvironmentEnum.staging:
        articleId = '18';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  // elements
  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.planHeader = new DcPlanHeader();
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);

  // note this is the root URL of the articles in the href links on this page e.g. /OV1/articles/2835
  this.articleUrlOnPageRoot = `/${participant.client.data.clientCode}/articles/`;

  this.carousel = new Carousel();
  this.carouselBudgetPlannerSlide = new CarouselSlide(
    'Budget Planner',
    'dc_budgetingLabel',
    'dc_budgetingLink');
  this.carouselAllowancesSlide = new CarouselSlide(
    'Allowances',
    'dc_allowancesLabel',
    'dc_allowancesLink');

  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  // wealth snapshot cards
  this.snapshotCard = element.all(by.tagName('ov-snapshot-card'));

  this.getSnapshotCardCount = async () => {
    const cardCount = await this.snapshotCard.count();
    return cardCount;
  };

  this.fundValueCard = element(by.css('ov-snapshot-card[idprefix="TotalFundValue"]'));
  this.transferCard = element(by.id('TransferValueCard'));
  this.retirementBenefitCard = element(by.css('ov-snapshot-card[idprefix="RetirementBenefit"]'));
  this.investmentsCard = element(by.css('ov-snapshot-card[idprefix="TotalFundValue"]'));
  this.contributionsCard = element(by.css('ov-snapshot-card[idprefix="Contributions"]'));
  this.planMaterialsCard = element(by.tagName('ov-plan-materials-card'));

  // details for wealth snapshot cards
  this.fundValueCardLabel = this.fundValueCard.element(by.id('TotalFundValueLabel'));
  this.fundValueCardIcon = this.fundValueCard.element(by.tagName('mercer-vector-icon'));
  this.fundValueCardValue = this.fundValueCard.element(by.id('TotalFundValueAmount'));
  this.fundValueCardDate = this.fundValueCard.element(by.id('TotalFundValueYear'));
  this.fundValueCardHelpIcon = this.fundValueCard.element(by.tagName('mercer-icon'));
  this.fundValueCardCTA = this.fundValueCard.element(by.id('TotalFundValueAction'));

  this.contributionsCardLabel = this.contributionsCard.element(by.id('ContributionsLabel'));
  this.contributionsCardIcon = this.contributionsCard.element(by.tagName('mercer-vector-icon'));
  this.contributionsCardValue = this.contributionsCard.element(by.id('ContributionsAmount'));
  this.contributionsCardDate = this.contributionsCard.element(by.id('ContributionsYear'));
  this.contributionsCardHelpIcon = this.contributionsCard.element(by.tagName('mercer-icon'));
  this.contributionsCardCTA = this.contributionsCard.element(by.id('ContributionsAction'));

  this.transferCardLabel = this.transferCard.element(by.id('TransferValueLabel'));
  this.transferCardValue = this.transferCard.element(by.id('TransferValueAmount'));
  this.transferCardDate = this.transferCard.element(by.id('TransferValueTerm'));
  this.transferCardNote = this.transferCard.element(by.id('TransferValueNote'));
  this.transferCardCTA = this.transferCard.element(by.id('TransferValueAction'));

  this.investmentsCardLabel = this.investmentsCard.element(by.id('TotalFundValueLabel'));
  this.investmentsCardContent = this.investmentsCard.element(by.id('TotalFundValueContent'));
  this.investmentsCardIcon = this.investmentsCardContent.element(by.tagName('mercer-vector-icon'));
  this.investmentsCardValue = this.investmentsCardContent.element(by.id('TotalFundValueAmount'));
  this.investmentsCardDate = this.investmentsCardContent.element(by.id('TotalFundValueYear'));
  this.investmentsCardInfoIcon = this.investmentsCardContent.element(by.tagName('mercer-icon'));
  this.investmentsCardCTA = this.investmentsCard.element(by.id('TotalFundValueAction'));

  // Transaction History Feature
  this.transactionHistory = element(by.id('TransHist'));
  this.transactionHistoryLabel
    = this.transactionHistory.element(by.id('TransHistLabel'));
  this.advSearchLabel = element(by.css(
    '#TransHist > mercer-card > div > div.mos-c-card__header > mercer-card-header > div > div:nth-child(4) > button'));
  this.downloadButton = element(by.css(
    '#TransHist > mercer-card > div > div.mos-c-card__header > mercer-card-header > div > div:nth-child(5) > button'));
  this.transDateLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(0);
  this.transactionLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(1);
  this.fundDescLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.transValueLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(3);
  this.tradeUnitLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(4);
  this.tradeUnitPrice = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(5);
  this.transSwitchLabel = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(6);
  this.transInfoIcon = element(by.className(
    'mos-c-icon mos-c-icon--sm mos-t-icon--tertiary mos-u-color-text--secondary'));
  // pagination controls
  this.pageBack = element(by.id('PageBack'));
  this.lastPage = element(by.id('LastPage'));
  this.pagination = pageIndex => element(by.id(`Page-${pageIndex}`));

  // transactionHistory Page
  this.transactionHistoryPage = element(by.id('TransLabel')); // need to change this as per the actual feature

  // exposed functions

  this.getTransactionHistoryTradeDateValue = index => element(by.id(`TradeDate-${index}`));
  this.getTransactionHistoryTransactionType = index => element(by.id(`ContriLabel-${index}`));
  this.getTransactionHistoryFundName = index => element(by.id(`FundName-${index}`));
  this.getTransactionHistoryFundValue = index => element(by.id(`FundVal-${index}`));
  this.getTransactionHistoryTradedUnits = async index => element(by.id(`TradedUnits-${index}`));
  this.getTransactionHistoryTradedPrice = index => element(by.id(`TradePrice-${index}`));
  this.getTransactionHistorySwitchNumber = index => element(by.id(`SwitchNo-${index}`));
  this.planMaterialName = index => element(by.id(`planMaterialName-${index}`));
};
module.exports = dcPlanSummaryPage;
