// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');

// page object
const errorPage = function errorPage() {
  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();

  // elements
  this.container = element(by.tagName('ov-error-page'));
  this.header = this.container.element(by.tagName('h1'));
  this.icon = this.container.element(by.css('mercer-vector-icon[size=md]'));
  this.description = this.container.element(by.tagName('p'));
  this.goBackButton = this.container.element(by.className('mos-c-button--md'));
};
module.exports = errorPage;
