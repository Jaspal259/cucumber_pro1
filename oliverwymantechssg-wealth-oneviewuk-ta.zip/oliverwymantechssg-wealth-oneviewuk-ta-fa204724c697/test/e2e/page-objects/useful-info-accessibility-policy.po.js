// *** NOTE THAT THIS PAGE OBJECT IS SEPARATE FROM THE COOKIE POLICY PAGE COMPONENT OBJECT ***
// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const CookiePolicy = require('../page-component-objects/cookie-policy.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const usefulInfoAccessibilityPolicyPage = function usefulInfoAccessibilityPolicyPage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/accessibility-policy`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.cookiePolicy = new CookiePolicy();
};
module.exports = usefulInfoAccessibilityPolicyPage;
