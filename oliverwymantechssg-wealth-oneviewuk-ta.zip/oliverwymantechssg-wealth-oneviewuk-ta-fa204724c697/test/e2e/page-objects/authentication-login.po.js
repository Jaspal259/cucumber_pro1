// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const CookiePolicy = require('../page-component-objects/cookie-policy.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const Toast = require('../page-component-objects/toast.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const loginPage = function loginPage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/login`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2858';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '58';
        break;
      case commonConstants.appEnvironmentEnum.staging:
        articleId = '61';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.cookiePolicy = new CookiePolicy();
  this.toast = new Toast();

  this.welcomeMessageLabel = (deviceType) => {
    let locator;

    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        locator = 'welcomeMessageLabel';
        break;
      case commonConstants.appDeviceTypeEnum.mobile:
        locator = `${commonConstants.mobileName}WelcomeMessageLabel`;
        break;
      default:
        throw new Error(`The deviceType '${deviceType}' is not supported.`);
    }

    return element(by.id(locator));
  };

  this.largeMercerLogo = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('MercerOneViewLogo', deviceType);
    return element(by.id(locator));
  };

  this.loginForm = element(by.tagName('ov-login-form'));
  this.loginFormHeader = this.loginForm.element(by.tagName('mercer-card-header'));

  this.loginFormLoginTabText = 'Log In';
  this.loginFormRegisterTabText = 'Register';

  this.loginFormSelectedTab = this.loginFormHeader.element(by.className('login-tab-selected'));
  this.loginFormSelectedTabDefaultText = this.loginFormLoginTabText;

  this.loginFormUnselectedTab = this.loginFormHeader.element(by.className('login-tab-unselected')); // default register
  this.loginFormUnselectedTabDefaultText = this.loginFormRegisterTabText;

  // login tab
  this.loginFormContent = this.loginForm.element(by.tagName('mercer-card-content'));

  this.userIdInput = this.loginFormContent.element(by.id('userIdInput'));
  this.userIdLabel = this.loginFormContent.element(by.css('label[for="userIdInput"]'));

  this.passcodeControl = this.loginFormContent.element(by.css('ov-input[type="password"]'));
  this.passcodeInput = this.passcodeControl.element(by.id('passcodeInput'));
  this.passcodeLabel = this.passcodeControl.element(by.css('label[for="passcodeInput"]'));

  this.loginBtn = this.loginFormContent.element(by.id('LogInBtn'));

  this.forgetCredentialLabel = this.loginFormContent.element(by.id('AdditionalTxt'));
  this.forgotUserIdLink = this.loginFormContent.element(by.id('LnkForgetYourUserId'));
  this.forgotPasscodeLink = this.loginFormContent.element(by.id('LnkForgetYourPassword'));

  this.userIdRequiredErrorText = this.loginFormContent.element(by.id('userIdRequiredErrorText'));
  this.passcodeRequiredErrorText = this.loginFormContent.element(by.id('passcodeRequiredErrorText'));

  // register tab
  this.registerHeading = this.loginFormContent.element(by.tagName('h3'));
  this.registerDescription = this.loginFormContent.element(by.tagName('p'));
  this.registerButton = this.loginFormContent.element(by.id('CreateIdBtn'));

  // articles
  this.articlesSection = element.all(by.className('row articles-section'));
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));
  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);

  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);


  // public functions
};
module.exports = loginPage;
