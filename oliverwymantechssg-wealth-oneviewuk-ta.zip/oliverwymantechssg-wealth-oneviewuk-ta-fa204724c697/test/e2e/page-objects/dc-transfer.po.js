// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DcPlanHeader = require('../page-component-objects/dc-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
const dcTransferPage = function dcTransferPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // otherwise errant space characters can creep into complete string
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/`
    + `dc-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/transfer_value`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2847';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '35';
        break;
      case commonConstants.appEnvironmentEnum.stage:
        articleId = '999 - needs Calc Studio set up';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new DcPlanHeader();
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);

  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));
};

module.exports = dcTransferPage;
