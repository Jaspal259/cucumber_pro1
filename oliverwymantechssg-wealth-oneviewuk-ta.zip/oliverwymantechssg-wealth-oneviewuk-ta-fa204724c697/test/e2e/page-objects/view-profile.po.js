// TODO: suspect view-profile.js has been superseded by profile.js but no current budget to amalgamate to profile.js

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const viewProfilePage = function viewProfilePage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/profile`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements

  // top of screen
  this.rsDropDownIcon = element(by.className('mos-c-circle--xxsm mos-c-icon--circle mos-c-avatar__dropdown-icon'));
  this.profileDropDown = element(by.id('ListDropDown'));
  this.profileLink = element(by.id('ProfileLink'));
  this.userNameLabel = element(by.id('UserNameLabel'));
  // -----------------------------------------------------------------
  // Page objects according to new view profile design
  this.greetingPreferencesEditButton = element(by.id('greetingPreferencesEditButton'));
  this.greetingAlternativeNameValue = element(by.id('greetingAlternativeNameValue'));
  this.greetingPreferencesCancelButton = element(by.id('greetingPreferencesCancelButton'));
  this.greetingPreferencesSaveButton = element(by.id('greetingPreferencesSaveButton'));
  this.greetingAlternativeNameInput = element(by.id('greetingAlternativeNameInputValueInput'));
  this.loseChangesConfirmButton = element(by.id('loseChangesConfirmButton'));
  this.userIdInformationTooltip = element(by.id('userIdInformationTooltip'));
  this.userIdEditButton = element(by.id('userIdEditButton'));
  this.userIdCancelButton = element(by.id('userIdCancelButton'));
  this.userIdSaveButton = element(by.id('userIdSaveButton'));
  this.userIdInput = element(by.id('userIdInputValueInput'));
  this.userIdLabel = element(by.id('currentUserIdLabel'));
  this.userIdValue = element(by.id('currentUserIdValue'));
  this.currentUserIdTitle = element(by.id('currentUserIdTitle'));
  this.passcodeInformationTooltip = element(by.id('passcodeInformationTooltip'));
  this.backButton = element(by.id('undefinedBackButton'));
  this.userIdSaveButton = element(by.id('userIdSaveButton'));
  this.userIdEditButton = element(by.id('userIdEditButton'));
  this.loseChangesConfirmButton = element(by.id('loseChangesConfirmButton'));
  // ---------------------------------------------------------------------
  this.contactDetailsTitle = element(by.id('contactDetailsTitle'));
  this.contactDetailsEditButton = element(by.id('contactDetailsEditButton'));
  this.contactDetailsCancelButton = element(by.id('contactDetailsCancelButton'));
  this.contactDetailSaveButton = element(by.id('contactDetailSaveButton'));
  this.profileContactDetailsPostalAddressLabel = element(by.id('profileContactDetailsPostalAddressLabel'));
  this.postalAddressValue = element(by.id('postalAddressValue'));
  this.profileContactDetailsPostalAddressLine1 = element(by.id('profileContactDetailsPostalAddressLine1'));
  this.profileContactDetailsPostalAddressLine2 = element(by.id('profileContactDetailsPostalAddressLine2'));
  this.profileContactDetailsPostalAddressLine3 = element(by.id('profileContactDetailsPostalAddressLine3'));
  this.profileContactDetailsPostalAddressLine4 = element(by.id('profileContactDetailsPostalAddressLine4'));
  this.profileContactDetailsPostalAddressLine5 = element(by.id('profileContactDetailsPostalAddressLine5'));
  this.profileContactDetailsPhoneNumberLabel = element(by.id('profileContactDetailsPhoneNumberLabel'));
  this.phoneNumberValue = element(by.id('phoneNumberValue'));
  this.contactDetailsPhoneNumberInput = element(by.id('contactDetailsPhoneNumberInput'));
  this.profileContactDetailsEmailAddressLabel = element(by.id('profileContactDetailsEmailAddressLabel'));
  this.emailAddressValue = element(by.id('emailAddressValue'));
  this.contactDetailsEmailAddressInput = element(by.id('contactDetailsEmailAddressInput'));
  this.profileContactDetailsResidencyLabel = element(by.id('profileContactDetailsResidencyLabel'));
  this.contactDetailsOverseasIndicatorInput = element(by.id('contactDetailsOverseasIndicatorInput'));

  this.electronicCommunicationHeader = element(by.id('electronicCommunicationHeader'));
  this.electronicCommunicationEditButton = element(by.id('electronicCommunicationEditButton'));
  this.electronicCommunicationRadioLabelDisabled = element(by.id('electronicCommunicationRadioLabelDisabled'));
  this.ecRadioYesDisabledLabel = element(by.id('ecRadioLabelYes-yes-disabled'));
  this.ecRadioYesDisabledLabelValue = element(by.id('ecRadioYes-yes-disabled'));
  this.ecRadioNoDisabledLabel = element(by.id('ecRadioLabelNo-no-disabled'));
  this.ecRadioNoDisabledLabelValue = element(by.id('ecRadioNo-no-disabled'));
  this.ecRadioYesLabel = element(by.id('ecRadioLabelYes-yes'));
  this.ecRadioNoLabel = element(by.id('ecRadioLabelNo-no'));
  this.ecRadioYesLabelValue = element(by.id('ecRadioYes-yes'));
  this.ecRadioNoLabelValue = element(by.id('ecRadioNo-no'));
  this.changesNotSavedLabel = element(by.className('mos-c-modal__header'));
  this.electronicCommunicationSaveButton = element(by.id('electronicCommunicationSaveButton'));
  this.electronicCommunicationCancelButton = element(by.id('electronicCommunicationCancelButton'));
  this.successMsgLabel = element(by.id('ecSuccessMessageLabel'));

  // exposed functions
  this.addressLine = function addressLine(index) {
    return element(by.id(`addressLine${index}`));
  };

  this.contactDetailsAddressLineInput = function contactDetailsAddressLineInput(index) {
    return element(by.id(`contactDetailsAddressLine${index}Input`));
  };
};
module.exports = viewProfilePage;
