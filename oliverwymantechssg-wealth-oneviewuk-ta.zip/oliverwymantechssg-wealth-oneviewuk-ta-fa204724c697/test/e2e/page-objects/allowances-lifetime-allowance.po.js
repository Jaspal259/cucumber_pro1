// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');

const lifetimeAllowance = function lifetimeAllowance(participant) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/OVTDEMO/allowances/lifetime
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/allowances/lifetime`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  this.annualAllowanceTab = element(by.id('allowances_annualLink'));
  this.lifetimeTab = element(by.id('allowances_lifetimeLink'));
  this.planLabel = element(by.id('planLabel'));
  this.statusLabel = element(by.id('statusLabel'));
  this.effectiveDateLabel = element(by.id('effectiveDateLabel'));
  this.lifeTimeAllowanceLabel = element(by.id('lifeTimeAllowanceLabel'));
  this.expandableArrow = element(by.id('uniqueId'));
  this.guidanceTextForLTA = element(by.id('guidanceTextForLTA'));
  this.guidanceLinkForLTA = element(by.id('guidanceLinkForLTA'));
  this.planValue = element(by.id('planValue'));
  this.statusValue = element(by.id('statusValue'));
  this.effectiveDateValue = element(by.id('effectiveDateValue'));
  this.lifeTimeAllowanceValue = element(by.id('lifeTimeAllowanceValue'));
  this.labelForHMRC = element(by.id('labelForHMRC'));
  this.descForHMRC = element(by.id('descForHMRC'));
  this.linkForHMRC = element(by.id('linkForHMRC'));
  this.modalWindowLabelForLTA = element(by.id('modalWindowLabelForLTA'));
  this.modalWindowDescForLTA = element(by.id('modalWindowDescForLTA'));
};

module.exports = lifetimeAllowance;
