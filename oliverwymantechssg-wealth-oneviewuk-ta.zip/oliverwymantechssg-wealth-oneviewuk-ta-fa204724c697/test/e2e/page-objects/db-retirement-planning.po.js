// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const dbRetirementPlanningPage = function dbRetirementPlanningPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/db-plan-summary/OVTL/17150
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/db_modeller`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2832';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '11';
        break;
      case commonConstants.appEnvironmentEnum.stage:
        articleId = '999 - needs Calc Studio set up';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.header = new Header();
  this.planHeader = new DbPlanHeader();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);

  this.retirementIllustrationAction = element(by.id('RetirementIllustrationAction'));
  this.dBRetirementIllustratorLabel = element(by.id('retirementIllustratorLabel'));
  this.produceStatementButton = element(by.id('produceStatementButton'));
  this.pensionIllustrationDateLabel = element(by.id('pensionIllustrationDateLabel'));
  this.pensionIllustrationDateValue = element(by.id('pensionIllustrationDateValue'));
  this.transactionIdLabel = element(by.id('transactionIdLabel'));
  this.transactionIdValue = element(by.id('transactionIdValue'));
  this.retirementIllustratorText = element(by.id('retirementIllustratorText'));
  this.disclaimerText = element(by.id('disclaimerText'));
  this.yourContributionOptionsLabel = element(by.id('yourContributionOptionsLabel'));
  this.yourRetirementOptionsLabel = element(by.id('yourRetirementOptionsLabel'));
  this.yourWorkingOptionsLabel = element(by.id('yourWorkingOptionsLabel'));
  this.yourRetainedBenefitsLabel = element(by.id('yourRetainedBenefitsLabel'));
  this.summaryViewButton = element(by.id('summaryViewButton'));
  this.detailViewButton = element(by.id('detailViewButton'));
  this.retirementDateLabel = element(by.id('retirementDateLabel'));
  this.retirementDateValue = element(by.id('retirementDateValue'));
  this.annualPensionOfLabel = element(by.id('annualPensionOfLabel'));
  this.annualPensionOfValue = element(by.id('annualPensionOfValue'));
  this.cashLumpSumLabel = element(by.id('cashLumpSumLabel'));
  this.cashLumpSumValue = element(by.id('cashLumpSumValue'));
  this.summaryViewButton = element(by.id('summaryViewButton'));
  this.retirementDate = element(by.id('retirementDate'));
  this.retirementDateValue = element(by.id('retirementDateValue'));
  this.lifetimeAllowancePercentage = element(by.id('lifetimeAllowancePercentage'));
  this.lifetimeAllowancePercentageValue = element(by.id('lifetimeAllowancePercentageValue'));
  this.annualPensionLabel = element(by.id('annualPensionLabel'));
  this.annualPensionValue = element(by.id('annualPensionValue'));
  this.cashLumpSumLabel = element(by.id('cashLumpSumLabel'));
  this.onYourDeathLabel = element(by.id('onYourDeathLabel'));
  this.statementsButton = element(by.id('statementsButton'));
  this.personalDetailsLabel = element(by.id('personalDetailsLabel'));
  this.financialAssumptionsLabel = element(by.id('financialAssumptionsLabel'));
  this.variableInformationLabel = element(by.id('variableInformationLabel'));
  this.otherAssumptionsLabel = element(by.id('otherAssumptionsLabel'));
  this.importantNotesLabel = element(by.id('importantNotesLabel'));

  // exposed functions
  this.getSummaryElementLabel = index => element(by.id(`summaryElementLabel${index}`));
  this.getBreakdownElementLabel = index => element(by.id(`breakdownElementLabel${index}`));
  this.getBreakdownElementValue = index => element(by.id(`breakdownElementValue${index}`));
  this.getCashLumpSumValue = index => element(by.id(`cashLumpSumValue${index}`));
  this.getPersonalInformation = index => element(by.id(`getPersonalInformation${index}`));
  this.getPersonalInformationValue = index => element(by.id(`personalInformationValue-${index}`));
  this.getFinancialAssumptions = index => element(by.id(`financialAssumptions${index}`));
  this.getFinancialAssumptionsValue = index => element(by.id(`financialAssumptionsValue-${index}`));
  this.getVariableInformation = index => element(by.id(`variableInformation${index}`));
  this.getVariableInformationValue = index => element(by.id(`variableInformationValue-${index}`));
  this.getOtherAssumptions = index => element(by.id(`otherAssumptions${index}`));
  this.getImportantNotes = index => element(by.id(`importantNotes${index}`));
};

module.exports = dbRetirementPlanningPage;
