// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const Carousel = require('../page-component-objects/carousel.co.js');
const CarouselSlide = require('../page-component-objects/carousel-slide.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is data driven
const dbPlanSummaryPage = function dbPlanSummaryPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/OVTDEMO/db-plan-summary/OVTL/17150/summary
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
      + `/db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}`;

  // DBTV page url
  this.ctaUrl
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
      + `/db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/summary/transfer-value`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2842';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '25';
        break;
      case commonConstants.appEnvironmentEnum.staging:
        articleId = '27';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  // elements
  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.planHeader = new DbPlanHeader();
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);
  this.carousel = new Carousel();
  this.carouselBudgetPlannerSlide = new CarouselSlide(
    'Budget Planner',
    'db_budgetingLabel',
    'db_budgetingLink');

  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  // wealth snapshot cards
  this.snapshotCard = element.all(by.tagName('ov-snapshot-card'));

  this.getSnapshotCardCount = async () => {
    const count = await this.snapshotCard.count();
    return count;
  };

  this.fundValueCard = element(by.css('ov-snapshot-card[idprefix="TotalFundValue"]'));
  this.transferCard = element(by.id('TransferValueCard'));

  // details for wealth snapshot cards
  this.fundValueCardLabel = this.fundValueCard.element(by.id('TotalFundValueLabel'));
  this.fundValueCardIcon = this.fundValueCard.element(by.tagName('mercer-vector-icon'));
  this.fundValueCardValue = this.fundValueCard.element(by.id('TotalFundValueAmount'));
  this.fundValueCardDate = this.fundValueCard.element(by.id('TotalFundValueYear'));
  this.fundValueCardHelpIcon = this.fundValueCard.element(by.tagName('mercer-icon'));
  this.fundValueCardCTAAnnual = this.fundValueCard.element(by.id('TotalFundValueAnnual'));
  this.fundValueCardCTADeferred = this.fundValueCard.element(by.id('TotalFundValueDeffered'));

  this.transferCardLabel = element(by.id('TransferValueLabel'));
  this.transferCardValue = element(by.id('TransferValueAmount'));
  this.transferCardTerm = element(by.id('TransferValueTerm'));
  this.transferCardNote = element(by.id('TransferValueNote'));
  this.transferCardCTA = element(by.id('TransferValueAction'));

  this.viewDetailsError1Label = element(by.id('viewDetailsError1Label'));


  // exposed functions
  // none yet
};

module.exports = dbPlanSummaryPage;
