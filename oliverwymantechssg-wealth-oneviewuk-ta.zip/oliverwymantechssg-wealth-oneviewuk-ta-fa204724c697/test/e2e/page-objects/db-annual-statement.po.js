// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');
const AnnualStatement = require('../page-component-objects/annual-statement.co.js');

const dbAnnualStatementPage = function annualStatementPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/OVTDEMO/db-plan-summary/OVTL/17150/annual_benefit_statement
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/annual_benefit_statement`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new DbPlanHeader();
  this.annualStatement = new AnnualStatement();
};
module.exports = dbAnnualStatementPage;
