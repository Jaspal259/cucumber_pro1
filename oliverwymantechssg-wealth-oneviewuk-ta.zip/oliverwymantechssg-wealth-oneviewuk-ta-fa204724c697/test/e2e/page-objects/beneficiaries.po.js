// load common
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const BeneficiaryManagementView = require('../page-component-objects/beneficiary-management-view.co.js');

// create new objects
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const beneficiariesPage = function beneficiariesPage(beneficiaryType) {
  const self = this;

  // note full url will include client, plan type, Midas scheme code and POS primary key
  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/dc-plan-summary/OVTL/17150/beneficiaries/lump_sum
  // but it is easier to check the bulk of the url using the relevant plan summary page and then just use the partial
  // url here to complete the check
  this.partialUrl = '/beneficiaries';

  // note also need to set something for this.url as used by the function used to check standard content on each page:
  // commonTests.checkPageLoadsAndContainsStandardElements(page);
  this.url = this.partialUrl;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  this.beneficiaryTypeEnum = {
    lumpSum: 0,
    dependants: 1,
  };

  if (beneficiaryType === 'lumpSum') {
    this.beneficiaryTypeEnumValue = self.beneficiaryTypeEnum.lumpSum;
  } else {
    this.beneficiaryTypeEnumValue = self.beneficiaryTypeEnum.dependants;
  }

  // the management view is used when EDITING
  this.beneficiaryManagementView = new BeneficiaryManagementView();


  // elements

  // top of screen
  // -----------------------------------------------------------------
  this.beneficiariesLabel = element(by.id('beneficiariesLabel'));
  this.beneficiariesHeaderLabel = element(by.id('beneficiariesHeaderLabel'));
  this.beneficiariesText = element(by.id('beneficiariesText'));
  this.beneficiariesBackButton = element(by.id('undefinedBackButton'));
  this.beneficiaryAddButton = element(by.id('beneficiaryAddButton'));
  this.loseChangesConfirmButton = element(by.id('loseChangesConfirmButton'));
  this.printButton = deviceType => element.all(by.id('dropdownPrintButton')).get(deviceType);
  this.downloadButton = deviceType => element.all(by.id('dropdownDownloadButton')).get(deviceType);

  // pop-up message when max no. of beneficiaries exceeded
  // -----------------------------------------------------------------
  this.tooManyBeneficiariesMessage = element(by.className(commonConstants.mosCssModalContentWrapper));
  this.tooManyBeneficiariesMessageContinue = this.tooManyBeneficiariesMessage.element(by.id('continueButton'));

  // tabs to switch between lump sum beneficiaries and dependants
  // -----------------------------------------------------------------
  this.lumpSumTab = element(by.id('tab-0'));
  this.dependantsTab = element(by.id('tab-1'));


  // beneficiaries table
  // -----------------------------------------------------------------
  this.beneficiariesTable = element(by.id('beneficiariesTable'));

  // not shown in mock-ups
  this.beneficiaryLastUpdatedLabelAndValue = element(by.css('.last-updated'));
  this.beneficiariesTableHeaderRow = self.beneficiariesTable.element(by.tagName('thead'));

  this.getCountOfDataTableHeaderColumns = async () => {
    const count = await self.beneficiariesTableHeaderRow.all(by.tagName('th')).count();
    return count;
  };

  this.getCountOfDataTableHeaderSorters = async () => {
    const count = await self.beneficiariesTableHeaderRow.all(by.tagName('mercer-icon')).count();
    return count;
  };

  this.getNumberOfBeneficiariesStored = async () => {
    const rowCount = await self.beneficiariesTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };

  this.nameLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(0);
  this.nameSorter = this.nameLabel.element(by.tagName('mercer-icon'));

  this.nameValue = index => self.beneficiariesTable.element(by.id(`nameValue-${index}`));

  this.addressLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(1);
  this.addressSorter = this.addressLabel.element(by.tagName('mercer-icon'));
  this.addressValue = index => self.beneficiariesTable.element(by.id(`addressValue-${index}`));

  // address pop-up
  this.fullAddressValue = element(by.id('fullAddressValue'));

  this.beneficiaryTypeLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.beneficiaryTypeSorter = this.beneficiaryTypeLabel.element(by.tagName('mercer-icon'));
  this.beneficiaryTypeValue
    = (index, deviceType) => self.beneficiariesTable.all(by.id(`beneficiaryTypeValue-${index}`)).get(deviceType);

  if (beneficiaryType === 'lumpSum') {
    this.shareOfBenefitLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(3);
    this.shareOfBenefitSorter = this.shareOfBenefitLabel.element(by.tagName('mercer-icon'));
  }

  this.shareOfBenefitValue
    = (index, deviceType) => self.beneficiariesTable.all(by.id(`shareOfBenefitValue-${index}`)).get(deviceType);

  if (beneficiaryType === 'lumpSum') {
    this.guardianLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(4);
  } else {
    this.guardianLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(3);
  }

  this.guardianSorter = this.guardianLabel.element(by.tagName('mercer-icon'));
  this.guardianValue
    = (index, deviceType) => self.beneficiariesTable.all(by.id(`guardianValue-${index}`)).get(deviceType);

  // guardian pop-up
  this.guardianFullNameValue = element(by.id('guardianFullNameValue'));
  this.guardianAddressValue = element(by.id('guardianAddressValue'));

  if (beneficiaryType === 'lumpSum') {
    this.actionLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(5);
  } else {
    this.actionLabel
    = this.beneficiariesTable.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(4);
  }

  this.actionEdit
    = (index, deviceType) => self.beneficiariesTable.all(by.id(`beneficiaryEditButton-${index}`)).get(deviceType);

  this.actionDelete
    = (index, deviceType) => self.beneficiariesTable.all(by.id(`beneficiaryDeleteButton-${index}`)).get(deviceType);


  // bottom of screen
  // -----------------------------------------------------------------
  this.beneficiariesDisclaimer = element(by.tagName('ov-disclaimer-text'));

  this.beneficiariesSaveButton = deviceType => element.all(by.id('beneficiariesSaveButton')).get(deviceType);
  this.beneficiariesCancelButton = deviceType => element.all(by.id('beneficiaryCancelAction')).get(deviceType);
  this.beneficiariesMessage = element(by.id('beneficiariesMessage'));
  this.beneficiariesMessageIcon = this.beneficiariesMessage.element(by.id('beneficiariesMessageIcon'));
  this.beneficiariesMessageLabel = this.beneficiariesMessage.element(by.id('beneficiariesMessageLabel'));
  this.beneficiariesMessageCloseButton
    = this.beneficiariesMessage.element(by.id('beneficiariesMessageCloseButton'));

  // exposed functions
};
module.exports = beneficiariesPage;
