// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const CookiePolicy = require('../page-component-objects/cookie-policy.co.js');

// page object
const forgotUserCredentialPage = function forgotUserCredentialPage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/forgot-`;

  // https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/forgot-userid
  this.forgotUserIdUrl = `${this.url}userid`;

  // https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/forgot-passcode
  this.forgotPasscodeUrl = `${this.url}passcode`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.cookiePolicy = new CookiePolicy();

  this.helpAndContactUsLink = element(by.id('helpAndContactUsLink'));
  this.mercerCardHeader = element(by.tagName('mercer-card-header'));
  this.mercerCardContent = element(by.tagName('mercer-card-content'));

  this.defaultUserIdControl = element(by.css('ov-input[icon="person"]'));
  this.defaultUserIdIcon = this.defaultUserIdControl.element(by.tagName('mercer-icon'));
  this.defaultUserIdLabel = this.defaultUserIdControl.element(by.css('label[for="defaultUserIdInput"]'));
  this.defaultUserIdInput = this.defaultUserIdControl.element(by.id('defaultUserIdInput'));
  this.userIdFieldError = element(by.id('defaultUserIdRequiredErrorText'));
  this.forgotUserIdLink = element(by.id('forgotUserIdLink'));

  this.emailAddressControl = element(by.css('ov-input[icon="mail_outline"]'));
  this.emailAddressIcon = this.emailAddressControl.element(by.tagName('mercer-icon'));
  this.emailAddressLabel = this.emailAddressControl.element(by.css('label[for="emailAddressInput"]'));
  this.emailAddressInput = this.emailAddressControl.element(by.id('emailAddressInput'));
  this.emailAddressFieldError = element(by.id('emailAddressRequiredErrorText'));

  // TODO: these are probably on the wrong page object
  this.registerTab = element(by.id('registerTab'));
  this.registerTab1 = element(by.id('registerTab1'));

  // forgot user ID page elements
  this.forgotUserIdLabel = element(by.id('forgotUseridLabel'));
  this.forgotUserIdHeaderLabel = deviceType => element.all(by.id('forgotUseridHeaderLabel')).get(deviceType);
  this.forgotUserIdPopUp = element(by.tagName('mercer-popup-content'));
  this.forgotUserIdPopUpTitle = this.forgotUserIdPopUp.element(by.className('mos-c-popup__title'));
  this.forgotUserIdPopUpDescription = this.forgotUserIdPopUp.element(by.className('mos-c-popup__content'));

  // forgot passcode page elements
  this.forgotPasscodeLabel = element(by.id('forgotPasscodeLabel'));
  this.forgotPasscodeHeaderLabel = deviceType => element.all(by.id('forgotPasscodeHeaderLabel')).get(deviceType);

  // card footer
  this.registrationCardFooter = element(by.tagName('mercer-card-footer'));
  this.cancelButton = this.registrationCardFooter.element(by.id('cancelButton'));
  this.loseChangesConfirmButton = element(by.id('loseChangesConfirmButton'));
  this.continueButton = this.registrationCardFooter.element(by.id('continueButton'));

  // define back button which should NOT be found (ouk-6213) - added as Dev are having problems removing
  this.backButton = this.registrationCardFooter.element(by.partialButtonText('Back'));
};
module.exports = forgotUserCredentialPage;
