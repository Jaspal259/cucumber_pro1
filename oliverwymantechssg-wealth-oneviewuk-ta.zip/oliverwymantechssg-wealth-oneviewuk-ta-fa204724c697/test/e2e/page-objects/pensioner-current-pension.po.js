// load common
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const PlanHeader = require('../page-component-objects/pensioner-plan-header.co.js');

// create new objects
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is data driven
const currentPensionPage = function currentPensionPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. http://usdf23v0218.mrshmc.com:5025/pip-plan-summary/OVTL/920
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/pip-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/pension-breakdown`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.pensionerPlanHeader = new PlanHeader('Pensioner');
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);

  // Gross Pension Card
  this.grossPenAction = element(by.id('GrossPenAction'));

  // tabs
  this.pensionViewTabs = element(by.className('ov-content-card-tab-container'));

  // Current Pension View
  this.currentPensionView = this.pensionViewTabs.element(by.id('tab-0'));
  this.grossPensionGraphImage = element(by.id('grossPensionGraphImage'));
  this.grossPensionAmountLabel = element(by.id('grossPensionAmountLabel'));
  this.elementNameHelpIcon = element(by.id('elementNameHelpIcon'));
  this.currentAmountHelpIcon = element(by.id('currentAmountHelpIcon'));
  this.reviewDateHelpIcon = element(by.id('reviewDateHelpIcon'));
  this.checkpointDateHelpIcon = element(by.id('checkpointDateHelpIcon'));
  this.currentPensionInformationText = element(by.id('currentPensionInformationText'));
  this.pensionTable = element(by.tagName('ov-pension-table'));
  this.pensionTableHeader = this.pensionTable.element(by.tagName('thead'));
  this.pensionTableBody = this.pensionTable.element(by.tagName('tbody'));

  // Future Benefits View
  this.futureBenefitsView = this.pensionViewTabs.element(by.id('tab-1'));

  // exposed functions
  this.getHeaderName = (index, deviceType) => {
    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        return this.pensionTableHeader.element(
          by.className(`mos-c-table__header--label mos-c-table__header-label-${index}`));

      case commonConstants.appDeviceTypeEnum.mobile:
        return this.pensionTableBody.all(by.tagName('tr')).get(0).all(by.tagName('td')).get(index);

      default:
        throw new Error(`deviceType '${deviceType}' is not supported`);
    }
  };

  this.getHeaderInfoIcon = (index, deviceType) => {
    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        return this.pensionTableHeader.all(by.css('mercer-icon[mercer-tooltip=""]')).get(index);

      case commonConstants.appDeviceTypeEnum.mobile:
        return this.pensionTableBody.element(by.id(`descriptionHelpIcon-${index}`));

      default:
        throw new Error(`deviceType '${deviceType}' is not supported`);
    }
  };

  // note sorters only apply to desktop
  this.getHeaderInfoSorter = index => this.pensionTableHeader.all(by.css('[icon^="arrow"]')).get(index);

  this.getPensionElementCount = async () => {
    const rowCount = await this.pensionTableBody.all(by.tagName('tr')).count();
    return rowCount;
  };

  this.getElementName = index => this.pensionTableBody.element(by.id(`elementName-${index}`));
  this.getElementNameHelpIcon = index => this.pensionTableBody.element(by.id(`elementNameHelpIcon-${index}`));
  this.getCurrentAmount = index => this.pensionTableBody.element(by.id(`currentAmount-${index}`));
  this.getReviewDate = index => this.pensionTableBody.element(by.id(`reviewDate-${index}`));
  this.getCheckpointDate = index => this.pensionTableBody.element(by.id(`increaseDate-${index}`));
};

module.exports = currentPensionPage;
