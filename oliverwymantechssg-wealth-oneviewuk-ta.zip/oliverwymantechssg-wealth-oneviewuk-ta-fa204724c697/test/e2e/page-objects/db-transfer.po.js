// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');


// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const InfoModal = require('../page-component-objects/info-modal.co.js');
const Toast = require('../page-component-objects/toast.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
const dbTransferPage = function dbTransferPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // otherwise errant space characters can creep into complete string
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/`
    + `db-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/transfer_value`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2847';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '35';
        break;
      case commonConstants.appEnvironmentEnum.stage:
        articleId = '999 - needs Calc Studio set up';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.infoModal = new InfoModal();
  this.toast = new Toast();

  // elements
  this.planHeader = new DbPlanHeader();
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);
  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  // elements
  this.transactionId = element(by.id('transaction_id'));
  this.infoText = element(by.id('info_text'));

  this.columnHeaderName = element(by.id('tbl_doc_name'));
  this.columnHeaderType = element(by.id('tbl_doc_type'));
  this.columnHeaderSize = element(by.id('tbl_doc_size'));
  this.columnHeaderAction = element(by.id('tbl_doc_action'));

  this.accordions = element.all(by.tagName('mercer-accordion'));
  this.accordion = index => this.accordions.get(index);
  this.accordionIcons = this.accordions.all(by.tagName('mercer-vector-icon'));
  this.accordionInfoIcons = element.all(by.css('[icon=info]'));
  this.getAccordionLabel = accordion => accordion.element(by.css('ov-label-with-tooltip > span > h4'));
  this.getAccordionIcon = accordion => accordion.element(by.css('.accordion-icon > mercer-icon'));
  this.getAccordionVectorIcon = accordion => accordion.element(by.className('mercer-vector-icon'));
  this.getAccordionInfoIcon = accordion => accordion.element(by.css('[icon=info]'));
  this.getAccordionInformationLabel = accordion => accordion.element(by.tagName('h4'));
  this.getAccordionExpandButton = accordion => accordion.element(by.css('mercer-accordion-close button'));
  this.getAccordionContent = accordion => accordion.element(by.className('mos-c-accordion__content'));

  /*
    note only the label elements have unique enough IDs in accordion content
    the value elements are located by getting the parent element of the label
    and then using this function to return the much more general partial ID used for values
   */
  this.accordionContentValue = async (accordionContentLabel) => {
    const labelParent = await commonTests.getParentElement(accordionContentLabel);
    return labelParent.element(by.css('[id*="cell_value"]'));
  };

  // Personal Information (labels only - please see this.accordionContentValue())
  this.personalInfoQuoteDateLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="QUODATE"]')).get(deviceType);
  this.personalInfoTotalTransferValueLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="TOUT"]')).get(deviceType);
  this.personalInfoNormalContsLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="NORM_CONTS"]')).get(deviceType);
  this.personalInfoMemberAVCsLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="AVC_CONTS"]')).get(deviceType);
  this.personalInfoMemberAVCsPre87Label
    = (accordion, deviceType) => accordion.all(by.css('[id*="AVC_PRE_APR87"]')).get(deviceType);
  this.personalInfoMemberAVCsPost87Label
    = (accordion, deviceType) => accordion.all(by.css('[id*="AVC_PST_APR87"]')).get(deviceType);
  this.personalInfoCOutInTotalLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="CO_INCLIN_TOT"]')).get(deviceType);
  this.personalInfoCOutInPre97Label
    = (accordion, deviceType) => accordion.all(by.css('[id*="CIN_TV_PRE97"]')).get(deviceType);
  this.personalInfoCOutInPost97Label
    = (accordion, deviceType) => accordion.all(by.css('[id*="CIN_TV_PST97"]')).get(deviceType);
  this.personalInfoTVSubjectToIncreasesLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="TV_SUBJTO_INC"]')).get(deviceType);
  this.personalInfoTV5PctIncreaseLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="TV_5_INCR"]')).get(deviceType);
  this.personalInfoTV2Point5PctIncreaseLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="TV_25_INCR"]')).get(deviceType);
  this.personalInfoLrpLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="LRP"]')).get(deviceType);

  // Transfer value Information (labels only - please see this.accordionContentValue())
  this.tvInfoMemberNameLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="MEM_NAME"]')).get(deviceType);
  this.tvInfoSchemeNameLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="SCHLNAME"]')).get(deviceType);
  this.tvInfoLastKnownAddressLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="LST_ADDR"]')).get(deviceType);
  this.tvInfoDateOfBirthLabel = accordion => accordion.element(by.css('[id*="MDOB "]'));  // space used as "MDOBA" too
  this.tvInfoDOBVerifiedLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="MDOBA"]')).get(deviceType);
  this.tvInfoMaritalStatusLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="MARSTAT"]')).get(deviceType);
  this.tvInfoClassLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="CLASSCODE"]')).get(deviceType);
  this.tvInfoNINumberLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="NINO"]')).get(deviceType);
  this.tvInfoDateJoinedCompanyLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DOJC"]')).get(deviceType);
  this.tvInfoDateEmploymentStartedLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DFCO"]')).get(deviceType);
  this.tvInfoDatePensionableServiceStartedLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DPSC"]')).get(deviceType);
  this.tvInfodatePensionableServiceEndedLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DPSE"]')).get(deviceType);

  // Pension Scheme Details (labels only - please see this.accordionContentValue())
  this.pensionSchemeDetailsDeferredPensionLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DEF_PENS_DOL"]')).get(deviceType);
  this.pensionSchemeDetailsOnDeathInServiceLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="MBDTH_PR_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsSpousesDISLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="SPPEN_PR_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsDependantsDISLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DPPEN_PR_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsChildrensDISLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="CHPEN_PR_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsDeathInRetirementLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="MBDTH_AF_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsSpousesDIRLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="SPPEN_PS_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsDependantsDIRLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="DPPEN_PS_PPDT"]')).get(deviceType);
  this.pensionSchemeDetailsChildrensDIRLabel
    = (accordion, deviceType) => accordion.all(by.css('[id*="CHPEN_PS_PPDT"]')).get(deviceType);

  // Notes About This Statement


  this.transferValueContinueButton = element(by.id('transfer_value_continue'));

  this.cancelButton = element(by.id('cancelButton'));
  this.undefinedBackButton = element(by.id('undefinedBackButton'));
  this.errorMessage = element(by.className('mos-o-display-4'));

  this.textForModalWindow = element(by.id('textForModalWindow'));
  this.transferValueLink = element(by.id('db_transfer_value_slideLink'));
  this.inputTextArea = element(by.id('ctlIDInput'));
  this.fieldValidationErrorMsg = element(by.id('ctlIDRequiredErrorText'));
  this.transferValueInformation = element(by.id('transferValueInformation'));
  this.DBTVClientDocumentTable = element(by.className('mos-c-list'));

  this.transferCellLabel = index => element(by.id(`cell_label-${index}`));
  this.transferCellValue = index => element(by.id(`cell_value-${index}`));

  this.getClientDocumentRecordCount = () => {
    const rowCount = this.DBTVClientDocumentTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };

  this.transferTable = element(by.tagName('ov-db-transfer-values-documents'));
  this.getTransferRecordCount = () => {
    const rowCount = this.transferTable.element(by.tagName('mercer-list')).all(by.tagName('a')).count();
    return rowCount;
  };

  this.documentName = index => element(by.id(`documentName-${index}`));
  this.documentType = index => element(by.id(`documentType${index}`));
  this.documentSize = index => element(by.id(`documentSize-${index}`));
  this.documentAction = index => element(by.id(`documentAction-${index}`));

  this.transferValueContinue = element(by.id('transfer_value_continue'));
  this.continueButton = element(by.id('continueButton'));
  this.newPensionArrangementInput = element(by.id('ctlIDInput'));
};
module.exports = dbTransferPage;
