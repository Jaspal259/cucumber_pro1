// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const DbPlanHeader = require('../page-component-objects/db-plan-header.co.js');
const BudgetPlannerDefault = require('../page-component-objects/budget-planner-default.co.js');
const BudgetPlannerEdit = require('../page-component-objects/budget-planner-edit.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const dbBudgetPlannerPage = function dbBudgetPlannerPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // note since we are using this object for the default and set budget pages this.url is more of a root URL
  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/db-plan-summary/OVTL/17150/budgeting
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/db-plan-summary`
    + `/${midasSchemeCode}/${periodOfServicePrimaryKey}/`;

  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/db-plan-summary/OVTL/17150/budgeting
  this.defaultBudgetUrl = `${this.url}budgeting`;

  // e.g. https://v218-dal-qa-merceros.mercer.com:10492/OVTDEMO/db-plan-summary/OVTL/17150/set-budget
  this.setBudgetUrl = `${this.url}set-budget`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();

  // elements
  this.planHeader = new DbPlanHeader();
  this.budgetPlannerDefault = new BudgetPlannerDefault();
  this.budgetPlannerEdit = new BudgetPlannerEdit();
};
module.exports = dbBudgetPlannerPage;
