// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DcPlanHeader = require('../page-component-objects/dc-plan-header.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const dcRetirementPlanningPage = function dcRetirementPlanningPage(
  participant, midasSchemeCode, periodOfServicePrimaryKey) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/dc-plan-summary/OVTL/17150
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/dc-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/retirement_planner`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2855';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '169';
        break;
      case commonConstants.appEnvironmentEnum.stage:
        articleId = '999 - needs Calc Studio set up';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.header = new Header();
  this.planHeader = new DcPlanHeader();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);
};

module.exports = dcRetirementPlanningPage;
