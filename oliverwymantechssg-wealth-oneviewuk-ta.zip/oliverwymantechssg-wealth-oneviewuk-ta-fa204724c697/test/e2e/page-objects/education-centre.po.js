// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');

// page object
// note this uses a constructor format as the URL is participant data driven
const educationCentrePage = function educationCentrePage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
};
module.exports = educationCentrePage;
