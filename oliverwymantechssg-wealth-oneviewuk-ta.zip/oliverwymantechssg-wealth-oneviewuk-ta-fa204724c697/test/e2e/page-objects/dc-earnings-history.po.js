// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const DcPlanHeader = require('../page-component-objects/dc-plan-header.co.js');

// page object
// note this uses a constructor format as the URL is data driven
const dcEarningsHistoryPage = function dcEarningsHistoryPage(participant, midasSchemeCode, periodOfServicePrimaryKey) {
  const self = this;

  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/dc-plan-summary/OVTL/17150/earnings_history
  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}`
    + `/dc-plan-summary/${midasSchemeCode}/${periodOfServicePrimaryKey}/earnings_history`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new DcPlanHeader();

  // top of screen
  // -----------------------------------------------------------------
  this.dcEarningsHistoryLabel = element(by.id('dcEarningsHistoryLabel'));
  this.dcEarningsHistoryHeaderLabel = element(by.id('dcEarningsHistoryHeaderLabel'));
  this.dcEarningsHistoryContent = element(by.id('dcEarningsHistoryContent'));
  this.dcEarningHistoryActionsButton = element(by.id('earningHistoryActionsButton'));
  this.dcEarningHistoryPrintButton = element(by.id('earningHistoryPrintButton'));
  this.dcEarningsHistoryBackButton = element(by.id('dcEarningsHistoryBackButton'));
  this.dcEarningsHistoryTab = element(by.id('earnings_historyTab'));
  // this.earningHistorySalaryTypeDropdown = element(by.id('earningHistorySalaryTypeDropdown'));
  this.earningHistorySalaryTypeDropdown = element(by.className('ov-content-card-tab-arrow'));
  this.pensionableSalaryLink = element(by.id('pensionableSalaryLink'));
  this.annualEarningsLink = element(by.id('annualEarningsLink'));
  this.grossEarningsLink = element(by.id('grossEarningsLink'));

  // tabs to switch between different earnings (a.k.a. salaries)
  // -----------------------------------------------------------------
  this.salaryTypeTab = function salaryTypeTab(index) {
    return element(by.id(`salaryTypeTab-${index}`));
  };

  // earnings table
  // -----------------------------------------------------------------
  this.dcEarningsTable = element(by.tagName('ov-earning-history-table'));
  this.dcEarningsTableHeaderRow = this.dcEarningsTable.element(by.tagName('thead'));

  this.getCountOfDataTableHeaderColumns = async () => {
    const count = await this.dcEarningsTableHeaderRow.all(by.tagName('th')).count();
    return count;
  };

  this.getCountOfDataTableHeaderSorters = async () => {
    const count = await this.dcEarningsTableHeaderRow.all(by.tagName('mercer-icon')).count();
    return count;
  };

  this.getEarningHistoryRecordCount = async () => {
    const rowCount = await this.dcEarningsTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };

  this.dateValue = index => self.dcEarningsTable.element(by.id(`dateValue-${index}`));

  this.amountValue = index => self.dcEarningsTable.element(by.id(`amountValue-${index}`));

  // exposed functions
};
module.exports = dcEarningsHistoryPage;
