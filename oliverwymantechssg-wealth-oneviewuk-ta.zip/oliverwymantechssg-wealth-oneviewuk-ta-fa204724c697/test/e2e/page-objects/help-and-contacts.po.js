// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');

// page object
const helpAndContactsPage = function helpAndContactsPage(participant) {
  const self = this;

  this.basePageUrl = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/help-and-contacts`;
  this.helpUrl = `${self.basePageUrl}/help`;

  this.url = this.basePageUrl;        // required for using commonTests.checkPageLoadsAndContainsStandardElements()

  this.baseContactUsUrl = `${self.basePageUrl}/contact-us`;
  this.contactUsOnlineUrl = `${self.baseContactUsUrl}/online`;
  this.contactUsPhoneUrl = `${self.baseContactUsUrl}/phone`;
  this.contactUsPostUrl = `${self.baseContactUsUrl}/post`;

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements

  // top of screen
  // -----------------------------------------------------------------
  this.headerContactUs = element(by.id('headerContactUs'));
  this.helpAndContactsLabel = deviceType => element.all(by.id('undefinedLabel')).get(deviceType);
  this.usefulInformationHeaderLabel = deviceType => element.all(by.id('undefinedHeaderLabel')).get(deviceType);

  this.backButton = element(by.id('backButton'));
  this.contactUsQuestion1 = element(by.id('aboutRadioLabelSite'));

  this.tabContainer = element(by.className('ov-content-card-tab-container'));
  this.helpTab = this.tabContainer.all(by.className('ov-content-card-tab')).get(0);
  this.helpTabLink = this.helpTab.element(by.tagName('a'));
  this.contactUsTab = this.tabContainer.all(by.className('ov-content-card-tab')).get(1);
  this.contactUsTabLink = this.contactUsTab.element(by.tagName('a'));

  this.contactUsTypeDesktopTabGroup = element(by.tagName('mercer-button-group'));
  this.contactUsTypeMobileDropDownContainer = element(by.css('ov-sub-categories[idprefix="contactButton-"]'));
  this.contactUsTypeMobileDropDown
    = this.contactUsTypeMobileDropDownContainer.element(by.className('ov-dropdown-selection'));
  this.contactUsTypeMobileDropDownList = element(by.className('mos-c-dropdown__list'));

  // contact us online
  this.contactUsOnlineDesktopSubTab = this.contactUsTypeDesktopTabGroup.element(by.id('contactButton-0'));
  this.contactUsOnlineMobileDropdownOption = this.contactUsTypeMobileDropDownList.all(by.tagName('a')).get(0);

  // contact us by phone
  this.contactUsPhoneDesktopSubTab = this.contactUsTypeDesktopTabGroup.element(by.id('contactButton-1'));
  this.contactUsPhoneMobileDropdownOption = this.contactUsTypeMobileDropDownList.all(by.tagName('a')).get(1);
  this.contactUsPhoneHeader = element(by.id('contactUsPhoneHeader'));
  this.contactUsPhoneMethod = index => element(by.id(`contactsByPhoneValue-${index}`));

  // contact us by post
  this.contactUsPostDesktopSubTab = this.contactUsTypeDesktopTabGroup.element(by.id('contactButton-2'));
  this.contactUsPostMobileDropdownOption = this.contactUsTypeMobileDropDownList.all(by.tagName('a')).get(2);
  this.contactUsPostHeader = element(by.id('contactUsPostHeader'));
  this.contactUsPostMethod = index => element(by.id(`detailsForMethodOfContactValue${index}`));

  this.stepOneCheck = element(by.id('stepOneCheck'));
  this.stepTwoCheck = element(by.id('stepOneCheck'));
  this.activeMethodOfContact = element(by.className('mos-u-spacer--padding-sm ov-custom-active-option'));
  this.methodRadioLabelOnline = this.activeMethodOfContact.element(by.id('methodRadioImageOnline'));
  this.detailsForMethodOfContactSelect = element(by.id('detailsForMethodOfContactSelect'));
  this.detailsForMethodOfContactText = element(by.id('detailsForMethodOfContactText'));
  this.contactDetailsEditButton = element(by.id('contactDetailsEditButton'));
  this.contactDetailsSubmitButton = element(by.id('contactDetailsSubmitButton'));
  this.contactDetailSaveButton = element(by.id('contactDetailSaveButton'));
  this.profileContactDetailsPhoneNumberLabel = element(by.id('profileContactDetailsPhoneNumberLabel'));
  this.phoneNumberValue = element(by.id('phoneNumberValue'));
  this.profileContactDetailsEmailAddressLabel = element(by.id('profileContactDetailsEmailAddressLabel'));
  this.emailAddressValue = element(by.id('emailAddressValue'));
  this.addressLine1 = element(by.id('addressLine1'));
  this.addressLine1RequiredErrorText = element(by.id('addressLine1RequiredErrorText'));
  this.updateSuccessMessageText = element(by.id('updateSuccessMessageText'));
  this.successMessageText = element(by.id('secure_message_success'));
  this.editButton = element(by.id('editButton'));
  this.undefinedRequiredErrorText = element(by.id('undefinedRequiredErrorText'));
  this.loseChangesConfirmButton = element(by.id('loseChangesConfirmButton'));
  this.enterYourQuestionsLabel = element(by.id('enter_your_questions'));
  this.editContactDetailsLabel = element(by.id('edit_your_contact_details'));
  this.submitButton = element(by.id('submitButton'));
  this.postalAddressLabel = element(by.id('contact_details_postal_address'));
  this.residencyLabel = element(by.id('residencyLabel'));
  this.residencyValue = element(by.id('residencyValue'));
  this.phoneNumberLabel = element(by.id('phoneNumberLabel'));
  this.emailAddressLabel = element(by.id('contact_details_email_address'));
  this.descriptionForContactDetails = element(by.id('descriptionForContactDetails'));
  this.secureMessageSubmit = element(by.id('secure_message_submit_warning'));
  this.textArea = element(by.tagName('textarea'));
  this.saveButton = element(by.id('saveButton'));
  this.confirmButton = element(by.id('confirmButton'));
  this.disclaimer = element(by.tagName('ov-disclaimer-text'));

  // help topics
  this.helpTopicsContainer = element(by.tagName('ov-help-accordion'));
  this.helpTopics = this.helpTopicsContainer.all(by.css('mercer-accordion[expandedheaderbg="primary-alt"]'));

  this.getHelpTopicCount = async () => {
    const topicCount = await this.helpTopics.count();
    return topicCount;
  };

  this.helpTopic = index => this.helpTopics.get(index);
  this.helpTopicIcon = index => this.helpTopic(index).element(by.tagName('mercer-vector-icon'));
  this.helpTopicLabel = index => this.helpTopic(index).element(by.id(`helpTopicLabel${index}`));
  this.helpTopicExpander = index => this.helpTopic(index).all(by.tagName('button')).get(0);

  // help stories (contained within each help topic)
  this.helpStoriesContainer = (topicIndex) => {
    this.helpTopic(topicIndex).element(by.tagName('ov-help-sub-accordion'));
  };

  this.helpStories = (topicIndex) => {
    this.helpStoriesContainer(topicIndex).all(by.tagName('mercer-accordion'));
  };

  this.getHelpStoryCount = async (topicIndex) => {
    const storyCount = await this.helpStories(topicIndex).count();
    return storyCount;
  };

  this.helpStory = (topicIndex, subTopicIndex) => {
    this.helpStories(topicIndex).get(subTopicIndex);
  };

  this.helpStoryLabel = (topicIndex, subTopicIndex) => {
    this.helpStory(topicIndex, subTopicIndex).element(by.className(
      'columns mos-u-align-center--vertical mos-o-body-2'));
  };

  this.helpStoryExpander = (topicIndex, subTopicIndex) => {
    this.helpStory(topicIndex, subTopicIndex).element(by.tagName('button'));
  };

  this.helpStoryContent = (topicIndex, subTopicIndex) => {
    this.helpStory(topicIndex, subTopicIndex).element(by.css('mos-c-accordion__content'));
  };
};
module.exports = helpAndContactsPage;
