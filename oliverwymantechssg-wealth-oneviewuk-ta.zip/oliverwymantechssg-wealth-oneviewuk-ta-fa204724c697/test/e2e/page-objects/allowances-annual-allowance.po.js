// load common
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const PensionerPlanHeader = require('../page-component-objects/pensioner-plan-header.co.js');

// create new objects
const commonConstants = new CommonConstants();

const annualAllowancePage = function annualAllowance(participant) {
  // e.g. https://v218-dal-qa-merceros.mercer.com:5025/OVTDEMO/allowances/annual

  this.url
    = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/`
    + 'pip-plan-summary/OVTL/920/allowances/annual';
  this.lifeTimeAllowance = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/`
    + 'pip-plan-summary/OVTL/920/allowances/lifetime';

  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();

  // elements
  this.planHeader = new PensionerPlanHeader();

  this.annualAllowanceTab = element(by.id('allowances_annualLink'));
  this.allowancesLabel = element(by.id('tab-0'));
  this.lifeTimeAllowanceTab = element(by.id('tab-1'));
  this.allowanceDescription = element(by.id('allownceDescription'));
  this.lifetimeAllowanceInformationInfo = element(by.id('lifetime_allowance_information_info'));
  this.lifetimeAllowanceLearnMore = element(by.id('lifetime_allowance_learn_more'));
  this.LifeTimeAllowancePlanLabel
    = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(0);
  this.LifeTimeAllowanceStatusLabel
    = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(1);
  this.LifeTimeAllowanceEffectiveDateLabel
    = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.LifeTimeAllowanceLabel
    = element.all(by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(3);
  this.guidanceWindowOkButton = element(by.id('guidance_modal_ok'));
  this.modalWindowText = element(by.id('modalWindowText'));
  this.annualAllowancesIntroText = element(by.id('annualAllowancesIntroText'));
  this.planLabel = element(by.id('planLabel'));
  this.pensionInputPeriodEndDateLabel = element(by.id('pensionInputPeriodEndDateLabel'));
  this.taxYearLabel = element(by.id('taxYearLabel'));
  this.pensionInputAmountLabel = element(by.id('pensionInputAmountLabel'));
  this.annualAllowanceLimitLabel = element(by.id('annualAllowanceLimitLabel'));
  this.annualAllowanceLabel = element(by.id('annualAllowanceLabel'));
  this.planValue = element(by.id('planValue'));
  this.pensionInputPeriodEndDateValue = element(by.id('pensionInputPeriodEndDateValue'));
  this.TaxYearValue = element(by.id('TaxYearValue'));
  this.pensionInputAmountValue = element(by.id('pensionInputAmountValue'));
  this.limitValueForAA = element(by.id('annualAllowanceLimitValue'));
  this.annualAllowanceValue = element(by.id('annualAllowanceValue'));
  this.guidanceLinkForMPAA = element(by.id('guidanceLinkForMPAA'));
  this.guidanceLinkForAA = element(by.id('guidanceLinkForAA'));
  this.annualAllowanceLimitInfoLink = element(by.id('annualAllowanceLimitInfoLink'));
  this.annualAllowanceInfoLink = element(by.id('annualAllowanceInfoLink'));
  this.labelForAA = element(by.id('labelForAA'));
  this.labeForMPAA = element(by.id('labeForMPAA'));
  this.limitsLinkForMPAA = element(by.id('limitsLinkForMPAA'));
  this.resourcesLabel = element(by.id('resourcesLabel'));
  this.lifeTimeAllowanceTable = element(by.className('mos-c-table mos-u-table--bordered mos-u-table--responsive'));

  // TODO: replace this.*Article with article component objects loaded into this page object
  this.logoForArticle = function logoForArticle(index) {
    return element(by.id(`logoForArticle-${index}`));
  };

  this.scheme = function scheme(index) {
    return element(by.id(`scheme-${index}`));
  };

  this.statusEffectiveDate = function statusEffectiveDate(index) {
    return element(by.id(`statusEffectiveDate-${index}`));
  };

  this.effectiveDate = function effectiveDate(index) {
    return element(by.id(`effectiveDate-${index}`));
  };

  this.allowancePercent = function allowancePercent(index) {
    return element(by.id(`allowancePercent-${index}`));
  };

  this.textForArticle = function textForArticle(index) {
    return element(by.id(`textForArticle-${index}`));
  };

  this.getLifeTimeAllowanceRecordCount = async () => {
    const rowCount = await this.lifeTimeAllowanceTable.element(by.tagName('tbody')).all(by.tagName('tr')).count();
    return rowCount;
  };

  this.linkForArticle = function linkForArticle(index) {
    return element(by.id(`linkForArticle-${index}`));
  };
};

module.exports = annualAllowancePage;
