// load common
const CommonTests = require('../utilities/common-tests.js');
const CommonConstants = require('../utilities/common-constants.js');

// load component objects
const Preloader = require('../page-component-objects/preloader.co.js');
const Header = require('../page-component-objects/header.co.js');
const ProductLogo = require('../page-component-objects/product-logo.co.js');
const Footer = require('../page-component-objects/footer.co.js');
const Tooltips = require('../page-component-objects/tooltips.co.js');
const CookiePolicy = require('../page-component-objects/cookie-policy.co.js');
const DashboardSummaryCard = require('../page-component-objects/dashboard-summary-card.co.js');
const EducationArticleCard = require('../page-component-objects/education-article-card.co.js');
const PlanSelectorModal = require('../page-component-objects/plan-selector-modal.co.js');
const Toast = require('../page-component-objects/toast.co.js');

// create new objects
const commonTests = new CommonTests();
const commonConstants = new CommonConstants();

// page object
// note this uses a constructor format as the URL is participant data driven
const dashboardPage = function dashboardPage(participant) {
  this.url = `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/dashboard`;

  // note this retrieves the ID for article instance 1
  this.article1Url = () => {
    const ov3Environment = commonTests.getOv3Environment();
    let articleId;

    switch (ov3Environment) {
      case commonConstants.appEnvironmentEnum.qa:
        articleId = '2838';
        break;
      case commonConstants.appEnvironmentEnum.uat:
        articleId = '19';
        break;
      case commonConstants.appEnvironmentEnum.staging:
        articleId = '20';
        break;
      default:
        throw new Error(`OV3 environment '${ov3Environment}' not supported by this page object`);
    }

    return `${browser.params.ov3RootUrl}${participant.client.data.clientCode}/education-centre/${articleId}`;
  };

  this.preloader = new Preloader();
  this.header = new Header();
  this.productLogo = new ProductLogo();
  this.footer = new Footer();
  this.tooltips = new Tooltips();
  this.cookiePolicy = new CookiePolicy();
  this.planSelectorModal = new PlanSelectorModal();
  this.toast = new Toast();

  // Hero Image
  this.productHeroImage = element(by.id('DashboardHeroImage'));
  this.productHeroImageDiv = this.productHeroImage.element(by.css('.mos-c-hero'));

  // InvestCards
  this.dcInvestCard = element(by.id('InvestCard'));
  this.investmentsCurrentLabel = this.dcInvestCard.element(by.id('CurrentLabel'));
  this.investmentsFutureLabel = element(by.id('futureLabel'));
  this.investPage = element(by.className('row'));

  // Contributions Card
  this.contributionCard = element(by.id('ContriCard'));
  this.contributionCardLabel = element(by.id('ContriLabel'));
  this.currentContiCardLabel = this.contributionCard.element(by.id('CurrentLabel'));
  this.historyContriLabel = element(by.id('HistoryLabel'));

  // Greeting
  this.greetingLabel = element(by.id('dashboardHeaderLabel'));

  // Last login time/date
  this.lastLoginLabel = element(by.id('LastLoginLabel'));
  this.lastLoginValue = element(by.id('LastLoginValue'));
  this.planName = element(by.id('define'));


  this.dcCard0 = new DashboardSummaryCard('DC', 0);
  this.dcCard1 = new DashboardSummaryCard('DC', 1);
  this.dbCard0 = new DashboardSummaryCard('DB', 0);
  this.dbCard1 = new DashboardSummaryCard('DB', 1);
  this.pensionerCard0 = new DashboardSummaryCard('PIP', 0);
  this.pensionerCard1 = new DashboardSummaryCard('PIP', 1);

  // articles
  this.article0 = new EducationArticleCard(0);
  this.article1 = new EducationArticleCard(1);
  this.article2 = new EducationArticleCard(2);
  this.article3 = new EducationArticleCard(3);
  this.article4 = new EducationArticleCard(4);

  this.getArticleCard = articleInstance => new EducationArticleCard(articleInstance);
  this.allArticles = element.all(by.tagName('ov-caas-article-card'));

  this.headerResources = element(by.id('headerResources'));
  this.headerManagement = element(by.id('headerManagement'));
  this.welcomeMessageLabel = deviceType => element.all(by.id('dashboardHeaderLabel')).get(deviceType);

  // disclaimer
  this.disclaimer = element(by.tagName('ov-disclaimer-text'));

  // note the plan selector link does not exist by default so a new content link has to be added to Drupal
  // in the disclaimer at the bottom of the OV1 client-specific dashboard using
  //    <a href="/plans/beneficiaries" class="ov-cms-link">Go to beneficiaries using Plan Selector.</a>
  this.planSelectorLink = this.disclaimer.all(by.tagName('a')).get(0);
};
module.exports = dashboardPage;
