// component object
const tooltips = function tooltips() {
  // tooltips should be rendered basically the same on all pages but some pages have multiple tips
  // some have tips at the right, bottom left etc
  this.simpleSoleTooltip = element(by.className('mos-c-tooltip'));
  this.soleTooltip = element(by.css('.mos-c-tooltip .mos-c-tooltip-text'));
  this.firstLeftTooltip
    = deviceType => element.all(by.className('mos-c-tooltip mos-c-tooltip__left')).get(deviceType);
  this.firstRightTooltip = element(by.className('mos-c-tooltip mos-c-tooltip__right'));
  this.topTooltip = element(by.className('mos-c-tooltip__top'));

  // content of tooltip
  this.tooltipArrow = element(by.className('mos-c-tooltip__arrow'));
  this.tooltipText = element(by.className('mos-c-tooltip-text'));

  // data table constants for tooltip data
  this.dataTableValueView = 'View';
  this.dataTableValueNotHeld = 'Not held';
};
module.exports = tooltips;
