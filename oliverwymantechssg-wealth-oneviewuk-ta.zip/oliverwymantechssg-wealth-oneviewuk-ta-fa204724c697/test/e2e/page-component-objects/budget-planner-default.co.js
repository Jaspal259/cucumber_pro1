// load component objects
const Tooltips = require('../page-component-objects/tooltips.co.js');
const BudgetPlannerPieChart = require('./budget-planner-pie-chart.co.js');

// page object
const budgetPlannerDefault = function budgetPlannerDefault() {
  // elements
  this.tooltips = new Tooltips();
  this.budgetPlannerPieChart = new BudgetPlannerPieChart();

  // default page
  // --------------------------------------------------------------------------------//
  this.defaultContainer = element(by.css('ov-content-card mercer-card-content'));

  // contents
  this.infoLabel = element(by.css('mercer-card-content h2'));
  this.chart = element(by.className('chart'));
  this.chartSegments = this.chart.all(by.tagName('path'));
  this.expensesContainer = element(by.id('expenses'));
  this.expensesLabel = this.expensesContainer.element(by.tagName('span'));
  this.expensesValue = this.expensesContainer.element(by.tagName('h3'));
  this.budgetContainer = element(by.id('budget'));
  this.budgetLabel = this.budgetContainer.element(by.tagName('span'));
  this.budgetValue = this.budgetContainer.element(by.tagName('h3'));
  this.lastUpdateDate = element.all(by.css('#lastUpdateDate > span')).last();
  this.setBudgetButton = this.defaultContainer.element(by.tagName('button'));

  // functions to help define expense items
  this.expenseContainer = expenseContainerId => this.defaultContainer.all(by.id(expenseContainerId)).last();
  this.expenseLabel = expenseContainer => expenseContainer.element(by.css('.show-for-large > span'));
  this.expenseValue = (expenseContainer, deviceType) => expenseContainer
    .all(by.css('.mos-u-float-right > span.mos-u-font-weight--medium')).get(deviceType);
  this.expenseInfoIcon = expenseContainer => expenseContainer.all(by.tagName('mercer-icon')).last();

  // Mortgage / rent
  this.mortgageRentContainer = this.expenseContainer('expenses-mortgage-rent');
  this.mortgageRentLabel = this.expenseLabel(this.mortgageRentContainer);
  this.mortgageRentValue = deviceType => this.expenseValue(this.mortgageRentContainer, deviceType);
  this.mortgageRentInfoIcon = this.expenseInfoIcon(this.mortgageRentContainer);

  // Council tax
  this.councilTaxContainer = this.expenseContainer('expenses-council-tax');
  this.councilTaxLabel = this.expenseLabel(this.councilTaxContainer);
  this.councilTaxValue = deviceType => this.expenseValue(this.councilTaxContainer, deviceType);
  this.councilTaxInfoIcon = this.expenseInfoIcon(this.councilTaxContainer);

  // Insurances & pension policies
  this.insurancesPensionPoliciesContainer = this.expenseContainer('expenses-insurances');
  this.insurancesPensionPoliciesLabel = this.expenseLabel(this.insurancesPensionPoliciesContainer);
  this.insurancesPensionPoliciesValue
    = deviceType => this.expenseValue(this.insurancesPensionPoliciesContainer, deviceType);
  this.insurancesPensionPoliciesInfoIcon = this.expenseInfoIcon(this.insurancesPensionPoliciesContainer);

  // Utilities (gas, electricity, water)
  this.utilitiesContainer = this.expenseContainer('expenses-utilities');
  this.utilitiesLabel = this.expenseLabel(this.utilitiesContainer);
  this.utilitiesValue = deviceType => this.expenseValue(this.utilitiesContainer, deviceType);
  this.utilitiesInfoIcon = this.expenseInfoIcon(this.utilitiesContainer);

  // TV / Phone / Internet (incl. mobile)
  this.tvPhoneInternetContainer = this.expenseContainer('expenses-tv-phone-internet');
  this.tvPhoneInternetLabel = this.expenseLabel(this.tvPhoneInternetContainer);
  this.tvPhoneInternetValue = deviceType => this.expenseValue(this.tvPhoneInternetContainer, deviceType);
  this.tvPhoneInternetInfoIcon = this.expenseInfoIcon(this.tvPhoneInternetContainer);

  // Groceries
  this.groceriesContainer = this.expenseContainer('expenses-groceries');
  this.groceriesLabel = this.expenseLabel(this.groceriesContainer);
  this.groceriesValue = deviceType => this.expenseValue(this.groceriesContainer, deviceType);
  this.groceriesInfoIcon = this.expenseInfoIcon(this.groceriesContainer);

  // Loan / Credit Card Repayments
  this.loanCreditCardContainer = this.expenseContainer('expenses-loan');
  this.loanCreditCardLabel = this.expenseLabel(this.loanCreditCardContainer);
  this.loanCreditCardValue = deviceType => this.expenseValue(this.loanCreditCardContainer, deviceType);
  this.loanCreditCardInfoIcon = this.expenseInfoIcon(this.loanCreditCardContainer);

  // Travel
  this.travelContainer = this.expenseContainer('expenses-travel');
  this.travelLabel = this.expenseLabel(this.travelContainer);
  this.travelValue = deviceType => this.expenseValue(this.travelContainer, deviceType);
  this.travelInfoIcon = this.expenseInfoIcon(this.travelContainer);

  // Leisure
  this.leisureContainer = this.expenseContainer('expenses-leisure');
  this.leisureLabel = this.expenseLabel(this.leisureContainer);
  this.leisureValue = deviceType => this.expenseValue(this.leisureContainer, deviceType);
  this.leisureInfoIcon = this.expenseInfoIcon(this.leisureContainer);

  // Other Expenses
  this.otherExpensesContainer = this.expenseContainer('expenses-other');
  this.otherExpensesLabel = this.expenseLabel(this.otherExpensesContainer);
  this.otherExpensesValue = deviceType => this.expenseValue(this.otherExpensesContainer, deviceType);
  this.otherExpensesInfoInfo = this.expenseInfoIcon(this.otherExpensesContainer);
};
module.exports = budgetPlannerDefault;
