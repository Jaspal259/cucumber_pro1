// component object
// *** NOTE THAT THIS COMPONENT OBJECT IS SEPARATE FROM THE COOKIE POLICY PAGE OBJECT ***

// load common
const CommonConstants = require('../utilities/common-constants.js');
const CommonTests = require('../utilities/common-tests.js');

// create new objects
const commonConstants = new CommonConstants();
const commonTests = new CommonTests();

// other
const until = protractor.ExpectedConditions;

const cookiePolicy = function cookiePolicy() {
  const self = this;

  // cookie policy is shown for any OV3 page
  this.cookiePolicyContainer = element(by.tagName('ov-cookies-policy'));
  this.cookiePolicyText = element(by.id('CookiePolicyText'));
  this.cookiePolicyAgreeButton = element(by.id('CookiePolicyAgreeButton'));
  this.cookiePolicyCancelButton = element(by.id('CookiePolicyCancelButton'));

  /**
   * @param isAgreed   if true, policy agreed, else policy cancelled
   */
  this.agreeCookiePolicy = async (isAgreed) => {
    // note need to check existence of agree and cancel buttons as otherwise policy window reappears
    // after cancel clicked

    /*
      note use of browser.sleep() then browser.isElementPresent() construction to detect the
      presence or otherwise of the cookiePolicyAgreeButton - we have to use this rather than
      browser.wait(until.presenceOf([element]), [wait time], [error]) because until.presenceOf
      will not allow us to do nothing if the element is not found - it can only report an error message
     */
    await browser.sleep(commonConstants.shortBrowserWaitDelay);
    const present = await browser.isElementPresent(self.cookiePolicyAgreeButton);

    if (present) {
      await browser.wait(
        until.elementToBeClickable(self.cookiePolicyAgreeButton),
        commonConstants.shortBrowserWaitDelay,
        'Cookie policy agree button is not clickable');

      if (isAgreed === true) {
        await commonTests.clickElement(self.cookiePolicyAgreeButton);
        await browser.wait(
          until.stalenessOf(self.cookiePolicyAgreeButton),
          commonConstants.briefBrowserWaitDelay,
          'Clicking button to agree cookie policy did not remove agree prompt');
        global.ov3CookiePolicyAgreed = true;
      } else {
        await commonTests.clickElement(self.cookiePolicyCancelButton);
      }
    } else {
      /*
        do nothing
        cookiePolicyAgreeButton not present
        no error to report
       */
    }
  };
};
module.exports = cookiePolicy;
