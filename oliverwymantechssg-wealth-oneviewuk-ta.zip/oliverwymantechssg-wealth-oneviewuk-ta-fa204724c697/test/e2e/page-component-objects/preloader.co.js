// component object
const preloader = function preloader() {
  // the preloader is only shown whilst the page is being prepared
  this.outerContainer = element(by.css('.ov-main-layout-preloader-outer-container'));
  this.innerContainer = element(by.css('.ov-main-layout-preloader-inner-container'));
  this.mainLayout = element(by.css('.ov-main-layout-preloader'));
};
module.exports = preloader;
