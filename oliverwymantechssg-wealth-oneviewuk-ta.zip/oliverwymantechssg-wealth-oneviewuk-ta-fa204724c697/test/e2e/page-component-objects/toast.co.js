// component object
const toast = function toast() {
  this.container = element(by.className('mos-c-toast--group')).element(by.className('mos-c-toast--container'));

  // contents
  this.infoIcon = this.container.element(by.className('shrink mos-c-toast__icon-box'));
  this.content = this.container.element(by.tagName('toaster-template'));
  this.heading = this.content.element(by.tagName('h4'));

  // note cannot use
  //   this.content.element(by.tagName('p'));
  // as sometimes there are multiple <p> tags in toasts
  this.message = this.content;
  this.closeIcon = this.container.element(by.css('mercer-icon[icon="close"]'));
};
module.exports = toast;
