// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const logoutModal = function logoutModal() {
  // header
  this.headerContainer = element(by.tagName('mercer-modal-header'));
  this.header = this.headerContainer.element(by.tagName('h3'));

  // contents
  this.contentContainer = element(by.tagName('mercer-modal-content'));
  this.descriptionUpper = this.contentContainer.all(by.tagName('p')).get(0);
  this.descriptionLower = this.contentContainer.all(by.tagName('p')).get(1);

  // footer - desktop
  this.footerContainer = deviceType => element.all(by.tagName('mercer-modal-footer')).get(deviceType);

  this.continueButton = (deviceType) => {
    if (deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      return this.footerContainer(deviceType).element(by.id('continueButton'));
    }
    return this.footerContainer(deviceType).element(by.id('continueButtonMobile'));
  };

  this.logoutButton = (deviceType) => {
    if (deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      return this.footerContainer(deviceType).element(by.id('logoutButton'));
    }
    return this.footerContainer(deviceType).element(by.id('logoutButtonMobile'));
  };

  this.logoutLosingChangesButton = (deviceType) => {
    if (deviceType === commonConstants.appDeviceTypeEnum.desktop) {
      return this.footerContainer(deviceType).element(by.id('loseChangesConfirmButton'));
    }
    // note no 'Mobile' suffix here but allowing for later difference in case
    return this.footerContainer(deviceType).element(by.id('loseChangesConfirmButton'));
  };
};
module.exports = logoutModal;
