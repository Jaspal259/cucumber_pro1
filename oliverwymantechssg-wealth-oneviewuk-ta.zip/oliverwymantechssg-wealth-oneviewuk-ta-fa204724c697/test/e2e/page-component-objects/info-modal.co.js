// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const infoModal = function infoModal() {
  this.container = element(by.className(commonConstants.mosCssModalContentWrapper));

  // header
  this.header = this.container.element(by.css('mercer-modal-header h3'));

  // contents
  this.content = this.container.element(by.tagName('mercer-modal-content'));
  this.description = this.content.element(by.tagName('p'));

  // footer
  this.footer = deviceType => this.container.all(by.tagName('mercer-modal-footer')).get(deviceType);
  this.continueButton = deviceType => this.footer(deviceType).element(by.id('continueButton'));
  this.cancelButton = deviceType => this.footer(deviceType).element(by.id('cancelButton'));
};
module.exports = infoModal;
