// component object
const unsavedChangesModal = function unsavedChangesModal() {
  // header
  this.headerContainer = element(by.tagName('mercer-modal-header'));
  this.header = this.headerContainer.element(by.tagName('h3'));

  // contents
  this.contentContainer = element(by.tagName('mercer-modal-content'));
  this.description = this.contentContainer.element(by.tagName('p'));

  // footer
  this.footerContainer
    = deviceType => element.all(by.tagName('mercer-modal-footer')).get(deviceType);
  this.cancelCancelButton
    = deviceType => this.footerContainer(deviceType).element(by.id('cancelButton'));
  this.confirmCancelButton
    = deviceType => this.footerContainer(deviceType).element(by.id('loseChangesConfirmButton'));
};
module.exports = unsavedChangesModal;
