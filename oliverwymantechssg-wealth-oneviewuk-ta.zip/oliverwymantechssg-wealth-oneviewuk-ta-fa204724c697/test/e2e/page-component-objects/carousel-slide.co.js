// load component objects
const Carousel = require('../page-component-objects/carousel.co.js');

// component object
// note this uses a constructor format as we need to potentially load several instances to the parent object
const carouselSlide = function carouselSlide(slideType, slideLabelId, slideLinkId) {
  this.slideType = slideType;
  this.carousel = new Carousel();

  // elements

  // note slide, icon and description text do not have unique IDs so just define label and link
  this.slideLabel = this.carousel.carouselContainer.element(by.id(slideLabelId));
  this.slideLink = this.carousel.carouselContainer.element(by.id(slideLinkId));

  // elements
  this.card = element(by.id(`${slideLabelId}Card-${slideLinkId}`));
  this.icon = this.card.element(by.id('Icon'));
  this.typeLabel = this.card.element(by.id('TypeLabel'));
  this.longSchemeNameValue = this.card.element(by.id('LongSchemeNameValue'));
  this.posStatusLabel = this.card.element(by.id('statusLabel'));
  this.posStatusValue = this.card.element(by.id('statusValue'));
  this.detailsButton = this.card.element(by.id('DetailsButton'));
  this.dateJoinedSchemeLabel = this.card.element(by.id('dateJoinedLabel'));
  this.dateJoinedSchemeValue = this.card.element(by.id('dateJoinedValue'));
  this.dateOfExitLabel = this.card.element(by.id('dateOfExitLabel'));
  this.dateOfExitValue = this.card.element(by.id('dateOfExitValue'));
  this.dateOfRetirementLabel = this.card.element(by.id('dateOfRetirementLabel'));
  this.dateOfRetirementInfoIcon = this.card.element(by.id('dateOfRetirementInfoIcon'));
  this.dateOfRetirementValue = this.card.element(by.id('dateOfRetirementValue'));
  this.clientDefinedIDLabel = this.card.element(by.id('penNumberLabel'));   // e.g. "PENSION NUMBER"
  this.clientDefinedIDValue = this.card.element(by.id('penNumberValue'));   // e.g. pension number value
  this.amountLabelDc = this.card.element(by.id('AmountLabel'));
  this.amountValue = this.card.element(by.id('AmountValue'));
  this.amountDateLabel = this.card.element(by.id('AmountDateLabel'));
  this.amountDateInfoIcon = this.card.element(by.id('AmountDateInfoIcon'));
  this.memberReferenceValue = this.card.element(by.id('memberReferenceValue'));

  // DC

  // DB

  // pensioner
  this.pensionStartDateLabel = this.card.element(by.id('dateStartLabel'));
  this.pensionStartDateValue = this.card.element(by.id('dateStartValue'));
  this.grossPensionLabel = this.card.element(by.id('AmountLabel'));
  this.grossPensionValue = this.card.element(by.id('AmountValue'));
  this.grossPensionDateLabel = this.card.element(by.id('AmountDateLabel'));
};
module.exports = carouselSlide;
