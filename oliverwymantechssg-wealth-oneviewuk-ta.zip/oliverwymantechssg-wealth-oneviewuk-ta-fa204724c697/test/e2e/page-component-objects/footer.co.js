// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const footer = function footer() {
  // footer is shown for any OV3 page, authorised or not
  this.commonFooter = element.all(by.tagName('footer')).get(0);
  this.mercerFooterLogo = this.commonFooter.element(by.tagName('mercer-footer-logo'));
  this.mercerFooterLogoImage = this.mercerFooterLogo.element(by.css(commonConstants.mosCssResponsiveImage));

  // external MMC links
  this.externalMmcLinks = this.commonFooter.element(by.tagName('mercer-footer-coop-links')).all(by.tagName('a'));
  this.marshLink = this.externalMmcLinks.get(0);
  this.guyCarpenterLink = this.externalMmcLinks.get(1);
  this.mercerLink = this.externalMmcLinks.get(2);
  this.oliverWymanLink = this.externalMmcLinks.get(3);

  // internal footer links
  // links identified by linkText as no ID - acceptable as text should never / rarely change
  this.internalFooterLinks = this.commonFooter.element(by.tagName('mercer-footer-corp-links')).all(by.tagName('a'));
  this.termsOfUseLink = this.internalFooterLinks.get(0);
  this.cookiePolicyLink = this.internalFooterLinks.get(1);
  this.accessibilityStatementLink = this.internalFooterLinks.get(2);

  this.mercerBrandBar = this.commonFooter.element(by.tagName('mercer-brand-bar'));
  this.mercerBrandBarLogo = this.mercerBrandBar.element(by.css('.mos-c-brand-bar__corp-logo'));
  this.mercerBrandBarLogoImage = this.mercerBrandBarLogo.element(by.css(commonConstants.mosCssResponsiveImage));
  this.copyrightLabel = this.mercerBrandBar.element(by.tagName('h4'));

  // the 'return to top of page floating icon'
  // not strictly a footer item but a handy place to store this common element
  this.goToTopOfPageIcon = element(by.tagName('ov-scroll-up'));
};
module.exports = footer;
