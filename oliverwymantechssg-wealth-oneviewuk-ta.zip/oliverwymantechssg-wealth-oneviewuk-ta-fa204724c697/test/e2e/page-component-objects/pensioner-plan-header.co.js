// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const pensionerPlanHeader = function planHeader() {
  // private

  // *** exposed properties ****

  // common

  // elements

  this.planHeader = element(by.id('CommonPensionerHeader'));
  this.typeLabel = this.planHeader.element(by.id('TypeLabel'));
  this.mobileExpandMore
    = this.planHeader.element(by.className('mobile-header-down-arrow')).element(by.tagName('mercer-icon'));
  this.longSchemeNameValue = this.planHeader.element(by.id('LongSchemeNameValue'));
  this.memberReferenceLabel = this.planHeader.element(by.id('memberReferenceLabel'));
  this.memberReferenceValue = this.planHeader.element(by.id('memberReferenceValue'));
  this.pensionNumberLabel = this.planHeader.element(by.id('penNumberLabel'));
  this.pensionNumberValue = this.planHeader.element(by.id('penNumberValue'));
  this.pensionStartDateLabel = this.planHeader.element(by.id('dateStartLabel'));
  this.pensionStartDateValue = this.planHeader.element(by.id('dateStartValue'));

  // navigation menu links (in scroller at top of page)
  // note from Nov 2018 cannot use this.navigationMenuLinksScroller in definition of links as
  // links are no longer contained in this element if they are only shown after clicking this.moreButton
  this.navigationMenuLinksScroller = element(by.tagName('ov-nav-bar'));
  this.moreButton = this.navigationMenuLinksScroller.element(by.tagName('mercer-dropdown'));
  this.summaryLink = element(by.id('summaryLink'));
  this.pensionBreakdownLink = element(by.id('pension-breakdownLink'));
  this.planMaterialsLink = element(by.id('plan_materialsLink'));
  this.historicalPensionLink = element(by.id('historical_pensionLink'));
  this.contactDetailsLink = element(by.id('contact_detailsLink'));
  this.dependantsLink = element(by.id('dependantsLink'));

  this.beneficiariesLink = (deviceType) => {
    /*
      note the deviceType argument is not really needed but is included so we can treat this.beneficiariesLink()
      in the same way whether we are using this pensioner plan header or the DC or DB plan headers
     */
    let link;

    if (deviceType === commonConstants.appDeviceTypeEnum.desktop
      || deviceType === commonConstants.appDeviceTypeEnum.mobile) {
      link = element(by.id('beneficiariesLink'));
    }
    return link;
  };

  this.bankAccountDetailsLink = element(by.id('bank_account_detailsLink'));
  this.allowancesLink = element(by.id('allowancesLink'));
  this.budgetingLink = element(by.id('budgetingLink'));

  // text for navigation menu links
  this.summaryLinkText = 'Summary';
  this.pensionBreakdownLinkText = 'Pension Breakdown';
  this.planMaterialsLinkText = 'Plan materials';
  this.historicalPensionLinkText = 'Historical pension';
  this.contactDetailsLinkText = 'Contact Details';
  this.dependantsLinkText = 'Dependants';
  this.beneficiariesLinkText = 'Beneficiaries';
  this.bankAccountDetailsLinkText = 'Bank Account Details';
  this.allowancesLinkText = 'Allowances';
  this.budgetingLinkText = 'Budgeting';
  this.moreButtonText = 'more';
};
module.exports = pensionerPlanHeader;
