// component object
const mobileHeaderBurgerMenu = function mobileHeaderBurgerMenu() {
  // header is shown for any authorised OV3 page when in mobile mode i.e. after login


  // private


  // *** exposed properties ****
  this.burgerMenuButton = element(by.id('burgerMenuButton'));
  this.homeLink = element(by.id('sideNavHomeButton'));
  this.helpLink = element(by.id('sideNavHelpButton'));
  this.contactUsLink = element(by.id('sideNavContactsButton'));
  this.notificationsLink = element(by.id('sideNavNotificationsButton'));
  this.viewProfileLink = element(by.id('sideNavProfileButton'));
  this.logoutLink = element(by.id('sideNavLogOutButton'));
};
module.exports = mobileHeaderBurgerMenu;
