// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// load component objects
const LogoutModal = require('../page-component-objects/logout-modal.co.js');
const MobileHeaderBurgerMenu = require('../page-component-objects/mobile-header-burger-menu.co.js');

// component object
const header = function header() {
  // header is shown for any authorised OV3 page i.e. after login


  // private


  // *** exposed properties ****


  this.logoutModal = new LogoutModal();
  this.mobileHeaderBurgerMenu = new MobileHeaderBurgerMenu();

  this.commonHeader = element(by.css('.mos-c-header'));

  this.commonHeaderBarSideNavBtn = this.commonHeader.element(by.css('.mos-c-header__bar-sidenav-button'));
  this.commonHeaderBarMercerLogo
    = this.commonHeader.all(by.tagName('mercer-header-logo')).get(0).element(by.tagName('img'));
  this.commonHeaderBarLeft = this.commonHeader.element(by.css('.mos-c-header__bar-left'));

  // client logo section of common header
  // client logo does not use this.commonHeaderBarLogo to locate as the login page does not have that element
  this.clientLogo = element.all(by.tagName('mercer-header-logo')).get(0);
  this.clientLogoImage = this.clientLogo.element(by.tagName('img'));

  // this is mainly for use with commonTests.clickCommonHeaderLink()
  this.commonHeaderLinkEnum = {
    home: 0,
    help: 1,
    contactUs: 2,
    notifications: 3,
    viewProfile: 4,
    logOut: 5
  };

  // menu section of common header
  this.commonHeaderMenuHome = this.commonHeaderBarLeft.element(by.id('headerHome'));
  this.commonHeaderAllowances = this.commonHeaderBarLeft.element(by.id('headerAllowances'));

  this.commonHeaderMenuHelpAndContacts = (isAuthPage) => {
    if (isAuthPage) {
      return this.commonHeaderBarLeft.element(by.id('headerContactUs'));
    }

    return element(by.id('helpAndContactUsLink'));
  };

  this.commonHeaderMenuResources = this.commonHeaderBarLeft.element(by.id('headerResources'));
  this.commonHeaderMenuManagement = this.commonHeaderBarLeft.element(by.id('headerManagement'));
  this.commonHeaderNotificationsIcon = this.commonHeaderBarLeft.element(by.css('mercer-icon[alt="Notifications"]'));

  // user profile section of common header
  this.commonHeaderBarRight = this.commonHeader.element(by.css('.mos-c-header__bar-right'));
  this.userProfileIcon = this.commonHeaderBarRight.element(by.tagName('mercer-avatar'));
  this.userDropDown = this.userProfileIcon;
  this.userDropDownIcon = this.userDropDown.element(by.tagName('mercer-icon'));
  this.userNameLabel = element(by.id('UserNameLabel'));
  this.viewProfileLink = element(by.id('ProfileLink'));

  // logout - note loaded logoutModal component object above
  this.logoutLink = element(by.id('LogoutLink'));

  // header underneath menu
  this.pageCategoryHeader = deviceType => element.all(by.id('undefinedLabel')).get(deviceType);
  this.pageHeader = deviceType => element.all(by.id('undefinedHeaderLabel')).get(deviceType);
  this.backButton = (deviceType) => {
    switch (deviceType) {
      case commonConstants.appDeviceTypeEnum.desktop:
        return element(by.id('undefinedBackButton'));
      case commonConstants.appDeviceTypeEnum.mobile:
        return element(by.className('back-button-phone'));
      default:
        throw new Error(`global.deviceType '${global.deviceType}' is not supported`);
    }
  };

  // back-button-phone

  // content underneath header underneath menu
  this.pageContentHeader = element(by.tagName('mercer-card-header'));

  // tabs
  this.pageContentHeaderMultipleTabs = this.pageContentHeader.all(by.css('.ov-content-card-tab'));
  this.pageContentHeaderMultipleTab = async (index) => {
    const tab = await this.pageContentHeaderMultipleTabs.get(index);
    return tab;
  };

  this.pageContentHeaderLoneTab = this.pageContentHeader.element(by.tagName('h3'));

  this.getPageContentHeaderTabCount = async () => {
    // this more complex function is required because a lone page content tab is rendered differently
    // from 1 of multiple page content tabs
    let tabsCount = commonConstants.notYetDefined;

    const headerPresent = await browser.isElementPresent(this.pageContentHeader);

    if (headerPresent) {
      const multipleTabsCount = await this.pageContentHeaderMultipleTabs.count();
      const singleTabExists = await browser.isElementPresent(this.pageContentHeaderLoneTab);

      if (multipleTabsCount > 0 && !singleTabExists) {
        // multiple tabs exist
        tabsCount = multipleTabsCount;
      } else if (multipleTabsCount === 0 && singleTabExists) {
        // single tab
        tabsCount = 1;
      } else {
        // tab not found
        fail('No page content tabs found');
      }
    } else {
      fail('No page header found');
    }

    return tabsCount;
  };

  this.pageContent = element.all(by.tagName('mercer-card-content')).first();
};
module.exports = header;
