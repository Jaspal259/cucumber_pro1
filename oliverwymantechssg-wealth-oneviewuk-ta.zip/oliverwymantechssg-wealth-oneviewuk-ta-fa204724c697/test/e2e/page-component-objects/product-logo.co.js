// component object - product logo probably a misnomer as really the Mercer logo
const productLogo = function productLogo() {
  this.standardMercerLogo = element.all(by.tagName('mercer-header-logo')).get(0);
  this.standardMercerLogoImage = this.standardMercerLogo.element(by.tagName('img'));
};
module.exports = productLogo;
