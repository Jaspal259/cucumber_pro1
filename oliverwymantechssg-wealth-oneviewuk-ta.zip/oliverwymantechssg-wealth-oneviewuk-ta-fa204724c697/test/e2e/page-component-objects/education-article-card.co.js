// load component objects
const Header = require('../page-component-objects/header.co.js');

// note this uses a constructor format as we need to potentially load several instances to the parent object
const educationArticleCard = function educationArticleCard(articleInstance) {
  // private

  // *** exposed properties ****

  // common


  /*
   cardInstance is the instance of the card
   e.g. if there is 1 article card we could only have 0
   e.g. if there are 3 article cards we could have 0, 1 or 2
   */
  this.header = new Header();
  this.articleInstance = articleInstance; // always use zero-based indexing in JS

  // elements
  this.article = element(by.id(`LogEduCard-${articleInstance}`));
  this.headline = this.article.element(by.id(`ArticleTitle-${articleInstance}`));
  this.icon = this.article.element(by.id(`Icon-${articleInstance}`));
  this.articleDesc = this.article.element(by.id(`EduArticleDesc-${articleInstance}`));
  this.callToAction = this.article.element(by.id(`EduArticleLink-${articleInstance}`));
};
module.exports = educationArticleCard;
