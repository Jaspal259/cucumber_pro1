// component object
const dcPlanHeader = function planHeader() {
  // private

  // *** exposed properties ****

  // common

  // elements

  this.planHeader = element(by.id('CommonDCHeader'));
  this.typeLabel = this.planHeader.element(by.id('TypeLabel'));
  this.mobileExpandMore
    = this.planHeader.element(by.className('mobile-header-down-arrow')).element(by.tagName('mercer-icon'));
  this.longSchemeNameValue = this.planHeader.element(by.id('LongSchemeNameValue'));
  this.memberReferenceLabel = this.planHeader.element(by.id('memberReferenceLabel'));
  this.memberReferenceValue = this.planHeader.element(by.id('memberReferenceValue'));
  this.posStatusLabel = this.planHeader.element(by.id('statusLabel'));
  this.posStatusValue = this.planHeader.element(by.id('statusValue'));
  this.dateJoinedSchemeLabel = this.planHeader.element(by.id('dateJoinedLabel'));
  this.dateJoinedSchemeValue = this.planHeader.element(by.id('dateJoinedValue'));
  this.dateOfExitLabel = this.planHeader.element(by.id('dateOfExitLabel'));
  this.dateOfExitValue = this.planHeader.element(by.id('dateOfExitValue'));
  this.dateOfRetirementLabel = this.planHeader.element(by.id('dateOfRetirementLabel'));
  this.dateOfRetirementInfoIcon = this.planHeader.element(by.id('dateOfRetirementInfoIcon'));
  this.dateOfRetirementValue = this.planHeader.element(by.id('dateOfRetirementValue'));

  // summary links (in scroller at top of page)
  // note from Nov 2018 cannot use this.navigationMenuLinksScroller in definition of links as
  // links are no longer contained in this element if they are only shown after clicking this.moreButton
  this.navigationMenuLinksScroller = element(by.tagName('ov-nav-bar'));
  this.moreButton = this.navigationMenuLinksScroller.element(by.className('sub-nav-more-icon'));
  this.summaryLink = element(by.id('summaryLink'));
  this.annualBenefitStatementLink = element(by.id('annual_benefit_statementLink'));
  this.earningsHistoryLink = element(by.id('earnings_historyLink'));
  this.planMaterialsLink = element(by.id('plan_materialsLink'));
  this.allowancesLink = element(by.id('allowancesLink'));
  this.beneficiariesLink = deviceType => element.all(by.id('beneficiariesLink')).get(deviceType);
  this.transferValueLink = element(by.id('transfer_valueLink'));
  this.retirementPlanningLink = element(by.id('retirement_plannerTab'));
  this.budgetingLink = element(by.id('budgetingLink'));

  // text for navigation menu links
  this.transferValueText = 'Transfer Quotation';
  this.moreButtonText = 'more';
};
module.exports = dcPlanHeader;
