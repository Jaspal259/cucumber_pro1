// component object
const budgetPlannerPieChart = function budgetPlannerPieChart() {
  this.container = element(by.className('slices'));

  // contents
  this.mortgageRentSlice = this.container.element(by.id('expenses-mortgage-rent'));
  this.councilTaxSlice = this.container.element(by.id('expenses-council-tax'));
  this.insurancesSlice = this.container.element(by.id('expenses-insurances'));
  this.utilitiesSlice = this.container.element(by.id('expenses-utilities'));
  this.tvSlice = this.container.element(by.id('expenses-tv-phone-internet'));
  this.groceriesSlice = this.container.element(by.id('expenses-groceries'));
  this.loanSlice = this.container.element(by.id('expenses-loan'));
  this.travelSlice = this.container.element(by.id('expenses-travel'));
  this.leisureSlice = this.container.element(by.id('expenses-leisure'));
  this.otherSlice = this.container.element(by.id('expenses-other'));
};
module.exports = budgetPlannerPieChart;
