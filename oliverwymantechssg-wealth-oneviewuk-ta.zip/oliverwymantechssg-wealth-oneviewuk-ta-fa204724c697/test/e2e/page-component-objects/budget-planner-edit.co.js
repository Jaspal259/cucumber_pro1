// load component objects
const InfoModal = require('../page-component-objects/info-modal.co.js');
const Toast = require('./toast.co.js');
const UnsavedChangesModal = require('../page-component-objects/unsaved-changes-modal.co.js');

// page object
const budgetPlannerEdit = function budgetPlannerEdit() {
  // elements
  this.infoModal = new InfoModal();
  this.toast = new Toast();
  this.unsavedChangesModal = new UnsavedChangesModal();

  // edit page
  // --------------------------------------------------------------------------------//
  this.editHeaderLabel = deviceType => element.all(by.id('undefinedHeaderLabel')).get(deviceType);

  // contents
  this.editSubHeaderLabel = deviceType => element.all(by.id('undefinedLabel')).get(deviceType);
  this.editContentContainer = element(by.css('div[ov-content-card-content=""]'));

  // Income
  this.editIncomeContainer = this.editContentContainer.element(by.tagName('ov-set-budget-income'));
  this.editIncomeInput = this.editIncomeContainer.element(by.id('ctlIDInput'));
  this.editIncomeLabel = this.editIncomeContainer.element(by.tagName('label'));
  this.editIncomeRequiredError = this.editIncomeContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editIncomeDescription = this.editIncomeContainer.element(by.tagName('p'));

  // Mortgage / rent
  this.editMortgageRentContainer = this.editContentContainer.element(by.id('expenses-mortgage-rent'));
  this.editMortgageRentInput = this.editMortgageRentContainer.element(by.id('ctlIDInput'));
  this.editMortgageRentLabel = this.editMortgageRentContainer.element(by.tagName('label'));
  this.editMortgageRentRequiredError = this.editMortgageRentContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editMortgageRentInfoLink = this.editMortgageRentContainer.element(by.css('p>a'));

  // Council tax
  this.editCouncilTaxContainer = this.editContentContainer.element(by.id('expenses-council-tax'));
  this.editCouncilTaxInput = this.editCouncilTaxContainer.element(by.id('ctlIDInput'));
  this.editCouncilTaxLabel = this.editCouncilTaxContainer.element(by.tagName('label'));
  this.editCouncilTaxRequiredError = this.editCouncilTaxContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editCouncilTaxInfoLink = this.editCouncilTaxContainer.element(by.css('p>a'));

  // Insurances & pension policies
  this.editInsurancesPensionPoliciesContainer = this.editContentContainer.element(by.id('expenses-insurances'));
  this.editInsurancesPensionPoliciesInput = this.editInsurancesPensionPoliciesContainer.element(by.id('ctlIDInput'));
  this.editInsurancesPensionPoliciesLabel = this.editInsurancesPensionPoliciesContainer.element(by.tagName('label'));
  this.editInsurancesPensionPoliciesRequiredError = this.editInsurancesPensionPoliciesContainer
    .element(by.id('ctlIDRequiredErrorText'));
  this.editInsurancesPensionPoliciesInfoLink = this.editInsurancesPensionPoliciesContainer.element(by.css('p>a'));

  // Utilities (gas, electricity, water)
  this.editUtilitiesContainer = this.editContentContainer.element(by.id('expenses-utilities'));
  this.editUtilitiesInput = this.editUtilitiesContainer.element(by.id('ctlIDInput'));
  this.editUtilitiesLabel = this.editUtilitiesContainer.element(by.tagName('label'));
  this.editUtilitiesRequiredError = this.editUtilitiesContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editUtilitiesInfoLink = this.editUtilitiesContainer.element(by.css('p>a'));

  // TV / Phone / Internet (incl. mobile)
  this.editTvPhoneInternetContainer = this.editContentContainer.element(by.id('expenses-tv-phone-internet'));
  this.editTvPhoneInternetInput = this.editTvPhoneInternetContainer.element(by.id('ctlIDInput'));
  this.editTvPhoneInternetLabel = this.editTvPhoneInternetContainer.element(by.tagName('label'));
  this.editTvPhoneInternetRequiredError = this.editTvPhoneInternetContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editTvPhoneInternetInfoLink = this.editTvPhoneInternetContainer.element(by.css('p>a'));

  // Groceries
  this.editGroceriesContainer = this.editContentContainer.element(by.id('expenses-groceries'));
  this.editGroceriesInput = this.editGroceriesContainer.element(by.id('ctlIDInput'));
  this.editGroceriesLabel = this.editGroceriesContainer.element(by.tagName('label'));
  this.editGroceriesRequiredError = this.editGroceriesContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editGroceriesInfoLink = this.editGroceriesContainer.element(by.css('p>a'));

  // Loan / Credit Card Repayments
  this.editLoanCreditCardContainer = this.editContentContainer.element(by.id('expenses-loan'));
  this.editLoanCreditCardInput = this.editLoanCreditCardContainer.element(by.id('ctlIDInput'));
  this.editLoanCreditCardLabel = this.editLoanCreditCardContainer.element(by.tagName('label'));
  this.editLoanCreditCardRequiredError = this.editLoanCreditCardContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editLoanCreditCardInfoLink = this.editLoanCreditCardContainer.element(by.css('p>a'));

  // Travel
  this.editTravelContainer = this.editContentContainer.element(by.id('expenses-travel'));
  this.editTravelInput = this.editTravelContainer.element(by.id('ctlIDInput'));
  this.editTravelLabel = this.editTravelContainer.element(by.tagName('label'));
  this.editTravelRequiredError = this.editTravelContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editTravelInfoLink = this.editTravelContainer.element(by.css('p>a'));

  // Leisure
  this.editLeisureContainer = this.editContentContainer.element(by.id('expenses-leisure'));
  this.editLeisureInput = this.editLeisureContainer.element(by.id('ctlIDInput'));
  this.editLeisureLabel = this.editLeisureContainer.element(by.tagName('label'));
  this.editLeisureRequiredError = this.editLeisureContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editLeisureInfoLink = this.editLeisureContainer.element(by.css('p>a'));

  // Other Expenses
  this.editOtherExpensesContainer = this.editContentContainer.element(by.id('expenses-other'));
  this.editOtherExpensesInput = this.editOtherExpensesContainer.element(by.id('ctlIDInput'));
  this.editOtherExpensesLabel = this.editOtherExpensesContainer.element(by.tagName('label'));
  this.editOtherExpensesRequiredError = this.editOtherExpensesContainer.element(by.id('ctlIDRequiredErrorText'));
  this.editOtherExpensesInfoLink = this.editOtherExpensesContainer.element(by.css('p>a'));

  // footer
  this.cancelButton = deviceType => element.all(by.id('cancelButton')).get(deviceType);
  this.saveButton = element(by.id('saveButton'));
};
module.exports = budgetPlannerEdit;
