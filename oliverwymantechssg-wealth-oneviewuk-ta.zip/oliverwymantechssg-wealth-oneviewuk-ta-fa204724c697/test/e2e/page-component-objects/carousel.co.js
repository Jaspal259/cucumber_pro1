// component object
const carousel = function carousel() {
  this.carouselContainer = element(by.tagName('ov-plan-summary-carousel'));

  // navigation
  this.carouselPreviousButton = this.carouselContainer.element(by.css('.mos-c-carousel__prev-container'));
  this.carouselNextButton = this.carouselContainer.element(by.css('.mos-c-carousel__next-container'));
};
module.exports = carousel;
