// component object

// load common
const CommonTests = require('../utilities/common-tests.js');

// create new objects
const commonTests = new CommonTests();


// note this uses a constructor format as we need to potentially load several instances to the parent object
const dashboardSummaryCard = function dashboardSummaryCard(planType, cardInstance) {
  // private

  // *** exposed properties ****

  // common

  /*
   planType should be 'DC', 'DC' or 'Pensioner'
   cardInstance is the instance of the card for that type
   e.g. if there is 1 DC card we could only have 0
   e.g. if 3 DB cards we could have 0, 1 or 2
   */
  this.planType = planType;
  this.cardInstance = cardInstance;

  // elements
  this.card = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator(
      `${planType}Card-${cardInstance}`,
      deviceType);
    return element(by.id(locator));
  };

  this.icon = deviceType => this.card(deviceType).element(by.id('Icon'));
  this.mobileExpandMore = deviceType => this.card(deviceType).element(by.css('button[icon="expand_more"]'));

  this.typeLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('TypeLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.longSchemeNameValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('LongSchemeNameValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.posStatusLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('statusLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.posStatusValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('statusValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.detailsButton = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('DetailsButton', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateJoinedSchemeLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateJoinedLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateJoinedSchemeValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateJoinedValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateOfExitLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateOfExitLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateOfExitValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateOfExitValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateOfRetirementLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateOfRetirementLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateOfRetirementInfoIcon = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateOfRetirementInfoIcon', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.dateOfRetirementValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateOfRetirementValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.clientDefinedIDLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('penNumberLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));   // e.g. "PENSION NUMBER"
  };

  this.clientDefinedIDValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('penNumberValue', deviceType);
    return this.card(deviceType).element(by.id(locator));   // e.g. pension number value
  };

  this.amountLabelDc = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.amountValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.amountDateLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountDateLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.amountDateInfoIcon = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountDateInfoIcon', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.memberReferenceValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('memberReferenceValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  // DC

  // DB

  // pensioner
  this.pensionStartDateLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateStartLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.pensionStartDateValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('dateStartValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.grossPensionLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.grossPensionValue = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountValue', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };

  this.grossPensionDateLabel = (deviceType) => {
    const locator = commonTests.getMobileOrDesktopLocator('AmountDateLabel', deviceType);
    return this.card(deviceType).element(by.id(locator));
  };
};
module.exports = dashboardSummaryCard;
