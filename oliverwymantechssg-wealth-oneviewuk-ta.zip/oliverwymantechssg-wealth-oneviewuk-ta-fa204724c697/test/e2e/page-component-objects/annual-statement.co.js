// component object
const annualStatement = function annualStatement() {
  // private


  // *** exposed properties ****

  // common

  // elements
  this.introTextPrecedingStatements = element(by.css('ov-content-card .mos-c-preloader__container > p'));

  // statement card header (inc. period selector)
  this.statementCardHeader = element(by.tagName('mercer-card-header'));
  this.statementCardHeaderTextWhenSinglePeriod = this.statementCardHeader.element(by.tagName('h3'));

  this.annualStatementTabs = element.all(by.css('.ov-content-card-tab-container [id^=tab]'));
  this.annualStatementTab = index => this.annualStatementTabs.get(index);
  this.getAnnualStatementTabsCount = async () => {
    const count = await this.annualStatementTabs.count();
    return count;
  };

  this.periodDropdownLabel = this.statementCardHeader.element(by.className('ov-content-card-tab-label'));
  this.periodDropdownSelection = this.statementCardHeader.element(by.className('ov-content-card-tab-selection'));
  this.periodDropdownSelectionValue = this.periodDropdownSelection.all(by.tagName('span')).get(1);
  this.periodDropdownOptions = this.statementCardHeader.all(by.css('mos-c-dropdown > a'));
  this.periodDropdownOption = index => this.periodDropdownOptions.get(index);
  this.getPeriodDropdownOptionsCount = async () => {
    const count = await this.periodDropdownOptions.count();
    return count;
  };

  // common statement elements
  this.statements = element.all(by.tagName('mercer-accordion'));
  this.statement = index => this.statements.get(index);
  this.getStatementsCount = async () => {
    const count = await this.statements.count();
    return count;
  };

  this.statementHeader
    = statement => statement.element(by.tagName('mercer-accordion-static'));
  this.statementHeaderIcon
    = statement => this.statementHeader(statement).element(by.tagName('mercer-vector-icon'));
  this.statementHeaderLabel
    = statement => this.statementHeader(statement).element(by.tagName('ov-label-with-tooltip'));
  this.statementHeaderInfoIcon
    = statement => this.statementHeaderLabel(statement).element(by.css('mercer-icon[icon="info"][mercer-tooltip=""]'));
  this.statementHeaderArrow
    = statement => this.statementHeader(statement).element(by.css('.ov-statements-accordion-arrow button'));

  this.statementDataRows = statement => statement.all(by.className('ov-statements-accordion-row'));

  // preamble statement
  this.preambleStatement = element(by.css('[id^=statement-preamble]'));
  this.preambleStatementText = this.preambleStatement.element(by.tagName('mercer-accordion-expanded'));

  // personalised statements
  this.personalisedStatements = element.all(by.css('[id^=statement-personalisedStatements]'));
  this.personalisedStatement = index => this.personalisedStatements.get(index);

  this.getPersonalisedStatementsCount = async () => {
    const count = await this.personalisedStatements.count();
    return count;
  };

  this.personalisedStatementIcon
    = index => this.personalisedStatement(index).element(by.tagName('mercer-vector-icon'));

  // data rows for personalised statements - column headers then data rows
  this.personalisedStatementTypeHeaderLabel = personalisedStatement => personalisedStatement
    .element(by.className('mos-c-table__header-label-0'));
  this.personalisedStatementNameHeaderLabel = personalisedStatement => personalisedStatement
    .element(by.className('mos-c-table__header-label-1'));
  this.personalisedStatementActionHeaderLabel = personalisedStatement => personalisedStatement
    .element(by.className('mos-c-table__header-label-2'));
  this.personalisedStatementRows = personalisedStatement => personalisedStatement
    .all(by.css('mercer-table tbody tr'));
  this.personalisedStatementRowTypeIcon = personalisedStatementRow => personalisedStatementRow
    .element(by.css('[id^=personalStatementType]'));
  this.personalisedStatementRowNameText = personalisedStatementRow => personalisedStatementRow
    .element(by.css('[id^=personalStatementName]'));
  this.personalisedStatementRowActionButton = personalisedStatementRow => personalisedStatementRow
    .element(by.css('span[id^=personalStatementAction]'));

  // notes statement
  this.notesStatement = element(by.css('[id^=statement-notes]'));
  this.notesStatementLabel = element(by.css('[id^=statement-notes] #yourAnnualStatementLabel'));
  this.notesStatementText = this.notesStatement.element(by.css('.mos-c-accordion__content'));

  // no data
  this.noDataContainer = element(by.tagName('ov-no-data'));
};
module.exports = annualStatement;
