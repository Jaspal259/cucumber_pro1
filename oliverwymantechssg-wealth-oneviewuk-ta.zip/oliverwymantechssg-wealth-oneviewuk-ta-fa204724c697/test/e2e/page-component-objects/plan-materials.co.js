/*
    NOTE:
    This component object contains selectedTopicEnum enumerator values specific to DC, DB and pensioner
    which have been gathered here for ease of maintenance
 */

// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const planMaterials = function planMaterials() {
  // private


  // *** exposed properties ****

  // common

  // elements
  // e.g. https://dal-uat-merceroneview.mercer.com/v1/oneview-be/resources/files/plans-materials
  this.unsecuredContentDownloadUrlPlanMaterialsRoot
    = `${commonConstants.unsecuredContentDownloadUrlRoot}/plans-materials`;

  this.cardContent = element(by.tagName('ov-content-card'));

  // tabs - note these are set in the header.co.js component

  // topics
  this.topicMenu = this.cardContent.element(by.tagName('ov-sub-categories'));
  this.planMaterialsMultipleTopics = this.topicMenu.all(by.css('[id^="planMaterialTopic_"]'));
  this.planMaterialsMultipleTopic = index => this.topicMenu.element(by.id(`planMaterialTopic_${index}`));
  this.planMaterialsLoneTopic = this.topicMenu.element(by.tagName('h3'));

  this.getPlanMaterialsTopicCount = async () => {
    // this more complex function is required because a lone page topic is rendered differently
    // from 1 of multiple topics
    let topicsCount;

    const topicMenuExists = await browser.isElementPresent(this.topicMenu);

    if (topicMenuExists) {
      const topics = await this.planMaterialsMultipleTopics;
      topicsCount = await topics.length;
      const singleTopicExists = await browser.isElementPresent(this.planMaterialsLoneTopic);

      if (topicsCount > 0 && !singleTopicExists) {
        // multiple topics exist
      } else if (topicsCount === 0 && singleTopicExists) {
        // single topic
        topicsCount = 1;
      } else {
        // topic not found
        fail('No plan materials topics found');
      }
    } else {
      fail('No plan materials topic menu found');
    }

    return topicsCount;
  };

  this.selectedTopicEnum = {
    dcPolicyDocuments: 0,
    dcPlanBooklets: 1,
    dcAddendums: 2,
    dcPlanInfo: 3,
    dcAnnouncements: 4,
    dcNewsletters: 5,
    dcForms: 6,
    dcInvestmentGuides: 7,
    dcFundFactsheets: 8,
    dcFundManagerInfo: 9,
    dbPolicyDocuments: 10,
    dbPlanBooklets: 11,
    dbAddendums: 12,
    dbPlanInfo: 13,
    dbAnnouncements: 14,
    dbNewsletters: 15,
    dbForms: 16,
    dbInvestmentGuides: 17,
    dbFundFactsheets: 18,
    dbFundManagerInfo: 19,
    pensionerPolicyDocuments: 20,
    pensionerPayslips: 21,
    pensionerP60s: 22,
    pensionerPensionIncreaseLetters: 23,
    pensionerConfirmationOfPayment: 24,
    pensionerPlanBooklets: 25,
    pensionerAddendums: 26,
    pensionerPlanInfo: 27,
    pensionerAnnouncements: 28,
    pensionerNewsletters: 29,
    pensionerForms: 30,
    pensionerInvestmentGuides: 31,
    pensionerFundFactsheets: 32,
    pensionerFundManagerInfo: 33,
  };

  // data table for topics
  this.planMaterialsTable = element(by.tagName('ov-plan-materials-list')).element(by.tagName('mercer-table'));
  this.planMaterialsTableHeader = this.planMaterialsTable.element(by.css('table > thead'));
  this.planMaterialsTableBody = this.planMaterialsTable.element(by.css('table > tbody'));
  this.planMaterialsDataRows = this.planMaterialsTableBody.all(by.tagName('tr'));

  // this count does not includes the header row
  this.getPlanMaterialsRecordCount = async () => {
    const count = await this.planMaterialsDataRows.count();
    return count;
  };

  // this does not include the header row
  this.planMaterialsDataRow = index => this.planMaterialsDataRows.get(index);

  /*
    This plan material table elements have been updated to cater for newer story OUK-8502
    Note OUK-8502 will only be covered in TE code by these updates to existing TE code for stories OUK-949, 1065, 1075
   */

  // plan material table headers
  this.columnHeaderName = this.planMaterialsTableHeader.all(
    by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(0);
  this.columnHeaderType = this.planMaterialsTableHeader.all(
    by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(1);
  this.columnHeaderSize = this.planMaterialsTableHeader.all(
    by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.columnHeaderNetPension = this.planMaterialsTableHeader.all(
    by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(2);
  this.columnHeaderAction = (showSizeOrNetPensionColumn) => {
    let index = 2;

    if (showSizeOrNetPensionColumn) {
      index = 3;
    }

    return this.planMaterialsTableHeader.all(
      by.className(commonConstants.mosCssTableHeaderLabelRoot)).get(index);
  };

  this.getPlanMaterialsSortIcons = this.planMaterialsTableHeader.all(by.tagName('mercer-icon'));

  this.getPlanMaterialsSortIconCount = async () => {
    const count = await this.getPlanMaterialsSortIcons.count();
    return count;
  };

  this.planMaterialsSortIcon = index => this.getPlanMaterialsSortIcons.get(index);

  // plan material table data rows
  this.planMaterialsName = index => this.planMaterialsTable.element(by.id(`planMaterialName-${index}`));
  this.planMaterialsType = index => this.planMaterialsTable.element(by.id(`planMaterialType-${index}`));
  this.planMaterialsSize = index => this.planMaterialsTable.element(by.id(`planMaterialSize-${index}`));
  this.planMaterialsNetPension = index => this.planMaterialsTable.element(by.id(`planMaterialNettPension-${index}`));
  this.planMaterialsAction
    = (index, deviceType) => this.planMaterialsTable.all(by.id(`planMaterialAction-${index}`)).get(deviceType);
};
module.exports = planMaterials;
