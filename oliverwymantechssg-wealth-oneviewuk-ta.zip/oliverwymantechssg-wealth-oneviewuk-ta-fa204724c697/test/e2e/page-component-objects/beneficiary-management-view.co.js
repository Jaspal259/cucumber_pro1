// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const beneficiaryManagementView = function beneficiaryManagementView() {
  // this component is only used when EDITING on on the beneficiaries page but, as it is fairly complex, it makes
  // sense to separate it out to a component object
  this.beneficiaryManagementView = element(by.css(commonConstants.mosCssModalContentWrapper));

  // top of form
  this.viewHeading = this.beneficiaryManagementView.element(by.id('viewHeading'));
  this.closeIcon = this.beneficiaryManagementView.element(by.css('ng-tns-c20-11'));

  // data controls
  this.fullNameLabel = this.beneficiaryManagementView.element(by.id('fullNameLabel'));
  this.fullNameValue = this.beneficiaryManagementView.element(by.id('fullNameValue'));
  this.addressLabel = this.beneficiaryManagementView.element(by.id('addressLabel'));
  this.addressValue = this.beneficiaryManagementView.element(by.id('addressValue'));
  this.dateOfBirthLabel = this.beneficiaryManagementView.element(by.id('dateOfBirthLabel'));
  this.dateOfBirthValue = this.beneficiaryManagementView.element(by.id('dateOfBirthValue'));
  this.beneficiaryTypeLabel = this.beneficiaryManagementView.element(by.id('beneficiaryTypeLabel'));
  this.beneficiaryTypeValue = this.beneficiaryManagementView.element(by.id('beneficiaryTypeValue'));
  this.shareOfBenefitLabel = this.beneficiaryManagementView.element(by.id('shareOfBenefitLabel'));
  this.shareOfBenefitValue = this.beneficiaryManagementView.element(by.id('shareOfBenefitValue'));
  this.guardianFullNameLabel = this.beneficiaryManagementView.element(by.id('guardianFullNameLabel'));
  this.guardianFullNameValue = this.beneficiaryManagementView.element(by.id('guardianFullNameValue'));
  this.guardianAddressLabel = this.beneficiaryManagementView.element(by.id('guardianAddressLabel'));
  this.guardianAddressValue = this.beneficiaryManagementView.element(by.id('guardianAddressValue'));

  // view controls within form
  this.revealButton
    = this.beneficiaryManagementView.element(by.id('revealButton'));

  // bottom of form
  this.requiredFieldLabel = this.beneficiaryManagementView.element(by.id('requiredFieldLabel'));
  this.warningIcon = this.beneficiaryManagementView.element(by.id('warningIcon'));
  this.warningLabel = this.beneficiaryManagementView.element(by.id('warningLabel'));
  this.errorMessageLabel = this.beneficiaryManagementView.element(by.id('errorMessageLabel'));
  this.cancelButton = this.beneficiaryManagementView.element(by.id('cancelButton'));
  this.confirmButton = this.beneficiaryManagementView.element(by.id('confirmButton'));
};
module.exports = beneficiaryManagementView;
