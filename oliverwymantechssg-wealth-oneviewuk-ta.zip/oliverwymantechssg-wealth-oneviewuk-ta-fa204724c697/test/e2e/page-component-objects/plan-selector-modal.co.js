// load common
const CommonConstants = require('../utilities/common-constants.js');

// create new objects
const commonConstants = new CommonConstants();

// component object
const planSelectorModal = function planSelectorModal() {
  this.container = element(by.className(commonConstants.mosCssModalContentWrapper));

  // header
  this.header = this.container.element(by.css('mercer-modal-header h3'));

  // contents
  this.content = this.container.element(by.tagName('mercer-modal-content'));
  this.description = this.container.all(by.tagName('p')).first();
  this.dropdownDescription = this.container.all(by.tagName('p')).last();
  this.dropdownRevealer = this.content.element(by.className('ov-plan-select-value'));
  this.dropdownList = element(by.className('mos-c-dropdown__list'));
  this.dropdownListOptions = this.dropdownList.all(by.className('ov-plan-select-dropdown-item'));

  this.getDropdownListOptionsCount = async () => {
    const count = await this.dropdownListOptions.count();
    return count;
  };

  this.dropdownListOption = index => this.dropdownListOptions.get(index);

  // footer
  this.footer = deviceType => this.container.all(by.tagName('mercer-modal-footer')).get(deviceType);
  this.continueButton = deviceType => this.footer(deviceType).element(by.id('continueButton'));
  this.cancelButton = deviceType => this.footer(deviceType).element(by.id('cancelButton'));
};
module.exports = planSelectorModal;
