/*
  This file is used to define common constants such as root URLs for different test environments e.g. QA, PROD
 */
const commonConfigConstants = function commonConfigConstants() {
  // constants for test config
  // ---------------------------------------------------------------------------------------------------------

  this.appName = 'OneView 3';
  this.testAutomation = 'TA';

  // local
  // ---------------------------------------------------------------------------------------------------------

  // Selenium server
  this.localSeleniumAddress = 'http://localhost:4444/wd/hub';


  // Jenkins
  // ---------------------------------------------------------------------------------------------------------
  this.jenkinsChromeDriverLocation = '/usr/bin/chromedriver';


  // full Chrome
  // ---------------------------------------------------------------------------------------------------------

  // used where Chrome options need to be re-stated
  this.fullChromeChromeOptionsArgs = [
    // note this does not remove "Chrome is being controlled by automated test software" notification
    '--disable-infobars=true',
    '--incognito',
    // used to bypass loading of extensions which will be blocked by MMC security policy anyway
    '-disable-extensions',
  ];


  // headless Chrome (as used in Jenkins)
  // ---------------------------------------------------------------------------------------------------------

  this.headlessChromeScreenResolutionX = '1280';
  this.headlessChromeScreenResolutionY = '1024';
  this.headlessChromeScreenResolution = `${this.headlessChromeScreenResolutionX}`
    + `x${this.headlessChromeScreenResolutionY}`;

  /*
    The following Chrome options run Chrome headless - i.e. no browser UI is launched (as on Jenkins)

    *** IMPORTANT ***
    There are known problems / limitations with headless Chrome compared to the full version - for OV3
    this affects testing links to external URLs and downloads (please see notes in commonTests.getUrlOfMediaLink())
    - so the global.isHeadlessChrome variable is set in the default.conf.js so you can adjust TE code for
    headless Chrome using an if() block where necessary

    Also please note:
    - Screenshots will still be taken on error (screeshot size set by '--window-size=x,y'
    - Headless requires '--headless' AND '--disable-gpu'
    - Each spec run will result in a console line like:
      "INFO:CONSOLE(1)] "Environment: ", source: http://*.bundle.js (1)"
    - The following errors are reported in the console ...
        "ERROR:gpu_process_transport_factory.cc(1009)] Lost UI shared context."
        "ERROR:instance.cc(49)] Unable to locate service manifest for metrics"
        "ERROR:service_manager.cc(890)] Failed to resolve service name: metrics"
      ... but these are really warnings which can be ignored according to:
      - https://github.com/GoogleChrome/puppeteer/issues/1547
      - https://github.com/GoogleChrome/puppeteer/issues/1543
   */
  this.headlessChromeChromeOptionsArgs = [
    '--headless',
    '--disable-gpu',
    `--window-size=${this.headlessChromeScreenResolutionX},${this.headlessChromeScreenResolutionY}`,
    // please see 23rd July 2018 comment in https://github.com/elgalu/docker-selenium/issues/20
    '--disable-dev-shm-usage',
    // should remove "Chrome is being controlled by automated test software" notification
    '--disable-infobars',
    '--incognito',
    // used to bypass loading of extensions which will be blocked by MMC security policy anyway
    '-disable-extensions',
  ];

  /*
    NOTE
    Please note directConnect can only be used for Chrome and Firefox,
    otherwise please use Sauce Labs or Selenium WebDriver

    Note that access to the Selenium server is effectively switched off by omitting

      seleniumAddress: 'http://localhost:4444/wd/hub',

    from the config

    note directConnect is reliable only when running Chrome headless (see ouk-2111)
   */
  this.headlessChromeAloneUsesDirectConnect = true;


  // Chrome mobile emulation (- )running emulator within desktop Chrome)
  // ---------------------------------------------------------------------------------------------------------
  this.chromeMobileEmulationIos = 'iPhone 6/7/8';
  this.chromeMobileEmulationAndroid = 'Galaxy S5';
};
module.exports = commonConfigConstants;
