/*
  This file is used to state the default browser [capabilities] and [multiCapabilities] parameters which will apply
  to all tests run, whichever environment and run method is used
 */
const capabilitiesDefaults = {
  // note browserName is set in individual environment config files e.g. qa-local.conf.js

  // Sauce Labs general settings
  // ------------------------------------------------------------------------------
  // these are common to all Sauce Labs test runs but some config is in the individual TE config files for SL

  /*
    for more info on SauceLabs config:
    https://github.com/saucelabs-sample-test-frameworks/JS-Protractor-Selenium/blob/master/conf.js
    https://wiki.saucelabs.com/display/DOCS/Best+Practice%3A+Use+Environment+Variables+for+Authentication+Credentials
    https://wiki.saucelabs.com/display/DOCS/Environment+Variables+Used+by+Sauce+Connect
    https://wiki.saucelabs.com/display/DOCS/Test+Configuration+Options

    Sauce Connect - required for running against non-PRD environments:
    https://saucelabs.com/
      blog/repost-angular-protractor-sauce-connect-launched-from-gulp-all-behind-a-corporate-firewall

    Sauce config:
    https://wiki.saucelabs.com/
      display/DOCS/Test+Configuration+Options#TestConfigurationOptions-Selenium-SpecificOptions
    https://github.com/angular/protractor/blob/master/lib/config.ts

    Sauce Labs Support:
    SL Support were very good in solving the initial problems with SL connection, SL reporting and SL
    speed (albeit it did take them about 3 weeks to resolve these issues) - particular thanks to Wim Selles,
    Josh Grant and Wendy Zingher
   */

  /*
    please note the following Sauce Labs settings must NOT be set or defined:

    - sauceSeleniumAddress:   not required as Protractor knows URL when SL username and SL key defined
    - sauceSeleniumUseHttp:   see above
    - webDriverProxy:         sauceProxy is used instead
   */

  timeZone: 'London',
  public: 'team',
  maxDuration: 10800,   // 3 hour safety limit to prevent tests from running indefinitely
  commandTimeout: 90,   // limits how long Selenium can take to run a command in our browsers
  idleTimeout: 90,      // limits how long a browser can wait for a test to send a new command
  maxInstances: 5,      // maximum number of instances to use when shardTestFiles = true (i.e. when Sauce Labs used)

  // these option are set to false in order to speed up the SL tests
  recordVideo: false,
  videoUploadOnPass: false,
  recordScreenshots: false,
  recordLogs: false,
  captureHtml: false,
  webdriverRemoteQuietExceptions: false,
  extendedDebugging: false,

  /*
    The 'tunnel-identifier' relates to the tunnel which is started on Mercer server USDFW11AS12V
    to connect OneView 3 environments behind the Mercer firewall to the Sauce Labs infrastructure
    outside the Mercer firewall.

    This are the 3 commands which must be used to launch the tunnel - note the parameters in [] must be
    replaced with actual values. Daniel Freeman and James Keene have access to run this command in the UK,
    Erik Horrell has overall responsibility and access to the Mercer / Sauce Lab tunnel servers.

    d:
    cd D:\Sauce connect setup files\sc-[latest SC version]-win32\sc-[latest SC version]-win32\bin
    sc.exe
       --user [same as process.env.SAUCE_USERNAME]
       --api-key [same as process.env.SAUCE_ACCESS_KEY]
       --proxy 10.23.33.39:8080
       --proxy-tunnel --tunnel-identifier OV3TestAutomationTunnel1 --no-remove-colliding-tunnels
       --pidfile /SauceConnectOtherLogsEtc/OV3TestAutomationTunnel1.pid
       --logfile /SauceConnectOtherLogsEtc/OV3TestAutomationTunnel1.log --scproxy-port 29999 --se-port 4446

    it is apparantly possible to start an SC tunnel programmatically for each test run (including closing
    the tunnel at the end) - this is not necessary at the moment but if it is needed in the future note that
    SL Support currently recommend the NPM sauce-connect-launcher package
   */
  'tunnel-identifier': 'OV3TestAutomationTunnel1',    // note this is the tunnel used by sauceProxy above

  // ------------------------------------------------------------------------------
  // end of Sauce Labs general settings


  // see https://github.com/SeleniumHQ/selenium/wiki/DesiredCapabilities#loggingpreferences-json-object
  // used in checkJavaScriptBrowserLogs() functions
  loggingPrefs: {
    driver: 'WARNING',
    server: 'WARNING',
    browser: 'SEVERE'     // 'SEVERE' for actual testing - only use 'INFO' or 'OFF' only when debugging
  },
  chromeOptions: {
    /*
      these are only needed for local or Jenkins runs against desktop Chrome or Firefox where the browser
      is not in mobile emulation mode because when in mobile emulation mode a more detailed chromeOptions
      is needed in the emulation config which replaces the chromeOptions stated here
     */
    args: [
      // note this does not remove "Chrome is being controlled by automated test software" notification
      '--disable-infobars=true',
      '--incognito',
      // used to bypass loading of extensions which will be blocked by MMC security policy anyway
      '-disable-extensions',
    ],
    prefs: {
      credentials_enable_service: false,
      profile: {
        password_manager_enabled: false
      },
      download: {
        /*
          Note this will only work if MGTI unlock the 'Ask where to save each file before downloading' option
          in Chrome settings under 'advanced > downloads'

          With this option set to true an OS dialogue box opens up when downloading any download file which
          will not open in the browser itself (such as a .docx file)

          Protractor cannot interact with anything outside of the browser reliably so - in practice - this means
          that any download links cannot be clicked by these tests when using Chrome
         */
        prompt_for_download: false,
      }
    }
  },
  'moz:firefoxOptions': {
    args: ['-new-window', 'google.co.uk']
  },
  acceptSslCerts: true,
};

module.exports = {
  capabilitiesDefaults
};
