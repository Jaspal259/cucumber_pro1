/* eslint prefer-destructuring: 'off' */

// thanks to Vipul Sharma, GTI for the suggestion of using protractor-jasmine2-screenshot-reporter
const HtmlScreenshotReporter = require('protractor-jasmine2-screenshot-reporter');
const Fecha = require('fecha');

const StringHelperUtil = require('../../utilities/string.helper.js');

const reporter = new HtmlScreenshotReporter({
  cleanDestination: true,
  showSummary: true,
  showConfiguration: true,
  reportTitle: 'Test Automation Report',
  dest: 'reports/',
  filename: 'TestAutomationReport.html',
  ignoreSkippedSpecs: true,
  reportOnlyFailedSpecs: false,
  captureOnlyFailedSpecs: true,
  reportFailedUrl: true,
});

exports.config = {
  specs: ['features/*/*spec.js'],
  /*
     to run a suite use --suite [suite name]
     e.g. protractor conf.js --suite=smoke
     note without suite all specs except those in the [exclude] section will be run

     debug* suites have been added for each automator to assist in running a select
     number of script(s) while developing new scripts
     e.g. protractor conf.js --suite=build
     e.g. protractor conf.js --suite=debugDaniel
   */
  suites: {
    // only list reviewed and working scripts in the regression suite
    regression: [
      'features/annual-statement/ouk-1569-spec.js',
      'features/annual-statement/ouk-1649-spec.js',
      'features/annual-statement/ouk-2427-spec.js',
      'features/annual-statement/ouk-6167-spec.js',
      'features/annual-statement/ouk-6169-spec.js',
      'features/annual-statement/ouk-6171-spec.js',
      'features/articles/ouk-2199-spec.js',
      'features/authentication/ouk-198-spec.js',
      'features/authentication/ouk-1578-spec.js',
      'features/authentication/ouk-1579-spec.js',
      'features/authentication/ouk-1638-spec.js',
      'features/authentication/ouk-2759-spec.js',
      'features/authentication/ouk-3078-spec.js',
      'features/authentication/ouk-4063-spec.js',
      'features/authentication/ouk-4064-spec.js',
      'features/authentication/ouk-5048-spec.js',
      'features/bank-account-details/ouk-4259-spec.js',
      'features/bank-account-details/ouk-4548-spec.js',
      'features/bank-account-details/ouk-4549-spec.js',
      'features/beneficiaries/ouk-1038-spec.js',
      'features/beneficiaries/ouk-1074-spec.js',
      'features/beneficiaries/ouk-4543-spec.js',
      'features/branding/ouk-121-spec.js',
      'features/branding/ouk-1192-spec.js',
      'features/budget-planner/ouk-1629-spec.js',
      'features/cms/ouk-1029-spec.js',
      'features/cookie-consent/ouk-1028-spec.js',
      'features/current-investment-mix/ouk-456-spec.js',
      'features/current-pension/ouk-579-spec.js',
      'features/current-pension/ouk-1663-spec.js',
      'features/dashboard/ouk-100-spec.js',
      'features/dashboard/ouk-102-spec.js',
      'features/dashboard/ouk-103-spec.js',
      'features/dashboard/ouk-107-spec.js',
      'features/dashboard/ouk-108-spec.js',
      'features/dashboard/ouk-109-spec.js',
      'features/dashboard/ouk-122-spec.js',
      'features/dashboard/ouk-124-spec.js',
      'features/dashboard/ouk-214-spec.js',
      'features/dashboard/ouk-216-spec.js',
      'features/dashboard/ouk-217-spec.js',
      'features/dashboard/ouk-222-spec.js',
      'features/dashboard/ouk-234-spec.js',
      'features/dashboard/ouk-235-spec.js',
      'features/dashboard/ouk-236-spec.js',
      'features/wealth-snapshot/ouk-233-spec.js',
      'features/wealth-snapshot/ouk-254-spec.js',
      'features/earning-history/ouk-1632-spec.js',
      'features/financial-and-retirement-planning/ouk-5110-spec.js',
      'features/financial-and-retirement-planning/ouk-5117-spec.js',
      'features/help-and-contacts/ouk-1620-spec.js',
      'features/help-and-contacts/ouk-2704-spec.js',
      'features/help-and-contacts/ouk-4271-spec.js',
      'features/help-and-contacts/ouk-4477-spec.js',
      'features/historical-pension/ouk-594-spec.js',
      'features/log-out/ouk-220-spec.js',
      'features/login/ouk-209-spec.js',
      'features/navigation/ouk-1913-spec.js',
      'features/outage/ouk-1420-spec.js',
      'features/page-footer/ouk-1025-spec.js',
      'features/page-header/ouk-205-spec.js',
      'features/page-header/ouk-1704-spec.js',
      'features/plan-header/ouk-210-spec.js',
      'features/plan-header/ouk-211-spec.js',
      'features/plan-header/ouk-212-spec.js',
      'features/plan-header/ouk-4201-spec.js',
      'features/plan-materials/ouk-949-spec.js',
      'features/plan-materials/ouk-1065-spec.js',
      'features/plan-materials/ouk-1075-spec.js',
      'features/profile/ouk-130-spec.js',
      'features/profile/ouk-207-spec.js',
      'features/profile/ouk-1581-spec.js',
      'features/profile/ouk-4624-spec.js',
      'features/profile/ouk-5252-spec.js',
      'features/summary-pages/ouk-591-spec.js',
      'features/summary-pages/ouk-3803-spec.js',
      'features/transfers/ouk-1979-spec.js',
      'features/transfers/ouk-2420-spec.js',
    ],
    // a copy of the regression suite edited down to just the tests which work for mobile
    mobileRegression: [
      'features/articles/ouk-2199-spec.js',
      'features/authentication/ouk-198-spec.js',
      'features/authentication/ouk-1578-spec.js',
      'features/authentication/ouk-1579-spec.js',
      'features/authentication/ouk-1638-spec.js',
      'features/authentication/ouk-2759-spec.js',
      'features/authentication/ouk-3078-spec.js',
      'features/authentication/ouk-4063-spec.js',
      'features/authentication/ouk-4064-spec.js',
      'features/authentication/ouk-5048-spec.js',
      'features/branding/ouk-121-spec.js',
      'features/branding/ouk-1192-spec.js',
      'features/cms/ouk-1029-spec.js',
      'features/cookie-consent/ouk-1028-spec.js',
      'features/current-investment-mix/ouk-456-spec.js',
      'features/current-pension/ouk-579-spec.js',
      'features/current-pension/ouk-1663-spec.js',
      'features/dashboard/ouk-100-spec.js',
      'features/dashboard/ouk-102-spec.js',
      'features/dashboard/ouk-103-spec.js',
      'features/dashboard/ouk-107-spec.js',
      'features/dashboard/ouk-108-spec.js',
      'features/dashboard/ouk-109-spec.js',
      'features/dashboard/ouk-122-spec.js',
      'features/dashboard/ouk-124-spec.js',
      'features/dashboard/ouk-214-spec.js',
      'features/dashboard/ouk-216-spec.js',
      'features/dashboard/ouk-217-spec.js',
      'features/dashboard/ouk-222-spec.js',
      'features/dashboard/ouk-234-spec.js',
      'features/dashboard/ouk-235-spec.js',
      'features/dashboard/ouk-236-spec.js',
      'features/wealth-snapshot/ouk-233-spec.js',
      'features/wealth-snapshot/ouk-254-spec.js',
      'features/help-and-contacts/ouk-1620-spec.js',
      'features/help-and-contacts/ouk-2704-spec.js',
      'features/help-and-contacts/ouk-4271-spec.js',
      'features/help-and-contacts/ouk-4477-spec.js',
      'features/log-out/ouk-220-spec.js',
      'features/login/ouk-209-spec.js',
      'features/navigation/ouk-1913-spec.js',
      'features/outage/ouk-1420-spec.js',
      'features/page-footer/ouk-1025-spec.js',
      'features/page-header/ouk-205-spec.js',
      'features/page-header/ouk-1704-spec.js',
      'features/plan-header/ouk-210-spec.js',
      'features/plan-header/ouk-211-spec.js',
      'features/plan-header/ouk-212-spec.js',
      'features/plan-header/ouk-4201-spec.js',
      'features/profile/ouk-207-spec.js',
      'features/profile/ouk-1581-spec.js',
      'features/summary-pages/ouk-3803-spec.js',
      'features/summary-pages/ouk-591-spec.js',
    ],
    smoke: [
      'features/login/ouk-209-spec.js',       // very simple test - great for demo + Sauce Labs config set-up testing
      'features/branding/ouk-121-spec.js',    // simple test - great for checking login / logout works
    ],
    /*
      these tests have some TA-code but need revision for reasons which can include:
      - UI design changes broke TA code
      - 1 or more scenarios in story now covered by another story TA-coded and in regression suite
      - TA coding was poor quality
      - TA coding was never completed
     */
    needsRevision: [
      // 'features/allowances/ouk-1613-spec.js',
      // 'features/allowances/ouk-1616-spec.js',
      // 'features/allowances/ouk-2762-spec.js',
      // 'features/allowances/ouk-4541-spec.js',
      // 'features/beneficiaries/ouk-1670-spec.js',
      // 'features/beneficiaries/ouk-1690-spec.js',
      // 'features/beneficiaries/ouk-3069-spec.js',
      // 'features/contact-details/ouk-87-spec.js',
      // 'features/contact-details/ouk-2152-spec.js',
      // 'features/contact-details/ouk-5609-spec.js',
      // 'features/deferred-statement/ouk-1567-spec.js',
      // 'features/deferred-statement/ouk-2376-spec.js',
      // 'features/earning-history/ouk-2218-spec.js',
      // 'features/financial-and-retirement-planning/ouk-1570-spec.js',
      // 'features/financial-and-retirement-planning/ouk-2217-spec.js',
      // 'features/financial-and-retirement-planning/ouk-2615-spec.js',
      // 'features/profile/ouk-4384-spec.js',
      // 'features/summary-pages/ouk-3804-spec.js',
      // 'features/transactions/ouk-249-spec.js',
      // 'features/transfers/ouk-1282-spec.js',
    ],
    /*
      these tests have fully working TA-code for desktop but need revision to work with mobile
     */
    needsRevisionMobileOnly: [
      // 'features/annual-statement/ouk-1569-spec.js',
      // 'features/annual-statement/ouk-1649-spec.js',
      // 'features/annual-statement/ouk-2427-spec.js',
      // 'features/annual-statement/ouk-6167-spec.js',
      // 'features/annual-statement/ouk-6169-spec.js',
      // 'features/annual-statement/ouk-6171-spec.js',
      // 'features/bank-account-details/ouk-4259-spec.js',
      // 'features/bank-account-details/ouk-4548-spec.js',
      // 'features/bank-account-details/ouk-4549-spec.js',
      // 'features/beneficiaries/ouk-1038-spec.js',
      // 'features/beneficiaries/ouk-1074-spec.js',
      // 'features/beneficiaries/ouk-4543-spec.js',
      // 'features/budget-planner/ouk-1629-spec.js',
      // 'features/earning-history/ouk-1632-spec.js',
      // 'features/financial-and-retirement-planning/ouk-5110-spec.js',
      // 'features/financial-and-retirement-planning/ouk-5117-spec.js',
      // 'features/historical-pension/ouk-594-spec.js',
      // 'features/plan-materials/ouk-949-spec.js',
      // 'features/plan-materials/ouk-1065-spec.js',
      // 'features/plan-materials/ouk-1075-spec.js',
      // 'features/profile/ouk-130-spec.js',
      // 'features/profile/ouk-4624-spec.js',
      // 'features/profile/ouk-5252-spec.js',
      // 'features/transfers/ouk-1979-spec.js',
      // 'features/transfers/ouk-2420-spec.js',
    ],
  },
  /*
     you can exclude specs from running permanently by including them here
     note you can also use wildcards to specify patterns of files
     for OV3 these are now-redundant stories
   */
  exclude: [
    'features/_redundant/ouk-2-spec.js',
    'features/_redundant/ouk-101-spec.js',
    'features/_redundant/ouk-120-spec.js',
    'features/_redundant/ouk-128-spec.js',
    'features/_redundant/ouk-199-spec.js',
    'features/_redundant/ouk-200-spec.js',
    'features/_redundant/ouk-213-spec.js',
    'features/_redundant/ouk-237-spec.js',
    'features/_redundant/ouk-261-spec.js',
    'features/_redundant/ouk-310-spec.js',
    'features/_redundant/ouk-418-spec.js',
    'features/_redundant/ouk-988-spec.js',
    'features/_redundant/ouk-1077-spec.js',
    'features/_redundant/ouk-1078-spec.js',
    'features/_redundant/ouk-1079-spec.js',
    'features/_redundant/ouk-1080-spec.js',
    'features/_redundant/ouk-1307-spec.js',
    'features/_redundant/ouk-1162-spec.js',
    'features/_redundant/ouk-1212-spec.js',
    'features/_redundant/ouk-1213-spec.js',
    'features/_redundant/ouk-1694-spec.js',
    'features/_redundant/ouk-2188-spec.js',
    'features/_redundant/ouk-2200-spec.js',
    'features/_redundant/ouk-2786-spec.js',
    'features/_redundant/ouk-3807-spec.js',
    'features/_redundant/ouk-3865-spec.js',
    'features/_redundant/ouk-4273-spec.js',
    'features/_redundant/ouk-4666-spec.js',
    'features/_redundant/ouk-5228-spec.js',
  ],

  /*
    SELENIUM_PROMISE_MANAGER must be false when using async / await as a mix of old control flow and async / await
    "causes the control flow to become unreliable"

    ref:
    https://www.protractortest.org/#/async-await
    https://github.com/angular/protractor/blob/master/docs/async-await.md
    https://chariotsolutions.com/blog/post/simplify-protractor-web-tests-with-async-and-await/
   */
  SELENIUM_PROMISE_MANAGER: false,

  /*
    if restartBrowserBetweenTests is true Protractor will restart the browser between each test
    SETTING TO TRUE FAILS CURRENTLY - KNOWN PROTRACTOR BUG (AND FAILED WHEN USED FOR HEADLESS 04/02/2019)
    CAUTION WHEN WORKING THIS WILL DRAMATICALLY SLOW DOWN THE TEST SUITE
    ALWAYS SET THIS TO FALSE
   */
  restartBrowserBetweenTests: false,

  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    isVerbose: true,
    includeStackTrace: true,

    /*
      defaultTimeoutInterval is the same as jasmine.DEFAULT_TIMEOUT_INTERVAL
      this is the timeout applied to each Jasmine it() block
      note that an it() block will time out even if it has not failed if it
      takes longer to run than this timeout
      ouk-949 takes a long time to run hence the increase from the original
      90 seconds to 180 seconds
     */
    defaultTimeoutInterval: 180000,
    print() {
    }
  },
  allScriptsTimeout: 60000, // increased from 20000 as DC TV takes a long time to load

  /*
    this was increased from 30 seconds as some logins failing but now
    note a longer timeout of 60 seconds has been set whenever the login page is
    requested (please see checkLoginPageLoads() in authentication-login.spec.js)
    this timeout should apply to all other instances of using browser.get(url)
   */
  getPageTimeout: 40000,

  // Sauce Labs - Mercer proxy used to connect to Sauce Labs tunnel - note http:// prefix
  sauceProxy: 'http://10.23.33.39:8080',

  // NOTE capabilities sand multiCapabilities are set purely in individual environment config files
  // e.g. qa-local.conf.js

  params: {
    env: null,
    ov3RootUrl: null,
    stringHelper: StringHelperUtil
  },

  // event handling

  beforeLaunch() {
    return new Promise((resolve) => {
      Fecha.masks.ukDate = 'DD/MM/YYYY';
      Fecha.masks.ukDateTime = 'DD/MM/YYYY HH:mm:ss.SSS';
      reporter.beforeLaunch(resolve);
    });
  },

  async onPrepare() {
    try {
      await browser.waitForAngularEnabled(true);
    } catch (e) {
      // eslint-disable-next-line no-console
      console.log(`Calling browser.waitForAngularEnabled failed:  ${e}`);
    }

    jasmine.getEnv().addReporter(reporter);
    jasmine.getEnv().beforeAll(() => {
      // this is where the custom matchers used to be hooked in - no longer required but beforeAll() left
      // in in case useful
    });

    // gets first passed argument to Protractor in command line - should be test environment
    const testEnvironmentParameter = process.argv[3].match(/^--params\.([^=]+)=(.*)$/);

    // gets second Protractor argument - should be test tun type (e.g. local full Chrome, Jenkins iOS mobile emulation)
    const testRunTypeParameter = process.argv[4].match(/^--params\.([^=]+)=(.*)$/);

    // extract test environment (if not found defaults to Dev)
    if (testEnvironmentParameter && testRunTypeParameter) {
      global.ov3TestEnvironment = testEnvironmentParameter[2];
      global.ov3TestRunType = testRunTypeParameter[2];

      /*
        is Sauce Labs going to be used?
        we need to know as tests will need to be thinned out considerably compared to running locally or on
        Jenkins because the speed of executing the number of WebDriver calls for the latter is not able to be
        supported over the cloud (e.g. SL) due to network speeds

        as a broad example, a WebDriver call that might take 10ms locally / on Jenkins could take 100ms on SL
        meaning running even the very simple OUK-209 test locally took 35 seconds whereas SL took 4 minutes
        when measured in November 2018

        therefore the global.ov3TestIsRunOnSauceLabs variable will be used to determine how much testing should
        be done for each run
       */
      if (global.ov3TestRunType.indexOf('sauce-labs') !== -1) {
        global.ov3TestIsRunOnSauceLabs = true;

        // eslint-disable-next-line no-console
        console.log('The test is being run on Sauce Labs so the number of tests will be thinned out');
      } else {
        global.ov3TestIsRunOnSauceLabs = false;

        // eslint-disable-next-line no-console
        console.log('The test is NOT being run on Sauce Labs so the full number of tests will be run');

        // use all the screen
        await browser.driver.manage().window().maximize();
      }

      /*
        is headless Chrome going to be used?

        we're not using this global variable any more but have kept for possible future use

        note looking for "jenkins" in global.ov3TestEnvironment works for both Jenkins and
        local machine usage of headless Chrome as local versions are defined as Jenkins simulations
       */
      global.ov3TestIsRunOnHeadlessChrome = false;

      if (global.ov3TestRunType.indexOf('jenkins') !== -1) {
        global.ov3TestIsRunOnHeadlessChrome = true;
      }
    } else {
      global.ov3TestEnvironment = 'local';
      global.ov3TestRunType = 'local';
      global.ov3TestIsRunOnSauceLabs = false;

      // eslint-disable-next-line no-console
      console.log('The test is NOT being run on Sauce Labs so the full number of tests will be run');

      global.ov3TestIsRunOnHeadlessChrome = false;
    }

    // if true then the browser cache and cookies will be cleared by commonTests.clearBrowserCacheAndCookies()
    // note setting to true will slow the test suite down, not so much from the clearing itself but from the
    // fact that the slow cookiePolicy.agreeCookiePolicy will be executed for each describe() block
    global.ov3ClearCacheAndCookiesAfterEachDescribeBlock = true;

    // assume cookie policy has not been agreed
    global.ov3CookiePolicyAgreed = false;

    // get device type
    // please see appDeviceTypeEnum in utilities/common-constants.js
    const config = await browser.getProcessedConfig();
    global.browserName = config.capabilities.browserName.toLowerCase();
    const browserTestedPhrase = `, browser: ${global.browserName}`;

    if (config.capabilities.deviceName === undefined) {
      // PC or Mac
      global.deviceType = 0;

      // eslint-disable-next-line no-console
      console.log(`Test on PC or Mac, global.deviceType: ${global.deviceType}${browserTestedPhrase}`);
    } else {
      // mobile (via Sauce Labs or run locally using mobile emulation in Chrome)
      global.deviceType = 1;

      if (global.ov3TestRunType.indexOf('emulation') !== -1) {
        global.ov3TestIsRunUsingChromeMobileEmulation = true;

        // eslint-disable-next-line no-console
        console.log('Test on Chrome mobile emulation'
          + `, deviceName: '${config.capabilities.deviceName}'`
          + `, global.deviceType: ${global.deviceType}`
          + `${browserTestedPhrase}`);
      } else {
        global.ov3TestIsRunUsingChromeMobileEmulation = false;

        // eslint-disable-next-line no-console
        console.log('Test on mobile emulator'
          + `, deviceName: '${config.capabilities.deviceName}'`
          + `, global.deviceType: ${global.deviceType}`
          + `${browserTestedPhrase}`);
      }
    }

    global.isHeadlessChrome = false;

    if (global.browserName === 'chrome') {
      let i;

      for (i = 0; i < config.capabilities.chromeOptions.args.length; i += 1) {
        // eslint-disable-next-line no-console
        console.log(
          `   chromeOptions.args[${i}]: `
          + `${config.capabilities.chromeOptions.args[i].valueOf()}`);

        if (config.capabilities.chromeOptions.args[i].indexOf('headless') !== -1) {
          global.isHeadlessChrome = true;
        }
      }
    }

    // eslint-disable-next-line no-console
    console.log(`   headless Chrome?: ${global.isHeadlessChrome}`);

    jasmine.getEnv().afterAll(async () => {
      /*
        note the browser cache and cookies are now cleared in the afterAll() block of each describe() block
        but clearing here has been kept for the reason below

        the test can fail stating "WebDriverError: invalid session id" if a previous fail has occurred
        this end-of-suite clearing has been kept for this reason - it could be the only clue to a fail
        see bug http://jira.mercer.com/browse/OUK-8802 for more details on this
       */

      // eslint-disable-next-line no-console
      console.log('Clear domain cookies from browser and clear browser cache at end of test suite');
      await browser.manage().deleteAllCookies();

      // cache
      await browser.executeScript('window.sessionStorage.clear();');
      await browser.executeScript('window.localStorage.clear();');
    });
  },

  afterLaunch(exitCode) {
    return new Promise((resolve) => {
      reporter.afterLaunch(resolve.bind(this, exitCode));
    });
  }
};
