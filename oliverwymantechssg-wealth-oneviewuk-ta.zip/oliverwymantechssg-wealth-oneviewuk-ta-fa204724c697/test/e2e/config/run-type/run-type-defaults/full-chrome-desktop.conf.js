/*
  This file is used to state the additional default browser [capabilities] and [multiCapabilities] parameters
  which OVERRIDE the relevant defaults in capabilities-defaults.conf.js which will apply to all tests run
  using full desktop Chrome, whichever environment and run type is used
 */

const fullChromeDesktopDefaults = {
  shardTestFiles: false,   // do not split test specs between multiple instances of browser under test
  browserName: 'chrome',
};

module.exports = {
  fullChromeDesktopDefaults
};
