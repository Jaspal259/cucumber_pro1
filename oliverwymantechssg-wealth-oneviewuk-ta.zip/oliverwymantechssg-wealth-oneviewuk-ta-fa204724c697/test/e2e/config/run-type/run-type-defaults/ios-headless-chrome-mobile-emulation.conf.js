/*
  This file is used to state the additional default browser [capabilities] and [multiCapabilities] parameters
  which OVERRIDE the relevant defaults in capabilities-defaults.conf.js which will apply to all tests run
  using iOS (Apple) mobile emulation mode in headless desktop Chrome, whichever environment and run type is used
 */
const CommonConfigConstants = require('../../_common/common-config-constants.js');

const commonConfigConstants = new CommonConfigConstants();

const iosHeadlessChromeMobileEmulationDefaults = {
  shardTestFiles: false,   // do not split test specs between multiple instances of browser under test
  browserName: 'chrome',
  screenResolution: commonConfigConstants.headlessChromeScreenResolution,

  /*
    note when using mobile emulation mode in the desktop Chrome browser:
    - capabilities.deviceName is also set so global.deviceType can be set in default.conf to indicate mobile test
    - the more detailed chromeOptions here replace those imported from capabilitiesDefaults
   */
  deviceName: commonConfigConstants.chromeMobileEmulationIos,
  chromeOptions: {
    mobileEmulation: {
      deviceName: commonConfigConstants.chromeMobileEmulationIos
    },
    /*
      note the chromeOptions in this config completely replaces the chromeOptions in capabilitiesDefaults
      so we have to re-state the args and prefs set in the capabilitiesDefaults chromeOptions
     */
    args: commonConfigConstants.headlessChromeChromeOptionsArgs,
    prefs: {
      credentials_enable_service: false,
      profile: {
        password_manager_enabled: false
      },
      download: {
        /*
          Note this will only work if MGTI unlock the 'Ask where to save each file before downloading' option
          in Chrome settings under 'advanced > downloads'

          With this option set to true an OS dialogue box opens up when downloading any download file which
          will not open in the browser itself (such as a .docx file)

          Protractor cannot interact with anything outside of the browser reliably so - in practice - this means
          that any download links cannot be clicked by these tests when using Chrome
         */
        prompt_for_download: false,
      }
    }
  },
};

module.exports = {
  iosHeadlessChromeMobileEmulationDefaults
};
