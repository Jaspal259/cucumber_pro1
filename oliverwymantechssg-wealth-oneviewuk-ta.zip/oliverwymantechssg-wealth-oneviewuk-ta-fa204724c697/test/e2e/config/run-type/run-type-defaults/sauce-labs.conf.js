/*
  This file is used to state the additional default browser [capabilities] and [multiCapabilities] parameters
  for running tests on the Sauce Labs infrastructure, whichever environment and run type is used
 */

const CommonConfigConstants = require('../../_common/common-config-constants.js');

const commonConfigConstants = new CommonConfigConstants();

const sauceLabsDefaults = {
  // test name
  name: `${this.appName} - TA test - on Sauce Labs`,
  tags: [
    commonConfigConstants.appName,
    commonConfigConstants.testAutomation
  ],
  shardTestFiles: true,   // split test specs between multiple instances of browser under test
};

module.exports = {
  sauceLabsDefaults
};
