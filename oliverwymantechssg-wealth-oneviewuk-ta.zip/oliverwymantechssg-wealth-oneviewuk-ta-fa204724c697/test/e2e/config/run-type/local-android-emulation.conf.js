const CapabilitiesDefaults = require('../_common/capabilities-defaults.conf.js');
const AndroidFullChromeMobileEmulationDefaults
  = require('./run-type-defaults/android-full-chrome-mobile-emulation.conf.js');
const CommonConfigConstants = require('../_common/common-config-constants.js');

const commonConfigConstants = new CommonConfigConstants();

exports.config = {
  seleniumAddress: commonConfigConstants.localSeleniumAddress,
  capabilities: {
    // note use of the JS spread operator '...' to merge in defaults for capabilities
    ...CapabilitiesDefaults.capabilitiesDefaults,
    ...AndroidFullChromeMobileEmulationDefaults.androidFullChromeMobileEmulationDefaults,
  },
};
