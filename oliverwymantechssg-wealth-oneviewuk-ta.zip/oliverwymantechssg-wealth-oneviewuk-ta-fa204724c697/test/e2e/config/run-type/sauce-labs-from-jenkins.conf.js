const CapabilitiesDefaults = require('../_common/capabilities-defaults.conf.js');
const SauceLabsDefaults = require('./run-type-defaults/sauce-labs.conf.js');

const capabilitiesDefaults = CapabilitiesDefaults.capabilitiesDefaults;
const sauceLabsDefaults = SauceLabsDefaults.sauceLabsDefaults;

exports.config = {

  // TODO: this is not final or tested - will almost certainly need adjustment for Jenkins

  // Sauce Labs general settings
  // ------------------------------------------------------------------------------
  // Sauce Labs configuration which is not set in the default.conf.js or sauce-labs.conf.js

  /*
    although the settings here are almost certainly common to all Sauce Labs configs they have to be set in
    the individual TE configs for SL runs rather than in default.conf.js otherwise all
    TE runs will attempt to use SL even if the config states local or Jenkins

    the Sauce username and access key are loaded from Win environment variables so they are not stored in TE code
    note the access key is NOT the same as the SL password

    please see the SL section of the capabilities-defaults.conf.js for more SL settings and comments
   */
  sauceUser: process.env.OV3_TE_SAUCE_USERNAME,
  sauceKey: process.env.OV3_TE_SAUCE_ACCESS_KEY,

  // TODO: switch on when Sauce Labs EU data centre available (planned Feb 2019) - note QA/UAT = us, STAGING/PROD = eu
  // see https://wiki.saucelabs.com/display/DOCS/Sauce+Labs+European+Data+Center+Configuration+Information
  // sauceRegion: 'eu',

  // logLevel: 'DEBUG', // switch on when you need info in SL app during debug

  // ------------------------------------------------------------------------------
  // end of Sauce Labs general settings

  multiCapabilities: [
    // note use of the JS spread operator '...' to merge in defaults for capabilities
    {
      // same as Mercer PC standard
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'chrome',
      platform: 'Windows 7',
      version: '71.0',
      screenResolution: '1280x960',
    },
    {
      // same as Mercer PC standard
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'internet explorer',
      platform: 'Windows 7',
      version: '11.0',
      screenResolution: '1280x960',
    },
    {
      // same as Mercer PC standard
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'firefox',
      platform: 'Windows 7',
      version: '52.0',
      screenResolution: '1280x960',
    },
    {
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'safari',
      platform: 'macOS 10.12',
      version: '11.0',
      screenResolution: '1280x960',
    },
    {
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'MicrosoftEdge',
      platform: 'Windows 10',
      version: '16.16299',
      screenResolution: '1280x960',
    },
    {
      ...capabilitiesDefaults,
      ...sauceLabsDefaults,
      browserName: 'firefox',
      platform: 'Linux',
      version: '45.0',
      screenResolution: '1024x768',
    },
    // {
    //   ...capabilitiesDefaults,
    //   ...sauceLabsDefaults,
    //   browserName: 'Safari',
    //   platform: 'iOS',
    //   version: '12.0',
    //   appiumVersion: '1.9.1',
    //   deviceName: 'iPhone SE Simulator',
    //   deviceOrientation: 'portrait',
    // }
  ],

  suites: {}
};
