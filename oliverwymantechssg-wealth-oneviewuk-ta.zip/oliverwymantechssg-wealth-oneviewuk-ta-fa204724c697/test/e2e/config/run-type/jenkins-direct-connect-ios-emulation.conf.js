const CapabilitiesDefaults = require('../_common/capabilities-defaults.conf.js');
const IosHeadlessChromeMobileEmulationDefaults
  = require('./run-type-defaults/ios-headless-chrome-mobile-emulation.conf.js');
const CommonConfigConstants = require('../_common/common-config-constants.js');

const commonConfigConstants = new CommonConfigConstants();

exports.config = {
  directConnect: commonConfigConstants.headlessChromeAloneUsesDirectConnect,
  chromeDriver: commonConfigConstants.jenkinsChromeDriverLocation,
  capabilities: {
    // note use of the JS spread operator '...' to merge in defaults for capabilities
    ...CapabilitiesDefaults.capabilitiesDefaults,
    ...IosHeadlessChromeMobileEmulationDefaults.iosHeadlessChromeMobileEmulationDefaults,
  },
};
