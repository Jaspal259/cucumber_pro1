exports.config = {
  params: {
    /*
      NOTE
      Please add specific LOCAL options here
      note usually not needed as default.conf.js defines most options required
     */
  },
  capabilities: {
    /*
      NOTE:
      see https://github.com/SeleniumHQ/selenium/wiki/DesiredCapabilities#loggingpreferences-json-object
      used in checkJavaScriptBrowserLogs() functions
      normally just use the loggingPrefs inherited from default.conf.js
     */
    // loggingPrefs: {
    //   driver: 'WARNING',
    //   server: 'WARNING',
    //   browser: 'SEVERE'      // 'SEVERE' for actual testing - only use 'INFO' or 'OFF' only when debugging
    // },
  },
  suites: {
    // add specific LOCAL suites here
    debug: [
      // add any test(s) you are developing / debugging here

      // this is a simple test involving login - ideal for very basic smoke testing
      'features/branding/ouk-121-spec.js',

      // this is an even simpler test with no login - ideal Sauce Labs config set-up testing
      // 'features/login/ouk-209-spec.js',

      // TE only tests for diagnosing problems
      // 'features/_diagnostic/diagnostic-001-spec.js',
      // 'features/_diagnostic/diagnostic-002-spec.js',
      // 'features/_diagnostic/diagnostic-003-spec.js',
    ]
  },
};
