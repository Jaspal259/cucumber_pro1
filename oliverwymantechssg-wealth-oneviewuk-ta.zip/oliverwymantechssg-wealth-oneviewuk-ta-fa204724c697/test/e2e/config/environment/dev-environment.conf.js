// DEV
exports.config = {
  params: {
    ov3RootUrl: 'http://localhost:3000/',
    ov3RootDownloadUrl: 'http://localhost:3036/be/'
  },
  suites: {}
};
