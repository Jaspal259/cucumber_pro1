// STAGING
exports.config = {
  params: {
    ov3RootUrl: 'https://staging.merceroneview.co.uk/',
    ov3RootDownloadUrl: 'https://staging.merceroneview.co.uk/v1/oneview-be/'
  },
  suites: {}
};
