// UAT
exports.config = {
  params: {
    ov3RootUrl: 'https://dal-uat-merceroneview.mercer.com/',
    ov3RootDownloadUrl: 'https://dal-uat-merceroneview.mercer.com/v1/oneview-be/'
  },
  suites: {}
};
