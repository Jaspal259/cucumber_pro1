// PROD
exports.config = {
  params: {
    ov3RootUrl: 'https://v3.merceroneview.co.uk/',
    ov3RootDownloadUrl: 'https://v3.merceroneview.co.uk/v1/oneview-be/'
  },
  suites: {}
};
