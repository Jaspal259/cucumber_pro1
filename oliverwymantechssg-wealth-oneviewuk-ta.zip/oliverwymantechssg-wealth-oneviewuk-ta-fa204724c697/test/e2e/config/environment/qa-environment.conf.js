// QA
exports.config = {
  params: {
    ov3RootUrl: 'https://v218-dal-qa-merceros.mercer.com:10492/',
    ov3RootDownloadUrl: 'https://v218-dal-qa-merceros.mercer.com:10491/'
  },
  suites: {}
};
