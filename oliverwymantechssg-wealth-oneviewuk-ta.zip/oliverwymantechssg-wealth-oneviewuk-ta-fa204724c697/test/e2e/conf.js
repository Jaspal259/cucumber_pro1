/* eslint global-require: 'off' */
/* eslint prefer-destructuring: 'off' */
const merge = require('deepmerge');
const defaultConfig = require('./config/_common/default.conf.js');
const resultMessaging = require('./utilities/result-messaging.js');


// environment config files
// -------------------------------------------------------------------------------
// e.g. qa, prod

const devEnvironmentConfig = require('./config/environment/dev-environment.conf.js');
const qaEnvironmentConfig = require('./config/environment/qa-environment.conf.js');
const uatEnvironmentConfig = require('./config/environment/uat-environment.conf.js');
const stagingEnvironmentConfig = require('./config/environment/staging-environment.conf.js');
const prodEnvironmentConfig = require('./config/environment/prod-environment.conf.js');


// run type config files
// -------------------------------------------------------------------------------
// e.g. local full Chrome, Jenkins iOS mobile emulation

// local - full Chrome
const LocalConfig
  = require('./config/run-type/local.conf.js');
const LocalIosEmulationConfig
  = require('./config/run-type/local-ios-emulation.conf.js');
const LocalAndroidEmulationsConfig
  = require('./config/run-type/local-android-emulation.conf.js');

// local - headless Chrome (simulate Jenkins)
const LocalSimulateJenkinsConfig
  = require('./config/run-type/local-simulate-jenkins.conf.js');
const LocalSimulateJenkinsIosEmulationConfig
  = require('./config/run-type/local-simulate-jenkins-ios-emulation.conf.js');
const LocalSimulateJenkinsAndroidEmulationConfig
  = require('./config/run-type/local-simulate-jenkins-android-emulation.conf.js');

// Jenkins - headless Chrome
const JenkinsDirectConnectConfig
  = require('./config/run-type/jenkins-direct-connect.conf.js');
const JenkinsDirectConnectIosEmulationConfig
  = require('./config/run-type/jenkins-direct-connect-ios-emulation.conf.js');
const JenkinsDirectConnectAndroidEmulationConfig
  = require('./config/run-type/jenkins-direct-connect-android-emulation.conf.js');

// Sauce Labs
const SauceLabsFromLocalConfig
  = require('./config/run-type/sauce-labs-from-local.conf.js');
const SauceLabsFromJenkinsConfig
  = require('./config/run-type/sauce-labs-from-jenkins.conf.js');


// load configs
// -------------------------------------------------------------------------------

// load config specific to particular machine and TE
let automatorConfig = {};

try {
  automatorConfig = require('./config/automator.conf.js');
} catch (error) {
  if (!(error instanceof Error && error.code === 'MODULE_NOT_FOUND')) {
    throw error;
  }
}

// load in environment config
const init = (baseConfig) => {
  /*
   * GENERIC ERROR HANDLING
   *
   * this function is required to handle otherwise unhandled promise rejections
   * BUT is only needed at the top level i.e. in the conf.js file ONLY
   *
   * an example of an unhandled promise rejection would be not handling clicking
   * on an element which does not exist
   *
   * without this function the test will report UnhandledPromiseRejectionWarning
   * and in the near future unhandled promise rejections will terminate the Node.js
   * process with a non-zero exit code and with no warning (which would be very difficult
   * to debug)
   */
  process.on('unhandledRejection', (e) => {
    resultMessaging.publishUnhandledPromiseException(e);
  });

  let environmentConfig = {};
  let environment;
  let runTypeConfig = {};
  let runType;

  /*
      the config is extracted from the command used to execute the test
      tests are executed by running a relevant command from the "scripts" block of the package.json
      for instance, to run against the QA environment simulating Jenkins on your local machine
      the command would be:

        npm run te-qa-local-simulate-jenkins-debug

      which runs the following package from the "scripts" block

        "te-qa-local-simulate-jenkins-debug": "protractor test/e2e/conf.js --params.env=qa
          --params.run-type=local-simulate-jenkins --suite=debug",

      and the config to extract would be:

        env=qa
        run-type=local-simulate-jenkins

      note Protractor handles the remaining "--suite" argument
   */

  // print the command run from the "scripts" block of the package.json
  process.argv.forEach((val, index) => {
    // eslint-disable-next-line no-console
    console.log(`Protractor command process.argv[${index}] : '${val}'`);
  });

  // gets first passed argument to Protractor in command line - should be test environment
  const testEnvironmentParameter = process.argv[3].match(/^--params\.([^=]+)=(.*)$/);

  // extract test environment (if not found defaults to Dev)
  if (testEnvironmentParameter) {
    environment = testEnvironmentParameter[2];
  } else {
    environment = 'dev';
  }

  switch (environment) {
    case 'dev':
      environmentConfig = devEnvironmentConfig;
      break;
    case 'qa':
      environmentConfig = qaEnvironmentConfig;
      break;
    case 'uat':
      environmentConfig = uatEnvironmentConfig;
      break;
    case 'staging':
      environmentConfig = stagingEnvironmentConfig;
      break;
    case 'prod':
      environmentConfig = prodEnvironmentConfig;
      break;
    default:
      throw new Error(`Config environment = ${environment} is not supported`);
  }

  // gets second Protractor argument - should be test tun type (e.g. local full Chrome, Jenkins iOS mobile emulation)
  const testRunTypeParameter = process.argv[4].match(/^--params\.([^=]+)=(.*)$/);

  // extract test run type (if not founf defaults to local-full-chrome)
  if (testRunTypeParameter) {
    runType = testRunTypeParameter[2];
  } else {
    runType = 'local';
  }

  switch (runType) {
    case 'local':
      runTypeConfig = LocalConfig;
      break;
    case 'local-ios-emulation':
      runTypeConfig = LocalIosEmulationConfig;
      break;
    case 'local-android-emulation':
      runTypeConfig = LocalAndroidEmulationsConfig;
      break;
    case 'local-simulate-jenkins':
      runTypeConfig = LocalSimulateJenkinsConfig;
      break;
    case 'local-simulate-jenkins-ios-emulation':
      runTypeConfig = LocalSimulateJenkinsIosEmulationConfig;
      break;
    case 'local-simulate-jenkins-android-emulation':
      runTypeConfig = LocalSimulateJenkinsAndroidEmulationConfig;
      break;
    case 'jenkins-direct-connect':
      runTypeConfig = JenkinsDirectConnectConfig;
      break;
    case 'jenkins-direct-connect-ios-emulation':
      runTypeConfig = JenkinsDirectConnectIosEmulationConfig;
      break;
    case 'jenkins-direct-connect-android-emulation':
      runTypeConfig = JenkinsDirectConnectAndroidEmulationConfig;
      break;
    case 'sauce-labs-from-local':
      runTypeConfig = SauceLabsFromLocalConfig;
      break;
    case 'sauce-labs-from-jenkins':
      runTypeConfig = SauceLabsFromJenkinsConfig;
      break;
    default:
      throw new Error(`Config run-type = ${runType} is not supported`);
  }

  return merge.all([baseConfig, environmentConfig, runTypeConfig, automatorConfig]).config;
};

exports.config = init(defaultConfig);
