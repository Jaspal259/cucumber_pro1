# ouk-oneview3-e2e-test
OneView 3 (UK) end-to-end test automation scripts

# contacts
- Ying Xu, ying.xu@mercer.com
- Daniel Freeman, daniel.freeman@mercer.com


# WebStorm config
If using WebStorm as code editor then please refer to the following document for set-up:
'ONEVIEW 3 (UK) - END-TO-END TEST AUTOMATION SCRIPTING GUIDELINES'

The latest version of this document is stored in the OV3 wiki at:
http://wiki.mercer.com/pages/viewpage.action?pageId=668631798


# how to install / re-install required NodeJS components
- Delete any **/node_modules** folder and all contents in this project

- In integrated terminal (i.e. terminal in code editor in this project)
  run the following commands to install the necessary Node modules under 
  the **/node_modules** folder and check none of the commands report ANY errors 
  EXCEPT those relating to ESLint which Darren Vincent has advised can be ignored since we are 
  using so little of ESLint for QA automation code review:  
  
  `npm uninstall -g protractor`  
  `npm uninstall -g webdriver-manager`  
  `npm install -g protractor` 
  `npm install`
  
  Note global install of Protractor is only required for running locally
    
- In integrated terminal run the following command to get the latest Selenium drivers 
  and check NO errors or warnings are reported:

  `webdriver-manager update`
  
  Note the IE driver can be installed using:
  
  `webdriver-manager update --ie11`
  
  but this driver does not work with the locked-down Mercer MGTI security settings for IE11

    
# how to run tests
- Please refer to the tests\e2e\conf.README.md file
 