const defaultConfig = require('./protractor.conf');
var _ = require('lodash');

var uatConfig = {
  params: {
    //capabilities: {
    //  firefoxOptions: {
    //    args: ['--headless']
    //  },
    //  'moz:firefoxOptions': {
    //    args: ['--headless']
    //  }
    //},
    capabilities: {
      browserName: 'chrome',
      chromeOptions: {
        args: [
          '--headless',
          '--window-size=1920, 1080'
        ]
      }
    },
    baseUrl: 'https://boeingapps-test.mercer.com/bambi',
    postDeploy: false,
    noBambiRolesCredentials: {
      username: 'bambi-autotestUAT',
      password: 'Welcome3!'
    },
    bambiMercerRoleCredentials: {
      username: 'bambi-autotestBoeingUAT',
      password: 'Welcome2!'
    },
    bambiAdminRoleCredentials: {
      username: 'bambi-autotestAdminUAT',
      password: 'Welcome2!'
    }
  }
};

exports.config = _.merge(defaultConfig.config, uatConfig);
