import { browser} from 'protractor';

export class BasePage {
  ec = browser.ExpectedConditions;

  constructor() {
    browser.waitForAngularEnabled(false);
    browser.ignoreSynchronization = true;
  }

  async waitForPage(pageName: string) {
    await browser.wait(this.ec.urlContains(pageName.toLowerCase()), 12000);
  }
}
