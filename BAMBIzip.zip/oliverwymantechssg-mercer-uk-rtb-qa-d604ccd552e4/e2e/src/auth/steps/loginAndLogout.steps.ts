import { Before, After, Given, Then, When } from 'cucumber';
import { expect } from 'chai';
import { browser } from 'protractor';

import { LoginPage } from '../pageObjects/loginPage.po';
import { HomePage } from '../../home/pageObjects/homePage.po';
import { LogoutPage } from '../pageObjects/logoutPage.po';
import { BasePage } from '../../base/pageObjects/basePage.po';

let loginPage: LoginPage;
let homePage: HomePage;
let logoutPage: LogoutPage;
let basePage: BasePage;

let { setDefaultTimeout } = require('cucumber');
setDefaultTimeout(60 * 2000);

Before(() => {
  loginPage = new LoginPage();
  homePage = new HomePage();
  logoutPage = new LogoutPage();
  basePage = new BasePage();
});

Given(/^I am on the login page$/, async () => {
  await loginPage.navigateToHome();
});

When('I log in as {string}', async (userRole: string) => {
  loginPage.enterLogin(userRole);
  loginPage.enterPassword(userRole);
  loginPage.clickLoginButton();
});

Then(/^I will get home page$/, async () => {
  const headerPresence = await homePage.getHeaderElementsPresence();
  expect(headerPresence).is.equal(true);
});

Then(/^I see Dashboard, Reports, User Support menu items$/, async () => {
  const headerPresence = await homePage.getHeaderElementsPresence();
  expect(headerPresence).is.equal(true);
});

Then('I {string} Admin menu item in User profile', async (condition: string) => {
  await browser.sleep(5000).then(() => {
    console.log('Waiting 5 seconds for Admin menu item');
  });
  const adminMenuItemPresence = await homePage.getAdminMenuItemPresence();
  switch (condition) {
    case 'see':
      expect(adminMenuItemPresence).is.equal(true);
      break;
    case 'don`t see':
      expect(adminMenuItemPresence).is.equal(false);
      break;
  }
  await homePage.logoutWhenDropDownIsOpen();
});

Then(/^I can logout from the application$/, async () => {
  await homePage.logoutWhenDropDownIsOpen();
  const successLogout = await logoutPage.getSuccessfulLogoutTextPresence();
  expect(successLogout).is.equal(true);
});

Then(/^I will get 'Home' page$/, async () => {
  await browser.sleep(5000).then(() => {
    console.log('Waiting 5 seconds for Home page');
  });
  const pageName = 'home';
  await basePage.waitForPage(pageName);
});

Then('I will redirected to {string}', async (url: string) => {
  await browser.sleep(5000).then(() => {
    console.log('Waiting 5 seconds for redirect');
  });
  const currentUrl = await browser.driver.getCurrentUrl();
  expect(currentUrl).is.equal(`${browser.params.baseUrl}${url}`);
});

Then('I see an {string} error', async (errorText: string) => {
  const adminMenuItemPresence = await homePage.getPageErrorTitle();
  expect(adminMenuItemPresence).is.equal(errorText);
  
  await homePage.logoutWhenDropDownIsNotOpen();
});
