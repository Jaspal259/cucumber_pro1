import { browser, by, element } from 'protractor';
import { By } from 'selenium-webdriver';


export class LoginPage {
  EC = browser.ExpectedConditions;

  userNameInputLocator: By;
  passwordInputLocator: By;
  loginButtonLocator: By;
  dashboardButtonLocator: By;

  constructor() {
    browser.waitForAngularEnabled(false);
    browser.ignoreSynchronization = true;

    this.userNameInputLocator = by.xpath('//input[@id="UserName"]');
    this.passwordInputLocator = by.xpath('//*[@id="Password"]');
    this.loginButtonLocator = by.xpath('//input[@class="btn btn-default"]');
    this.dashboardButtonLocator = by.xpath('//a[contains(text(),"Dashboard")]');
  }

  navigateToHome() {
    return browser.get(browser.params.baseUrl, 15000);
  }

  enterLogin(userRole: string) {
    browser.wait(this.EC.presenceOf(element(this.userNameInputLocator)), 30000);
    let userName;

    switch (userRole) {
      case 'BAMBI User':
        userName = browser.params.bambiMercerRoleCredentials.username;
        break;
      case 'BAMBI Admin':
        userName = browser.params.bambiAdminRoleCredentials.username;
        break;
      case 'a user without BAMBI role':
        userName = browser.params.noBambiRolesCredentials.username;
        break;
    }
    browser.findElement(this.userNameInputLocator).sendKeys(userName);
  }

  enterPassword(userRole: string) {
    let password;
    switch (userRole) {
      case 'BAMBI User':
        password = browser.params.bambiMercerRoleCredentials.password;
        break;
      case 'BAMBI Admin':
        password = browser.params.bambiAdminRoleCredentials.password;
        break;
      case 'a user without BAMBI role':
        password = browser.params.noBambiRolesCredentials.password;
        break;
    }    browser.wait(this.EC.presenceOf(element(this.passwordInputLocator)), 30000);
    browser.findElement(this.passwordInputLocator).sendKeys(password);
  }

  clickLoginButton() {
    browser.wait(this.EC.presenceOf(element(this.passwordInputLocator)), 30000);
    element(this.loginButtonLocator).click();
  }

  loginAsUserWithBambiMercerRole() {
    browser.wait(this.EC.presenceOf(element(this.userNameInputLocator)), 30000)
      .then(() => browser.findElement(this.userNameInputLocator).sendKeys(browser.params.bambiMercerRoleCredentials.username));

    browser.wait(this.EC.presenceOf(element(this.passwordInputLocator)), 30000)
      .then(() => browser.findElement(this.passwordInputLocator).sendKeys(browser.params.bambiMercerRoleCredentials.password));

    browser.wait(this.EC.presenceOf(element(this.passwordInputLocator)), 30000)
      .then(() => element(this.loginButtonLocator).click());
  }
}
