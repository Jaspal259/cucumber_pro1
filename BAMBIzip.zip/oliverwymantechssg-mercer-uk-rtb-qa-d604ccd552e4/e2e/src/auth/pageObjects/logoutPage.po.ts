import { browser, by, element } from 'protractor';
import { By } from 'selenium-webdriver';


export class LogoutPage {
  EC = browser.ExpectedConditions;

  logoutTextLocator: By;


  constructor() {
    browser.waitForAngularEnabled(false);
    browser.ignoreSynchronization = true;

    this.logoutTextLocator = by.xpath('//p[contains(text(),"You have been logged out of this session.")]');
  }

  async getSuccessfulLogoutTextPresence() {
    await browser.wait(this.EC.presenceOf(element(this.logoutTextLocator)), 10000);

    return browser.findElement(this.logoutTextLocator).isDisplayed();
  }
}
