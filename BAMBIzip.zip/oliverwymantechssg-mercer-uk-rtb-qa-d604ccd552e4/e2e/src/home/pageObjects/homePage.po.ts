import { browser, by, element } from 'protractor';
import { By } from 'selenium-webdriver';


export class HomePage {
  EC = browser.ExpectedConditions;

  homeMenuItemLocator: By;
  dashboardMenuItemLocator: By;
  reportsMenuItemLocator: By;
  userSupportMenuItemLocator: By;
  userAvatarMenuLocator: By;
  logoutButtonLocator: By;
  confirmLogoutLocator: By;
  adminMenuItemLocator: By;
  userNameMenuItemLocator: By;
  userNameMenuItemsListLocator: By;
  pageErrorTitleLocator: By;
  welcomeMessageLocator: By;
  bambiOverviewSectionLocator: By;
  bambiWhatCanIDoSectionLocator: By;
  userGuideDownloadLinkLocator: By;
  disclaimerLocator: By;

  constructor() {
    browser.waitForAngularEnabled(false);
    browser.ignoreSynchronization = true;

    this.homeMenuItemLocator = by.xpath('//bam-header//li[1]//a[1]');
    this.dashboardMenuItemLocator = by.xpath('//a[contains(text(),"Dashboard")]');
    this.reportsMenuItemLocator = by.xpath('//a[contains(text(),"Reports")]');
    this.userSupportMenuItemLocator = by.xpath('//a[contains(text(),"User Support")]');
    this.userAvatarMenuLocator = by.xpath('//div[@class="mos-c-avatar"]');
    this.logoutButtonLocator = by.xpath('//a[contains(text(),"Logout")]');
    this.confirmLogoutLocator = by.xpath('//bam-button[text()="Logout"]');
    this.adminMenuItemLocator = by.xpath('//a[contains(text(),"Admin")]');
    this.userNameMenuItemLocator = by.xpath('//div[@class="mos-c-hcard"]');
    this.userNameMenuItemsListLocator = by.xpath('//ul[@class="mos-c-dropdown__list"]');
    this.pageErrorTitleLocator = by.xpath('//h2[@class="bam-error-title"]');
    this.welcomeMessageLocator = by.xpath('//h1[@class="bam-title align-center"]');
    this.bambiOverviewSectionLocator = by.xpath('//h3[contains(text(),"BAMBI Overview")]');
    this.bambiWhatCanIDoSectionLocator = by.xpath('//h3[contains(text(),"What can I do with BAMBI?")]');
    this.userGuideDownloadLinkLocator = by.xpath('//a[contains(text(),"User Guide")]');
    this.disclaimerLocator = by.xpath('//p[contains(text(),"The BAMBI application contains confidential")]');
  }

  async getHeaderElementsPresence() {
    await browser.wait(this.EC.presenceOf(element(this.homeMenuItemLocator)), 5000);

    return await browser.findElement(this.dashboardMenuItemLocator).isDisplayed()
      && browser.findElement(this.reportsMenuItemLocator).isDisplayed()
      && browser.findElement(this.userSupportMenuItemLocator).isDisplayed();
  }

  async logoutWhenDropDownIsOpen() {
    await browser.wait(this.EC.elementToBeClickable(element(this.logoutButtonLocator)), 5000);
    element(this.logoutButtonLocator).click();

    await browser.wait(this.EC.elementToBeClickable(element(this.confirmLogoutLocator)), 5000);
    element(this.confirmLogoutLocator).click();

    await browser.sleep(5000).then(() => {
      console.log('Waiting 5 seconds to complete logout');
    });
  }

  async logoutWhenDropDownIsNotOpen() {
    await browser.wait(this.EC.elementToBeClickable(element(this.userAvatarMenuLocator)), 5000);
    element(this.userAvatarMenuLocator).click();

    await this.logoutWhenDropDownIsOpen();
  }

  async getAdminMenuItemPresence() {
    await browser.sleep(5000).then(() => {
      console.log('Waiting 5 seconds for Admin menu presence');
    });
    await browser.wait(this.EC.presenceOf(element(this.userAvatarMenuLocator)), 10000);
    element(this.userAvatarMenuLocator).click();

    await browser.wait(this.EC.elementToBeClickable(element(this.userNameMenuItemLocator)), 5000);
    return await element(this.adminMenuItemLocator).isPresent();
  }

  async getPageErrorTitle() {
    await browser.wait((element(this.pageErrorTitleLocator).isDisplayed()), 10000);
    return await element(this.pageErrorTitleLocator).getText();
  }

  async getWelcomeMessagePresence() {
    await browser.wait((element(this.welcomeMessageLocator).isDisplayed()), 5000);
    return await element(this.welcomeMessageLocator).getText();
  }

  async getSectionPresence(sectionName: string) {
    let sectionPresence;
    switch (sectionName) {
      case 'BAMBI OVERVIEW':
        await browser.wait((element(this.bambiOverviewSectionLocator).isDisplayed()), 5000);
        sectionPresence = await element(this.bambiOverviewSectionLocator).isPresent();
        break;
      case 'WHAT CAN I DO WITH BAMBI?':
        await browser.wait((element(this.bambiWhatCanIDoSectionLocator).isDisplayed()), 5000);
        sectionPresence = await element(this.bambiWhatCanIDoSectionLocator).isPresent();
        break;
    }
    return sectionPresence;
  }

  async getLinkInSectionPresence() {
    await browser.wait((element(this.userGuideDownloadLinkLocator).isDisplayed()), 5000);
    return await element(this.welcomeMessageLocator).isPresent();
  }

  async waitForPage(pageName: string) {
    await browser.wait(this.EC.urlContains(pageName.toLowerCase()), 15000);
  }

  async getDisclaimerPresence() {
    await browser.wait((element(this.disclaimerLocator).isDisplayed()), 5000);
    return await element(this.disclaimerLocator).isPresent();
  }
}
