import { Before, Given, Then, When } from 'cucumber';
import { expect } from 'chai';
import { browser } from 'protractor';

import { LoginPage } from '../../auth/pageObjects/loginPage.po';
import { LogoutPage } from '../../auth/pageObjects/logoutPage.po';
import { HomePage } from '../../home/pageObjects/homePage.po';

let loginPage: LoginPage;
let homePage: HomePage;
let logoutPage: LogoutPage;

let { setDefaultTimeout } = require('cucumber');
setDefaultTimeout(60 * 2000);

Before(() => {
  loginPage = new LoginPage();
  homePage = new HomePage();
  logoutPage = new LogoutPage();
});

Given(/^I logged in to BAMBI application$/, async () => {
  await loginPage.navigateToHome();
  loginPage.loginAsUserWithBambiMercerRole();
});

When('I am on {string} page', async (pageName: string) => {
  await homePage.waitForPage(pageName);
});

Then(/^I see that Home page contains Welcome message$/, async () => {
  const welcomeMessage = await homePage.getWelcomeMessagePresence();
  expect(welcomeMessage).is.equal('Welcome to BAMBI');
});

Then('Home page contains {string} section', async (sectionName: string) => {
  const sectionPresence = await homePage.getSectionPresence(sectionName);
  expect(sectionPresence).is.equal(true);
});

Then('WHAT CAN I DO WITH BAMBI? section contains User Guide link', async () => {
  const userGuideLinkPresence = await homePage.getLinkInSectionPresence();
  expect(userGuideLinkPresence).is.equal(true);
});

Then(/^Home page contains disclaimer$/, async () => {
  const headerPresence = await homePage.getDisclaimerPresence();
  expect(headerPresence).is.equal(true);
});
