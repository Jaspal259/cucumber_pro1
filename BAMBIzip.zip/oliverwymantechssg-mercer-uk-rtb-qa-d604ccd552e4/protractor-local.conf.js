const defaultConfig = require('./protractor.conf');
let localConfig = {
  params: {
    baseUrl: 'https://localhost:8052/bambi',
    postDeploy: false,
    noBambiRolesCredentials: {
      username: 'bambi-autotestUAT',
      password: 'Welcome3!'
    },
    bambiMercerRoleCredentials: {
      username: 'bambi-autotestBoeingUAT',
      password: 'Welcome2!'
    },
    bambiAdminRoleCredentials: {
      username: 'bambi-autotestAdminUAT',
      password: 'Welcome2!'
    }
  }
};

exports.config = Object.assign(defaultConfig.config, localConfig);
