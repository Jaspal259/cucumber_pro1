var tsNode = require('ts-node');
// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts
var reporter = require('cucumber-html-reporter');

exports.config = {
  allScriptsTimeout: 600 * 3000,
  specs: [
    './e2e/src/**/features/loginAndLogout.feature'
  ],
  //capabilities: {
  //  browserName: 'firefox',
  //  marionette: true,
  //  acceptInsecureCerts: true,
  //  firefoxOptions: {
  //    args: ['--headless']
  //  },
  //  'moz:firefoxOptions': {
  //    args: ['--headless']
  //  }
  //},
  capabilities: {
    browserName: 'chrome',
    chromeOptions: {
      args: [
        '--headless',
        '--window-size=1920, 1080'
      ]
    }
  },
  directConnect: true,
  framework: 'custom',
  frameworkPath: require.resolve('protractor-cucumber-framework'),
  cucumberOpts: {
    require: ['./e2e/src/**/steps/loginAndLogout.steps.ts'],
    format: 'json:./e2e/src/reporting/e2e_bambi_report.json'
  },
  onPrepare() {
    tsNode.register({
      project: 'e2e/tsconfig.e2e.json'
    });
  },
  onComplete: () => {
    console.log('on complete called');
    var options = {
      theme: 'bootstrap',
      output: './e2e/src/reporting/e2e_bambi_report.html',
      jsonDir:'./e2e/src/reporting/',
      reportSuiteAsScenarios: true,
      scenarioTimestamp: true,
      launchReport: false,
	  removeExistingJsonReportFile: true,
	  automaticallyGenerateReport:true,
	  reportName: 'E2E BAMBI report',
	  saveCollectedJSON: false
    };

    reporter.generate(options);
  }
};
