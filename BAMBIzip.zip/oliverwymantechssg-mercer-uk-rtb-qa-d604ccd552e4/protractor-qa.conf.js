const defaultConfig = require('./protractor.conf');
var _ = require('lodash');

var qaConfig = {
  
  capabilities: {	
    browserName: 'chrome',
    chromeOptions: {
      args: [
        '--headless',
        '--window-size=1920, 1080',
		'--ignore-certificate-errors'
      ]
    }
    //firefoxOptions: {
    //  args: ['--headless']
    //},
    //'moz:firefoxOptions': {
    //  args: ['--headless']
    //}
  },
  params: {
    baseUrl: 'https://usdf14v0050/bambi',
    postDeploy: false,
    noBambiRolesCredentials: {
      username: 'bambi-autotestQA',
      password: 'Welcome2!'
    },
    bambiMercerRoleCredentials: {
      username: 'bambi-autotestBoeingQA',
      password: 'Welcome2!'
    },
    bambiAdminRoleCredentials: {
      username: 'bambi-autotestAdminQA',
      password: 'Welcome2!'
    }
  }
};

exports.config = _.merge(defaultConfig.config, qaConfig);
