import { Resolve } from '@angular/router';
import { ResourceService } from '../services/resources/resource.service';
import { ResourceProvider } from '../services/resources/resource-provider';
import { ResourceSectionKey } from '../models/resources/resource-section-key';

export class BaseResourceResolver<TSectionKey extends ResourceSectionKey> implements Resolve<ResourceProvider> {
  constructor(protected resourceService: ResourceService, private resourceAlias: TSectionKey) {
  }

  resolve(): Promise<ResourceProvider> {
    return this.resourceService.getResources(this.resourceAlias);
  }
}
