import { Injectable } from '@angular/core';
import { BaseResourceResolver } from './base-resource-resolver';
import { ResourceService } from '../services/resources/resource.service';

@Injectable()
export class GlobalResourceResolver extends BaseResourceResolver<'global'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'global');
  }
}
