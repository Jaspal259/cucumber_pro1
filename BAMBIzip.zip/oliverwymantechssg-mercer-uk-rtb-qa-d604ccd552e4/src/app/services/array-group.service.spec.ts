import { TestBed, inject } from '@angular/core/testing';

import { ArrayGroupService } from './array-group.service';

describe('ArrayGroupService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ArrayGroupService]
    });
  });

  it('should be created', inject([ArrayGroupService], (service: ArrayGroupService) => {
    expect<any>(service).toBeTruthy();
  }));
});
