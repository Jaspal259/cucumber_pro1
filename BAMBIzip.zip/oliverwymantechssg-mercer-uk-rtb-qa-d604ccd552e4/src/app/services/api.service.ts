import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';

@Injectable()
export class ApiService {
  private contentTypeHeader = { 'Content-Type': 'application/json' };

  private get xsrfHeader() {
    return { 'X-XSRF-Token': this.renderer.selectRootElement('input[name = "__RequestVerificationToken"]').value };
  }

  private renderer: Renderer2;

  constructor(
    private httpClient: HttpClient,
    private rendererFactory: RendererFactory2
  ) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  async get<T>(url: string, params?: HttpParams): Promise<T> {
    const httpOptions = {
      params: params,
      headers: new HttpHeaders(this.contentTypeHeader)
    };

    const response = await this.httpClient.get<T>(`api/${url}`, httpOptions).toPromise<T>();
    return response;
  }

  async post<T>(url: string, body: any, responseType?): Promise<T> {
    const httpOptions = {
      responseType,
      headers: this.getPostPutHeaders()
    };

    return await this.httpClient.post<T>(`api/${url}`, body, httpOptions).toPromise<T>();
  }

  async postFile<T>(url: string, file: any): Promise<T> {
    const httpOptions = {
      headers: new HttpHeaders({
        ...this.xsrfHeader
      })
    };

    const fileContent = new FormData();
    fileContent.append('file', file.file, file.name);

    return await this.httpClient.post<T>(`api/${url}`, fileContent, httpOptions).toPromise<T>();
  }

  async put<T>(url: string, body: any): Promise<T> {
    const httpOptions = {
      headers: this.getPostPutHeaders()
    };

    return await this.httpClient.put<T>(`api/${url}`, body, httpOptions).toPromise<T>();
  }

  private getPostPutHeaders(): HttpHeaders {
    return new HttpHeaders({
        ...this.contentTypeHeader,
        ...this.xsrfHeader
      }
    );
  }
}
