
import {filter} from 'rxjs/operators';
import { Injectable, ElementRef } from '@angular/core';
import { LocationStrategy } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';

@Injectable()
export class ScrollingService {
  isPopState = false;
  readonly headerHeightPx = 69;

  constructor(private router: Router, private locationStrategy: LocationStrategy) {
  }

  public scrollToTopOfPage() {
    this.locationStrategy.onPopState(() => {
      this.isPopState = true;
    });

    this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        if (!this.isPopState) {
          window.scrollTo(0, 0);
        }
        this.isPopState = false;
      }
    );
  }

  public scrollToElement(elementRef: ElementRef, offsetPx: number) {
    const rect = elementRef.nativeElement.getBoundingClientRect();
    const verticalOffsetPx = rect.top + window.pageYOffset - document.documentElement.scrollTop - this.headerHeightPx - offsetPx;
    window.scrollBy(0, verticalOffsetPx);
  }
}
