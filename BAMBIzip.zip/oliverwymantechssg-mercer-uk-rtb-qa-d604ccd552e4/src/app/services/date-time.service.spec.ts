import { TestBed, inject } from '@angular/core/testing';
import { DateTimeService } from './date-time.service';

fdescribe('DateTimeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DateTimeService]
    });
  });

  it('should be created', inject([DateTimeService], (service: DateTimeService) => {
    expect<any>(service).toBeTruthy();
  }));

  it('should return full month and year', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getFullMonthAndYear(201912)).toEqual('December 2019');
  });

  it('should return empty string if date is null', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getFullMonthAndYear(null)).toEqual('');
  });

  it('should return correct local date', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getLocalDate(new Date(2020, 0, 1))).toEqual('01/01/2020');
  });

  it('should return correct local time', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getLocalTime(new Date(2020, 0, 1, 12, 30, 0, 0))).toEqual('12:30');
  });

  it('should return correct month and year', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getMonthAndYear(202006)).toEqual('Jun 2020');
  });

  it('should return empty string if date is null', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getMonthAndYear(null)).toEqual('');
  });

  it('should return correct month and year from date', () => {
    const service: DateTimeService = TestBed.get(DateTimeService);
    expect(service.getMonthAndYearsFromDate(2021, 1)).toEqual('Jan 2021');
  });
});
