import { Injectable, OnDestroy } from '@angular/core';
import { Subject ,  Subscription } from 'rxjs';
// tslint:disable-next-line:max-line-length
import { LoadingIndicatorKeyValue, LoadingIndicatorSection, LoadingIndicatorDictionary  } from '../controls/spinner/models/loading-indicator-section.type';
import * as _ from 'lodash';
import { filter } from 'rxjs/operators';
import { TimeoutService } from './timeout.service';

@Injectable()
export class SpinnerService implements OnDestroy  {
  private loadingIndicatorSubject = new Subject<LoadingIndicatorKeyValue>();
  private loadingIndicatorChanged$ = this.loadingIndicatorSubject.asObservable();
  latestValueSubscription: Subscription;

  private latestValue: LoadingIndicatorDictionary = {};

  constructor(private timeoutService: TimeoutService) {
    this.latestValueSubscription = this.loadingIndicatorChanged$.subscribe(message => this.latestValue[message.key] = message.value);
  }

  getLatestValue(key: LoadingIndicatorSection) {
    if (this.latestValue[key]) {
      return this.latestValue[key];
    }

    return false;
  }

  subscribeToLoadingIndicator(key: LoadingIndicatorSection, subscriptionCallback: (loadingIndicator: boolean) => void): Subscription {
    const loadingIndicatorChanged$ = this.loadingIndicatorChanged$.pipe(filter(loadingIndicator => loadingIndicator.key === key));
    return loadingIndicatorChanged$.subscribe(loadingIndicator => {
        subscriptionCallback(loadingIndicator.value);
    });
  }

  async show(key: LoadingIndicatorSection, action: () => Promise<void>) {
    try {
      this.showSpinner(key);
      await action();
    } finally {
      this.hideSpinner(key);
    }
  }

  async showWithTimeout(key: LoadingIndicatorSection, action: () => Promise<void>, ms: number) {
    await this.show(key, async() => {
      await action();
      await this.timeoutService.timeout(ms);
    });
  }

  private showSpinner(key: LoadingIndicatorSection) {
    this.latestValue[key] = true;
    this.loadingIndicatorSubject.next({
      key,
      value: true
    });
  }

  private hideSpinner(key: LoadingIndicatorSection) {
    this.latestValue[key] = false;
    this.loadingIndicatorSubject.next({
      key,
      value: false
    });
  }

  ngOnDestroy() {
    this.latestValueSubscription.unsubscribe();
  }
}
