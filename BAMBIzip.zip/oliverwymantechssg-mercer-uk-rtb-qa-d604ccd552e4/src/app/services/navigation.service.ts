
import {mergeMap, map, filter} from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd, Data } from '@angular/router';
import { Subscription } from 'rxjs';

@Injectable()
export class NavigationService {
  constructor(private router: Router,
    private activatedRoute: ActivatedRoute) { }

  public subscribeToRouteDataChange(subscriptionCallback: (data: Data) => void): Subscription {
    return this.router.events.pipe(
      filter((event) => event instanceof NavigationEnd),
      map(() => this.activatedRoute),
      map((route: ActivatedRoute) => {
        while (route.firstChild) {
          route = route['firstChild'];
        }
        return route;
      }),
      filter((route: ActivatedRoute) => route.outlet === 'primary'),
      mergeMap((route: ActivatedRoute) => route.data))
      .subscribe(subscriptionCallback);
  }

  public openNewWindow(url: string) {
    window.open(url, '_blank');
  }
}
