import { Injectable } from '@angular/core';

@Injectable()
export class TimeoutService {
  public timeout(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
