import { TestBed } from '@angular/core/testing';

import { ArrayHelperService } from './array-helper.service';

fdescribe('ArrayHelperService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ArrayHelperService = TestBed.get(ArrayHelperService);
    expect(service).toBeTruthy();
  });

  it('should get max value to the nearest 10', () => {
    const service: ArrayHelperService = TestBed.get(ArrayHelperService);
    expect(service.getMaxToTheNearest10([1, 3, 5])).toEqual(5);
    expect(service.getMaxToTheNearest10([11, 33, 55])).toEqual(60);
    expect(service.getMaxToTheNearest10([11, 33, 99])).toEqual(100);
    expect(service.getMaxToTheNearest10([11, 33, 801])).toEqual(810);
    expect(service.getMaxToTheNearest10([11, 33, 999])).toEqual(1000);
  });
});
