import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { GroupedObjectByKeys } from '../models/grouped-object-by-keys.model';
import { KeyValues } from '../models/key-values.model';

@Injectable()
export class ArrayGroupService {

  constructor() { }

  groupByMultipleFields<T>(array: T[], fields: (keyof T)[]): GroupedObjectByKeys<T>[] {
    if (!array) {
      return null;
    }

    const groups = {};
    const f = m => _.map(fields, key => m[key]);
    array.forEach(o => {
      const group = JSON.stringify(f(o));
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });

    return _(groups).map((group, key) => {
        return {
          keys: key.replace(/[\[\]'"]+/g, '').split(','),
          values: group
        };
      })
      .value();
  }

  groupBy<T>(array: T[], field: keyof T): KeyValues<T> {
    if (!array) {
      return null;
    }

    const groupedObj: KeyValues<T> = _.groupBy(array, field);

    return groupedObj;
  }
}
