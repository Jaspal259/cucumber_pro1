import { TestBed, inject } from '@angular/core/testing';
import { FileExtensionService } from './file-extension.service';

fdescribe('FileExtensionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FileExtensionService]
    });
  });

  const expectedExtensions = ['.pdf', '.xlsx'];

  const dataTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'];

  it('should be created', inject([FileExtensionService], (service: FileExtensionService) => {
    expect(service).toBeTruthy();
  }));

  it('should return correct pdf file extension', inject([FileExtensionService], (service: FileExtensionService) => {
    const result = service.getExtensionFromDataType(dataTypes[0]);

    expect(result).toEqual(expectedExtensions[0]);
  }));

  it('should return correct xlsx file extension', inject([FileExtensionService], (service: FileExtensionService) => {
    const result = service.getExtensionFromDataType(dataTypes[1]);

    expect(result).toEqual(expectedExtensions[1]);
  }));

  it('should return null file extension', inject([FileExtensionService], (service: FileExtensionService) => {
    const result = service.getExtensionFromDataType(dataTypes[2]);

    expect(result).toEqual(null);
  }));
});
