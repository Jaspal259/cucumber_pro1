import { Injectable } from '@angular/core';

@Injectable()
export class FileExtensionService {

  getExtensionFromDataType(dataType: string): string {
    switch (dataType) {
    case 'application/pdf':
      return '.pdf';
    case 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':
      return '.xlsx';
    default:
      return null;
    }
  }
}
