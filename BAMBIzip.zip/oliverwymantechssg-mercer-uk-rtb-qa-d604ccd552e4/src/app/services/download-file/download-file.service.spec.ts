import { TestBed, inject } from '@angular/core/testing';

import { DownloadFileService } from './download-file.service';
import { FileExtensionService } from './file-extension.service';

fdescribe('DownloadFileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DownloadFileService, FileExtensionService]
    });
  });

  it('should be created', inject([DownloadFileService], (service: DownloadFileService) => {
    expect<any>(service).toBeTruthy();
  }));
});
