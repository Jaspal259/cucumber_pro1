import { Injectable } from '@angular/core';
import { FileExtensionService } from './file-extension.service';

@Injectable()
export class DownloadFileService {
  constructor(private fileExtensionService: FileExtensionService) {
  }

  triggerFileDownload(data: Blob, fileName: string) {

    const fileNameWithExtension = fileName + this.fileExtensionService.getExtensionFromDataType(data.type);

    if (navigator && navigator.msSaveOrOpenBlob) {
      // for IE and Edge browsers
      window.navigator.msSaveBlob(data, fileNameWithExtension);
    } else {
      // for chrome and firefox
      const file = new Blob([data], { type: data.type });
      const url = URL.createObjectURL(file);

      const refToFile = document.createElement('a');
      refToFile.href = url;
      refToFile.download = fileNameWithExtension;

      document.body.appendChild(refToFile);
      refToFile.click();

      setTimeout(() => {
          document.body.removeChild(refToFile);
          window.URL.revokeObjectURL(url);
        },
        0);
    }
  }
}
