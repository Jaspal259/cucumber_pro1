import { Injectable } from '@angular/core';
import * as moment from 'moment';

@Injectable()
export class DateTimeService {

  private dateTimeFormat = 'MM/DD/YYYY';
  private monthAndYearFormat = 'MMM YYYY';

  getMonthAndYear(date: number): string {
    if (date == null) {
      return '';
    }
    return moment(this.getTransformedDate(date)).format(this.monthAndYearFormat);
  }

  getMonthAndYearsFromDate(year: number, month: number): string {
    const date = moment(new Date(year, month - 1));
    return date.format(this.monthAndYearFormat);
  }

  getFullMonthAndYear(date: number) {
    if (date == null) {
      return '';
    }
    return moment(this.getTransformedDate(date)).format('MMMM YYYY');
  }

  private getTransformedDate(date: number): Date {
    const delimiter = 100;
    return new Date(Math.floor(date / delimiter), date % delimiter - 1);
  }

  getPreviousMonthAndYear(): string {
    return moment().subtract(1, 'month').format('MMMM YYYY');
  }

  getLocalDate(date: Date): string {
    const localDate = this.getMomentLocalTime(date);
    return localDate.format(this.dateTimeFormat);
  }

  getLocalCurrentDate(): string {
    return moment().format('MMDDYY');
  }

  getLocalTime(date: Date): string {
    const localDate = this.getMomentLocalTime(date);
    return localDate.format('HH:mm');
  }

  private getMomentLocalTime(date: Date): moment.Moment {
    return moment.utc(date).local();
  }
}
