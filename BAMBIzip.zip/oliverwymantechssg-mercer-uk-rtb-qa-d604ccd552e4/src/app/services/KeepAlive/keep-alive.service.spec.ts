import { TestBed, inject } from '@angular/core/testing';

import { KeepAliveService } from './keep-alive.service';

describe('KeepAliveService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [KeepAliveService]
    });
  });

  it('should be created', inject([KeepAliveService], (service: KeepAliveService) => {
    expect<any>(service).toBeTruthy();
  }));
});
