import { TestBed, inject } from '@angular/core/testing';

import { KeepAliveApiService } from './keep-alive-api.service';

describe('KeepAliveApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [KeepAliveApiService]
    });
  });

  it('should be created', inject([KeepAliveApiService], (service: KeepAliveApiService) => {
    expect<any>(service).toBeTruthy();
  }));
});
