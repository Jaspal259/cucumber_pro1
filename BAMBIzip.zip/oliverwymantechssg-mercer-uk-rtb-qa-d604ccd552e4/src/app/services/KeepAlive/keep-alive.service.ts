import { Injectable } from '@angular/core';
import { KeepAliveSettings } from '../../models/keep-alive-settings.model';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { AuthenticateService } from '../authenticate.service';
import { KeepAliveApiService } from './keep-alive-api.service';

@Injectable()
export class KeepAliveService {

  constructor(private keepAliveApiService: KeepAliveApiService,
    private authenticateService: AuthenticateService) { }

  private keepAliveSettings: KeepAliveSettings;

  private async getSettings() {
    if (!this.keepAliveSettings) {
      return await this.keepAliveApiService.getSettings();
    }
    return this.keepAliveSettings;
  }

  public async setup(idle: Idle, keepalive: Keepalive) {
    this.keepAliveSettings = await this.getSettings();

    idle.setIdle(this.keepAliveSettings.idleLogoutTimeoutSeconds);
    idle.setTimeout(this.keepAliveSettings.timeOut);
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onTimeout.subscribe(
      () =>
        this.authenticateService.logout()
    );

    keepalive.interval(this.keepAliveSettings.keepAliveIntervalSeconds);
    keepalive.onPing.subscribe(() =>
      this.keepAliveApiService.ping()
    );

    idle.watch();
  }
}
