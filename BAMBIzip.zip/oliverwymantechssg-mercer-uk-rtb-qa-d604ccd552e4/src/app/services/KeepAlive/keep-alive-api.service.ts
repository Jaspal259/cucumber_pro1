import { Injectable } from '@angular/core';
import { ApiService } from '../api.service';
import { KeepAliveSettings } from '../../models/keep-alive-settings.model';

@Injectable()
export class KeepAliveApiService {
  private readonly path = 'keepAlive';

  constructor(private apiService: ApiService) { }

  async getSettings(): Promise<KeepAliveSettings> {
    return await this.apiService.get<KeepAliveSettings>(`${this.path}/GetSettings`);
  }

  async ping(): Promise<string> {
    return await this.apiService.get<string>(`${this.path}/Ping`);
  }
}
