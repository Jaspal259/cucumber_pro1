import { Injectable } from '@angular/core';
import { ResourceProviderDictionary } from '../models/resources/resource-provider-dictionary';
import { SiteResourcesApiService } from '../views/admin/services/api/site-resources-api.service';
import { ResourceRouteService } from './resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { DownloadFileService } from './download-file/download-file.service';

@Injectable()
export class UserGuideService {
  readonly resources = new ResourceProviderDictionary();

  constructor(private siteResourceService: SiteResourcesApiService,
    resourceRouteService: ResourceRouteService,
    private downloadFileService: DownloadFileService,
    route: ActivatedRoute) {
    this.resources.siteResource = resourceRouteService.getResource(route, 'siteResource');
  }

  async downloadUserGuide() {
    const blob = await this.siteResourceService.getUserGuide();

    this.downloadFileService.triggerFileDownload(blob, this.resources.siteResource.get('user_guide_file_name'));
  }
}
