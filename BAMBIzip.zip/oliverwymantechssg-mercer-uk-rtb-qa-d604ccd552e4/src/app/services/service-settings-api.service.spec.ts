import { TestBed, inject } from '@angular/core/testing';

import { ServerSettingsApiService } from './service-settings-api.service';

describe('ServerSettingsApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ServerSettingsApiService]
    });
  });

  it('should be created', inject([ServerSettingsApiService], (service: ServerSettingsApiService) => {
    expect<any>(service).toBeTruthy();
  }));
});
