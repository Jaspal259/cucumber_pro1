
import { catchError } from 'rxjs/operators';
import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';

import { InternalServerErrorService } from './internal-server-error.service';

/**
 * Intercepts the HTTP responses, and in case that an error/exception is thrown, handles it
 * and extract the relevant information of it.
 */
@Injectable()
export class ErrorInterceptorService implements HttpInterceptor {

  constructor(private injector: Injector) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(catchError(errorResponse => {

      const internalServerErrorService = this.injector.get(InternalServerErrorService);

      if (errorResponse instanceof HttpErrorResponse) {

        const httpErrorResponse: any = new HttpErrorResponse({
          error: errorResponse.error,
          headers: errorResponse.headers,
          status: errorResponse.status,
          statusText: errorResponse.statusText,
          url: errorResponse.url
        });

        internalServerErrorService.handleError(httpErrorResponse);

        return throwError(httpErrorResponse);
      }
      return throwError(errorResponse.message ? errorResponse.message : errorResponse.toString());
    }));
  }
}
