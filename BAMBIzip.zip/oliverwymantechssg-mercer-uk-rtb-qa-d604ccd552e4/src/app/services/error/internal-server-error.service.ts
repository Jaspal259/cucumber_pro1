import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class InternalServerErrorService {

  constructor(private router: Router) { }

  public handleError(error: HttpErrorResponse) {
    if (error.status === 403) {
      this.handleForbiddenError(error);
      return;
    }
    this.handleServerError(error);
  }

  private handleForbiddenError(error: HttpErrorResponse) {
    switch (error.error) {
      case 'report_read_not_allowed':
        this.router.navigateByUrl('/reports');
        return;
      default:
        this.handleServerError(error);
        return;
    }
  }

  private handleServerError(error: HttpErrorResponse) {
    console.log(this.createErrorMessage(error));
    this.router.navigate(['/error', error.status.toString()]);
  }

  private createErrorMessage(errorResponse: HttpErrorResponse) {
    return errorResponse.error ? errorResponse.error : errorResponse.statusText;
  }

}
