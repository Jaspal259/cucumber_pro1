import { TestBed, inject } from '@angular/core/testing';

import { InternalServerErrorService } from './internal-server-error.service';

describe('InternalServerErrorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [InternalServerErrorService]
    });
  });

  it('should be created', inject([InternalServerErrorService], (service: InternalServerErrorService) => {
    expect<any>(service).toBeTruthy();
  }));
});
