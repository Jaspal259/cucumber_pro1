import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArrayHelperService {
  getMaxToTheNearest10(array: number[]): number {
    const max = Math.max(...array);

    return max > 10 ? (Math.ceil(max / 10) * 10) : Math.ceil(max);
  }
}
