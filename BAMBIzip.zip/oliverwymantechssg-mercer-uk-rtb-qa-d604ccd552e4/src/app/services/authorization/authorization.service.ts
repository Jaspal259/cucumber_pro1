import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { AuthorizationApiService } from './authorization-api.service';
import { AuthorizationResource, AuthorizationResources  } from '../../models/authorization-resource.type';

@Injectable()
export class AuthorizationService {
  private permissionsCache: AuthorizationResource[];

  constructor(private authorizationApiService: AuthorizationApiService) { }

  public async accessAllowed(resource: AuthorizationResource) {
    const permissions = await this.getUserPermissions();

    return _.includes(permissions, resource);
  }

  public async getRequestedPermissions(requestedResources: AuthorizationResource[]): Promise<AuthorizationResources> {
    const userPermissions = await this.getUserPermissions();

    const requestedPermissions: AuthorizationResources =
      _.reduce(requestedResources,
        (obj, resource) => {
          obj[resource] = _.includes(userPermissions, resource);
          return obj;
        },
        {});

    return requestedPermissions;
  }

  private async getUserPermissions() {
    if (!this.permissionsCache) {
      this.permissionsCache = await this.authorizationApiService.getUserPermissions();
    }

    return this.permissionsCache;
  }
}
