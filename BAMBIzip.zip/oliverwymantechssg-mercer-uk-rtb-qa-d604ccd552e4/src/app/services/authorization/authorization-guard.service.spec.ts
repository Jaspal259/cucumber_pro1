import { TestBed, inject } from '@angular/core/testing';

import { AuthorizationGuardService } from './authorization-guard.service';

describe('AuthorizationGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthorizationGuardService]
    });
  });

  it('should be created', inject([AuthorizationGuardService], (service: AuthorizationGuardService) => {
    expect<any>(service).toBeTruthy();
  }));
});
