import { Injectable } from '@angular/core';

import { ApiService } from '../api.service';
import { AuthorizationResource } from '../../models/authorization-resource.type';

@Injectable()
export class AuthorizationApiService {
  private readonly path = 'authorizationResources';

  constructor(private apiService: ApiService) { }

  public async getUserPermissions(): Promise<AuthorizationResource[]> {
    return await this.apiService.get<AuthorizationResource[]>(`${this.path}/GetAvailableResources`);
  }
}
