import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';

import { AuthorizationService } from './authorization.service';

@Injectable()
export class AuthorizationGuardService implements CanActivate {
  constructor(private authorizationService: AuthorizationService, private router: Router) { }

  async canActivate(route: ActivatedRouteSnapshot): Promise<boolean> {
    const accessAllowed = await this.authorizationService.accessAllowed(route.data['authorizationResource']);
    if (accessAllowed) {
      return true;
    }

    this.router.navigateByUrl('/error/403');

    return false;
  }
}
