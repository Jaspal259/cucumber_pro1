import { TestBed, inject } from '@angular/core/testing';

import { ResourceRouteService } from './resource-route.service';

describe('ResourceRouteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResourceRouteService]
    });
  });

  it('should be created', inject([ResourceRouteService], (service: ResourceRouteService) => {
    expect<any>(service).toBeTruthy();
  }));
});
