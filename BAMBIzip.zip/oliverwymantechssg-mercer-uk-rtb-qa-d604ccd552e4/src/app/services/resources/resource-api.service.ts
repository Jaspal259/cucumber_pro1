import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ApiService } from '../api.service';
import { KeyValueDictionary } from '../../models/key-value-dictionary.model';

@Injectable()
export class ResourceApiService {
  private readonly path = 'resource';

  constructor(private apiService: ApiService) { }

  async get(name: string): Promise<KeyValueDictionary<string>> {
    const params = new HttpParams().set('id', String(name));
    return await this.apiService.get<KeyValueDictionary<string>>(`${this.path}/GetResources`, params);
  }
}
