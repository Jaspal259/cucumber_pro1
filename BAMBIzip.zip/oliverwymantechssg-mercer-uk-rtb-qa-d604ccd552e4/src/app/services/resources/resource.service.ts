import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { ResourceApiService } from './resource-api.service';
import { ResourceProvider } from './resource-provider';
import { IResourceResolvers } from '../../models/resources/resource-resolvers';

@Injectable()
export class ResourceService {
  private resourceCache: { [index: string]: Promise<ResourceProvider> } = {};

  constructor(private resourceApiService: ResourceApiService) { }

  async makeRequest(name: string): Promise<ResourceProvider> {
    const data = await this.resourceApiService.get(name);

    return new ResourceProvider(data);
  }

  async getResources(name: keyof IResourceResolvers): Promise<ResourceProvider> {
    if (!this.resourceCache[name]) {
      this.resourceCache[name] = this.makeRequest(name);
    }

    return await this.resourceCache[name];
  }
}
