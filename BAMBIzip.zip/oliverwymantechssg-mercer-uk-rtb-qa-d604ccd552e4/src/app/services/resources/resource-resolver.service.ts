import { IResourceResolvers } from '../../models/resources/resource-resolvers';

export function createResourceResolvers(resolvers: IResourceResolvers) {
  return resolvers;
}
