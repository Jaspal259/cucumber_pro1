import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, ActivatedRoute } from '@angular/router';
import { ResourceProvider } from './resource-provider';
import { IResourceResolvers } from '../../models/resources/resource-resolvers';

@Injectable()
export class ResourceRouteService {

  private getSnapshotResource(snapshot: ActivatedRouteSnapshot, key: keyof IResourceResolvers): ResourceProvider {
  const resourceProvider: ResourceProvider = snapshot.data[key];
    if (!resourceProvider) {
      return this.getSnapshotResource(snapshot.parent, key);
    }
    return resourceProvider;
  }

  getResource(route: ActivatedRoute, key: keyof IResourceResolvers): ResourceProvider {
    return this.getSnapshotResource(route.snapshot, key);
  }
}
