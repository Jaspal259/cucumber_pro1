import { KeyValueDictionary } from '../../models/key-value-dictionary.model';
import * as _ from 'lodash';

export class ResourceProvider {
  constructor(
    private resources: KeyValueDictionary<string>
  ) {
  }

  exists(name: string): boolean {
    const text = this.resources[name];

    if (text === undefined) {
      return false;
    }

    return true;
  }

  get(name: string): string {
    if (_.isEmpty(this.resources, true)) {
      return '';
    }

    const text = this.resources[name];

    if (text === undefined) {
      console.log(`Resource not found: ${name}`);
      return '!resource_not_found:' + name;
    }

    return text;
  }
}
