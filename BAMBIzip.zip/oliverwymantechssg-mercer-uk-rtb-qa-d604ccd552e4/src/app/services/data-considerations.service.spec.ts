import { TestBed } from '@angular/core/testing';

import { DataConsiderationsService } from './data-considerations.service';

describe('DataConsiderationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataConsiderationsService = TestBed.get(DataConsiderationsService);
    expect(service).toBeTruthy();
  });
});
