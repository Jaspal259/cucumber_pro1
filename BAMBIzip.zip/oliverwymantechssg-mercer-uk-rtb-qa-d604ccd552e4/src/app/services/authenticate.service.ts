import { Injectable } from '@angular/core';
import { PlatformLocation } from '@angular/common';

@Injectable()
export class AuthenticateService {

  constructor(private platformLocation: PlatformLocation) { }

  logout() {
    const relativeLogoutUrl = 'Account/LogOut';
    const logoutUrl = window.location.origin + this.platformLocation.getBaseHrefFromDOM() + relativeLogoutUrl;
    window.location.replace(logoutUrl);
  }
}
