import { Routes } from '@angular/router';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { ServerErrorComponent } from './views/server-error/server-error.component';
import { reportRoutes} from './views/reports/reports.route';
import { GlobalResourceResolver } from './resolvers/global-resource-resolver';
import { createResourceResolvers } from './services/resources/resource-resolver.service';
import { ReportsComponent } from './views/reports/reports.component';
import { ReportsResourceResolver } from './views/reports/resolvers/reports-resource-resolver';
import { ReportHistoryActionsResourceResolver } from './views/reports/resolvers/report-history-actions-resource-resolver';
import { ReportActionsResourceResolver } from './views/reports/resolvers/report-actions-resource-resolver';
// tslint:disable-next-line: max-line-length
import { EnrollmentsResourceResolver } from './views/reports/plan-details/plan-summary/plan-enrollment/services/enrollments-resource-resolver.service';
import { CostsResourceResolver } from './views/reports/plan-details/plan-summary/plan-costs/services/costs-resource-resolver.service';
import { DashboardResourceResolver } from './views/dashboard/resolvers/dashboard-resource-resolver';
import { MembershipCountResourceResolver } from './views/dashboard/resolvers/membership-count-resource-resolver';
import { LayoutComponent } from './views/layout/layout.component';
import { ServerErrorsResourceResolver } from './views/server-error/resolvers/server-errors-resource-resolver';
import { AuthorizationGuardService } from './services/authorization/authorization-guard.service';
import { HeaderResourceResolver } from './controls/header/resolvers/header-resource-resolver';
import { FooterResourceResolver } from './controls/footer/resolvers/footer-resource-resolver';
import { ActiveEnrollmentResourceResolver } from './views/dashboard/resolvers/active-enrollment-resource-resolver';
import { AcoEnrollmentResourceResolver } from './views/dashboard/resolvers/aco-enrollment-resource-resolver';
import { UserProfileResourceResolver } from './controls/header/resolvers/user-profile-resource-resolver';
// tslint:disable-next-line: max-line-length
import { PlanPoliciesExportResourceResolver } from './views/reports/policy-table/policies-export/services/plan-policies-export-resource-resolver.service';
import { HomeComponent } from './views/home/home.component';
import { HomeResourceResolver } from './views/home/resolvers/home-resource-resolver';
import { OverviewResourceResolver } from './views/home/resolvers/overview-resource-resolver';
import { ActivitiesResourceResolver } from './views/home/resolvers/activities-resource-resolver';
import { WelfareEnrollmentResourceResolver } from './views/dashboard/resolvers/welfare-enrollment-resource-resolver';
import { TotalHealthcareCostsResourceResolver } from './views/dashboard/resolvers/total-healthcare-costs-resource-resolver';
import { AdminComponent } from './views/admin/admin.component';
import { adminChildRoutes } from './views/admin/admin.route';
import { AdminResourceResolver } from './views/admin/resolvers/admin-resource-resolver.service';
import { FileUploadResourceResolver } from './views/admin/resolvers/file-upload-resource-resolver.service';
import { SiteResourceResolver } from './controls/header/resolvers/site-resource-resolver';
import { UserGuideResourceResolver } from './views/admin/resolvers/user-guide-resource-resolver.service';
// tslint:disable-next-line: max-line-length
import { DataConsiderationsResourceResolver } from './views/admin/resolvers/data-considerations-resource-resolver.service';
import { DisclaimerResourceResolver } from './views/home/resolvers/disclaimer-resource-resolver';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    resolve: createResourceResolvers({
      global: GlobalResourceResolver,
      header: HeaderResourceResolver,
      siteResource: SiteResourceResolver,
      footer: FooterResourceResolver,
      userProfile: UserProfileResourceResolver
    }),
    children: [
      {
        path: 'home',
        component: HomeComponent,
        resolve: createResourceResolvers({
          'home.home': HomeResourceResolver,
          'home.overview': OverviewResourceResolver,
          'home.activities': ActivitiesResourceResolver,
          'home.disclaimer': DisclaimerResourceResolver
        }),
        canActivate: [
          AuthorizationGuardService
        ],
        data: { authorizationResource: 'home' }
      },
      {
        path: 'dashboard',
        component: DashboardComponent,
        resolve: createResourceResolvers({
          dashboard: DashboardResourceResolver,
          membershipCount: MembershipCountResourceResolver,
          activeEnrollment: ActiveEnrollmentResourceResolver,
          acoEnrollment: AcoEnrollmentResourceResolver,
          welfareEnrollment: WelfareEnrollmentResourceResolver,
          totalHealthcareCosts: TotalHealthcareCostsResourceResolver
        }),
        canActivate: [
          AuthorizationGuardService
        ],
        data: { authorizationResource: 'dashboard' }
      },
      {
        path: 'reports',
        component: ReportsComponent,
        resolve: createResourceResolvers({
          adHocReports: ReportsResourceResolver,
          adHocReportActions: ReportActionsResourceResolver,
          adHocReportHistoryActions: ReportHistoryActionsResourceResolver,
          enrollments: EnrollmentsResourceResolver,
          costs: CostsResourceResolver,
          planPoliciesExport: PlanPoliciesExportResourceResolver
        }),
        canActivate: [
          AuthorizationGuardService
        ],
        data: { authorizationResource: 'reports' },
        children: reportRoutes
      },
      {
        path: 'admin',
        component: AdminComponent,
        resolve: createResourceResolvers({
          admin: AdminResourceResolver,
          userGuide: UserGuideResourceResolver,
          dataConsiderations: DataConsiderationsResourceResolver,
          fileUpload: FileUploadResourceResolver
        }),
        canActivate: [
          AuthorizationGuardService
        ],
        data: { authorizationResource: 'admin' },
        children: adminChildRoutes
      },
      {
        path: 'error/:code',
        component: ServerErrorComponent,
        resolve: createResourceResolvers({
          serverErrors: ServerErrorsResourceResolver
        })
      },
      { path: '**', redirectTo: 'home' }
    ]
  }
];

