
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { RouterStateSerializer, StoreRouterConnectingModule } from '@ngrx/router-store';
import { environment } from '../environments/environment';
import { reducers, metaReducers } from './reducers';
import { CustomRouterStateSerializer } from './shared/utils';
import { AppComponent } from './app.component';
import { ApiService } from './services/api.service';
import { ResourceService } from './services/resources/resource.service';
import { ResourceApiService } from './services/resources/resource-api.service';
import { ErrorInterceptorService } from './services/error/error-interceptor.service';
import { ServerErrorComponent } from './views/server-error/server-error.component';
import { ResourceRouteService } from './services/resources/resource-route.service';
import { GlobalResourceResolver } from './resolvers/global-resource-resolver';
import { ReportActionsResourceResolver } from './views/reports/resolvers/report-actions-resource-resolver';
import { AuthenticateService } from './services/authenticate.service';
import { KeepAliveApiService } from './services/KeepAlive/keep-alive-api.service';
import { KeepAliveService } from './services/KeepAlive/keep-alive.service';
import { LayoutComponent } from './views/layout/layout.component';
import { ServerErrorsResourceResolver } from './views/server-error/resolvers/server-errors-resource-resolver';
import { AuthorizationGuardService } from './services/authorization/authorization-guard.service';
import { HeaderResourceResolver } from './controls/header/resolvers/header-resource-resolver';
import { FooterResourceResolver } from './controls/footer/resolvers/footer-resource-resolver';
import { ScrollingService } from './services/scrolling.service';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MercerOSModule, MosSVGInlinerService } from 'merceros-ui-components';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HeaderModule } from './controls/header/header.module';
import { FooterModule } from './controls/footer/footer.module';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InfoIconModule } from './controls/info-icon/info-icon.module';
import { IconModule } from './controls/icon/icon.module';
import { MultiselectFilterViewModule } from './controls/readonly-property/readonly-property.module';
import { ModalModule } from './controls/modal/modal.module';
import { StoreModule } from '@ngrx/store';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { SpinnerModule } from './controls/spinner/spinner.module';
import { ReportsModule } from './views/reports/reports.module';
import { DashboardModule } from './views/dashboard/dashboard.module';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { EffectsModule } from '@ngrx/effects';
import { HomeModule } from './views/home/home.module';
import { AdminModule } from './views/admin/admin.module';
import { SiteResourceResolver } from './controls/header/resolvers/site-resource-resolver';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    MercerOSModule.forRoot(),
    CommonModule,
    HeaderModule,
    FooterModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    InfoIconModule,
    IconModule,
    MultiselectFilterViewModule,
    ModalModule,
    AdminModule,
    /**
     * StoreModule.forRoot is imported once in the root module, accepting a reducer
     * function or object map of reducer functions. If passed an object of
     * reducers, combineReducers will be run creating your application
     * meta-reducer. This returns all providers for an @ngrx/store
     * based application.
     */
    StoreModule.forRoot(reducers, { metaReducers }),

    /**
     * @ngrx/router-store keeps router state up-to-date in the store.
     */
    StoreRouterConnectingModule.forRoot({
      /*
        They stateKey defines the name of the state used by the router-store reducer.
        This matches the key defined in the map of reducers
      */
      stateKey: 'router'
    }),

    /**
     * Store devtools instrument the store retaining past versions of state
     * and recalculating new states. This enables powerful time-travel
     * debugging.
     *
     * To use the debugger, install the Redux Devtools extension for either
     * Chrome or Firefox
     *
     * See: https://github.com/zalmoxisus/redux-devtools-extension
     */
    StoreDevtoolsModule.instrument({
      name: 'NgRx Store DevTools',
      logOnly: environment.production
    }),

    /**
     * EffectsModule.forRoot() is imported once in the root module and
     * sets up the effects class to be initialized immediately when the
     * application starts.
     *
     * See: https://github.com/ngrx/platform/blob/master/docs/effects/api.md#forroot
     */
    EffectsModule.forRoot([]),
    /**
     * Service Worker for offline capabilities.
     * See: https://angular.io/guide/service-worker-intro
     */
    // ServiceWorkerModule.register('/Scripts/ClientApp/ngsw-worker.js', { enabled: environment.production }),
    NgIdleKeepaliveModule.forRoot(),
    SpinnerModule,
    ReportsModule,
    DashboardModule,
    HomeModule
  ],
  providers: [
    /**
     * The `RouterStateSnapshot` provided by the `Router` is a large complex structure.
     * A custom RouterStateSerializer is used to parse the `RouterStateSnapshot` provided
     * by `@ngrx/router-store` to include only the desired pieces of the snapshot.
     */
    { provide: RouterStateSerializer, useClass: CustomRouterStateSerializer },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorInterceptorService,
      multi: true
    },
    MosSVGInlinerService,
    ApiService,
    ResourceService,
    ResourceApiService,
    ReportActionsResourceResolver,
    GlobalResourceResolver,
    ServerErrorsResourceResolver,
    ResourceRouteService,
    AuthenticateService,
    KeepAliveApiService,
    KeepAliveService,
    AuthorizationGuardService,
    HeaderResourceResolver,
    SiteResourceResolver,
    FooterResourceResolver,
    ScrollingService
  ],
  declarations: [
    AppComponent,
    ServerErrorComponent,
    LayoutComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(
    private mosSVGInlinerService: MosSVGInlinerService) {
    mosSVGInlinerService.preloadAll();
  }
}
