interface String {
  format(...values: string[]): string;
}

String.prototype.format = function (...values: string[]): string {
  return this.replace(/\{(\d+)\}/g, (m, n) => {
    const argv = values[n];
    return (typeof argv !== 'undefined' && argv !== null) ? argv : m;
  });
};

