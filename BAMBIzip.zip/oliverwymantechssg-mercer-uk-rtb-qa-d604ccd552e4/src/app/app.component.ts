import { Component, OnInit } from '@angular/core';

import { SpinnerSettings } from './controls/spinner/models/spinner-settings';
import { KeepAliveService } from './services/KeepAlive/keep-alive.service';
import { Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { LoadingIndicatorSection } from './controls/spinner/models/loading-indicator-section.type';
import { ScrollingService } from './services/scrolling.service';

@Component({
  selector: 'bam-app',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  loadingSpinnerSettings: SpinnerSettings;
  loadingIndicatorKey: LoadingIndicatorSection;

  constructor(private keepAliveService: KeepAliveService,
    private idle: Idle,
    private keepalive: Keepalive,
    private scrollingService: ScrollingService) {
  }

  ngOnInit() {
    this.loadingIndicatorKey = 'full_page';

    this.loadingSpinnerSettings = {
      fullPageLoader: true
    };

    this.keepAliveService.setup(this.idle, this.keepalive);
    this.scrollingService.scrollToTopOfPage();
  }
}
