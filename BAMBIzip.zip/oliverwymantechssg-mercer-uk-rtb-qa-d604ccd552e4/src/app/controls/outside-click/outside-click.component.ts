import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'bam-outside-click',
  templateUrl: './outside-click.component.html'
})
export class OutsideClickComponent implements OnInit {

  constructor() { }
  @Output() bamOutsideClick = new EventEmitter<any>();
  ngOnInit() {
  }

  clickOutside() {
    this.bamOutsideClick.emit();
  }

}
