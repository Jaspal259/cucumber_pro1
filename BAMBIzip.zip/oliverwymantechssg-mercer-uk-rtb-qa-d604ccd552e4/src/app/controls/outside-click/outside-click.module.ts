import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClickOutsideModule } from 'ng-click-outside';
import { OutsideClickComponent } from './outside-click.component';
@NgModule({
  imports: [
    CommonModule,
    ClickOutsideModule
  ],
  declarations: [OutsideClickComponent],
  exports: [
    OutsideClickComponent
  ]
})
export class OutsideClickModule { }
