import { Component, OnInit, Input, ViewChild } from '@angular/core';
import {AlertComponent} from '../alert/alert.component';

@Component({
  selector: 'bam-warning-alert',
  templateUrl: './warning-alert.component.html'
})
export class WarningAlertComponent implements OnInit {
  @ViewChild(AlertComponent) alert;

  constructor() { }

  ngOnInit() {
  }

  open(message: string) {
    this.alert.open(message);
  }
}
