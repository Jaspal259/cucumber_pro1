import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { AlertComponent } from '../alert/alert.component';

@Component({
  selector: 'bam-error-alert',
  templateUrl: './error-alert.component.html'
})
export class ErrorAlertComponent implements OnInit {
  @ViewChild(AlertComponent) alert;

  constructor() { }

  ngOnInit() {
  }

  open(message: string) {
    this.alert.open(message);
  }
}
