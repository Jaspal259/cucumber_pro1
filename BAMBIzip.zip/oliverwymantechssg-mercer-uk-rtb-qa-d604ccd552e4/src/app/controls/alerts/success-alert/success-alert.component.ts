import { Component, OnInit, Input, ViewChild } from '@angular/core';
import {AlertComponent} from '../alert/alert.component';

@Component({
  selector: 'bam-success-alert',
  templateUrl: './success-alert.component.html'
})
export class SuccessAlertComponent implements OnInit {
  @ViewChild(AlertComponent) alert;

  constructor() { }

  ngOnInit() {
  }

  open(message: string) {
    this.alert.open(message);
  }
}
