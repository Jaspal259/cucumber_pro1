import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MosToastComponent } from 'merceros-ui-components';

@Component({
  selector: 'bam-alert',
  templateUrl: './alert.component.html'
})
export class AlertComponent implements OnInit {
  @ViewChild(MosToastComponent) mercerToast;
  @Input() theme: string;
  @Input() icon: string;
  @Input() iconTheme: string;
  message: string;

  ngOnInit() {
  }

  open(message: string) {
    this.message = message;
    this.mercerToast.open();
  }
}
