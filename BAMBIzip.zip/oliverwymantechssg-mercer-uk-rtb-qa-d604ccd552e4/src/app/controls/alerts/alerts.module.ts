import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertComponent } from './alert/alert.component';
import { ErrorAlertComponent } from './error-alert/error-alert.component';
import { SuccessAlertComponent } from './success-alert/success-alert.component';
import { WarningAlertComponent } from './warning-alert/warning-alert.component';
import { MercerOSModule } from 'merceros-ui-components';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule
  ],
  declarations: [
    AlertComponent,
    ErrorAlertComponent,
    SuccessAlertComponent,
    WarningAlertComponent
  ],
  exports: [
    ErrorAlertComponent,
    SuccessAlertComponent,
    WarningAlertComponent
  ]
})
export class AlertsModule { }
