import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MosModalComponent } from 'merceros-ui-components';

@Component({
  selector: 'bam-modal',
  templateUrl: './modal.component.html'
})
export class ModalComponent implements OnInit {
  @ViewChild(MosModalComponent) mercerModal: MosModalComponent;
  @Input() header: string;
  @Input() text: string;

  constructor() {
  }

  ngOnInit() {
  }

  open() {
    this.mercerModal.open();
  }

  close() {
    this.mercerModal.close();
  }
}
