import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadonlyPropertyComponent } from './readonly-property.component';

describe('ReadonlyPropertyComponent', () => {
  let component: ReadonlyPropertyComponent;
  let fixture: ComponentFixture<ReadonlyPropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReadonlyPropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadonlyPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
