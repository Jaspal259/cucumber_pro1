import { Component, OnInit, Input } from '@angular/core';
import { ReadonlyPropertySettings } from '../../views/reports/report-filter/report-filter-view/models/readonly-property-settings.model';

@Component({
  selector: 'bam-readonly-property',
  templateUrl: './readonly-property.component.html',
  styleUrls: ['./readonly-property.component.scss']
})
export class ReadonlyPropertyComponent implements OnInit {
  @Input() filterSettings: ReadonlyPropertySettings;

  getValuesAsString = (values: string[]) => {
    return values.join(', ');
  }

  ngOnInit() {
  }

}
