import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReadonlyPropertyComponent } from './readonly-property.component';
import { InfoIconModule } from '../info-icon/info-icon.module';

@NgModule({
  imports: [
    CommonModule,
    InfoIconModule
  ],
  declarations: [
    ReadonlyPropertyComponent
  ],
  exports: [
    ReadonlyPropertyComponent
  ]
})
export class MultiselectFilterViewModule { }
