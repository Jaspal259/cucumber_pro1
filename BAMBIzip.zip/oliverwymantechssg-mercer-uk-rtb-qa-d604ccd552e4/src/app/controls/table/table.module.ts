import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableComponent } from './table.component';
import { TableRowsService } from '../../views/reports/plan-details/plan-summary/services/table-rows.service';
import { ColumnVisibilityService } from '../../views/reports/plan-details/plan-summary/table-build/column-visibility.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [TableComponent],
  exports: [TableComponent],
  providers: [
    TableRowsService,
    ColumnVisibilityService
    ]
})
export class TableModule { }
