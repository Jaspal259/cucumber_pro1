import { Component, OnInit } from '@angular/core';
import { ColumnVisibilityService } from '../../views/reports/plan-details/plan-summary/table-build/column-visibility.service';
import { TableRowsService } from '../../views/reports/plan-details/plan-summary/services/table-rows.service';
import { Input } from '@angular/core';
import { TableHeader } from '../../views/reports/plan-details/plan-summary/table-build/models/table-header';
import { TableRowValue } from '../../views/reports/plan-details/plan-summary/table-build/models/table-row-value.model';
import { Table } from './models/table.model';

@Component({
  selector: 'bam-table',
  exportAs: 'bamTable',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent<T> implements OnInit {

  constructor(private columnVisibilityService: ColumnVisibilityService<T>,
    private tableRowsService: TableRowsService<T>) {
  }

  @Input() table: Table<T>;
  formattedRows: TableRowValue<T>[];
  headerData: TableHeader<T>[];

  ngOnInit() {
    this.headerData = this.columnVisibilityService.getVisibleHeaders(this.table.headers, this.table.visibleColumns);
    this.formattedRows = this.tableRowsService.getFormattedRows(this.table.columns, this.table.rows);
  }

}
