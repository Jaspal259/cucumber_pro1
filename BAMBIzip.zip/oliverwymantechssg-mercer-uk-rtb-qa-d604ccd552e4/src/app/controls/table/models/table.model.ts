import { TableHeader } from '../../../views/reports/plan-details/plan-summary/table-build/models/table-header';
import { Columns } from '../../../views/reports/plan-details/plan-summary/models/columns.model';
import { StringKeys } from '../../../models/string-keys.type';

export interface Table<T> {
    columns: Columns<T>[];
    headers: TableHeader<T>[];
    rows: T[];
    visibleColumns: StringKeys<T>[];
    class: string;
  }
