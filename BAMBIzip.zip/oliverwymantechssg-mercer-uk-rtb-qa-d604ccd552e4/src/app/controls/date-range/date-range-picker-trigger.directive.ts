
import {Subscription ,  Observable } from 'rxjs';
import { merge , of } from 'rxjs';

import {
  AfterContentInit,
  ChangeDetectorRef,
  Directive,
  HostBinding,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges
} from '@angular/core';
import { OwlDateTimeComponent } from 'ng-pick-datetime';

@Directive({
  selector: '[bamOwlDateTimeTrigger]',
})
export class OwlDateTimeTriggerDirective<T> implements OnInit, OnChanges, AfterContentInit, OnDestroy {

  // tslint:disable-next-line: no-input-rename
  @Input('bamOwlDateTimeTrigger') bamOwlDateTimeTrigger: OwlDateTimeComponent<T>;

  private _disabled: boolean;
  @Input()
  get disabled(): boolean {
    return this._disabled === undefined ? this.bamOwlDateTimeTrigger.disabled : !!this._disabled;
  }

  set disabled(value: boolean) {
    this._disabled = value;
  }

  @HostBinding('class.owl-dt-trigger-disabled')
  get owlDTTriggerDisabledClass(): boolean {
    return this.disabled;
  }

  private stateChanges = Subscription.EMPTY;

  constructor(protected changeDetector: ChangeDetectorRef) {
  }

  public ngOnInit(): void {
  }

  public ngOnChanges(changes: SimpleChanges) {
    if (changes.datepicker) {
      this.watchStateChanges();
    }
  }

  public ngAfterContentInit() {
    this.watchStateChanges();
  }

  public ngOnDestroy(): void {
    this.stateChanges.unsubscribe();
  }

  @HostListener('click', ['$event'])
  public handleClickOnHost(event: Event): void {
    if (this.bamOwlDateTimeTrigger) {
      this.bamOwlDateTimeTrigger.open();
    }
  }

  private watchStateChanges(): void {
    this.stateChanges.unsubscribe();

    const inputDisabled = this.bamOwlDateTimeTrigger && this.bamOwlDateTimeTrigger.dtInput ?
      this.bamOwlDateTimeTrigger.dtInput.disabledChange : of();

    const pickerDisabled = this.bamOwlDateTimeTrigger ?
      this.bamOwlDateTimeTrigger.disabledChange : of();

    this.stateChanges = merge(pickerDisabled, inputDisabled)
      .subscribe(() => {
        this.changeDetector.markForCheck();
      });
  }
}
