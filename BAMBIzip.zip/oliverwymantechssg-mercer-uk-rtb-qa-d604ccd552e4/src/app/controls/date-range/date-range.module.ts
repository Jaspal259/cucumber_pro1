import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';

import { DateRangeComponent } from './date-range.component';
import { OwlDateTimeTriggerDirective } from './date-range-picker-trigger.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule
  ],
  declarations: [DateRangeComponent, OwlDateTimeTriggerDirective],
  exports: [DateRangeComponent]
})
export class DateRangeModule { }
