import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';

import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';

export const nativeFormats = {
  datePickerInput: { year: 'numeric', month: '2-digit', day: '2-digit' },
  monthYearLabel: { year: 'numeric', month: 'short' }
};

@Component({
  selector: 'bam-date-range',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [
    { provide: OWL_DATE_TIME_FORMATS, useValue: nativeFormats }
  ]
})
export class DateRangeComponent implements OnInit {
  @ViewChild('date') dateRangeControl;

  @Output() invalidDateChange = new EventEmitter();
  @Output() dateRangeChange = new EventEmitter();
  readonly resources = new ResourceProviderDictionary();
  dateRangeValue: Date[];

  constructor(activatedRoute: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
      this.resources.global = resourceRouteService.getResource(activatedRoute, 'global');
  }

  ngOnInit() {

  }

  onDateInput() {
    this.updateDateValidity();
  }

  onAfterPickerClosed() {
    this.updateDateValidity();
  }

  private updateDateValidity() {
    this.invalidDateChange.emit(this.dateRangeControl.invalid);
  }

  @Input()
  get dateRange(): Date[] {
    return this.dateRangeValue;
  }

  set dateRange(value: Date[]) {
    this.dateRangeValue = value;
    this.dateRangeChange.emit(this.dateRangeValue);
  }

  isInvalidDate(date): boolean {
    return date.invalid && date.errors.owlDateTimeRange;
  }
}
