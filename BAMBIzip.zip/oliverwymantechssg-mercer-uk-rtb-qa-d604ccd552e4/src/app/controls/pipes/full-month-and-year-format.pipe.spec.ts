import { FullMonthAndYearFormatPipe } from './full-month-and-year-format.pipe';
import { inject } from '@angular/core/testing';

describe('FullMonthAndYearFormatPipe', () => {
  it('create an instance', inject([FullMonthAndYearFormatPipe], (pipe: FullMonthAndYearFormatPipe) => {
    expect<any>(pipe).toBeTruthy();
}));
});
