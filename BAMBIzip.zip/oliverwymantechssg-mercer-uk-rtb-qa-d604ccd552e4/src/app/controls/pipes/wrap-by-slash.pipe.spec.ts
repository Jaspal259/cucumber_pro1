import { WrapBySlashPipe } from './wrap-by-slash.pipe';

fdescribe('WrapBySlashPipe', () => {
  it('create an instance', () => {
    const pipe = new WrapBySlashPipe();
    expect<any>(pipe).toBeTruthy();
  });

  it('transform a string without whitespace after slash', () => {
    const inputString = 'abc/def/geh';

    const pipe = new WrapBySlashPipe();
    const expected = 'abc/ def/ geh';
    expect<any>(pipe.transform(inputString)).toBe(expected);
  });

  it('transform a string with whitespace after slash', () => {
    const inputString = 'abc/ def/ geh';

    const pipe = new WrapBySlashPipe();
    expect<any>(pipe.transform(inputString)).toBe(inputString);
  });
});
