import { DateFormatPipe } from './date-format.pipe';
import { inject } from '@angular/core/testing';

describe('DateFormatPipe', () => {
  it('create an instance', inject([DateFormatPipe], (pipe: DateFormatPipe) => {
    expect<any>(pipe).toBeTruthy();
  }));
});
