import { ValueOrNaPipe } from './value-or-na.pipe';

describe('ValueOrNaPipe', () => {
  it('create an instance', () => {
    const pipe = new ValueOrNaPipe();
    expect<any>(pipe).toBeTruthy();
  });
});
