import { PercentFormatPipe } from './percent-format.pipe';
import { inject } from '@angular/core/testing';

describe('PercentFormatPipe', () => {
  it('create an instance', inject([PercentFormatPipe], (pipe: PercentFormatPipe) => {
    expect<any>(pipe).toBeTruthy();
  }));
});
