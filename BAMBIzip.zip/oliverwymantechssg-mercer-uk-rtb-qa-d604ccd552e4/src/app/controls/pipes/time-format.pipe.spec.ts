import { TimeFormatPipe } from './time-format.pipe';
import { inject } from '@angular/core/testing';

describe('TimeFormatPipe', () => {
  it('create an instance', inject([TimeFormatPipe], (pipe: TimeFormatPipe) => {
    expect<any>(pipe).toBeTruthy();
  }));
});
