import { ValuesOrAllPipe } from './values-or-all.pipe';

fdescribe('ValuesOrAllPipe', () => {
  it('create an instance', () => {
    const pipe = new ValuesOrAllPipe();
    expect<any>(pipe).toBeTruthy();
  });
});
