import { Pipe, PipeTransform } from '@angular/core';
import { DateTimeService } from '../../services/date-time.service';

@Pipe({
  name: 'fullMonthAndYearFormat'
})
export class FullMonthAndYearFormatPipe implements PipeTransform {
  constructor(private dateTimeService: DateTimeService) { }

  transform(value: number, args?: any): string {
    return this.dateTimeService.getFullMonthAndYear(value);
  }
}
