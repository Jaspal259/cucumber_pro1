import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'valueOrDashFormat'
})
export class ValueOrDashFormatPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return value ? value : '-';
  }
}
