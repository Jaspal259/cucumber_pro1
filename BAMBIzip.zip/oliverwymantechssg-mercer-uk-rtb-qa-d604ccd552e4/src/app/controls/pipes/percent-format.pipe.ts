import { Pipe, PipeTransform } from '@angular/core';
import { PercentPipe } from '@angular/common';

@Pipe({
  name: 'percentFormat'
})
export class PercentFormatPipe extends PercentPipe implements PipeTransform {

  transform(value: any, args?: any): string {
    return super.transform(value, '0.1-1');
  }
}
