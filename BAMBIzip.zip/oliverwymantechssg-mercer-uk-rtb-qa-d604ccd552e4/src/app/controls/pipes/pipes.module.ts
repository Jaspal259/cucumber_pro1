import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateFormatPipe } from './date-format.pipe';
import { TimeFormatPipe } from './time-format.pipe';
import { PercentFormatPipe } from './percent-format.pipe';
import { ValueOrDashFormatPipe } from './value-or-dash-format.pipe';
import { ValueOrNaPipe } from './value-or-na.pipe';
import { ValuesOrAllPipe } from './values-or-all.pipe';
import { WrapBySlashPipe } from './wrap-by-slash.pipe';
import { FullMonthAndYearFormatPipe } from './full-month-and-year-format.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DateFormatPipe,
    TimeFormatPipe,
    PercentFormatPipe,
    ValueOrDashFormatPipe,
    ValueOrNaPipe,
    ValuesOrAllPipe,
    WrapBySlashPipe,
    FullMonthAndYearFormatPipe
  ],
  exports: [
    DateFormatPipe,
    TimeFormatPipe,
    PercentFormatPipe,
    ValueOrDashFormatPipe,
    ValuesOrAllPipe,
    WrapBySlashPipe,
    FullMonthAndYearFormatPipe
  ]
})
export class PipesModule { }
