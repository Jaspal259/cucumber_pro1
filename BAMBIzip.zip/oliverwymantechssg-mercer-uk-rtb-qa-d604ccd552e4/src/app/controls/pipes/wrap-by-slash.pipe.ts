import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';

@Pipe({
  name: 'wrapBySlash'
})
export class WrapBySlashPipe implements PipeTransform {

  transform(value: string): any {
    const pattern = /\/([^ ])/g;
    return value.replace(pattern, '/ $1');
  }
}
