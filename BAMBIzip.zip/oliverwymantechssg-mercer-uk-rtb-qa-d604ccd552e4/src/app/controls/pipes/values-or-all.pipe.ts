import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash';

import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';

@Pipe({
  name: 'valuesOrAll'
})
export class ValuesOrAllPipe implements PipeTransform {

  transform(values: any[], resources: ResourceProviderDictionary): any[] {
    const all = resources.adHocReports.get('all_filter_items').toUpperCase();
    return values.length > 0 ? _.slice(values) : [all];
  }
}
