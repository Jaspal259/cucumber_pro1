import { ValueOrDashFormatPipe } from './value-or-dash-format.pipe';

describe('ValueOrDashFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new ValueOrDashFormatPipe();
    expect<any>(pipe).toBeTruthy();
  });
});
