import { Pipe, PipeTransform } from '@angular/core';
import { DateTimeService } from '../../services/date-time.service';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe implements PipeTransform {
  constructor(private dateTimeService: DateTimeService) {

  }
  transform(value: Date, args?: any): string {
    return this.dateTimeService.getLocalDate(value);
  }

}
