import { Component, OnChanges, Input, ViewChild, ChangeDetectionStrategy, ViewEncapsulation } from '@angular/core';
import { MosFileDropzoneComponent, UploadStateEnum } from 'merceros-ui-components';
import { MosFileDropzoneResult } from 'merceros-ui-components/lib/components/form-controls/file-dropzone/file-dropzone.component';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { SuccessAlertComponent } from '../alerts/success-alert/success-alert.component';
import { UploadSettings } from '../../views/admin/models/upload-setting.model';

@Component({
  selector: 'bam-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class FileUploadComponent implements OnChanges {
  @ViewChild(SuccessAlertComponent) successAlert: SuccessAlertComponent;
  @ViewChild(MosFileDropzoneComponent) public dropzone: MosFileDropzoneComponent;
  @Input() uploadSettings: UploadSettings;
  @Output() public fileSelected = new EventEmitter();

  readonly resources = new ResourceProviderDictionary();
  uploadData = [];
  customUploadMessages: string[];

  constructor(private resourceRouteService: ResourceRouteService,
    private route: ActivatedRoute) {
    this.resources.fileUpload = resourceRouteService.getResource(route, 'fileUpload');
    this.resources.admin = resourceRouteService.getResource(route, 'admin');
    this.setDefaultUploadMessages();
  }

  public ngOnChanges() {
    this.filesSelected(this.uploadData);
  }

  get uploadSuccess(): boolean {
    return this.dropzone.uploadState === UploadStateEnum.UploadSuccess;
  }

  private checkUploadingStatus() {
    if (this.uploadSuccess) {
      this.dropzone.setMultiFileStaging();
    }
  }

  public filesSelected(files: MosFileDropzoneResult[]) {
    if (!files.length) {
      return;
    }
    this.fileSelected.emit(null);
    const file = files[0];
    this.uploadData.push(file);

    this.runValidation(file);
    this.checkUploadingStatus();
  }

  get empty() {
    return this.uploadData.length === 0 && this.dropzone.uploadState === UploadStateEnum.Empty;
  }

  public cancel() {
    if (this.empty) {
      return;
    }

    this.clearFiles();
    this.setDefaultUploadMessages();
  }

  private runValidation(file: MosFileDropzoneResult) {
    if (file.file.size >= this.uploadSettings.limitations.maxSizeInBytes) {
      this.setUploadFailure(this.resources.fileUpload.get('max_file_upload_size_error_message'));
      return;
    }

    if (file.file.size <= 0) {
      this.setUploadFailure(this.resources.fileUpload.get('empty_file_upload_error_message'));
      return;
    }

    if (this.uploadSettings.limitations.formats.indexOf(file.type) < 0) {
      this.setUploadFailure(this.resources.fileUpload.get('wrong_file_type_error_message'));
      return;
    }
  }

  private clearFiles() {
    this.dropzone.clearAllFiles();
    this.uploadData = [];
  }

  public setUploadSuccess() {
    this.dropzone.setUploadSuccess();
    this.customUploadMessages[4] = this.resources.fileUpload.get('_file_success_message');
    this.successAlert.alert.open(this.resources.fileUpload.get('upload_file_success_message'));
  }

  private setUploadFailure(error: string) {
    this.dropzone.setUploadFailure();
    this.customUploadMessages[4] = error;
    this.uploadData = [];
  }

  private setDefaultUploadMessages() {
    this.customUploadMessages = [
      this.resources.fileUpload.get('upload_file_invitation_message'),
      '',
      '',
      this.resources.fileUpload.get('upload_file_success_message'),
      this.resources.fileUpload.get('upload_file_try_again_message')
    ];
  }

  get uploadIsNotAllowed(): boolean {
    return this.dropzone.uploadState === UploadStateEnum.UploadFailure
      || this.dropzone.uploadState === UploadStateEnum.UploadSuccess
      || this.dropzone.uploadState === UploadStateEnum.Empty;
  }

  get cancelIsNotAllowed(): boolean {
      return this.dropzone.uploadState === UploadStateEnum.Empty;
  }
}
