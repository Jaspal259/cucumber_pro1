import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';
import { FileUploadComponent } from './file-upload.component';
import { AlertsModule } from '../alerts/alerts.module';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    AlertsModule
  ],
  declarations: [FileUploadComponent],
  exports: [FileUploadComponent]
})
export class FileUploadModule { }
