import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RequestFileUploadComponent } from './request-file-upload.component';

describe('RequestFileUploadComponent', () => {
  let component: RequestFileUploadComponent;
  let fixture: ComponentFixture<RequestFileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestFileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
