import { Component, ViewChild, EventEmitter, Input, Output, ChangeDetectionStrategy } from '@angular/core';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { AdminApiService } from '../../views/admin/services/api/admin-api.service';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { UploadSettings } from '../../views/admin/models/upload-setting.model';

@Component({
  selector: 'bam-request-file-upload',
  templateUrl: './request-file-upload.component.html'
})
export class RequestFileUploadComponent {
  @ViewChild(FileUploadComponent) public fileUpload: FileUploadComponent;
  @Input() uploadSettings: UploadSettings;
  private uploadingIsInProgress = false;
  readonly resources = new ResourceProviderDictionary();
  helperText: string;
  @Output() public uploadFile = new EventEmitter();

  constructor(private resourceRouteService: ResourceRouteService,
    private adminApiService: AdminApiService,
    private route: ActivatedRoute) {
    this.resources.fileUpload = resourceRouteService.getResource(route, 'fileUpload');
  }

  get disableUploadButton(): boolean {
    return this.uploadingIsInProgress || this.fileUpload.uploadIsNotAllowed;
  }

  get disableCancelButton(): boolean {
    return this.fileUpload.cancelIsNotAllowed;
  }

  upload() {
    if (this.uploadingIsInProgress || this.fileUpload.uploadIsNotAllowed) {
      return;
    }
    this.uploadingIsInProgress = true;
    this.uploadFile.emit(this.fileUpload.uploadData[0]);
    this.uploadingIsInProgress = false;
    this.fileUpload.setUploadSuccess();
  }

  clear() {
    if (this.disableCancelButton) {
      return;
    }
    this.fileUpload.cancel();
  }
}
