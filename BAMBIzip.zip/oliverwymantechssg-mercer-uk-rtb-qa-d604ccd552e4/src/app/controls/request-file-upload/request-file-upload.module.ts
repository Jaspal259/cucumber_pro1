import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminApiService } from '../../views/admin/services/api/admin-api.service';
import { FileUploadModule } from '../file-upload/file-upload.module';
import { RequestFileUploadComponent } from './request-file-upload.component';
import { ButtonModule } from '../button/button.module';

@NgModule({
  imports: [
    CommonModule,
    FileUploadModule,
    ButtonModule
  ],
  providers: [AdminApiService],
  declarations: [RequestFileUploadComponent],
  exports: [RequestFileUploadComponent]
})
export class RequestFileUploadModule { }
