import { Injectable } from '@angular/core';
import { PaginationInfo } from 'merceros-ui-components';

@Injectable()
export class PaginationService {
  private readonly defaultPaginationInfo: PaginationInfo = {
    totalCount: 0,
    offset: 0,
    limit: 20,
    limits: [20, 40, 60]
  };

  getDefaultPaginationInfo(): PaginationInfo {
    return this.defaultPaginationInfo;
  }
}
