import { Component, Input, OnInit } from '@angular/core';
import { PaginationSettings } from './pagination-settings';

@Component({
  selector: 'bam-pagination',
  templateUrl: './pagination.component.html'
})
export class PaginationComponent implements OnInit {
  @Input() paginationSettings: PaginationSettings;

  ngOnInit() {
  }
}
