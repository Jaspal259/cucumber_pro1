import { PaginationInfo } from 'merceros-ui-components';

export interface PaginationSettings {
  paginationInfoRequest: Function;
  paginationInfo: PaginationInfo;
  showLimitOptions: boolean;
  showItemInfo: boolean;
}
