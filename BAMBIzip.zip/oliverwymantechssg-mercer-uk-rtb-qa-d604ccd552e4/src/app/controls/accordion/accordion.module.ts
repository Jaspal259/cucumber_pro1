import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionComponent } from './accordion.component';
import { MercerOSModule } from 'merceros-ui-components';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule
  ],
  declarations: [
    AccordionComponent
  ],
  exports: [
    AccordionComponent
  ]
})
export class AccordionModule { }
