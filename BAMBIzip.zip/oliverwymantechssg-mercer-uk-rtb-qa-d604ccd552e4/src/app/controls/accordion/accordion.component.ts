import { Component, OnInit, Input, TemplateRef, ViewChild } from '@angular/core';
import { MosAccordionComponent } from 'merceros-ui-components';

@Component({
  selector: 'bam-accordion',
  templateUrl: './accordion.component.html'
})
export class AccordionComponent implements OnInit {
  @ViewChild(MosAccordionComponent) mercerAccordion: MosAccordionComponent;
  @Input() accordionStaticTemplate: TemplateRef<any>;
  @Input() accordionExpandedTemplate: TemplateRef<any>;

  public get expanded() {
    return this.mercerAccordion.expanded;
  }

  ngOnInit() {
  }
}
