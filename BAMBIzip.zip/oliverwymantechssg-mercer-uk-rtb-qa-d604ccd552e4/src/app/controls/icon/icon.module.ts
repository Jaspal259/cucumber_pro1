import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from './icon.component';
import { MercerOSModule } from 'merceros-ui-components';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule
  ],
  declarations: [IconComponent],
  exports: [IconComponent]
})
export class IconModule { }
