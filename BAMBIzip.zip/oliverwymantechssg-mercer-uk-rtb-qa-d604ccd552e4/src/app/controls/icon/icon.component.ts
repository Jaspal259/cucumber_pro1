import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-icon',
  templateUrl: './icon.component.html',
  host: {'class': 'bam-icon'}
})
export class IconComponent implements OnInit {

  @Input() icon: string;
  @Input() size = 'md';

  constructor() { }

  ngOnInit() {
  }

}
