import { Component, Input, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { Options, ChartObject } from 'highcharts';

import { PieChartService } from './services/pie-chart.service';
import { DrillBreadcrumbsService } from './drill-breadcrumbs/services/drill-breadcrumbs.service';
import { Subscription } from 'rxjs';
import { PieChartSettings } from './models/pie-chart-settings.model';
import { SimpleChanges } from '@angular/core';

@Component({
  selector: 'bam-pie-chart',
  templateUrl: './pie-chart.component.html',
  providers: [DrillBreadcrumbsService]
})
export class PieChartComponent implements OnInit, OnDestroy, OnChanges {
  @Input() settings: PieChartSettings;

  chartOptions: Options;
  chart: ChartObject;
  drillUpSubscription: Subscription;

  constructor(private pieChartService: PieChartService,
    private drillBreadcrumbsService: DrillBreadcrumbsService) {
  }

  private setChartOptions() {
    this.chartOptions = this.pieChartService.getChartOptions(this.settings.chartModel);
  }

  ngOnInit() {
    this.setChartOptions();
    this.drillUpSubscription = this.drillBreadcrumbsService.subscribeToChartDrillUp((levels: number) => {
      this.drillUp(levels);
    });
  }

  ngOnDestroy() {
    this.drillUpSubscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.setChartOptions();
  }

  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }

  drillDown(event) {
    if (event.originalEvent.seriesOptions.data.length > 1) {
      this.drillBreadcrumbsService.triggerDrillDown();
    }
  }

  private drillUp(levels: number) {
    for (let i = 0; i < levels; i++) {
      this.chart.drillUp();
    }
  }
}
