import { Component, OnInit, OnDestroy } from '@angular/core';
import { Input } from '@angular/core';
import { DrillLevel } from '../../models/drill-level.model';
import { DrillBreadcrumbsService } from './services/drill-breadcrumbs.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'bam-drill-breadcrumbs',
  templateUrl: './drill-breadcrumbs.component.html',
  styleUrls: ['./drill-breadcrumbs.component.scss']
})
export class DrillBreadcrumbsComponent implements OnInit, OnDestroy {
  @Input() drillLevels: DrillLevel[];

  chartOptions: Highcharts.Options;
  chart: Highcharts.ChartObject;
  currentDrillLevel: number;
  drillDownSubscription: Subscription;

  constructor(private drillBreadcrumbsService: DrillBreadcrumbsService) {
  }

  ngOnInit() {
    this.currentDrillLevel = 0;
    this.drillDownSubscription = this.drillBreadcrumbsService.subscribeToChartDrillDown(() => {
      this.currentDrillLevel++;
    });
  }

  ngOnDestroy() {
    this.drillDownSubscription.unsubscribe();
  }

  navigateToLevel(level: number) {
    this.drillBreadcrumbsService.triggerDrillUp(this.currentDrillLevel - level);
    this.currentDrillLevel = level;
  }

  backLinkState(level) {
    return this.currentDrillLevel > level;
  }

  currentNavigationState(level) {
    return this.currentDrillLevel === level;
  }

  showNavigation(level) {
    return level !== 0 && level !== (this.drillLevels.length - 1) && this.currentDrillLevel >= level;
  }
}
