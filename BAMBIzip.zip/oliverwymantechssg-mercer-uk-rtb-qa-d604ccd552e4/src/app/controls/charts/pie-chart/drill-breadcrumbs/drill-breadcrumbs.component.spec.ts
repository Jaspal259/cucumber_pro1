import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrillBreadcrumbsComponent } from './drill-breadcrumbs.component';

describe('DrillBreadcrumbsComponent', () => {
  let component: DrillBreadcrumbsComponent;
  let fixture: ComponentFixture<DrillBreadcrumbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DrillBreadcrumbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrillBreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
