import { Injectable } from '@angular/core';
import { Subscription ,  Subject } from 'rxjs';

@Injectable()
export class DrillBreadcrumbsService {
  private chartDrilledDownSubject = new Subject<string>();
  private chartDrilledDown$ = this.chartDrilledDownSubject.asObservable();
  private chartDrilledUpSubject = new Subject<string>();
  private chartDrilledUp$ = this.chartDrilledUpSubject.asObservable();

  subscribeToChartDrillDown(subscriptionCallback: () => void): Subscription {
    return this.chartDrilledDown$.subscribe(() => {
      subscriptionCallback();
    });
  }

  subscribeToChartDrillUp(subscriptionCallback: (levels: number) => void): Subscription {
    return this.chartDrilledUp$.subscribe((levels: string) => {
      const levelNumber = Number(levels);
      subscriptionCallback(levelNumber);
    });
  }

  triggerDrillDown() {
    this.chartDrilledDownSubject.next();
  }

  triggerDrillUp(levels: number) {
    this.chartDrilledUpSubject.next(levels.toString());
  }
}
