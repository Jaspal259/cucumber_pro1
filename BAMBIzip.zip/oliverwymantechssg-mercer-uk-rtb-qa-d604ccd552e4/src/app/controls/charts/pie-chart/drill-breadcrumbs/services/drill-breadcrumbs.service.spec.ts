import { TestBed, inject } from '@angular/core/testing';

import { DrillBreadcrumbsService } from './drill-breadcrumbs.service';

describe('DrillBreadcrumsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DrillBreadcrumbsService]
    });
  });

  it('should be created', inject([DrillBreadcrumbsService], (service: DrillBreadcrumbsService) => {
    expect<any>(service).toBeTruthy();
  }));
});
