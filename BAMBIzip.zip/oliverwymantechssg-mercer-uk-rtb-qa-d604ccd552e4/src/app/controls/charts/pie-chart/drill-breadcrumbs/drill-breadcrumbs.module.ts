import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DrillBreadcrumbsComponent } from './drill-breadcrumbs.component';
import { IconModule } from '../../../icon/icon.module';

@NgModule({
  imports: [
    CommonModule,
    IconModule
  ],
  declarations: [DrillBreadcrumbsComponent],
  exports: [DrillBreadcrumbsComponent]
})
export class DrillBreadcrumbsModule { }
