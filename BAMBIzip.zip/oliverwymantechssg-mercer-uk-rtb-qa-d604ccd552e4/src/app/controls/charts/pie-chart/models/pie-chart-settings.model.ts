import { PieChartModel } from './pie-chart-model.model';
import { DrillLevel } from '../../models/drill-level.model';

export interface PieChartSettings {
  chartModel: PieChartModel;
  drillLevels?: DrillLevel[];
}
