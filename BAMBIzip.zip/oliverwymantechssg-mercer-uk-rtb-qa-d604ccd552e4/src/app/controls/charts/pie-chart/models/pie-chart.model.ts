import { PieChartSection } from './pie-chart-section.model';

export interface PieChart {
  name: string;
  id: string;
  data: PieChartSection[];
}
