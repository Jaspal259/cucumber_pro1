import { PieChart } from './pie-chart.model';
import { PieDataLabels} from 'Highcharts';

export interface PieChartModel {
  parent: PieChart;
  dataLabelsFormat: string;
  drilldowns?: PieChart[];
  title?: string;
  subtitle?: string;
  dataLabels?: PieDataLabels;
}
