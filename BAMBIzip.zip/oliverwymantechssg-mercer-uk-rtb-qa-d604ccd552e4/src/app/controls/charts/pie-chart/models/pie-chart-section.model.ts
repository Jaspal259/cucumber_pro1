export interface PieChartSection {
  name: string;
  drilldown?: string;
  y: number;
  tooltipText: string;
  color: string;
}
