import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import * as Highcharts from 'highcharts';

import { PieChartComponent } from './pie-chart.component';
import { PieChartService } from './services/pie-chart.service';
import { DrillBreadcrumbsModule } from './drill-breadcrumbs/drill-breadcrumbs.module';

export function highchartsFactory() {
  const dd = require('highcharts/modules/drilldown');
  dd(Highcharts);

  return Highcharts;
}

@NgModule({
  imports: [
    CommonModule,
    ChartModule,
    DrillBreadcrumbsModule
  ],
  providers: [
    PieChartService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    }
  ],
  declarations: [PieChartComponent],
  exports: [PieChartComponent]
})
export class PieChartModule { }
