import { Injectable } from '@angular/core';
import { Options, PieDataLabels, CSSObject } from 'Highcharts';
import { PieChartModel } from '../models/pie-chart-model.model';

@Injectable()
export class PieChartService {
  private getChartSeries(chartModel: PieChartModel) {
    return chartModel == null ? null : [chartModel.parent];
  }

  private getChartDrillDownSeries(chartModel: PieChartModel) {
    return chartModel == null ? null : chartModel.drilldowns;
  }

  get dataLabelStyle(): CSSObject {
    return  {
        fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif',
        fontSize: '10px',
        fontWeight: 'normal',
        textOutline: 'none',
    };
  }


  private getDefaultDataLabels(): PieDataLabels {
    return {
      enabled: true,
      distance: -50,
      padding: 0,
      crop: false,
      format: '<span style="color:#fff">{point.name}:</span><br/><span style="color:#fff">{point.y}</span>',
      style: this.dataLabelStyle
    };
  }

  getChartOptions(chartModel: PieChartModel): Options {
    return {
      chart: {
        type: 'pie',
        style: {
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif'
        }
      },
      title: {
        text: chartModel.title
      },
      subtitle: {
        text: chartModel.subtitle
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        pie: {
          size: '100%',
          allowPointSelect: true,
          borderWidth: 0,
          cursor: 'pointer',
          dataLabels: chartModel.dataLabels || this.getDefaultDataLabels()
        },
        series: {
          dataLabels: {
            enabled: true,
            format: chartModel.dataLabelsFormat
          }
        }
      },

      tooltip: {
        formatter: function () {
          return '<span style="color:#fff">' + this.point.tooltipText + '</span>';
        },
        borderWidth: 0,
        backgroundColor: 'rgba(64, 64, 64, 0.9)',
        borderRadius: 3
      },

      series:
        this.getChartSeries(chartModel),
      drilldown: {
        series:
          this.getChartDrillDownSeries(chartModel),
        activeAxisLabelStyle: {
          cursor: 'default',
          color: '#5f6a72',
          fontWeight: 'normal',
          textDecoration: 'none'
        },
        activeDataLabelStyle: {
          cursor: 'default',
          color: '#5f6a72',
          fontWeight: 'normal',
          textDecoration: 'none'
        }
      }
    };
  }
}
