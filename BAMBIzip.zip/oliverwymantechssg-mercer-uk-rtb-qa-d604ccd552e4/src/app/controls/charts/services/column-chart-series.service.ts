import { Injectable } from '@angular/core';
import { ColumnChartSeriesOptions } from 'highcharts';
import * as _ from 'lodash';

import { ColumnGroupChartSeriesOption } from '../models/column-group-chart-series-option.model';
import { ColumnGroupChart } from '../models/column-group-chart.model';
import { ColumnGroupChartSeries } from '../models/column-group-chart-series.model';

@Injectable()
export class ColumnChartSeriesService {

  private getColumnChartSeriesOptions(series: ColumnGroupChartSeriesOption, stack: string, color: string): ColumnChartSeriesOptions {
    return {
      name: series.title,
      data: series.values,
      stack: stack,
      color: color
    };
  }

  public getChartSeries(chart: ColumnGroupChart, colors: string[]): ColumnChartSeriesOptions[] {
    const series: ColumnChartSeriesOptions[] = [];
    _.forEach(chart.chartGroups,
      (chartGroup: ColumnGroupChartSeries) => {
        _.forEach(chartGroup.series,
          (chartGroupSeriesOption: ColumnGroupChartSeriesOption) => {
            const columnChartSeriesOptions =
            this.getColumnChartSeriesOptions(chartGroupSeriesOption, chartGroup.title, colors[series.length]);
            series.push(columnChartSeriesOptions);
          }
        );
      });

    return series;
  }

  public getChartSeriesValues(chartGroups: ColumnGroupChartSeries[]): number[] {
    return _(chartGroups)
      .map('series')
      .flatten()
      .map('values')
      .flatten()
      .value();
  }
}
