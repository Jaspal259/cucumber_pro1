import { Injectable } from '@angular/core';
import * as Highcharts from 'highcharts';

@Injectable()
export class HighchartFormatterService {

  constructor() { }

  formatToNumber(value: number) {
    return Number.isInteger(value) ? Highcharts.numberFormat(value, 0) : Highcharts.numberFormat(value, 2);
  }

  formatToMoney(value: number) {
    return '$' + this.formatToNumber(value);
  }
}
