import { TestBed, inject } from '@angular/core/testing';

import { HighchartFormatterService } from './highchart-formatter.service';

describe('HighchartFormatterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HighchartFormatterService]
    });
  });

  it('should be created', inject([HighchartFormatterService], (service: HighchartFormatterService) => {
    expect<any>(service).toBeTruthy();
  }));
});
