import { TestBed, inject } from '@angular/core/testing';

import { ColumnChartSeriesService } from './column-chart-series.service';
import { ColumnGroupChartSeries } from '../models/column-group-chart-series.model';

describe('ColumnChartSeriesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ColumnChartSeriesService]
    });
  });

  it('should be created', inject([ColumnChartSeriesService], (service: ColumnChartSeriesService) => {
    expect<any>(service).toBeTruthy();
  }));

  it('should get ColumnCharSeries values', inject([ColumnChartSeriesService], (service: ColumnChartSeriesService) => {

    const groups: ColumnGroupChartSeries[] = [
      {
        title: '1',
        series: [
          {
            title: '11',
            values: [1, 2]
          },
          {
            title: '12',
            values: [11, 22]
          }
        ]
      },
      {
        title: '2',
        series: [
          {
            title: '21',
            values: [33]
          }]
      }
    ];

    expect<any>(service.getChartSeriesValues(groups)).toEqual([1, 2, 11, 12, 33]);
  }));
});
