import { TestBed, inject } from '@angular/core/testing';

import { StackedColumnGroupChartService } from './stacked-column-group-chart.service';

describe('StackedColumnGroupChartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StackedColumnGroupChartService]
    });
  });

  it('should be created', inject([StackedColumnGroupChartService], (service: StackedColumnGroupChartService) => {
    expect<any>(service).toBeTruthy();
  }));
});
