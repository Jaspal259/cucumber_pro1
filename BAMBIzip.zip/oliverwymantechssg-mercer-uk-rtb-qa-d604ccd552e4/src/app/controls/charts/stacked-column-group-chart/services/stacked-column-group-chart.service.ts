import { Injectable } from '@angular/core';
import { ColumnGroupChart } from '../../models/column-group-chart.model';
import * as Highcharts from 'highcharts';
import * as _ from 'lodash';
import { ResourceProvider } from '../../../../services/resources/resource-provider';
import { ColumnChartSeriesService } from '../../services/column-chart-series.service';
import { HighchartFormatterService } from '../../services/highchart-formatter.service';

@Injectable()
export class StackedColumnGroupChartService {
  private readonly colors = [
    'rgba(33,186,255,1)',
    'rgba(2,98,140,0.9)',
    'rgba(193,188,91,0.9)',
    'rgba(140,135,11,1)'
  ];

  constructor(private columnChartSeriesService: ColumnChartSeriesService,
    private highchartFormatterService: HighchartFormatterService ) { }

  getChartOptions(chart: ColumnGroupChart, resources: ResourceProvider): Highcharts.Options {
    const scope = this;

    return {
      chart: {
        type: 'column',
        style: {
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif'
        }
      },

      title: {
        text: chart.chartTitle
      },

      xAxis: {
        categories: chart.categories
      },

      yAxis: {
        allowDecimals: false,
        min: 0,
        labels: {
          formatter: function () {
            const value = scope.highchartFormatterService.formatToNumber(this.value);
            return '$' + value;
          }
        },
        title: {
          text: ''
        }
      },

      tooltip: {
        formatter: function () {
          return `<span style="color:#fff; font-weight:bold;">${this.x
            }</span><br/><span style="color:#fff;">${this.series.name}: </span>
            <span style="color:#fff; font-weight:bold;">
            ${scope.highchartFormatterService.formatToMoney(this.y)}
            </span><br/>${`<span style="color:#fff;">
            ${resources.get('total')} ${this.series.userOptions.stack}
            :  </span>`}<span style="color:#fff; font-weight:bold;">${scope.highchartFormatterService.formatToMoney(this.point.stackTotal)
            }</span>`;
        },
        borderWidth: 0,
        backgroundColor: 'rgba(64, 64, 64, 0.9)',
        borderRadius: 3
      },

      plotOptions: {
        column: {
          stacking: 'normal'
        }
      },
      legend: {
        itemStyle: {
          fontSize: '12px',
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif',
          fontWeight: 'normal',
          color: '#5f6a72'
        },
        shadow: false
      },
      series: this.columnChartSeriesService.getChartSeries(chart, this.colors),
      credits: {
        enabled: false
      }
    };
  }
}
