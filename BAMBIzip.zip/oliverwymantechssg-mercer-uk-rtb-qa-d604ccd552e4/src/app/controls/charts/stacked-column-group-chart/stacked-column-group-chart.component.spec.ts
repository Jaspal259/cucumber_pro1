import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StackedColumnGroupChartComponent } from './stacked-column-group-chart.component';

describe('StackedColumnGroupChartComponent', () => {
  let component: StackedColumnGroupChartComponent;
  let fixture: ComponentFixture<StackedColumnGroupChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StackedColumnGroupChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StackedColumnGroupChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
