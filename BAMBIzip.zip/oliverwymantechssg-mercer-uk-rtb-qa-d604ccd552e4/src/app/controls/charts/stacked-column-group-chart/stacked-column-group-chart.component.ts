import { Component, OnInit, Input } from '@angular/core';
import { Options } from 'highcharts';
import { ColumnGroupChart } from '../models/column-group-chart.model';
import { StackedColumnGroupChartService } from './services/stacked-column-group-chart.service';
import { ResourceProvider } from '../../../services/resources/resource-provider';

@Component({
  selector: 'bam-stacked-column-group-chart',
  templateUrl: './stacked-column-group-chart.component.html'
})
export class StackedColumnGroupChartComponent implements OnInit {
  chartOptions: Options;
  @Input() resources: ResourceProvider;
  @Input() chart: ColumnGroupChart;

  constructor(private stackedColumnGroupChartService: StackedColumnGroupChartService) { }

  ngOnInit() {
    this.chartOptions = this.stackedColumnGroupChartService.getChartOptions(this.chart, this.resources);
  }
}
