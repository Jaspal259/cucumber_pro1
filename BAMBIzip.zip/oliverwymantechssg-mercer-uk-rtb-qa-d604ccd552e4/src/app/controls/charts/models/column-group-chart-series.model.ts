import { ColumnGroupChartSeriesOption } from './column-group-chart-series-option.model';

export interface ColumnGroupChartSeries {
  title: string;
  series: ColumnGroupChartSeriesOption[];
}
