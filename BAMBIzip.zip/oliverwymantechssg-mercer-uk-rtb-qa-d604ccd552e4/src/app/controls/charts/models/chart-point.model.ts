export interface ChartPoint {
  seriesName: string;
  category: string;
  value: number;
}
