import { ChartPoint } from './chart-point.model';

export interface ColumnChartTooltipSettings {
  chartPoints: ChartPoint[];
}
