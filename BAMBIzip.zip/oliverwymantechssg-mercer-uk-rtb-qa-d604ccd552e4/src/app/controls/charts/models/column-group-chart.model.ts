import { ColumnGroupChartSeries } from './column-group-chart-series.model';
import { ColumnChartTooltipSettings } from './column-chart-tooltip-settings.model';

export interface ColumnGroupChart {
  chartTitle: string;
  categories: string [];
  chartGroups: ColumnGroupChartSeries[];
  tooltipSettings?: ColumnChartTooltipSettings;
  yAxisFormatting?: (value: string) => string;
}
