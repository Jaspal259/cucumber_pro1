export interface ColumnGroupChartSeriesOption {
  title: string;
  values: number[];
}
