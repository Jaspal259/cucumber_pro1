export interface DrillLevel {
  level: number;
  title: string;
}
