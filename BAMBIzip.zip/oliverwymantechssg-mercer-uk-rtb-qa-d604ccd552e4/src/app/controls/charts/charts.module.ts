import { NgModule } from '@angular/core';
import { ChartModule} from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import * as Highcharts from 'highcharts';

import { FixedColumnGroupChartComponent } from './fixed-column-group-chart/fixed-column-group-chart.component';
import { FixedColumnGroupChartService } from './fixed-column-group-chart/services/fixed-column-group-chart.service';
import { StackedColumnGroupChartComponent } from './stacked-column-group-chart/stacked-column-group-chart.component';
import { StackedColumnGroupChartService } from './stacked-column-group-chart/services/stacked-column-group-chart.service';
import { PieChartModule } from './pie-chart/pie-chart.module';
import { StackedPercentageColumnChartComponent } from './stacked-percentage-column-chart/stacked-percentage-column-chart.component';
import { StackedPercentageColumnChartService } from './stacked-percentage-column-chart/services/stacked-percentage-column-chart.service';
import { ColumnChartSeriesService } from './services/column-chart-series.service';
import { HighchartFormatterService } from './services/highchart-formatter.service';
import { ArrayHelperService } from '../../services/array-helper.service';

Highcharts.setOptions({ lang: { thousandsSep: ',' } });

export function highchartsFactory() {
  const dd = require('highcharts/modules/drilldown');
  dd(Highcharts);

  return Highcharts;
}


@NgModule({
  imports: [
    ChartModule,
    PieChartModule
  ],
  declarations: [
    FixedColumnGroupChartComponent,
    StackedColumnGroupChartComponent,
    StackedPercentageColumnChartComponent
  ],
  providers: [
    FixedColumnGroupChartService,
    StackedColumnGroupChartService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    },
    StackedPercentageColumnChartService,
    ColumnChartSeriesService,
    HighchartFormatterService,
    ArrayHelperService],
  exports: [
    FixedColumnGroupChartComponent,
    StackedColumnGroupChartComponent,
    StackedPercentageColumnChartComponent,
    PieChartModule
  ]
})
export class ChartsModule { }
