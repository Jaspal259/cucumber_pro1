import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StackedPercentageColumnChartComponent } from './stacked-percentage-column-chart.component';

describe('StackedPercentageColumnChartComponent', () => {
  let component: StackedPercentageColumnChartComponent;
  let fixture: ComponentFixture<StackedPercentageColumnChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StackedPercentageColumnChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StackedPercentageColumnChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
