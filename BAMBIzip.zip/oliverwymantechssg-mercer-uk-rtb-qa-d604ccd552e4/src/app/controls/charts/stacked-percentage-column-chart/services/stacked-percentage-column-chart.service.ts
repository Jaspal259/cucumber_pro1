import { Injectable } from '@angular/core';
import { Options } from 'highcharts';
import * as _ from 'lodash';

import { ColumnGroupChart } from '../../models/column-group-chart.model';
import { ResourceProvider } from '../../../../services/resources/resource-provider';
import { ColumnChartSeriesService } from '../../services/column-chart-series.service';

@Injectable()
export class StackedPercentageColumnChartService {
  readonly colors = [
    '#21BAFF',
    '#02628C'
  ];

  constructor(private columnChartSeriesService: ColumnChartSeriesService) { }

  getChartOptions(chart: ColumnGroupChart, resources: ResourceProvider): Options {
    return {
      chart: {
        type: 'column',
        style: {
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif'
        },
        marginBottom: 100,
      },
      credits: {
        enabled: false
      },
      title: {
        text: chart.chartTitle
      },
      exporting: {
        enabled: false
      },
      xAxis: {
        categories: chart.categories,
        labels: {
          rotation: 0,
          style: {
            fontSize: '9px',
            color: '#5F6A72',
            textOverflow: 'none'
          }
        },
      },

      yAxis: {
        allowDecimals: false,
        min: 0,
        max: 100,
        title: {
          text: ''
        },
        labels: chart.yAxisFormatting
          ? {
            formatter: function () {
              return chart.yAxisFormatting(this.value);
            }
          }
          : null,
        reversedStacks: false
      },
      legend: {
        enabled: true,
        y: 0
      },
      tooltip: {
        headerFormat: '',
        pointFormat: '<span style="color:#fff">{series.name}: {point.y}</span>',
        borderWidth: 0,
        backgroundColor: 'rgba(64, 64, 64, 0.9)',
        borderRadius: 3
      },

      plotOptions: {
        column: {
          stacking: 'percent',
          allowPointSelect: false
        }
      },

      series: this.columnChartSeriesService.getChartSeries(chart, this.colors)
    };
  }
}
