import { TestBed, inject } from '@angular/core/testing';

import { StackedPercentageColumnChartService } from './stacked-percentage-column-chart.service';

describe('StackedPercentageColumnChartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StackedPercentageColumnChartService]
    });
  });

  it('should be created', inject([StackedPercentageColumnChartService], (service: StackedPercentageColumnChartService) => {
    expect<any>(service).toBeTruthy();
  }));
});
