import { Component, OnInit, OnChanges, Input, SimpleChanges } from '@angular/core';
import { Options } from 'highcharts';

import { ResourceProvider } from '../../../services/resources/resource-provider';
import { StackedPercentageColumnChartService } from './services/stacked-percentage-column-chart.service';
import { ColumnGroupChart } from '../models/column-group-chart.model';

@Component({
  selector: 'bam-stacked-percentage-column-chart',
  templateUrl: './stacked-percentage-column-chart.component.html'
})
export class StackedPercentageColumnChartComponent implements OnInit, OnChanges {
  chartOptions: Options;
  @Input() chart: ColumnGroupChart;
  @Input() resources: ResourceProvider;

  constructor(private stackedPercentageColumnChartService: StackedPercentageColumnChartService) { }

  ngOnInit() {
    this.chartOptions = this.stackedPercentageColumnChartService.getChartOptions(this.chart, this.resources);
  }

  ngOnChanges(changes: SimpleChanges) {
    this.chartOptions = this.stackedPercentageColumnChartService.getChartOptions(this.chart, this.resources);
  }
}
