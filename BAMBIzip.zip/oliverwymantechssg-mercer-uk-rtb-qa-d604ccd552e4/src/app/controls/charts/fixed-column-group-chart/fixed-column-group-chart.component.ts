import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Options} from 'highcharts';
import { ColumnGroupChart } from '../models/column-group-chart.model';
import { FixedColumnGroupChartService } from './services/fixed-column-group-chart.service';

@Component({
  selector: 'bam-fixed-column-group-chart',
  templateUrl: './fixed-column-group-chart.component.html'
})
export class FixedColumnGroupChartComponent implements OnInit, OnChanges {
  chartOptions: Options;
  @Input() chart: ColumnGroupChart;

  constructor(private fixedColumnGroupChartService: FixedColumnGroupChartService
  ) { }

  private updateChartOptions() {
    this.chartOptions = this.fixedColumnGroupChartService.getChartOptions(this.chart);
  }

  ngOnInit() {
    this.updateChartOptions();
  }

  ngOnChanges() {
    this.updateChartOptions();
  }

}
