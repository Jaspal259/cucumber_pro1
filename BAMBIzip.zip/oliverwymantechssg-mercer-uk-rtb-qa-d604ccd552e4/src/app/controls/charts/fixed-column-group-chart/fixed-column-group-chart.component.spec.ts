import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FixedColumnGroupChartComponent } from './fixed-column-group-chart.component';

describe('FixedColumnChartComponent', () => {
  let component: FixedColumnGroupChartComponent;
  let fixture: ComponentFixture<FixedColumnGroupChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FixedColumnGroupChartComponent]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FixedColumnGroupChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
