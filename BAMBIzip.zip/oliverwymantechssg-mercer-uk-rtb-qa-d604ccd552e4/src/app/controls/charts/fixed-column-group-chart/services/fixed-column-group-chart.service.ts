import { Injectable } from '@angular/core';
import * as Highcharts from 'highcharts';
import * as _ from 'lodash';

import { ColumnGroupChart } from '../../models/column-group-chart.model';
import { ColumnGroupChartSeriesOption } from '../../models/column-group-chart-series-option.model';
import { ColumnGroupChartSeries } from '../../models/column-group-chart-series.model';
import { ColumnChartSeriesService } from '../../services/column-chart-series.service';
import { ArrayHelperService } from '../../../../services/array-helper.service';
import { ChartPoint } from '../../models/chart-point.model';

@Injectable()
export class FixedColumnGroupChartService {
  constructor(private columnChartSeriesService: ColumnChartSeriesService,
    private arrayHelperService: ArrayHelperService) { }

  getChartOptions(chart: ColumnGroupChart): Highcharts.Options {
    const tooltipSettings = chart.tooltipSettings;
    const maxYAxis = this.arrayHelperService.getMaxToTheNearest10(this.columnChartSeriesService.getChartSeriesValues(chart.chartGroups));

    return {
      chart: {
        type: 'column',
        style: {
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif'
        }
      },
      title: {
        text: chart.chartTitle
      },
      xAxis: {
        categories: chart.categories
      },
      yAxis: [{
        max: maxYAxis,
        min: 0,
        title: {
          text: ''
        },
        labels: chart.yAxisFormatting
          ? {
            formatter: function () {
              return chart.yAxisFormatting(this.value);
            }
          }
          : null
      }],
      tooltip: {
        shared: true,
        headerFormat: `<span style="color:#fff; font-weight: bold;">
                        {point.key}
                      </span><br/>`,
        pointFormatter: function () {
          const value = tooltipSettings
            ? _.find(tooltipSettings.chartPoints, (item: ChartPoint) => {
              return item.seriesName === this.series.name && item.category === this.category;
            }).value
            : this.y;

          return value === 0
            ? null
            : `<span style="color:${this.series.color}">\u25CF</span>
              <span style="color:#fff">${this.series.name}: </span>
              <span style="color:#fff; font-weight: bold;">
                ${Highcharts.numberFormat(value, 0, '.', ',')}
              </span>
              <br/>`;
        },
        borderWidth: 0,
        backgroundColor: 'rgba(64, 64, 64, 0.9)',
        borderRadius: 3
      },
      plotOptions: {
        column: {
          grouping: false,
          shadow: false,
          borderWidth: 0
        }
      },
      legend: {
        itemStyle: {
          fontSize: '12px',
          fontFamily: 'HelveticaNeueW01-55Roman, Helvetica, Arial, sans-serif',
          fontWeight: 'normal',
          color: '#5f6a72'
        },
        shadow: false
      },
      series: this.getChartSeries(chart),
      credits: {
        enabled: false
      }
    };
  }

  private getPointPlacement(groupIndex: number, groupCount: number): number {
    if (groupCount === 1) {
      return 0;
    }

    let pointPlacement: number = groupCount / 10;

    if (groupIndex % 2 === 0) {
      pointPlacement = pointPlacement * (-1);
    }

    return pointPlacement;
  }

  private getColumnChartSeriesOptions(series: ColumnGroupChartSeriesOption,
    color: string,
    pointPadding: number,
    pointPlacement: number): Highcharts.ColumnChartSeriesOptions {
    return {
      name: series.title,
      color: color,
      data: series.values,
      pointPadding: pointPadding,
      pointPlacement: pointPlacement
    };
  }

  private getChartSeries(chart: ColumnGroupChart): Highcharts.ColumnChartSeriesOptions[] {
    const colors = [
      'rgba(33,186,255,1)',
      'rgba(2,98,140,0.9)',
      'rgba(217,120,6,1)',
      'rgba(140,76,0,0.9)'
    ];

    const series: Highcharts.ColumnChartSeriesOptions[] = [];
    _.forEach(chart.chartGroups,
      (chartGroup: ColumnGroupChartSeries, groupIndex: number) => {
        const pointPlacement = this.getPointPlacement(groupIndex, chart.chartGroups.length);
        _.forEach(chartGroup.series,
          (chartGroupSeriesOption: ColumnGroupChartSeriesOption, seriesIndex) => {
            const pointPadding = 0.3 + (seriesIndex / 10);
            const columnChartSeriesOptions = this.getColumnChartSeriesOptions(chartGroupSeriesOption,
              colors[series.length],
              pointPadding,
              pointPlacement);
            series.push(columnChartSeriesOptions);
          }
        );
      });

    return series;
  }

  private getAllyAxisValues(chartGroups: ColumnGroupChartSeries[]) {
    return _(chartGroups)
      .map('series')
      .flatten()
      .map('values')
      .flatten()
      .value();
  }
}
