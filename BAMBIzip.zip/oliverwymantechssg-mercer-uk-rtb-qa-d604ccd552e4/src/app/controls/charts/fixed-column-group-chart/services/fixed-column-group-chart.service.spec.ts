import { TestBed, inject } from '@angular/core/testing';
import { FixedColumnGroupChartService } from './fixed-column-group-chart.service';


describe('ColumnGroupChartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FixedColumnGroupChartService]
    });
  });

  it('should be created', inject([FixedColumnGroupChartService], (service: FixedColumnGroupChartService) => {
    expect<any>(service).toBeTruthy();
  }));
});
