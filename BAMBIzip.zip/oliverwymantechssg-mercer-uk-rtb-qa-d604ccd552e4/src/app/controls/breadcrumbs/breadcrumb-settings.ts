export interface BreadcrumbSettings {
  title: string;
  navigateUrl?: string;
  backPage: string;
}
