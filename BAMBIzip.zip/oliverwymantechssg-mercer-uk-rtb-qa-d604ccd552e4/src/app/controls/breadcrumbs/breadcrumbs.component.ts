import { Component, OnInit, Input } from '@angular/core';
import { BreadcrumbSettings } from './breadcrumb-settings';
import { Router } from '@angular/router';

@Component({
  selector: 'bam-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent implements OnInit {
  @Input() settings: BreadcrumbSettings;

  constructor(private router: Router) { }

  ngOnInit() {
  }
}
