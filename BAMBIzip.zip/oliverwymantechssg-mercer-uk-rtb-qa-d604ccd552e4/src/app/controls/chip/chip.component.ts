import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bam-chip',
  templateUrl: './chip.component.html',
  styleUrls: ['./chip.component.scss']
})
export class ChipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
