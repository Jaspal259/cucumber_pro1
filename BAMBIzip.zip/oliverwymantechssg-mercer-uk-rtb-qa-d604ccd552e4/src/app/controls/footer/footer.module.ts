import { NgModule } from '@angular/core';

import { FooterComponent } from './footer.component';
import { MercerOSModule } from 'merceros-ui-components';
import { IconModule } from '../icon/icon.module';
import { ServerSettingsApiService } from '../../services/service-settings-api.service';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [MercerOSModule, IconModule, CommonModule],
  declarations: [FooterComponent],
  exports: [FooterComponent],
  providers: [ServerSettingsApiService]
})
export class FooterModule { }
