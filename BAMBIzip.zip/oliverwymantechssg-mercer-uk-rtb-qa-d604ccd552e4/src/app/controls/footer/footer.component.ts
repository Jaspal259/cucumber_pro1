import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { ServerSettingsApiService } from '../../services/service-settings-api.service';

@Component({
  selector: 'bam-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FooterComponent implements OnInit {
  resources = new ResourceProviderDictionary();
  serverName: string;
  email: string;

  constructor(
    private route: ActivatedRoute,
    private resourceRouteService: ResourceRouteService,
    private serverSettingsApiService: ServerSettingsApiService) {
    this.resources.footer = this.resourceRouteService.getResource(this.route, 'footer');
  }


  async ngOnInit() {
    this.serverName = await this.serverSettingsApiService.getMachineName();
    this.email = this.resources.footer.get('email');
  }
}
