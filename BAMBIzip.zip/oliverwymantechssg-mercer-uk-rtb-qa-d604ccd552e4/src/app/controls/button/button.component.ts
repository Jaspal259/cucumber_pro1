import { Component, OnInit, HostBinding, Input } from '@angular/core';

@Component({
  selector: 'bam-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {

  @Input() @HostBinding('class.bam-button-round') public round = false;
  @Input() @HostBinding('class.bam-button-outline') public outline = false;
  @Input() @HostBinding('class.bam-button-disabled') public disabled = false;
  @Input() @HostBinding('class.bam-button-cancel') public cancel = false;
  @Input() @HostBinding('class.bam-button-inline') public inline = false;

   /** Set the id of the icon you want to use, for example: thumb_up. */
  @Input() public icon: string;

  /** Set the position of the icon in the button. Values: left or right */
  @Input() public iconPosition: string;

  constructor() { }

  ngOnInit() {
  }

}
