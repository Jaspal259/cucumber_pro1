import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonComponent } from './button.component';
import { IconModule } from '../icon/icon.module';
import { MercerOSModule } from 'merceros-ui-components';

@NgModule({
  imports: [
    CommonModule,
    IconModule,
    MercerOSModule
  ],
  declarations: [ButtonComponent],
  exports: [ButtonComponent]
})
export class ButtonModule { }
