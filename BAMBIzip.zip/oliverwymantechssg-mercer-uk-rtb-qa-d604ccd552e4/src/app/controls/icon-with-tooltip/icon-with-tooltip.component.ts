import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-icon-with-tooltip',
  templateUrl: './icon-with-tooltip.component.html',
  styleUrls: ['./icon-with-tooltip.component.scss']
})
export class IconWithTooltipComponent implements OnInit {
  @Input() size: string;
  @Input() tooltipText: string;
  @Input() icon: string;

  constructor() { }

  ngOnInit() {
  }
}
