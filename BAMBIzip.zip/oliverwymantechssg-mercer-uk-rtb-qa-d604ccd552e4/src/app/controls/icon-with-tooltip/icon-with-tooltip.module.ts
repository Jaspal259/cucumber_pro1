import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconWithTooltipComponent } from './icon-with-tooltip.component';
import { MercerOSModule } from 'merceros-ui-components';
import { IconModule } from '../icon/icon.module';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    IconModule
  ],
  declarations: [
    IconWithTooltipComponent
  ],
  exports: [
    IconWithTooltipComponent
  ]
})
export class IconWithTooltipModule { }
