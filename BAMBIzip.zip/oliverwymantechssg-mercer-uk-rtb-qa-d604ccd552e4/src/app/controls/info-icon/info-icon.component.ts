import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-info-icon',
  templateUrl: './info-icon.component.html'
})
export class InfoIconComponent implements OnInit {
  @Input() tooltipText: string;

  constructor() { }

  ngOnInit() {
  }

}
