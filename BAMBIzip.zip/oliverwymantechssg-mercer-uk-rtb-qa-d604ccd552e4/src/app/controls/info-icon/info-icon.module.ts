import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InfoIconComponent } from './info-icon.component';
import { IconWithTooltipModule } from '../icon-with-tooltip/icon-with-tooltip.module';

@NgModule({
  imports: [
    CommonModule,
    IconWithTooltipModule
  ],
  declarations: [InfoIconComponent],
  exports: [
    InfoIconComponent
  ]
})
export class InfoIconModule { }
