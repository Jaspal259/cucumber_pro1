export type LoadingIndicatorSection = 'full_page' | 'plan_det_costs' | 'plan_det_enrollment' | 'plan_det_claims'
  | 'plan_det_eligibilities' | 'plan_det_rates' | 'plan_det_contributions' | 'dashboard_membership_count'
  | 'dashboard_active_enrollment' | 'dashboard_aco_enrollment' | 'dashboard_welfare_enrollment';

export interface LoadingIndicatorKeyValue {
  key: LoadingIndicatorSection;
  value: boolean;
}

export type LoadingIndicatorDictionary = {
  [key in LoadingIndicatorSection]?: boolean;
};
