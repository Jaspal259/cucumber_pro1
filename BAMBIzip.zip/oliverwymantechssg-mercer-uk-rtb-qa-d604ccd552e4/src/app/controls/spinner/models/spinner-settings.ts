export interface SpinnerSettings {
  loadingMessage?: string;
  loadingTitle?: string;
  loadingProgressMessage?: string;
  fullPageLoader?: boolean;
}
