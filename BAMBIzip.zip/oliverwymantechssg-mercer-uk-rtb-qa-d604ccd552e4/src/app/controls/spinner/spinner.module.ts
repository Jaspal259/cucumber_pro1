import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpinnerComponent } from './spinner.component';
import { MercerOSModule } from 'merceros-ui-components';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule
  ],
  declarations: [SpinnerComponent],
  exports: [
    SpinnerComponent
  ]
})
export class SpinnerModule { }
