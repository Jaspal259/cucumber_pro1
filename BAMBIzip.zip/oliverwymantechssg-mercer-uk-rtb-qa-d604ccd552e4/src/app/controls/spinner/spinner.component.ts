import { Component, OnInit, ViewChild, OnDestroy, Input } from '@angular/core';
import { SpinnerService } from '../../services/spinner.service';
import { Subscription } from 'rxjs';
import { MosPreloaderComponent } from 'merceros-ui-components';
import { SpinnerSettings } from './models/spinner-settings';
import { LoadingIndicatorSection } from './models/loading-indicator-section.type';

@Component({
  selector: 'bam-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit, OnDestroy {
  constructor(private spinnerService: SpinnerService) { }

  loadingIndicatorSubscription: Subscription;
  @ViewChild('preloaderReference') private preloaderReference: MosPreloaderComponent;
  @Input() settings: SpinnerSettings;
  @Input() key: LoadingIndicatorSection;

  private switchLoadingIndicator(loadingIndicator: boolean) {
    if (loadingIndicator) {
      this.preloaderReference.load();
      return;
    }
    this.preloaderReference.loaded();
  }

  ngOnInit() {
    this.loadingIndicatorSubscription = this.spinnerService.subscribeToLoadingIndicator(this.key,
      (loadingIndicator: boolean) => this.switchLoadingIndicator(loadingIndicator));
    this.switchLoadingIndicator(this.spinnerService.getLatestValue(this.key));
  }

  ngOnDestroy() {
    this.loadingIndicatorSubscription.unsubscribe();
  }

}
