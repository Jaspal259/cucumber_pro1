import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss']
})
export class PageHeaderComponent implements OnInit {

  @Input() pageTitle = '';
  @Input() theme = '';
  @Input() alignCenter = false;

  constructor() { }

  ngOnInit() {
  }

}
