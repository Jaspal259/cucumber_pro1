import { PlatformLocation } from '@angular/common';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { NavigationService } from '../../services/navigation.service';
import { AuthorizationService } from '../../services/authorization/authorization.service';
import { AuthorizationResources } from '../../models/authorization-resource.type';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { UserProfileService } from './services/user-profile.service';
import { LogoutModalComponent } from './logout-modal/logout-modal.component';
import { SiteResourcesApiService } from '../../views/admin/services/api/site-resources-api.service';
import { DownloadFileService } from '../../services/download-file/download-file.service';
import { UserGuideService } from '../../services/user-guide.service';
import { LoadingIndicatorSection } from '../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerSettings } from '../../controls/spinner/models/spinner-settings';
import { SpinnerService } from '../../services/spinner.service';
import { DataConsiderationsService } from '../../services/data-considerations.service';

@Component({
  selector: 'bam-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [UserGuideService, DataConsiderationsService],
  encapsulation: ViewEncapsulation.None
})
export class HeaderComponent implements OnInit {
  @ViewChild(LogoutModalComponent) logoutModal: LogoutModalComponent;
  userFullName: string;
  permissions: AuthorizationResources;
  resources = new ResourceProviderDictionary();
  loadingIndicatorKey: LoadingIndicatorSection = 'full_page';
  loadingSpinnerSettings: SpinnerSettings = {
    fullPageLoader: true
  };

  constructor(
    private route: ActivatedRoute,
    private navigationService: NavigationService,
    private userProfileService: UserProfileService,
    private authorizationService: AuthorizationService,
    private resourceRouteService: ResourceRouteService,
    private siteResourceService: SiteResourcesApiService,
    private downloadFileService: DownloadFileService,
    private userGuideService: UserGuideService,
    private dataConsiderationService: DataConsiderationsService,
    private spinnerService: SpinnerService,
    private platformLocation: PlatformLocation) { }

  async ngOnInit() {
    this.resources.header = this.resourceRouteService.getResource(this.route, 'header');
    this.resources.userProfile = this.resourceRouteService.getResource(this.route, 'userProfile');
    this.resources.siteResource = this.resourceRouteService.getResource(this.route, 'siteResource');
    // tslint:disable-next-line: max-line-length
    this.permissions = await this.authorizationService.getRequestedPermissions(['home', 'dashboard', 'reports', 'admin', 'siteresources']);
    this.userFullName = await this.userProfileService.getUserFullName();
  }

  logout() {
    this.logoutModal.open();
  }

  async getUserGuide() {
    await this.spinnerService.show(this.loadingIndicatorKey, async () => {
      await this.userGuideService.downloadUserGuide();
    });
  }

  async getDataConsiderations() {
    await this.spinnerService.show(this.loadingIndicatorKey, async () => {
      await this.dataConsiderationService.downloadDataConsiderations();
    });
  }
}
