import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header.component';
import { MercerOSModule } from 'merceros-ui-components';
import { IconModule } from '../icon/icon.module';
import { NavigationService } from '../../services/navigation.service';
import { AuthorizationService } from '../../services/authorization/authorization.service';
import { AuthorizationApiService } from '../../services/authorization/authorization-api.service';
import { UserProfileService } from './services/user-profile.service';
import { UserProfileApiService } from './services/user-profile-api.service';
import { LogoutModalModule } from './logout-modal/logout-modal.module';
import { UserProfileResourceResolver } from './resolvers/user-profile-resource-resolver';
import { SiteResourcesApiService } from '../../views/admin/services/api/site-resources-api.service';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    IconModule,
    RouterModule,
    LogoutModalModule
  ],
  declarations: [HeaderComponent],
  providers: [
    NavigationService,
    UserProfileService,
    UserProfileApiService,
    AuthorizationService,
    AuthorizationApiService,
    SiteResourcesApiService,
    UserProfileResourceResolver
  ],
  exports: [HeaderComponent]
})
export class HeaderModule { }
