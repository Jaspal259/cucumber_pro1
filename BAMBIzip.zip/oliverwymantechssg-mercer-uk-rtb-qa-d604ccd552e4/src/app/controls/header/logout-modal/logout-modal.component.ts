import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ModalComponent } from '../../modal/modal.component';
import { AuthenticateService } from '../../../services/authenticate.service';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';

@Component({
  selector: 'bam-logout-modal',
  templateUrl: './logout-modal.component.html'
})
export class LogoutModalComponent implements OnInit {
  @ViewChild(ModalComponent) modal: ModalComponent;
  resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private authenticateService: AuthenticateService) {
      this.resources.global = resourceRouteService.getResource(route, 'global');
      this.resources.userProfile = resourceRouteService.getResource(route, 'userProfile');
  }

  ngOnInit() {
  }

  open() {
    this.modal.open();
  }

  onCancel() {
    this.modal.close();
  }

  async onLogout() {
    await this.authenticateService.logout();
  }
}
