import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LogoutModalComponent } from './logout-modal.component';
import { ModalModule } from '../../modal/modal.module';
import { AuthenticateService } from '../../../services/authenticate.service';
import { ButtonModule } from '../../button/button.module';

@NgModule({
  imports: [
    CommonModule,
    ModalModule,
    ButtonModule
  ],
  declarations: [LogoutModalComponent],
  providers: [AuthenticateService],
  exports: [LogoutModalComponent]
})
export class LogoutModalModule { }
