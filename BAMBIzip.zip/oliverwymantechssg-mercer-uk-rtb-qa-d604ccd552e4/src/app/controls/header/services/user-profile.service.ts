import { Injectable } from '@angular/core';

import { UserProfileApiService } from './user-profile-api.service';

@Injectable()
export class UserProfileService {

  constructor(private apiService: UserProfileApiService) {
  }

  async getUserFullName(): Promise<string> {
    return await this.apiService.getUserFullName();
  }
}
