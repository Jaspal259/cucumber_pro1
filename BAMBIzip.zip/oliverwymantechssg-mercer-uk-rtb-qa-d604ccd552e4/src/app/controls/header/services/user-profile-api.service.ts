import { Injectable } from '@angular/core';

import { ApiService } from '../../../services/api.service';

@Injectable()
export class UserProfileApiService {
  private readonly controllerName = 'userProfile';

  constructor(private apiService: ApiService) { }

  async getUserFullName(): Promise<string> {
    return await this.apiService.post<string>(`${this.controllerName}/GetFullName`, null);
  }
}
