import { TestBed, inject } from '@angular/core/testing';

import { UserProfileApiService } from './user-profile-api.service';

describe('UserProfileApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserProfileApiService]
    });
  });

  it('should be created', inject([UserProfileApiService], (service: UserProfileApiService) => {
    expect<any>(service).toBeTruthy();
  }));
});
