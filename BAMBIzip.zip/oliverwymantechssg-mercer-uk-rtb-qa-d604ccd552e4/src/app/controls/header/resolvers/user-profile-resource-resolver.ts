import { Injectable } from '@angular/core';
import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable()
export class UserProfileResourceResolver extends BaseResourceResolver<'userProfile'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'userProfile');
  }
}
