export interface KeyValueDictionary<T> {
  [key: string]: T;
}
