export interface KeyValues<T = string> {
  [key: string]: T[];
}
