export interface GroupedObjectByKeys<T> {
  keys: string[];
  values: T[];
}
