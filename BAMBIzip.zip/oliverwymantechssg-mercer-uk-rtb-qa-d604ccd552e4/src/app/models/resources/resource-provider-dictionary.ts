import { ResourceProvider } from '../../services/resources/resource-provider';

export class ResourceProviderDictionary {
  fileUpload: ResourceProvider;
  admin: ResourceProvider;
  adHocReports: ResourceProvider;
  adHocReportActions: ResourceProvider;
  global: ResourceProvider;
  planSummary: ResourceProvider;
  planDetails: ResourceProvider;
  planDesign: ResourceProvider;
  enrollments: ResourceProvider;
  costs: ResourceProvider;
  dashboard: ResourceProvider;
  membershipCount: ResourceProvider;
  acoEnrollment: ResourceProvider;
  activeEnrollment: ResourceProvider;
  welfareEnrollment: ResourceProvider;
  serverErrors: ResourceProvider;
  header: ResourceProvider;
  footer: ResourceProvider;
  userProfile: ResourceProvider;
  planPoliciesExport: ResourceProvider;
  home: ResourceProvider;
  overview: ResourceProvider;
  activities: ResourceProvider;
  totalHealthcareCosts: ResourceProvider;
  siteResource: ResourceProvider;
  userGuide: ResourceProvider;
  dataConsiderations: ResourceProvider;
}
