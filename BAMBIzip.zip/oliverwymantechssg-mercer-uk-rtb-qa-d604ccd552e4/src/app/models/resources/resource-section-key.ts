export type ResourceSectionKey = 'admin' |
  'adHocReports' |
  'adHocReportActions' |
  'adHocReportHistoryActions' |
  'planDetails' |
  'planSummary' |
  'planDesign' |
  'global' |
  'enrollments' |
  'costs' |
  'dashboard' |
  'membershipCount' |
  'acoEnrollment' |
  'activeEnrollment' |
  'welfareEnrollment' |
  'totalHealthcareCosts' |
  'serverErrors' |
  'header' |
  'footer' |
  'userProfile' |
  'planPoliciesExport'|
  'home.home' |
  'home.overview' |
  'home.activities' |
  'home.disclaimer' |
  'fileUpload' |
  'siteResource' |
  'userGuide' |
  'dataConsiderations';
