import { BaseResourceResolver } from '../../resolvers/base-resource-resolver';
import { ResourceSectionKey } from './resource-section-key';

export type ResolverConstructor<T extends ResourceSectionKey> = new (...args: any[]) => BaseResourceResolver<T>;
