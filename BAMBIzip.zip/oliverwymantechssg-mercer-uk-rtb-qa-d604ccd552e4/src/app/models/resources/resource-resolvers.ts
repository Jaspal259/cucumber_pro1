import { ResourceSectionKey } from './resource-section-key';
import { ResolverConstructor } from './resolver-constructor';

export type IResourceResolvers = {
  readonly [P in ResourceSectionKey]?: ResolverConstructor<ResourceSectionKey>;
};
