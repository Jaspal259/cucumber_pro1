export interface DropDownItem {
  id: string;
  itemName: string;
  originalValue: number | string;
}
