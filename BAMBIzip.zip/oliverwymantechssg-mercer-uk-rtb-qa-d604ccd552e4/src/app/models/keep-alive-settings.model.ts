export interface KeepAliveSettings {
  idleLogoutTimeoutSeconds: number;
  keepAliveIntervalSeconds: number;
  timeOut: number;
}
