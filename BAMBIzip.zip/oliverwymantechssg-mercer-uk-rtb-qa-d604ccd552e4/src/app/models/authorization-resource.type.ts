export type AuthorizationResources = {
  [P in AuthorizationResource]: boolean;
  };

export type AuthorizationResource = 'home' | 'dashboard' | 'reports' | 'admin' | 'siteresources';
