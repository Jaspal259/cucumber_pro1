export type StringKeys<T> = Extract<keyof T, string>;
