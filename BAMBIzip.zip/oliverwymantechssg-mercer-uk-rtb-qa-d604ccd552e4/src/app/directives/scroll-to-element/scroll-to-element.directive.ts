import { Directive, ElementRef, Input, AfterViewInit } from '@angular/core';

import { ScrollingService } from '../../services/scrolling.service';

@Directive({
  selector: '[bamScrollToElement]'
})
export class ScrollToElementDirective implements AfterViewInit {
  @Input() offset: number;

  constructor(private elementRef: ElementRef, private scrollingService: ScrollingService) {
  }

  ngAfterViewInit() {
    this.scrollingService.scrollToElement(this.elementRef, this.offset);
  }
}
