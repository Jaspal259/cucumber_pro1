import { ScrollToElementDirective } from './scroll-to-element.directive';

describe('ScrollToElementDirective', () => {
});
