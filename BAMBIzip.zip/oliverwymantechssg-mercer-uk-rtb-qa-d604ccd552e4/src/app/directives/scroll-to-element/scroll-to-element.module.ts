import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ScrollToElementDirective } from './scroll-to-element.directive';
import { ScrollingService } from '../../services/scrolling.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ScrollToElementDirective],
  exports: [ScrollToElementDirective],
  providers: [ScrollingService]
})
export class ScrollToElementModule { }
