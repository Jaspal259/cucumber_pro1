export interface TotalHealthcareCosts {
    topLevelLabel: string;
    secondLevelLabel: string;
    totalCost: number;
}
