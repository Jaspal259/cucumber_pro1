import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { PieChartSettings } from '../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';
import { TotalHealthcareCosts } from './models/total-healthcare-costs.model';
import { ReportDetails } from '../models/report-details.model';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { SpinnerService } from '../../../services/spinner.service';
import { TotalHealthcareCostsService } from './services/total-healthcare-costs.service';

@Component({
  selector: 'bam-total-healthcare-costs-tile',
  templateUrl: './total-healthcare-costs-tile.component.html',
  providers: [TotalHealthcareCostsService]
})
export class TotalHealthcareCostsTileComponent implements OnInit {
  loadingIndicatorKey: LoadingIndicatorSection;
  loadingSpinnerSettings: SpinnerSettings;
  costsExist: boolean;
  pieChartSettings: PieChartSettings;
  readonly resources = new ResourceProviderDictionary();
  sectionColors: KeyValueDictionary<string>;
  totalHealthcareCostsTile: ReportDetails<TotalHealthcareCosts[]>;

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private spinnerService: SpinnerService,
    private totalHealthcareCostsService: TotalHealthcareCostsService) {
      this.resources.totalHealthcareCosts = resourceRouteService.getResource(route, 'totalHealthcareCosts');
  }

  private getPieChartSettings(totalHealthcareCosts: TotalHealthcareCosts[]) {
    const sectionColors = this.totalHealthcareCostsService.getSectionColors(totalHealthcareCosts);
    return this.totalHealthcareCostsService.getPieChartSettings(totalHealthcareCosts, sectionColors);
  }

  async ngOnInit() {
    this.loadingIndicatorKey = 'dashboard_membership_count';
    this.loadingSpinnerSettings = {
      fullPageLoader: false
    };

    await this.spinnerService.show(this.loadingIndicatorKey,
      async () => {
        this.totalHealthcareCostsTile = await this.totalHealthcareCostsService.getTotalHealthcareCostsTile();
        this.pieChartSettings = this.getPieChartSettings(this.totalHealthcareCostsTile.details);
        this.costsExist = this.pieChartSettings.chartModel.parent && this.pieChartSettings.chartModel.parent.data ? true : false;
    });
  }
}
