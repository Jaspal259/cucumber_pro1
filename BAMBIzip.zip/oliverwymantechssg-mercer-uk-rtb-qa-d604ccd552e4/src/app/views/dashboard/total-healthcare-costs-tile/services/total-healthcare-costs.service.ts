import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';
import * as Highcharts from 'highcharts';

import { TotalHealthcareCosts } from '../models/total-healthcare-costs.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';
import { PieChartSettings } from '../../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { PieChartColorSettings } from '../../models/pie-chart-color-settings.model';
import { PieChartSectionService } from '../../services/pie-chart-section.service';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { DrillLevel } from '../../../../controls/charts/models/drill-level.model';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ArrayGroupService } from '../../../../services/array-group.service';
import { PieChartModel } from '../../../../controls/charts/pie-chart/models/pie-chart-model.model';
import { KeyValues } from '../../../../models/key-values.model';
import { DrilldownSettings } from '../../membership-count-tile/models/drilldown-settings.model';
import { PieChartSection } from '../../../../controls/charts/pie-chart/models/pie-chart-section.model';
import { GroupedObjectByKeys } from '../../../../models/grouped-object-by-keys.model';
import { PieChart } from '../../../../controls/charts/pie-chart/models/pie-chart.model';
import { PieDataLabels } from 'Highcharts';
import { PieChartService } from '../../../../controls/charts/pie-chart/services/pie-chart.service';

@Injectable()
export class TotalHealthcareCostsService {
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute,
    private pieChartSectionService: PieChartSectionService<TotalHealthcareCosts>,
    private dashboardApiService: DashboardApiService,
    private arrayGroupService: ArrayGroupService,
    private pieChartService: PieChartService) {
    this.resources.totalHealthcareCosts = resourceRouteService.getResource(route, 'totalHealthcareCosts');
  }

  public getSectionColors(totalHealthcareCosts: TotalHealthcareCosts[]): KeyValueDictionary<string> {
    const colorSettings: PieChartColorSettings<TotalHealthcareCosts> = {
      details: totalHealthcareCosts,
      sections: ['topLevelLabel', 'secondLevelLabel'],
      sectionColors: ['#02628c', '#0699d9', '#6ec6ec', '#ffb700', '#ff8700', '#ff3100', '#00933b', '#2aaa5e', '#40b8ec']
    };
    return this.pieChartSectionService.getSectionColors(colorSettings);
  }

  private getDrillLevels(): DrillLevel[] {
    const drillLevels = Array.apply(null, { length: 2 }).map(Number.call, Number);
    return _.map(drillLevels, (drillLevel) => {
      return {
        level: drillLevel,
        title: this.resources.totalHealthcareCosts.get(`drill_level_${drillLevel}`)
      };
    });
  }

  private getTopLevelSettings(totalHealthcareCosts: TotalHealthcareCosts[], sectionColors: KeyValueDictionary<string>)
    : DrilldownSettings<TotalHealthcareCosts> {
    return {
      groupedObjects: this.arrayGroupService.groupByMultipleFields<TotalHealthcareCosts>(totalHealthcareCosts, ['topLevelLabel']),
      sectionColors,
      childKey: 'topLevelLabel',
      drilldown: false
    };
  }

  private getPieChartSections(itemsByKey: KeyValues<TotalHealthcareCosts>, drilldownSettings
    : DrilldownSettings<TotalHealthcareCosts>): PieChartSection[] {
    return _(itemsByKey).filter((values: TotalHealthcareCosts[]) => values.length > 1)
      .map((values: TotalHealthcareCosts[]) => {
        return _.map(values, (value: TotalHealthcareCosts) => {
          return {
            name: value.secondLevelLabel,
            y: value.totalCost,
            tooltipText: `${value.secondLevelLabel}: $${Highcharts.numberFormat(value.totalCost, 2)}`,
            color: drilldownSettings.sectionColors[value.secondLevelLabel]
          };
        });
      })
      .flatten()
      .value();
  }

  private getDrilldownData(drilldownSettings: DrilldownSettings<TotalHealthcareCosts>): PieChart[] {
    if (!drilldownSettings.groupedObjects) {
      return null;
    }
    return _(drilldownSettings.groupedObjects)
      .map((groupedFields: GroupedObjectByKeys<TotalHealthcareCosts>) => {
        const itemsByKey =
          this.arrayGroupService.groupBy<TotalHealthcareCosts>(groupedFields.values, drilldownSettings.childKey);
        const sections = this.getPieChartSections(itemsByKey, drilldownSettings);
        return this.pieChartSectionService.getDrilldownData(sections, groupedFields, groupedFields.keys.length);
      })
      .filter((pieChart: PieChart) => pieChart != null)
      .value();
  }

  private getDrilldowns(costs: TotalHealthcareCosts[], sectionColors: KeyValueDictionary<string>): PieChart[] {
    return this.getDrilldownData(this.getTopLevelSettings(costs, sectionColors));
  }

  private sumCosts(costs: TotalHealthcareCosts[]): number {
    return _.sumBy(costs, (e: TotalHealthcareCosts) => e.totalCost);
  }

  private getParentData(groupedCosts: KeyValues<TotalHealthcareCosts>, sectionColors: KeyValueDictionary<string>): PieChartSection[] {
    if (!groupedCosts) {
      return null;
    }
    return _.map(groupedCosts, (groupedFields: TotalHealthcareCosts[], key: string) => {
      const groupedFieldsSum = this.sumCosts(groupedFields);
      const section: PieChartSection = {
        name: key,
        drilldown: key.toLowerCase(),
        y: groupedFieldsSum,
        tooltipText: `${key}: $${Highcharts.numberFormat(groupedFieldsSum, 2)}`,
        color: sectionColors[key]
      };
      return section;
    });
  }

  private getChartDataLabels(): PieDataLabels {
    return {
      enabled: true,
      distance: 30,
      padding: 0,
      crop: false,
      format: '<span style="color:#fff">{point.name}:</span><br/><span style="color:#fff">{point.y}</span>',
      style: this.pieChartService.dataLabelStyle
    };
  }

  private getTotalHealthcareCostsPieChartData(totalHealthcareCosts: TotalHealthcareCosts[], sectionColors: KeyValueDictionary<string>)
    : PieChartModel {
    const parentData =
      this.getParentData(this.arrayGroupService.groupBy<TotalHealthcareCosts>(totalHealthcareCosts, 'topLevelLabel'), sectionColors);

    const all = this.resources.totalHealthcareCosts.get('all');
    const pieChartData: PieChartModel = {
      parent: {
        name: all,
        id: all.toLowerCase(),
        data: parentData
      },
      dataLabelsFormat: '<span style="color:#5F6A72">{point.name}:</span><br/><span style="color:#5F6A72">{percentage:.1f}%</span>',
      drilldowns: this.getDrilldowns(totalHealthcareCosts, sectionColors),
      dataLabels: this.getChartDataLabels()
    };

    return pieChartData;
  }

  public getPieChartSettings(totalHealthcareCosts: TotalHealthcareCosts[], sectionColors: KeyValueDictionary<string>): PieChartSettings {
    return {
      drillLevels: this.getDrillLevels(),
      chartModel: this.getTotalHealthcareCostsPieChartData(totalHealthcareCosts, sectionColors)
    };
  }

  public async getTotalHealthcareCostsTile() {
    return await this.dashboardApiService.getTotalHealthcareCostsTile();
  }
}
