import { TestBed, inject } from '@angular/core/testing';

import { TotalHealthcareCostsService } from './total-healthcare-costs.service';

describe('TotalHealthcareCostsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TotalHealthcareCostsService]
    });
  });

  it('should be created', inject([TotalHealthcareCostsService], (service: TotalHealthcareCostsService) => {
    expect<any>(service).toBeTruthy();
  }));
});
