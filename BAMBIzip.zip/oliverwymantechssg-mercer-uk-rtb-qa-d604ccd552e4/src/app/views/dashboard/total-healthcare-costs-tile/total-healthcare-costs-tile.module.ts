import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TotalHealthcareCostsTileComponent } from './total-healthcare-costs-tile.component';
import { DashboardTileModule } from '../dashboard-tile/dashboard-tile.module';
import { ChartsModule } from '../../../controls/charts/charts.module';
import { BreadcrumbsModule } from '../../../controls/breadcrumbs/breadcrumbs.module';
import { SpinnerModule } from '../../../controls/spinner/spinner.module';
import { TotalHealthcareCostsResourceResolver } from '../resolvers/total-healthcare-costs-resource-resolver';

@NgModule({
  imports: [
    CommonModule,
    DashboardTileModule,
    ChartsModule,
    BreadcrumbsModule,
    SpinnerModule
  ],
  declarations: [TotalHealthcareCostsTileComponent],
  exports: [TotalHealthcareCostsTileComponent],
  providers: [TotalHealthcareCostsResourceResolver]
})
export class TotalHealthcareCostsTileModule { }
