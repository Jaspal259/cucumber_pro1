import { Component, OnInit, ViewEncapsulation } from '@angular/core';

import { BreadcrumbSettings } from '../../controls/breadcrumbs/breadcrumb-settings';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'bam-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {
  membershipBreadcrumbs: BreadcrumbSettings;
  readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    private resourceRouteService: ResourceRouteService) {
    this.resources.dashboard = resourceRouteService.getResource(route, 'dashboard');
  }

  ngOnInit(): void {
  }
}
