import { Injectable } from '@angular/core';
import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable()
export class MembershipCountResourceResolver extends BaseResourceResolver<'membershipCount'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'membershipCount');
  }
}
