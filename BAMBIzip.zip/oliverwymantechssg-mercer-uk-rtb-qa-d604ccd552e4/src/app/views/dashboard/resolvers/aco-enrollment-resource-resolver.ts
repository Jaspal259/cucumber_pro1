import { Injectable } from '@angular/core';
import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable()
export class AcoEnrollmentResourceResolver extends BaseResourceResolver<'acoEnrollment'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'acoEnrollment');
  }
}
