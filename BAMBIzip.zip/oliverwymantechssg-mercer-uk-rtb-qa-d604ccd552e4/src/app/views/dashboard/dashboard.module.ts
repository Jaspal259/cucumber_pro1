import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { PageHeaderModule } from '../../controls/page-header/page-header.module';
import { DashboardResourceResolver } from './resolvers/dashboard-resource-resolver';
import { MembershipCountTileModule } from './membership-count-tile/membership-count-tile.module';
import { BreadcrumbsModule } from '../../controls/breadcrumbs/breadcrumbs.module';
import { ActiveEnrollmentTileModule } from './active-enrollment-tile/active-enrollment-tile.module';
import { AcoEnrollmentTileModule } from './aco-enrollment-tile/aco-enrollment-tile.module';
import { PieChartSectionService } from './services/pie-chart-section.service';
import { WelfareEnrollmentTileModule } from './welfare-enrollment-tile/welfare-enrollment-tile.module';
import { CheckboxSubscriptionService } from './services/checkbox-subscription.service';
import { TotalHealthcareCostsTileModule } from './total-healthcare-costs-tile/total-healthcare-costs-tile.module';
import { PlaceholderTileModule } from './placeholder-tile/placeholder-tile.module';

@NgModule({
  imports: [
    CommonModule,
    PageHeaderModule,
    AcoEnrollmentTileModule,
    MembershipCountTileModule,
    BreadcrumbsModule,
    ActiveEnrollmentTileModule,
    WelfareEnrollmentTileModule,
    TotalHealthcareCostsTileModule,
    PlaceholderTileModule
  ],
  declarations: [DashboardComponent],
  exports: [DashboardComponent],
  providers: [
    DashboardResourceResolver,
    PieChartSectionService,
    CheckboxSubscriptionService
  ]
})
export class DashboardModule { }
