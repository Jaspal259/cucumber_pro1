import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardCheckboxesComponent } from './dashboard-checkboxes.component';

describe('DashboardCheckboxesComponent', () => {
  let component: DashboardCheckboxesComponent;
  let fixture: ComponentFixture<DashboardCheckboxesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardCheckboxesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardCheckboxesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
