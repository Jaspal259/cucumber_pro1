import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardCheckboxesComponent } from './dashboard-checkboxes.component';
import { CheckboxSubscriptionService } from '../services/checkbox-subscription.service';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [DashboardCheckboxesComponent],
  exports: [DashboardCheckboxesComponent]
})
export class DashboardCheckboxesModule { }
