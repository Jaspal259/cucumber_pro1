import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';

import { DashboardCheckboxResources } from './models/dashboard-checkbox-resources.model';
import { CheckboxSubscriptionService } from '../services/checkbox-subscription.service';
import { CheckboxesEnabled as CheckboxEnabled } from './models/checkboxes-enabled.model';

@Component({
  selector: 'bam-dashboard-checkboxes',
  templateUrl: './dashboard-checkboxes.component.html',
  styleUrls: ['./dashboard-checkboxes.component.scss']
})
export class DashboardCheckboxesComponent implements OnInit {
  @Input() checkboxResources: DashboardCheckboxResources<string>;
  checkboxesEnabled: CheckboxEnabled[] = [];

  constructor(private subscriptionService: CheckboxSubscriptionService<string>) { }

  ngOnInit() {
    _.forEach(this.checkboxResources.resourceNames, (resourceName: string) => {
      this.checkboxesEnabled.push({ resourceName, enabled: true });
    });
  }

  onCheck(resourceName: string, event) {
    const checked = event.target.checked;
    this.subscriptionService.triggerCheck(resourceName, checked);
    _.forEach(this.checkboxesEnabled, (checkboxEnabled: CheckboxEnabled) => {
      if (resourceName !== checkboxEnabled.resourceName) {
        checkboxEnabled.enabled = checked;
      }
    });
  }

  checkboxDisabled(resourceName: string) {
    if (!this.checkboxesEnabled) {
      return false;
    }
    const checkboxEnabled = _.find(this.checkboxesEnabled,
      (item: CheckboxEnabled) => item.resourceName === resourceName);
    return !checkboxEnabled.enabled;
  }
}
