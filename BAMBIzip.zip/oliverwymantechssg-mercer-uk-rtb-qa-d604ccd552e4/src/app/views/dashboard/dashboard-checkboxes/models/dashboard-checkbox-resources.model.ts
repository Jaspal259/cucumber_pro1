import { ResourceProvider } from '../../../../services/resources/resource-provider';

export interface DashboardCheckboxResources<T> {
    filterResourceName: string;
    resources: ResourceProvider;
    resourceNames: T[];
}
