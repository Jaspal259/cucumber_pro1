export interface CheckboxesEnabled {
    resourceName: string;
    enabled: boolean;
}
