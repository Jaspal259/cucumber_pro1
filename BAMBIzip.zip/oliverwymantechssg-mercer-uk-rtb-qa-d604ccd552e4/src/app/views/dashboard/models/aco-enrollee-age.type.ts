export type AcoEnrolleeAge = 'under_40' | 'over_40';
