import { ActiveEnrollment } from '../active-enrollment-tile/models/active-enrollment.model';
import { AcoEnrollment } from '../aco-enrollment-tile/models/aco-enrollment.model';
import { MembershipCount } from '../membership-count-tile/models/membership-count.model';
import { TotalHealthcareCosts } from '../total-healthcare-costs-tile/models/total-healthcare-costs.model';
import { LeaveOfAbsenceEnrollment } from '../welfare-enrollment-tile/models/leave-of-absence-enrollment.model';

export type DashboardTile = ActiveEnrollment | AcoEnrollment | MembershipCount | LeaveOfAbsenceEnrollment | TotalHealthcareCosts;
