import { DashboardTile } from './dashboard-tile.type';

export interface ReportDetails<T extends DashboardTile | DashboardTile[]> {
  details: T;
  reportingDate: number;
}
