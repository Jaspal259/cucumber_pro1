export interface PieChartColorSettings<T> {
  details: T[];
  sections: (keyof T)[];
  sectionColors: string[];
}
