import { Injectable } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { ReportDetails } from '../models/report-details.model';
import { ActiveEnrollment } from '../active-enrollment-tile/models/active-enrollment.model';
import { MembershipCount } from '../membership-count-tile/models/membership-count.model';
import { AcoEnrollment } from '../aco-enrollment-tile/models/aco-enrollment.model';
import { TotalHealthcareCosts } from '../total-healthcare-costs-tile/models/total-healthcare-costs.model';
import { LeaveOfAbsenceEnrollment } from '../welfare-enrollment-tile/models/leave-of-absence-enrollment.model';

@Injectable()
export class DashboardApiService {
  private readonly controllerName = 'dashboard';

  constructor(
    private apiService: ApiService
  ) { }

  async getMembershipCountTile(): Promise<ReportDetails<MembershipCount[]>> {
    return await this.apiService.get<ReportDetails<MembershipCount[]>>(`${this.controllerName}/GetMembershipCount`);
  }

  async getActiveEnrollmentTile(): Promise<ReportDetails<ActiveEnrollment[]>> {
    return await this.apiService.get<ReportDetails<ActiveEnrollment[]>>(`${this.controllerName}/GetActiveEnrollment`);
  }

  async getAcoEnrollmentTile(): Promise<ReportDetails<AcoEnrollment[]>> {
    return await this.apiService.get<ReportDetails<AcoEnrollment[]>>(`${this.controllerName}/GetAcoEnrollment`);
  }

  async getWelfareEnrollmentTile(): Promise<ReportDetails<LeaveOfAbsenceEnrollment[]>> {
    return await this.apiService.get<ReportDetails<LeaveOfAbsenceEnrollment[]>>(`${this.controllerName}/GetWelfareEnrollment`);
  }

  async getTotalHealthcareCostsTile(): Promise<ReportDetails<TotalHealthcareCosts[]>> {
    return await this.apiService.get<ReportDetails<TotalHealthcareCosts[]>>(`${this.controllerName}/GetTotalHealthcareCosts`);
  }
}
