import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';

@Injectable()
export class CheckboxSubscriptionService<T extends string> {
  private subjects: KeyValueDictionary<Subject<boolean>> = {};

  constructor() { }

  subscribeToCheck(name: T, subscriptionCallback: (checked: boolean) => void) {
    this.subjects[name] = new Subject<boolean>();
    return this.subjects[name]
      .asObservable()
      .subscribe((checked: boolean) => {
        subscriptionCallback(checked);
    });
  }

  triggerCheck(name: T, checked: boolean) {
    this.subjects[name].next(checked);
  }
}
