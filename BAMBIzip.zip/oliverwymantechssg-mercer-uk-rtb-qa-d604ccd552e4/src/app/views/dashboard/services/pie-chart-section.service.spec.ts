import { TestBed, inject } from '@angular/core/testing';

import { PieChartSectionService } from './pie-chart-section.service';
import { PieChartColorSettings } from '../models/pie-chart-color-settings.model';
import { MembershipCount } from '../membership-count-tile/models/membership-count.model';
import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';

fdescribe('PieChartSectionService', () => {
  let expectedSectionColors: KeyValueDictionary<string>;

  function setExpectedSectionColors() {
    expectedSectionColors = {};
    expectedSectionColors['Population1'] = expectedSectionColors['Union1'] = expectedSectionColors['MemberType1'] = '#02628C';
    expectedSectionColors['Population2'] = expectedSectionColors['Union2'] = expectedSectionColors['MemberType2'] = '#21BAFF';
  }

  beforeEach(() => {
    setExpectedSectionColors();

    TestBed.configureTestingModule({
      providers: [PieChartSectionService]
    });
  });

  it('should be created', inject([PieChartSectionService], (service: PieChartSectionService<MembershipCount>) => {
    expect<any>(service).toBeTruthy();
  }));

  it('#getSectionColors should return expected colors for distinct values', inject([PieChartSectionService],
    (service: PieChartSectionService<MembershipCount>) => {
      const colorSettings: PieChartColorSettings<MembershipCount> = {
        details: [{
          population: 'Population1',
          union: 'Union1',
          memberType: 'MemberType1',
          memberCount: 100
        }, {
          population: 'Population2',
          union: 'Union2',
          memberType: 'MemberType2',
          memberCount: 15
        }],
        sections: ['population', 'union', 'memberType'],
        sectionColors: ['#02628C', '#21BAFF', '#0698D9']
      };

      const actualSectionColors = service.getSectionColors(colorSettings);

      expect<any>(actualSectionColors).toEqual(expectedSectionColors);
  }));

  it('#getSectionColors should return the same colors for the same values', inject([PieChartSectionService],
    (service: PieChartSectionService<MembershipCount>) => {
      const colorSettings: PieChartColorSettings<MembershipCount> = {
        details: [{
          population: 'Population1',
          union: 'Union1',
          memberType: 'MemberType1',
          memberCount: 100
        }, {
          population: 'Population2',
          union: 'Union1',
          memberType: 'MemberType2',
          memberCount: 15
        }, {
          population: 'Population2',
          union: 'Union2',
          memberType: 'MemberType2',
          memberCount: 70
        }],
        sections: ['population', 'union', 'memberType'],
        sectionColors: ['#02628C', '#21BAFF', '#0698D9']
      };

      expect<any>(service.getSectionColors(colorSettings)).toEqual(expectedSectionColors);
  }));
});
