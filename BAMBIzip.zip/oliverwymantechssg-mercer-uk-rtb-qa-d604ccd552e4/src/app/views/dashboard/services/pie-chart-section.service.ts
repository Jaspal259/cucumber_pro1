import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';
import { PieChartColorSettings } from '../models/pie-chart-color-settings.model';
import { PieChartSection } from '../../../controls/charts/pie-chart/models/pie-chart-section.model';
import { GroupedObjectByKeys } from '../../../models/grouped-object-by-keys.model';
import { PieChart } from '../../../controls/charts/pie-chart/models/pie-chart.model';

@Injectable()
export class PieChartSectionService<T> {
  getSectionColors(colorSettings: PieChartColorSettings<T>): KeyValueDictionary<string> {
    const sectionColors: KeyValueDictionary<string> = {};

    _.forEach(colorSettings.sections, (key: keyof T) => {
      const sectionTitles = _(colorSettings.details).map(key).uniq().value();
      _.forEach(sectionTitles, (title: string, index: number) => {
        sectionColors[title] = colorSettings.sectionColors[index];
      });
    });

    return sectionColors;
  }

  getDrilldownData(sections: PieChartSection[], groupedFields: GroupedObjectByKeys<T>, keyCount: number): PieChart {
    return sections.length === 0 ?
      null : {
        name: groupedFields.keys[keyCount - 1],
        id: (keyCount > 1
          ? groupedFields.keys[keyCount - 2] + groupedFields.keys[keyCount - 1]
          : groupedFields.keys[keyCount - 1]).toLowerCase(),
        data: sections
      };
  }
}
