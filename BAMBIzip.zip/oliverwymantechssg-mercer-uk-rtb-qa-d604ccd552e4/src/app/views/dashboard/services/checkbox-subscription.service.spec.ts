import { TestBed, inject } from '@angular/core/testing';

import { CheckboxSubscriptionService } from './checkbox-subscription.service';
import { Gender } from '../models/gender.type';

describe('CheckboxSubscriptionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CheckboxSubscriptionService]
    });
  });

  it('should be created', inject([CheckboxSubscriptionService], (service: CheckboxSubscriptionService<Gender>) => {
    expect<any>(service).toBeTruthy();
  }));
});
