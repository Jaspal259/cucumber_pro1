import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';

import { PieChartModel } from '../../../../controls/charts/pie-chart/models/pie-chart-model.model';
import { MembershipCount } from '../models/membership-count.model';
import { PieChartSection } from '../../../../controls/charts/pie-chart/models/pie-chart-section.model';
import { PieChart } from '../../../../controls/charts/pie-chart/models/pie-chart.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';
import { GroupedObjectByKeys } from '../../../../models/grouped-object-by-keys.model';
import { ArrayGroupService } from '../../../../services/array-group.service';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { DrillLevel } from '../../../../controls/charts/models/drill-level.model';
import { PieChartSettings } from '../../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { KeyValues } from '../../../../models/key-values.model';
import { DrilldownSettings } from '../models/drilldown-settings.model';
import { PieChartColorSettings } from '../../models/pie-chart-color-settings.model';
import { PieChartSectionService } from '../../services/pie-chart-section.service';

@Injectable()
export class MembershipCountService {
  readonly resources = new ResourceProviderDictionary();

  constructor(private dashboardApiService: DashboardApiService,
    private arrayGroupService: ArrayGroupService,
    private pieChartSectionService: PieChartSectionService<MembershipCount>,
    resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
    this.resources.membershipCount = resourceRouteService.getResource(route, 'membershipCount');
  }

  async getMembershipCountTile() {
    return await this.dashboardApiService.getMembershipCountTile();
  }

  private getDrillLevels(): DrillLevel[] {
    const drillLevels = Array.apply(null, { length: 3 }).map(Number.call, Number);
    return _.map(drillLevels, (drillLevel) => {
      return {
        level: drillLevel,
        title: this.resources.membershipCount.get(`drill_level_${drillLevel}`)
      };
    });
  }

  getSectionColors(membershipCounts: MembershipCount[]) {
    const colorSettings: PieChartColorSettings<MembershipCount> = {
      details: membershipCounts,
      sections: ['population', 'union', 'memberType'],
      sectionColors: ['#02628C', '#21BAFF', '#0698D9']
    };
    return this.pieChartSectionService.getSectionColors(colorSettings);
  }

  getPieChartSettings(membershipCounts: MembershipCount[], sectionColors: KeyValueDictionary<string>): PieChartSettings {
    return {
      drillLevels: this.getDrillLevels(),
      chartModel: this.getMembershipCountPieChartData(membershipCounts, sectionColors)
    };
  }

  private getUnionSettings(membershipCounts: MembershipCount[], sectionColors: KeyValueDictionary<string>)
  : DrilldownSettings<MembershipCount> {
    return {
      groupedObjects: this.arrayGroupService.groupByMultipleFields<MembershipCount>(membershipCounts, ['union']),
      sectionColors,
      childKey: 'population',
      drilldown: true
    };
  }

  private getPopulationSettings(membershipCounts: MembershipCount[], sectionColors: KeyValueDictionary<string>)
  : DrilldownSettings<MembershipCount> {
    return {
      groupedObjects: this.arrayGroupService.groupByMultipleFields<MembershipCount>(membershipCounts, ['union', 'population']),
      sectionColors,
      childKey: 'memberType',
      drilldown: false
    };
  }

  private getDrilldowns(membershipCounts: MembershipCount[], sectionColors: KeyValueDictionary<string>): PieChart[] {
    return _.union(
      this.getDrilldownData(this.getUnionSettings(membershipCounts, sectionColors)),
      this.getDrilldownData(this.getPopulationSettings(membershipCounts, sectionColors))
    );
  }

  private getMembershipCountPieChartData(membershipCounts: MembershipCount[], sectionColors: KeyValueDictionary<string>): PieChartModel {
    const parentData =
      this.getParentData(this.arrayGroupService.groupBy<MembershipCount>(membershipCounts, 'union'), sectionColors);

    const all = this.resources.membershipCount.get('all');
    const pieChartData: PieChartModel = {
      parent: {
        name: all,
        id: all.toLowerCase(),
        data: parentData
      },
      dataLabelsFormat: '<span style="color:#fff">{point.name}:</span><br/><span style="color:#fff">{point.y:,.0f}</span>',
      drilldowns: this.getDrilldowns(membershipCounts, sectionColors)
    };

    return pieChartData;
  }

  private sum(membershipCount: MembershipCount[]): number {
    return _.sumBy(membershipCount, v => v.memberCount);
  }

  private getTooltipText(sectionName: string, parentSectionName?: string, chartLevel?: string): string {
    const formattedSectionName = _.replace(sectionName.toLowerCase(), ' ', '_');

    return (chartLevel === 'memberType' && parentSectionName && parentSectionName.toLowerCase().includes('retiree')) ?
      this.resources.membershipCount.get(`tooltip_retiree_${formattedSectionName}`) :
      this.resources.membershipCount.get(`tooltip_${formattedSectionName}`);
  }

  private getDrilldownData(drilldownSettings: DrilldownSettings<MembershipCount>): PieChart[] {
    if (!drilldownSettings.groupedObjects) {
      return null;
    }
    return _.map(drilldownSettings.groupedObjects, (groupedFields: GroupedObjectByKeys<MembershipCount>) => {
      const keyCount = groupedFields.keys.length;
      const counts = this.arrayGroupService.groupBy<MembershipCount>(groupedFields.values, drilldownSettings.childKey);
      const data: PieChartSection[] = _.map(counts, (value, groupedKey) => {
        const parentSectionName = groupedFields.keys[keyCount - 1];
        return {
          name: groupedKey,
          drilldown: drilldownSettings.drilldown ? (parentSectionName + groupedKey).toLowerCase() : null,
          y: this.sum(value),
          tooltipText: this.getTooltipText(groupedKey, parentSectionName, drilldownSettings.childKey),
          color: drilldownSettings.sectionColors[groupedKey]
          };
      });
      return this.pieChartSectionService.getDrilldownData(data, groupedFields, keyCount);
    });
  }

  private getParentData(groupedMembershipCount: KeyValues<MembershipCount>, sectionColors: KeyValueDictionary<string>): PieChartSection[] {
    if (!groupedMembershipCount) {
      return null;
    }
    return _.map(groupedMembershipCount, (groupedFields: MembershipCount[], key: string) => {
      const section: PieChartSection = {
        name: key,
        drilldown: key.toLowerCase(),
        y: this.sum(groupedFields),
        tooltipText: this.getTooltipText(key),
        color: sectionColors[key]
      };
      return section;
    });
  }
}
