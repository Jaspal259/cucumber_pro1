import { TestBed, inject } from '@angular/core/testing';

import { MembershipCountService } from './membership-count.service';

describe('MembershipCountService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MembershipCountService]
    });
  });

  it('should be created', inject([MembershipCountService], (service: MembershipCountService) => {
    expect<any>(service).toBeTruthy();
  }));
});
