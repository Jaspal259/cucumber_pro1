export interface MembershipCount {
  population: string;
  union: string;
  memberType: string;
  memberCount: number;
}
