import { GroupedObjectByKeys } from '../../../../models/grouped-object-by-keys.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';

export interface DrilldownSettings<T> {
  groupedObjects: GroupedObjectByKeys<T>[];
  sectionColors: KeyValueDictionary<string>;
  childKey: keyof T;
  drilldown: boolean;
}
