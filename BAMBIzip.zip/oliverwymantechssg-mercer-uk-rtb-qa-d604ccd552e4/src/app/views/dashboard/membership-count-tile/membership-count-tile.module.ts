import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MembershipCountTileComponent } from './membership-count-tile.component';
import { BreadcrumbsModule } from '../../../controls/breadcrumbs/breadcrumbs.module';
import { DashboardTileModule } from '../dashboard-tile/dashboard-tile.module';
import { ChartsModule } from '../../../controls/charts/charts.module';
import { ArrayGroupService } from '../../../services/array-group.service';
import { SpinnerModule } from '../../../controls/spinner/spinner.module';
import { MembershipCountResourceResolver } from '../resolvers/membership-count-resource-resolver';
import { DateTimeService } from '../../../services/date-time.service';
import { DashboardApiService } from '../services/dashboard-api.service';

@NgModule({
  imports: [
    CommonModule,
    DashboardTileModule,
    ChartsModule,
    BreadcrumbsModule,
    SpinnerModule
  ],
  declarations: [MembershipCountTileComponent],
  providers: [DashboardApiService, ArrayGroupService, MembershipCountResourceResolver, DateTimeService],
  exports: [MembershipCountTileComponent]
})
export class MembershipCountTileModule { }
