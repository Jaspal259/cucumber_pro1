import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { MembershipCountService } from './services/membership-count.service';
import { SpinnerService } from '../../../services/spinner.service';
import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { PieChartSettings } from '../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';
import { MembershipCount } from './models/membership-count.model';
import { ReportDetails } from '../models/report-details.model';

@Component({
  selector: 'bam-membership-count-tile',
  templateUrl: './membership-count-tile.component.html',
  providers: [MembershipCountService]
})
export class MembershipCountTileComponent implements OnInit {
  loadingIndicatorKey: LoadingIndicatorSection;
  loadingSpinnerSettings: SpinnerSettings;
  membershipCountsExist: boolean;
  pieChartSettings: PieChartSettings;
  readonly resources = new ResourceProviderDictionary();
  sectionColors: KeyValueDictionary<string>;
  membershipCountTile: ReportDetails<MembershipCount[]>;

  constructor(route: ActivatedRoute,
    private resourceRouteService: ResourceRouteService,
    private membershipCountService: MembershipCountService,
    private spinnerService: SpinnerService) {
    this.resources.membershipCount = resourceRouteService.getResource(route, 'membershipCount');
  }

  private getPieChartSettings(membershipCounts: MembershipCount[]) {
    const sectionColors = this.membershipCountService.getSectionColors(membershipCounts);
    return this.membershipCountService.getPieChartSettings(membershipCounts, sectionColors);
  }

  async ngOnInit() {
    this.loadingIndicatorKey = 'dashboard_membership_count';
    this.loadingSpinnerSettings = {
      fullPageLoader: false
    };

  await this.spinnerService.show(this.loadingIndicatorKey,
    async () => {
      this.membershipCountTile = await this.membershipCountService.getMembershipCountTile();
      this.pieChartSettings = this.getPieChartSettings(this.membershipCountTile.details);
      this.membershipCountsExist = this.pieChartSettings.chartModel.parent && this.pieChartSettings.chartModel.parent.data ? true : false;
    });
  }
}
