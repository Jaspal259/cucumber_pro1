import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MembershipCountTileComponent } from './membership-count-tile.component';

describe('MembershipCountTileComponent', () => {
  let component: MembershipCountTileComponent;
  let fixture: ComponentFixture<MembershipCountTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MembershipCountTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembershipCountTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
