import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../../controls/icon/icon.module';
import { PlaceholderTileComponent } from './placeholder-tile.component';

@NgModule({
  imports: [
    CommonModule,
    IconModule
  ],
  declarations: [PlaceholderTileComponent],
  exports: [PlaceholderTileComponent],
  providers: []
})
export class PlaceholderTileModule { }
