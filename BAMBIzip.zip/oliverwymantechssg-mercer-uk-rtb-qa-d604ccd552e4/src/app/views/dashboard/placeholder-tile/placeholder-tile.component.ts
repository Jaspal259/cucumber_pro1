import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-placeholder-tile',
  templateUrl: './placeholder-tile.component.html',
  styleUrls: ['./placeholder-tile.component.scss']
})
export class PlaceholderTileComponent implements OnInit {

  @Input() title: string;
  @Input() icon: 'pie_hart';

  constructor() { }

  ngOnInit() {
  }

}
