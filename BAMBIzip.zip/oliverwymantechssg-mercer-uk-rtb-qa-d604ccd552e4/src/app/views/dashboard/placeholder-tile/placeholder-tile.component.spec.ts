import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceholderTileComponent } from './placeholder-tile.component';

describe('PlaceholderTileComponent', () => {
  let component: PlaceholderTileComponent;
  let fixture: ComponentFixture<PlaceholderTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaceholderTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceholderTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
