import { Injectable } from '@angular/core';
import { TimeoutService } from '../../../../services/timeout.service';
import { ColumnGroupChart } from '../../../../controls/charts/models/column-group-chart.model';

@Injectable()
export class PercentageColumnChartFakeService {
  constructor(private timeoutService: TimeoutService) {}

  async createFakeColumnChart(timeout): Promise<ColumnGroupChart> {
    await this.timeoutService.timeout(timeout);

    return {
      chartTitle: '',
      categories: [
        'Disability',
        'Education',
        'FMLA',
        'Military',
        'Personal'
      ],
      chartGroups: [{
        title: '',
        series: [{
          title: `Nonunion`,
          values: [57.555, 21, 3.4, 10.9999, 29]
        }]
      }, {
        title: '',
        series: [{
          title: `Union`,
          values: [57.588, 1000, 3.9, 5.4444, 20]
        }]
      }]
    };
  }
}
