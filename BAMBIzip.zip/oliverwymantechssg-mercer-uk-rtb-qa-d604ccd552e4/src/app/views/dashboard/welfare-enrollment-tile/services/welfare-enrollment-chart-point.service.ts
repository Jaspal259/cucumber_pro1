import * as _ from 'lodash/index';
import { Injectable } from '@angular/core';
import { LeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';
import { ChartPoint } from '../../../../controls/charts/models/chart-point.model';
import { WelfareEnrollmentCalculationService } from './welfare-enrollment-calculations.service';
import { LeaveOfAbsenceEnrollment as ILeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';

@Injectable()
export class WelfareEnrollmentChartPointService {

  constructor(private welfareEnrollmentCalculationService: WelfareEnrollmentCalculationService<ILeaveOfAbsenceEnrollment>) { }

  getChartPoints(absenceEnrollment: LeaveOfAbsenceEnrollment[]): ChartPoint[] {
    const groupedEnrollment = _.groupBy(absenceEnrollment, (e: LeaveOfAbsenceEnrollment) => e.leaveType);
    const subcategories = _(absenceEnrollment).map((e: LeaveOfAbsenceEnrollment) => e.isUnion).uniq().value();
    const points: ChartPoint[] = [];

    _(groupedEnrollment).forEach((enrollment: LeaveOfAbsenceEnrollment[], leaveType) => {
      const subPoints = _(subcategories).map((subcategory: string) => {
          const point: ChartPoint = {
            seriesName: subcategory,
            category: leaveType,
            value: this.welfareEnrollmentCalculationService.filterAndSumByKey(enrollment,
              'isUnion',
              subcategory,
              'onLeave')
          };
          return point;
        })
        .value();

      points.push(...subPoints);
    });

    return points;
  }
}
