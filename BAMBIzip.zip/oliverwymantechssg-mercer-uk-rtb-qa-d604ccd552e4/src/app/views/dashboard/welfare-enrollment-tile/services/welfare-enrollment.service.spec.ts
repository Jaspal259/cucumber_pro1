import { TestBed, inject } from '@angular/core/testing';

import { WelfareEnrollmentService } from './welfare-enrollment.service';

describe('WelfareEnrollmentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WelfareEnrollmentService]
    });
  });

  it('should be created', inject([WelfareEnrollmentService], (service: WelfareEnrollmentService) => {
    expect<any>(service).toBeTruthy();
  }));
});
