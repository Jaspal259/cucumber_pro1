import { Injectable } from '@angular/core';
import * as _ from 'lodash/index';
import { ReportDetails } from '../../models/report-details.model';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { ColumnGroupChart } from '../../../../controls/charts/models/column-group-chart.model';
import { ResourceProvider } from '../../../../services/resources/resource-provider';
import { GenderFilters } from '../models/gender-filters.model';
import { LeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';
import { PercentageColumnChartService } from './percentage-column-chart.service';
import { WelfareEnrollmentCalculationService } from './welfare-enrollment-calculations.service';
import { TotalEmployeeCounts } from '../models/total-employee-counts.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';
import { ChartPoint } from '../../../../controls/charts/models/chart-point.model';
import { ColumnChartSettings } from '../models/column-chart-settings.model';
import { WelfareEnrollmentChartPointService } from './welfare-enrollment-chart-point.service';


@Injectable()
export class WelfareEnrollmentService {

  constructor(private dashboardApiService: DashboardApiService,
    private chartService: PercentageColumnChartService<LeaveOfAbsenceEnrollment>,
    private welfareEnrollmentCalculationService: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>,
    private welfareEnrollmentChartPointService: WelfareEnrollmentChartPointService) { }

  async getWelfareEnrollmentTile(): Promise<ReportDetails<LeaveOfAbsenceEnrollment[]>> {
    return await this.dashboardApiService.getWelfareEnrollmentTile();
  }

  async createColumnChart(welfareEnrollment: LeaveOfAbsenceEnrollment[], resources: ResourceProvider, genderFilters: GenderFilters)
    : Promise<ColumnGroupChart> {
    const itemsByGender = this.getItemsByGender(welfareEnrollment, genderFilters, this.updateOnLeaveByGender);
    const chartSettings: ColumnChartSettings<LeaveOfAbsenceEnrollment> = {
      items: itemsByGender,
      totalCounts: this.getTotalCounts(itemsByGender),
      categoryFieldName: 'leaveType',
      subcategoryFieldName: 'isUnion',
      valueFieldName: 'onLeave'
    };
    const groupedEnrollment = this.chartService.getGroupedPercentageValues(chartSettings);
    return this.chartService.createColumnChart(groupedEnrollment, 'onLeave', resources,
      this.welfareEnrollmentChartPointService.getChartPoints(chartSettings.items));
  }

  private filterTotalEmployeeCounts(items: TotalEmployeeCounts[], gender: string): TotalEmployeeCounts[] {
    return _.filter(items, (item: TotalEmployeeCounts) => item.gender === gender);
  }

  private updateOnLeaveByGender(items: LeaveOfAbsenceEnrollment[], gender: string): LeaveOfAbsenceEnrollment[] {
    return _.map(items, (item: LeaveOfAbsenceEnrollment) => {
      if (item.gender === gender) {
        return item;
      }
      const newItem = _.cloneDeep(item);
      newItem.onLeave = 0;
      return newItem;
    });
  }

  private getItemsByGender<T>(items: T[], genderFilters: GenderFilters, getItems: (items: T[], gender: string) => T[]): T[] {
    const maleOnly = genderFilters.male && !genderFilters.female;
    const femaleOnly = !genderFilters.male && genderFilters.female;

    return maleOnly ? getItems(items, 'M') : femaleOnly ? getItems(items, 'F') : items;
  }

  private getTotalCounts(leaveOnAbsenceEnrollment: LeaveOfAbsenceEnrollment[]): KeyValueDictionary<number> {
    const totalCounts: KeyValueDictionary<number> = {};
    totalCounts['Union'] =
      this.welfareEnrollmentCalculationService.filterAndSumByKey(leaveOnAbsenceEnrollment, 'isUnion', 'Union', 'onLeave');
    totalCounts['Nonunion'] =
      this.welfareEnrollmentCalculationService.filterAndSumByKey(leaveOnAbsenceEnrollment, 'isUnion', 'Nonunion', 'onLeave');

    return totalCounts;
  }
}
