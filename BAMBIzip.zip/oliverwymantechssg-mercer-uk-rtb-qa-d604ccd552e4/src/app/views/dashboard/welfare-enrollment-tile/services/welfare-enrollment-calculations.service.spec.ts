import { TestBed, inject } from '@angular/core/testing';
import { WelfareEnrollmentCalculationService } from './welfare-enrollment-calculations.service';
import { LeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';

fdescribe('WelfareEnrollmentCalculationService', () => {
  const items: LeaveOfAbsenceEnrollment[] = [{
    isUnion: 'Union',
    gender: 'b',
    leaveType: 'c',
    onLeave: 1
  },
  {
    isUnion: 'Union',
    gender: 'e',
    leaveType: 'c',
    onLeave: 2
  },
  {
    isUnion: 'Nonunion',
    gender: 'b',
    leaveType: 'c',
    onLeave: 7
    }];

  const itemsWithEmptyValue: LeaveOfAbsenceEnrollment[] = [{
      isUnion: 'Union',
      gender: 'b',
      leaveType: 'c',
      onLeave: 0
    },
    {
      isUnion: 'Union',
      gender: 'e',
      leaveType: 'c',
      onLeave: 0
    },
    {
      isUnion: 'Nonunion',
      gender: 'b',
      leaveType: 'c',
      onLeave: 0
    }];


  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WelfareEnrollmentCalculationService]
    });
  });

  it('should be created', inject([WelfareEnrollmentCalculationService],
     (service: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>) => {
    expect<any>(service).toBeTruthy();
  }));

  it('#sumByKey should return sum by key', inject([WelfareEnrollmentCalculationService],
    (service: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>) => {
      const expectedSum: KeyValueDictionary<number> = {};
      expectedSum['onLeave'] = 10;

      const actualSum = service.sumByKey('onLeave', items);

      expect<any>(actualSum).toEqual(expectedSum['onLeave']);
    }));

  it('#filterAndSumByKey should return sum of Filtered Values', inject([WelfareEnrollmentCalculationService],
    (service: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>) => {
      expect<number>(service.filterAndSumByKey(items, 'isUnion', 'Union', 'onLeave')).toEqual(3);
      expect<number>(service.filterAndSumByKey(items, 'isUnion', 'Nonunion', 'onLeave')).toEqual(7);
    }));

  it('#getPercentageOfTotalCount should return percentage of total count', inject([WelfareEnrollmentCalculationService],
    (service: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>) => {
      const totalCount = 25;
      const expectedPercentage: KeyValueDictionary<number> = {};
      expectedPercentage['a'] = 12;
      expectedPercentage['d'] = 28;

      const actualPercentage1 = service.getPercentageOfTotalCount('onLeave', [items[0], items[1]], totalCount);
      const actualPercentage2 = service.getPercentageOfTotalCount('onLeave', [items[2]], totalCount);

      expect<any>(Math.round(actualPercentage1['onLeave'])).toEqual(expectedPercentage['a']);
      expect<any>(Math.round(actualPercentage2['onLeave'])).toEqual(expectedPercentage['d']);
    }));

  it('#getPercentageOfTotalCount should return null if total count is null', inject([WelfareEnrollmentCalculationService],
    (service: WelfareEnrollmentCalculationService<LeaveOfAbsenceEnrollment>) => {
      const totalCount = 0;
      const expectedPercentage: KeyValueDictionary<number> = {};
      expectedPercentage['a'] = 0;
      expectedPercentage['d'] = 0;

      const actualPercentage1 =
        service.getPercentageOfTotalCount('onLeave', [itemsWithEmptyValue[0], itemsWithEmptyValue[1], itemsWithEmptyValue[2]], totalCount);

      const actualPercentage2 = service.getPercentageOfTotalCount('onLeave', [itemsWithEmptyValue[2]], totalCount);

      expect<any>(actualPercentage1['onLeave']).toEqual(expectedPercentage['a']);
      expect<any>(actualPercentage2['onLeave']).toEqual(expectedPercentage['d']);
    }));
});
