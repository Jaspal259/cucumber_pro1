import { Injectable } from '@angular/core';
import * as _ from 'lodash/index';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';

@Injectable()
export class WelfareEnrollmentCalculationService<T> {

  sumByKey(valueFieldName: keyof T, items: T[]): number {
    return _.sumBy(items, (item: T) => item[valueFieldName]);
  }

  filterAndSumByKey(items: T[], filterKey: keyof T, filterValue: any, sumKey: keyof T): number {
    const filteredItems = _.filter(items, (item: T) => item[filterKey] === filterValue);

    return this.sumByKey(sumKey, filteredItems);
  }

  getPercentageOfTotalCount(valueFieldName: keyof T, items: T[], totalCount: number): KeyValueDictionary<number> {
    const totals = totalCount !== 0 ? this.sumByKey(valueFieldName, items) / totalCount * 100 : 0;

    return {
      [valueFieldName.toString()]: totals
    };
  }
}
