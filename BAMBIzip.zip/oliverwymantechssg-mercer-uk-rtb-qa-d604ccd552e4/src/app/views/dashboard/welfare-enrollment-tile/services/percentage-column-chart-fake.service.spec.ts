import { TestBed, inject } from '@angular/core/testing';

import { PercentageColumnChartFakeService } from './percentage-column-chart-fake.service';

describe('PercentageColumnChartFakeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PercentageColumnChartFakeService]
    });
  });

  it('should be created', inject([PercentageColumnChartFakeService], (service: PercentageColumnChartFakeService) => {
    expect<any>(service).toBeTruthy();
  }));
});
