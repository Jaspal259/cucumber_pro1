import { TestBed, inject } from '@angular/core/testing';
import { HttpClient, HttpHandler } from '@angular/common/http';

import { WelfareEnrollmentChartPointService } from './welfare-enrollment-chart-point.service';
import { LeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';
import { ChartPoint } from '../../../../controls/charts/models/chart-point.model';
import { WelfareEnrollmentService } from './welfare-enrollment.service';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { ApiService } from '../../../../services/api.service';
import { PercentageColumnChartService } from './percentage-column-chart.service';
// tslint:disable-next-line: max-line-length
import { ColumnGroupChartService } from '../../../reports/plan-details/plan-summary/column-group-chart/services/column-group-chart.service';
import { WelfareEnrollmentCalculationService } from './welfare-enrollment-calculations.service';


describe('WelfareEnrollmentChartPointService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WelfareEnrollmentChartPointService = TestBed.get(WelfareEnrollmentChartPointService);
    expect(service).toBeTruthy();
  });
});

fdescribe('WelfareEnrollmentChartPointService', () => {
  const absenceEnrollmentData: LeaveOfAbsenceEnrollment[] = [
    { gender: 'F', isUnion: 'Nonunion', leaveType: 'Disability', onLeave: 397 },
    { gender: 'F', isUnion: 'Union', leaveType: 'Disability', onLeave: 230 },
    { gender: 'M', isUnion: 'Nonunion', leaveType: 'Disability', onLeave: 418 },
    { gender: 'M', isUnion: 'Union', leaveType: 'Disability', onLeave: 615 }
  ];

  const absenceEnrollmentDataWithoutUnion: LeaveOfAbsenceEnrollment[] = [
    { gender: 'F', isUnion: 'Nonunion', leaveType: 'Disability', onLeave: 115 },
    { gender: 'M', isUnion: 'Nonunion', leaveType: 'Disability', onLeave: 64 }
  ];

  const expectedChartPoints: ChartPoint[] = [
    { seriesName: 'Nonunion', category: 'Disability', value: 815 },
    { seriesName: 'Union', category: 'Disability', value: 845 }
  ];

  const expectedChartPoints2: ChartPoint[] = [
    { seriesName: 'Nonunion', category: 'Disability', value: 179 }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        WelfareEnrollmentChartPointService,
        WelfareEnrollmentService,
        DashboardApiService,
        ApiService,
        HttpClient,
        HttpHandler,
        PercentageColumnChartService,
        ColumnGroupChartService,
        WelfareEnrollmentCalculationService
      ]
    });
  });

  it('should be created', () => {
    const service: WelfareEnrollmentChartPointService = TestBed.get(WelfareEnrollmentChartPointService);
    expect(service).toBeTruthy();
  });

  it('#getChartPoints should return proper result', inject([WelfareEnrollmentChartPointService],
    (service: WelfareEnrollmentChartPointService) => {
      const chartPoints = service.getChartPoints(absenceEnrollmentData);

      expect<any>(chartPoints).toEqual(expectedChartPoints);
    }));

  it('#getChartPoints should return proper result without union data on input', inject([WelfareEnrollmentChartPointService],
    (service: WelfareEnrollmentChartPointService) => {
      const chartPoints = service.getChartPoints(absenceEnrollmentDataWithoutUnion);

      expect<any>(chartPoints).toEqual(expectedChartPoints2);
    }));
});
