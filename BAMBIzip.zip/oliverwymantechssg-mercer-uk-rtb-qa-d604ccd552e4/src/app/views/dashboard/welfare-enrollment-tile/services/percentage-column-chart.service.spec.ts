import { TestBed, inject } from '@angular/core/testing';
import { PercentageColumnChartService } from './percentage-column-chart.service';
import { LeaveOfAbsenceEnrollment } from '../models/leave-of-absence-enrollment.model';

describe('PercentageColumnChartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PercentageColumnChartService]
    });
  });

  it('should be created', inject([PercentageColumnChartService], (service: PercentageColumnChartService<LeaveOfAbsenceEnrollment[]>) => {
    expect<any>(service).toBeTruthy();
  }));
});
