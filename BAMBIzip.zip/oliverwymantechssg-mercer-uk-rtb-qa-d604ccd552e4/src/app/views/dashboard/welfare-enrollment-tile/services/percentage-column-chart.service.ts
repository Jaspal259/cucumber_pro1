import { Injectable } from '@angular/core';
import * as _ from 'lodash/index';
import { WelfareEnrollmentCalculationService } from './welfare-enrollment-calculations.service';
import { ResourceProvider } from '../../../../services/resources/resource-provider';
import { ChartPoint } from '../../../../controls/charts/models/chart-point.model';
import { ColumnGroupChart } from '../../../../controls/charts/models/column-group-chart.model';
import { ColumnGroupChartService } from '../../../reports/plan-details/plan-summary/column-group-chart/services/column-group-chart.service';
import { ColumnChartSettings } from '../models/column-chart-settings.model';
import { ValuesForCategory } from '../../../reports/plan-details/plan-summary/column-group-chart/models/values-for-category.model';
import { KeyValues } from '../../../../models/key-values.model';

@Injectable()
export class PercentageColumnChartService<T> {

  constructor(private columnGroupChartService: ColumnGroupChartService,
    private welfareEnrollmentCalculationService: WelfareEnrollmentCalculationService<T>) { }

  getGroupedPercentageValues(chartSettings: ColumnChartSettings<T>)
    : ValuesForCategory[] {
    const groupedEnrollment: KeyValues<T> = _.groupBy(chartSettings.items,
      (enrollment: T) => enrollment[chartSettings.categoryFieldName]
    );
    return _(groupedEnrollment).map((enrollment: T[], category: string) => {
      const groupedBySubcategory: KeyValues<T> = _.groupBy(enrollment, (e: T) => e[chartSettings.subcategoryFieldName]);

      return _.map(groupedBySubcategory, (items: T[], subcategory: string) => {
        const valueForCategory: ValuesForCategory = {
          category,
          subcategory,
          values: this.welfareEnrollmentCalculationService.getPercentageOfTotalCount(
            chartSettings.valueFieldName, items, chartSettings.totalCounts[subcategory]
          )
        };
        return valueForCategory;
      });
    })
      .flatten()
      .value();
  }

  createColumnChart(groupedValues: ValuesForCategory[],
    field: (keyof ValuesForCategory['values']),
    resources: ResourceProvider,
    chartPoints: ChartPoint[])
    : ColumnGroupChart {
    const chart: ColumnGroupChart = {
      chartTitle: '',
      categories: this.columnGroupChartService.getCategories(groupedValues, field),
      chartGroups: this.columnGroupChartService.getColumnGroupChartSeries(groupedValues, resources, field),
      tooltipSettings: {
        chartPoints
      },
      yAxisFormatting: (value: string) => {
        return value + '%';
      }
    };
    return chart;
  }
}
