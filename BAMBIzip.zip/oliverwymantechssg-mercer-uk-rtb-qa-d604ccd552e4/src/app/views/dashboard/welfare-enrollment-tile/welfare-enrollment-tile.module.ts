import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WelfareEnrollmentTileComponent } from './welfare-enrollment-tile.component';
import { WelfareEnrollmentResourceResolver } from '../resolvers/welfare-enrollment-resource-resolver';
import { WelfareEnrollmentService } from './services/welfare-enrollment.service';
import { DashboardTileModule } from '../dashboard-tile/dashboard-tile.module';
import { ChartsModule } from '../../../controls/charts/charts.module';
import { ColumnGroupChartService } from '../../reports/plan-details/plan-summary/column-group-chart/services/column-group-chart.service';
import { WelfareEnrollmentGenderModule } from './welfare-enrollment-gender/welfare-enrollment-gender.module';
import { PercentageColumnChartService } from './services/percentage-column-chart.service';
import { PercentageColumnChartFakeService } from './services/percentage-column-chart-fake.service';
import { WelfareEnrollmentCalculationService } from './services/welfare-enrollment-calculations.service';
import { WelfareEnrollmentChartPointService } from './services/welfare-enrollment-chart-point.service';

@NgModule({
  imports: [
    CommonModule,
    DashboardTileModule,
    ChartsModule,
    WelfareEnrollmentGenderModule
  ],
  declarations: [WelfareEnrollmentTileComponent],
  exports: [WelfareEnrollmentTileComponent],
  providers: [
    WelfareEnrollmentResourceResolver,
    WelfareEnrollmentService,
    WelfareEnrollmentChartPointService,
    PercentageColumnChartService,
    PercentageColumnChartFakeService,
    ColumnGroupChartService,
    WelfareEnrollmentCalculationService
  ]
})
export class WelfareEnrollmentTileModule { }
