export interface LeaveOfAbsenceEnrollment {
  isUnion: 'Nonunion' | 'Union';
  gender: string;
  leaveType: string;
  onLeave: number;
}
