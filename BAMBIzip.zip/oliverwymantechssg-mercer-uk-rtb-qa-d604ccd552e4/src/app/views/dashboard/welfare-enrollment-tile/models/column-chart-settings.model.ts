import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';
import { StringKeys } from '../../../../models/string-keys.type';

export interface ColumnChartSettings<T> {
    categoryFieldName: keyof T;
    subcategoryFieldName: keyof T;
    items: T[];
    valueFieldName: StringKeys<T>;
    totalCounts: KeyValueDictionary<number>;
}
