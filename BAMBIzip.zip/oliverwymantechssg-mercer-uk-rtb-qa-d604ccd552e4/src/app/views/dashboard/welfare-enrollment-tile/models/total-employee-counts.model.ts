export interface TotalEmployeeCounts {
  unionEmployees: number;
  nonUnionEmployees: number;
  gender: string;
}
