export interface GenderFilters {
    male: boolean;
    female: boolean;
}
