import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WelfareEnrollmentGenderComponent } from './welfare-enrollment-gender.component';
import { DashboardCheckboxesModule } from '../../dashboard-checkboxes/dashboard-checkboxes.module';

@NgModule({
  imports: [
    CommonModule,
    DashboardCheckboxesModule
  ],
  declarations: [WelfareEnrollmentGenderComponent],
  exports: [WelfareEnrollmentGenderComponent]
})
export class WelfareEnrollmentGenderModule { }
