import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { DashboardCheckboxResources } from '../../dashboard-checkboxes/models/dashboard-checkbox-resources.model';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { Gender } from '../../models/gender.type';

@Component({
  selector: 'bam-welfare-enrollment-gender',
  templateUrl: './welfare-enrollment-gender.component.html',
})
export class WelfareEnrollmentGenderComponent implements OnInit {
  checkboxResources: DashboardCheckboxResources<Gender>;
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
      this.resources.welfareEnrollment = resourceRouteService.getResource(route, 'welfareEnrollment');
  }

  ngOnInit() {
    this.checkboxResources = {
      filterResourceName: 'gender',
      resources: this.resources.welfareEnrollment,
      resourceNames: ['male', 'female']
    };
  }
}
