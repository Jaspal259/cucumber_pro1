import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WelfareEnrollmentGenderComponent } from './welfare-enrollment-gender.component';

describe('WelfareEnrollmentGenderComponent', () => {
  let component: WelfareEnrollmentGenderComponent;
  let fixture: ComponentFixture<WelfareEnrollmentGenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WelfareEnrollmentGenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WelfareEnrollmentGenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
