import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WelfareEnrollmentTileComponent } from './welfare-enrollment-tile.component';

describe('WelfareEnrollmentTileComponent', () => {
  let component: WelfareEnrollmentTileComponent;
  let fixture: ComponentFixture<WelfareEnrollmentTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WelfareEnrollmentTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WelfareEnrollmentTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
