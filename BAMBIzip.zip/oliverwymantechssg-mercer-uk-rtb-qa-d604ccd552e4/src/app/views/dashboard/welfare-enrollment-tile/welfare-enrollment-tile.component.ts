import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { SpinnerService } from '../../../services/spinner.service';
import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { ReportDetails } from '../models/report-details.model';
import { WelfareEnrollmentService } from './services/welfare-enrollment.service';
import { ColumnGroupChart } from '../../../controls/charts/models/column-group-chart.model';
import { CheckboxSubscriptionService } from '../services/checkbox-subscription.service';
import { Gender } from '../models/gender.type';
import { GenderFilters } from './models/gender-filters.model';
import { LeaveOfAbsenceEnrollment } from './models/leave-of-absence-enrollment.model';

@Component({
  selector: 'bam-welfare-enrollment-tile',
  templateUrl: './welfare-enrollment-tile.component.html',
})
export class WelfareEnrollmentTileComponent implements OnInit, OnDestroy {
  welfareEnrollmentExist = false;
  chartLoaded = false;
  readonly resources = new ResourceProviderDictionary();
  welfareEnrollmentTile: ReportDetails<LeaveOfAbsenceEnrollment[]>;
  loadingIndicatorKey: LoadingIndicatorSection;
  loadingSpinnerSettings: SpinnerSettings;
  chart: ColumnGroupChart;
  subscriptions: Subscription[];
  genderFilters: GenderFilters;

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private welfareEnrollmentService: WelfareEnrollmentService,
    private spinnerService: SpinnerService,
    private subscriptionService: CheckboxSubscriptionService<Gender>) {
      this.resources.welfareEnrollment = resourceRouteService.getResource(route, 'welfareEnrollment');
  }

  private async createWelfareEnrollmentChart() {
    this.chart = await this.welfareEnrollmentService.createColumnChart(
      this.welfareEnrollmentTile.details,
      this.resources.welfareEnrollment,
      this.genderFilters
    );
  }

  private subscribeToGender() {
    this.subscriptions = [
      this.subscriptionService.subscribeToCheck('male', async (checked: boolean) => {
        this.genderFilters.male = checked;
        await this.createWelfareEnrollmentChart();
      }),
      this.subscriptionService.subscribeToCheck('female', async (checked: boolean) => {
        this.genderFilters.female = checked;
        await this.createWelfareEnrollmentChart();
      })
    ];
  }

  async ngOnInit() {
    this.genderFilters = { male: true, female: true };
    this.loadingIndicatorKey = 'dashboard_welfare_enrollment';
    this.loadingSpinnerSettings = {
      fullPageLoader: false
    };

    await this.spinnerService.show(this.loadingIndicatorKey,
      async () => {
        this.welfareEnrollmentTile = await this.welfareEnrollmentService.getWelfareEnrollmentTile();
        await this.createWelfareEnrollmentChart();
        this.chartLoaded = true;
        this.welfareEnrollmentExist = this.chart.categories && this.chart.categories.length > 0;
        this.subscribeToGender();
    });
  }

  ngOnDestroy() {
    if (!this.subscriptions) {
      return;
    }
    for (const subscription of this.subscriptions) {
      subscription.unsubscribe();
    }
  }
}
