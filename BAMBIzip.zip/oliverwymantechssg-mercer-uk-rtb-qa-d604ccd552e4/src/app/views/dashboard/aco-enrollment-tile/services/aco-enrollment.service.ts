import { ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import * as _ from 'lodash/index';

import { AcoEnrollment } from '../models/aco-enrollment.model';
import { ColumnGroupChart } from '../../../../controls/charts/models/column-group-chart.model';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { ReportDetails } from '../../models/report-details.model';
import { ArrayGroupService } from '../../../../services/array-group.service';
import { ColumnGroupChartSeries } from '../../../../controls/charts/models/column-group-chart-series.model';
import { ColumnGroupChartSeriesOption } from '../../../../controls/charts/models/column-group-chart-series-option.model';
import { GroupedObjectByKeys } from '../../../../models/grouped-object-by-keys.model';
import { AcoAge } from '../models/aco-age.type';
import { AcoType } from '../models/aco-type.type';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { AcoAgeFilters } from '../models/aco-age-filters.model';

@Injectable()
export class AcoEnrollmentService {
  readonly resources: ResourceProviderDictionary = new ResourceProviderDictionary();

  constructor(private dashboardApiService: DashboardApiService,
    private arrayGroupService: ArrayGroupService,
    route: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
    this.resources.acoEnrollment = resourceRouteService.getResource(route, 'acoEnrollment');
  }

  async getAcoEnrollmentTile(): Promise<ReportDetails<AcoEnrollment[]>> {
    return await this.dashboardApiService.getAcoEnrollmentTile();
  }

  private getCategories(items: GroupedObjectByKeys<AcoEnrollment>[]): string[] {
    return _.map(items, (groupedFields: GroupedObjectByKeys<AcoEnrollment>) => {
      return _(groupedFields.values).map((enrollment: AcoEnrollment) => {
        return `${enrollment.location} (${enrollment.unionGroupName})`;
      })
        .uniq()
        .value();
    });
  }

  private getGroupedAcoEnrollments(acoEnrollmentTile: ReportDetails<AcoEnrollment[]>): GroupedObjectByKeys<AcoEnrollment>[] {
    return this.arrayGroupService.groupByMultipleFields(acoEnrollmentTile.details, ['location', 'unionGroupName']);
  }

  private filterAcoEnrollment(acoEnrollmentTile: ReportDetails<AcoEnrollment[]>, acoAgeFilters: AcoAgeFilters)
    : GroupedObjectByKeys<AcoEnrollment>[] {
    const groupedAcoEnrollment = this.getGroupedAcoEnrollments(acoEnrollmentTile);
    const under40YearsOnly = acoAgeFilters.under40Years && !acoAgeFilters.over40Years;
    const over40YearsOnly = !acoAgeFilters.under40Years && acoAgeFilters.over40Years;

    const filteredAcoEnrollment = under40YearsOnly
      ? this.filterEnrollmentByAge(groupedAcoEnrollment, 'Under 40')
      : over40YearsOnly
        ? this.filterEnrollmentByAge(groupedAcoEnrollment, 'Over 40')
        : groupedAcoEnrollment;

    return this.filterEnrollmentByAcoType(filteredAcoEnrollment);
  }

  private filterEnrollmentByAcoType(enrollment: GroupedObjectByKeys<AcoEnrollment>[])
    : GroupedObjectByKeys<AcoEnrollment>[] {
    return _.filter(enrollment,
      (enrollmentItem: GroupedObjectByKeys<AcoEnrollment>) => {
        const acoEnrollment = _.find(enrollmentItem.values, (value: AcoEnrollment) => {
          return value.acoType === 'ACO';
        });

        return acoEnrollment !== undefined;
      });
  }

  private filterEnrollmentByAge(enrollment: GroupedObjectByKeys<AcoEnrollment>[], age: AcoAge)
    : GroupedObjectByKeys<AcoEnrollment>[] {
    _.forEach(enrollment, (enrollmentItem: GroupedObjectByKeys<AcoEnrollment>) => {
      enrollmentItem.values = _.filter(enrollmentItem.values, { 'age': age });
    });

    return enrollment;
  }

  private getSeries(items: GroupedObjectByKeys<AcoEnrollment>[]): ColumnGroupChartSeriesOption[] {
    const acoTypes: AcoType[] = ['ACO', 'Non-ACO'];

    return _.map(acoTypes, (acoType: AcoType) => {
      const values = _.map(items, (groupedFields: GroupedObjectByKeys<AcoEnrollment>) => {
        return this.sumEnrollment(groupedFields.values, acoType);
      });

      return {
        values,
        title: acoType === 'ACO' ? `${this.resources.acoEnrollment.get('aco')}*` : this.resources.acoEnrollment.get('non_aco')
      };
    });
  }

  private getColumnChartSeries(items: GroupedObjectByKeys<AcoEnrollment>[]): ColumnGroupChartSeries {
    return { title: '', series: this.getSeries(items) };
  }

  createColumnChart(acoEnrollmentTile: ReportDetails<AcoEnrollment[]>, acoAgeFilters: AcoAgeFilters): ColumnGroupChart {
    const filteredAcoEnrollment = this.filterAcoEnrollment(acoEnrollmentTile, acoAgeFilters);
    const chartGroup = this.getColumnChartSeries(filteredAcoEnrollment);

    const chart: ColumnGroupChart = {
      chartTitle: '',
      categories: this.getCategories(filteredAcoEnrollment),
      chartGroups: [chartGroup],
      yAxisFormatting: (value: string) => {
        return value + '%';
      }
    };
    return chart;
  }

  private sumEnrollment(acoEnrollment: AcoEnrollment[], acoType: AcoType): number {
    return _.sumBy(acoEnrollment, (e: AcoEnrollment) => e.acoType === acoType ? e.enrollment : 0);
  }
}
