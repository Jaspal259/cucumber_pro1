import { TestBed, inject } from '@angular/core/testing';

import { AcoEnrollmentService } from './aco-enrollment.service';

describe('AcoEnrollmentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AcoEnrollmentService]
    });
  });

  it('should be created', inject([AcoEnrollmentService], (service: AcoEnrollmentService) => {
    expect<any>(service).toBeTruthy();
  }));
});
