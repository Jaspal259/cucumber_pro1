export interface AcoAgeFilters {
  under40Years: boolean;
  over40Years: boolean;
}
