export type AcoAge = 'Under 40' | 'Over 40';
