export type AcoType = 'ACO' | 'Non-ACO';
