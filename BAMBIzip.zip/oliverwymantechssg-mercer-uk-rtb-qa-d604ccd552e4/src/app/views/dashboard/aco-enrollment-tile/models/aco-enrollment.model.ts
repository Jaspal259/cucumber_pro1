import { AcoAge } from './aco-age.type';
import { AcoType } from './aco-type.type';

export interface AcoEnrollment {
  location: string;
  unionGroupName: string;
  acoType: AcoType;
  age: AcoAge;
  enrollment: number;
}
