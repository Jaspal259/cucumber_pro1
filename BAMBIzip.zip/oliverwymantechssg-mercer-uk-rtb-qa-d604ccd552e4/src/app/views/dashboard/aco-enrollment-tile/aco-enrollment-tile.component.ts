import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { ColumnGroupChart } from '../../../controls/charts/models/column-group-chart.model';
import { AcoEnrollmentService } from './services/aco-enrollment.service';
import { ReportDetails } from '../models/report-details.model';
import { AcoEnrollment } from './models/aco-enrollment.model';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerService } from '../../../services/spinner.service';
import { AcoAgeFilters } from './models/aco-age-filters.model';
import { CheckboxSubscriptionService } from '../services/checkbox-subscription.service';
import { AcoEnrolleeAge } from '../models/aco-enrollee-age.type';

@Component({
  selector: 'bam-aco-enrollment-tile',
  templateUrl: './aco-enrollment-tile.component.html',
  providers: [AcoEnrollmentService]
})
export class AcoEnrollmentTileComponent implements OnInit, OnDestroy {
  columnGroupChart: ColumnGroupChart;
  readonly resources = new ResourceProviderDictionary();
  subscriptions: Subscription[];
  acoAgeFilters: AcoAgeFilters;
  acoEnrollmentsExist = false;
  chartLoaded = false;
  acoEnrollmentTile: ReportDetails<AcoEnrollment[]>;
  loadingIndicatorKey: LoadingIndicatorSection;
  loadingSpinnerSettings: SpinnerSettings;

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private acoEnrollmentService: AcoEnrollmentService,
    private subscriptionService: CheckboxSubscriptionService<AcoEnrolleeAge>,
    private spinnerService: SpinnerService) {
      this.resources.acoEnrollment = resourceRouteService.getResource(route, 'acoEnrollment');
  }

  private async createAcoEnrollmentChart() {
    this.columnGroupChart = await this.acoEnrollmentService.createColumnChart(this.acoEnrollmentTile, this.acoAgeFilters);
  }

  async ngOnInit() {
    this.acoAgeFilters = { under40Years: true, over40Years: true };
    this.loadingIndicatorKey = 'dashboard_aco_enrollment';
    this.loadingSpinnerSettings = {
      fullPageLoader: false
    };

    await this.spinnerService.show(this.loadingIndicatorKey,
      async () => {
        this.acoEnrollmentTile = await this.acoEnrollmentService.getAcoEnrollmentTile();
        await this.createAcoEnrollmentChart();
        this.chartLoaded = true;
        this.acoEnrollmentsExist = this.columnGroupChart && this.columnGroupChart.categories && this.columnGroupChart.categories.length > 0;
        this.subscribeToAcoEnrollmentAge();
    });
  }

  private subscribeToAcoEnrollmentAge() {
    this.subscriptions = [
      this.subscriptionService.subscribeToCheck('under_40', async (checked: boolean) => {
        this.acoAgeFilters.under40Years = checked;
        await this.createAcoEnrollmentChart();
      }),
      this.subscriptionService.subscribeToCheck('over_40', async (checked: boolean) => {
        this.acoAgeFilters.over40Years = checked;
        await this.createAcoEnrollmentChart();
      })
    ];
  }

  ngOnDestroy() {
    if (!this.subscriptions) {
      return;
    }
    for (const subscription of this.subscriptions) {
      subscription.unsubscribe();
    }
  }
}
