import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcoEnrollmentTileComponent } from './aco-enrollment-tile.component';
import { DashboardTileModule } from '../dashboard-tile/dashboard-tile.module';
import { ChartsModule } from '../../../controls/charts/charts.module';
import { AcoEnrollmentResourceResolver } from '../resolvers/aco-enrollment-resource-resolver';
import { AcoEnrollmentAgeModule } from './aco-enrollment-age/aco-enrollment-age.module';
import { DateTimeService } from '../../../services/date-time.service';

@NgModule({
  imports: [
    CommonModule,
    DashboardTileModule,
    ChartsModule,
    AcoEnrollmentAgeModule
  ],
  declarations: [AcoEnrollmentTileComponent],
  exports: [AcoEnrollmentTileComponent],
  providers: [
    AcoEnrollmentResourceResolver,
    DateTimeService
  ]
})
export class AcoEnrollmentTileModule { }
