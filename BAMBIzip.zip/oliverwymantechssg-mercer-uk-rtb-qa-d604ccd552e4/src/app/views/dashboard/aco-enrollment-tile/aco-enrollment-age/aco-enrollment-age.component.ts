import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { AcoEnrolleeAge } from '../../models/aco-enrollee-age.type';
import { DashboardCheckboxResources } from '../../dashboard-checkboxes/models/dashboard-checkbox-resources.model';

@Component({
  selector: 'bam-aco-enrollment-age',
  templateUrl: './aco-enrollment-age.component.html',
  styleUrls: ['./aco-enrollment-age.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AcoEnrollmentAgeComponent implements OnInit {
  checkboxResources: DashboardCheckboxResources<AcoEnrolleeAge>;
  readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
      this.resources.acoEnrollment = resourceRouteService.getResource(route, 'acoEnrollment');
  }

  ngOnInit() {
    this.checkboxResources = {
      filterResourceName: 'age',
      resources: this.resources.acoEnrollment,
      resourceNames: ['under_40', 'over_40']
    };
  }
}
