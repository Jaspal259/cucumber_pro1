import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcoEnrollmentAgeComponent } from './aco-enrollment-age.component';

describe('AcoEnrollmentAgeComponent', () => {
  let component: AcoEnrollmentAgeComponent;
  let fixture: ComponentFixture<AcoEnrollmentAgeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcoEnrollmentAgeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcoEnrollmentAgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
