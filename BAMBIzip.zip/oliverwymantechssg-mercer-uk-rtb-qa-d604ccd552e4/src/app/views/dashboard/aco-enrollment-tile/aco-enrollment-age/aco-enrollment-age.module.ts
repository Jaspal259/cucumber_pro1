import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AcoEnrollmentAgeComponent } from './aco-enrollment-age.component';
import { DashboardCheckboxesModule } from '../../dashboard-checkboxes/dashboard-checkboxes.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    DashboardCheckboxesModule
  ],
  declarations: [AcoEnrollmentAgeComponent],
  exports: [AcoEnrollmentAgeComponent]
})
export class AcoEnrollmentAgeModule { }
