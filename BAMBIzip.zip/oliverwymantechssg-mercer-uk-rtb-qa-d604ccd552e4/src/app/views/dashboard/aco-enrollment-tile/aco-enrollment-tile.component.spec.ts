import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcoEnrollmentTileComponent } from './aco-enrollment-tile.component';

describe('AcoEnrollmentTileComponent', () => {
  let component: AcoEnrollmentTileComponent;
  let fixture: ComponentFixture<AcoEnrollmentTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcoEnrollmentTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcoEnrollmentTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
