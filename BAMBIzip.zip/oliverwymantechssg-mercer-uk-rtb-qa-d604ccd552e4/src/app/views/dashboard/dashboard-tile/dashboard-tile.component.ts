import { Component, OnInit, Input } from '@angular/core';

import { ResourceProvider } from '../../../services/resources/resource-provider';
import { DateTimeService } from '../../../services/date-time.service';
import { ReportDetails } from '../models/report-details.model';
import { DashboardTile } from '../models/dashboard-tile.type';
import { FullMonthAndYearFormatPipe } from '../../../controls/pipes/full-month-and-year-format.pipe';


@Component({
  selector: 'bam-dashboard-tile',
  templateUrl: './dashboard-tile.component.html',
  styleUrls: ['./dashboard-tile.component.scss']
})
export class DashboardTileComponent implements OnInit {
  @Input() resources: ResourceProvider;
  @Input() tile: ReportDetails<DashboardTile>;
  fullMonthAndYearPipe: FullMonthAndYearFormatPipe;

  constructor(private dateTimeService: DateTimeService) {
    this.fullMonthAndYearPipe = new FullMonthAndYearFormatPipe(dateTimeService);
  }

  ngOnInit() {
  }

  get title() {
    return this.resources.get('title');
  }

  get subtitle() {
    return this.tile && this.tile.reportingDate
      ? this.resources.get('subtitle').format(this.fullMonthAndYearPipe.transform(this.tile.reportingDate))
      : '';
  }
}
