import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardTileComponent } from './dashboard-tile.component';
import { PipesModule } from '../../../controls/pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule,
    PipesModule
  ],
  declarations: [DashboardTileComponent],
  exports: [DashboardTileComponent]
})
export class DashboardTileModule { }
