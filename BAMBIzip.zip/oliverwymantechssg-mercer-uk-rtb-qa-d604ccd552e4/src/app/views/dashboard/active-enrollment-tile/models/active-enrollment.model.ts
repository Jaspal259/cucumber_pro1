export interface ActiveEnrollment {
  gender: string;
  ageBand: string;
  union: string;
  planType: string;
  enrollment: number;
  ageBandOrder: number;
}
