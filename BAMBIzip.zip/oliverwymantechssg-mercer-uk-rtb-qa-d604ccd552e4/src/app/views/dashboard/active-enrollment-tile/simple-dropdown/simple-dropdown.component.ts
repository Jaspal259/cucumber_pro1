import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { SimpleDropdownService } from './services/simple-dropdown.service';
import { SimpleDropDown } from './models/simple-drop-down.model';

@Component({
  selector: 'bam-simple-dropdown',
  templateUrl: './simple-dropdown.component.html',
  styleUrls: ['./simple-dropdown.component.scss']
})
export class SimpleDropdownComponent implements OnInit {
  @Input() title: string;
  @Input() dropDown: SimpleDropDown;
  @Output() dropdownChange = new EventEmitter();

  constructor(private dropDownService: SimpleDropdownService) {

  }

  ngOnInit() {
  }

  change(event) {
    this.dropDown.selectedItem = this.dropDownService.getSelectedItem(this.dropDown.dropDownList, event.target.value);
    this.dropdownChange.emit();
  }
}
