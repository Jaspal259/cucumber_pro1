export interface SimpleDropDownItem {
  itemName: string;
  originalValue: number | string;
  order: number | string;
}
