import { TestBed, inject } from '@angular/core/testing';

import { SimpleDropdownService } from './simple-dropdown.service';

describe('SimpleDropdownService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SimpleDropdownService]
    });
  });

  it('should be created', inject([SimpleDropdownService], (service: SimpleDropdownService) => {
    expect<any>(service).toBeTruthy();
  }));
});
