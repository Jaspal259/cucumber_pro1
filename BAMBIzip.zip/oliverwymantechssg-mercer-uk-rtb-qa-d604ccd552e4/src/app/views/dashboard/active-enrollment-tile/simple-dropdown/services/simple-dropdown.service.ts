import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { SimpleDropDownItem } from '../models/simple-drop-down-item.model';

@Injectable()
export class SimpleDropdownService {

  getSelectedItem(dropDownList: SimpleDropDownItem[], selectedValue: string) {
    return _.find(dropDownList, {'itemName': selectedValue});
  }
}
