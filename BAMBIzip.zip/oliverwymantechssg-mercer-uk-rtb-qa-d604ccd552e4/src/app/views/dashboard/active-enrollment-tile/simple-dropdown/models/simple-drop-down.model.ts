import { SimpleDropDownItem } from './simple-drop-down-item.model';

export interface SimpleDropDown {
  key: string;
  dropDownList: SimpleDropDownItem[];
  selectedItem: SimpleDropDownItem;
}
