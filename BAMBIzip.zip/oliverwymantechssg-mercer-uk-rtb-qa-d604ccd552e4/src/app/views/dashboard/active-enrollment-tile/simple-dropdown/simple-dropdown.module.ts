import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { SimpleDropdownComponent } from './simple-dropdown.component';
import { SimpleDropdownService } from './services/simple-dropdown.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [SimpleDropdownComponent],
  exports: [SimpleDropdownComponent],
  providers: [SimpleDropdownService]
})
export class SimpleDropdownModule { }
