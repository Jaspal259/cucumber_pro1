import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveEnrollmentTileComponent } from './active-enrollment-tile.component';

describe('ActiveEnrollmentTileComponent', () => {
  let component: ActiveEnrollmentTileComponent;
  let fixture: ComponentFixture<ActiveEnrollmentTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveEnrollmentTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveEnrollmentTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
