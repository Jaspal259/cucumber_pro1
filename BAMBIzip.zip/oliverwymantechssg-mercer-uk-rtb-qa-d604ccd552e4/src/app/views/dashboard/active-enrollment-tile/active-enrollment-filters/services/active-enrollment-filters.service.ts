import { ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';

import { ActiveEnrollment } from '../../models/active-enrollment.model';
import { ResourceProviderDictionary } from '../../../../../models/resources/resource-provider-dictionary';
import { SimpleDropDownItem } from '../../simple-dropdown/models/simple-drop-down-item.model';
import { SimpleDropDown } from '../../simple-dropdown/models/simple-drop-down.model';
import { ActiveEnrollmentFilterStrategy } from './filter-strategy/active-enrollment-filter-strategy.service';
import { ActiveEnrollmentFilterStrategyFactory } from './filter-strategy/active-enrollment-filter-strategy-factory.service';
import { ResourceRouteService } from '../../../../../services/resources/resource-route.service';

@Injectable()
export class ActiveEnrollmentFiltersService {
  readonly resources = new ResourceProviderDictionary();
  readonly all: string;

  constructor(
    private activeEnrollmentFilterStrategyFactory: ActiveEnrollmentFilterStrategyFactory,
    route: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
    this.resources.activeEnrollment = resourceRouteService.getResource(route, 'activeEnrollment');
    this.all = this.resources.activeEnrollment.get('all');
  }

  private createFactory(key: keyof ActiveEnrollment): ActiveEnrollmentFilterStrategy {
    return this.activeEnrollmentFilterStrategyFactory.createActiveEnrollmentFilterStrategy(key);
  }

  private getFilters(activeEnrollments: ActiveEnrollment[], key: keyof ActiveEnrollment): SimpleDropDownItem[] {
    const factory = this.createFactory(key);

    return factory.getSimpleDropDownItems(activeEnrollments);
  }

  getFilteredDetails(activeEnrollments: ActiveEnrollment[], dropDowns: SimpleDropDown[]): ActiveEnrollment[] {
    return _.filter(activeEnrollments, (enrollment: ActiveEnrollment) => {
      return _.every(dropDowns, (dropDown: SimpleDropDown) => {
        return dropDown.selectedItem.originalValue === this.all || dropDown.selectedItem.originalValue === enrollment[dropDown.key];
      });
    });
  }

  createDropDownFilter(key: keyof ActiveEnrollment, activeEnrollments: ActiveEnrollment[]): SimpleDropDown {
    const dropDownList: SimpleDropDownItem[] = this.getFilters(activeEnrollments, key);

    return {
      key,
      dropDownList,
      selectedItem: { itemName: this.all, originalValue: this.all, order: '' }
    };
  }
}
