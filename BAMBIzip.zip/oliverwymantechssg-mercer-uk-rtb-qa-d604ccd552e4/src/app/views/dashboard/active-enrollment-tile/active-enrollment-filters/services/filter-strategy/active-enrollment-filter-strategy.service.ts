import { Injectable } from '@angular/core';
import { ActiveEnrollment } from '../../../models/active-enrollment.model';
import { SimpleDropDownItem } from '../../../simple-dropdown/models/simple-drop-down-item.model';
import * as _ from 'lodash';
import { ResourceProvider } from '../../../../../../services/resources/resource-provider';

@Injectable()
export abstract class ActiveEnrollmentFilterStrategy {
  abstract getSimpleDropDownItems(enrollments: ActiveEnrollment[]): SimpleDropDownItem[];

  protected createFilter(items: SimpleDropDownItem[], resources: ResourceProvider): SimpleDropDownItem[] {
    const all = resources.get('all');

    const filterValues = _(items)
      .orderBy(item => item.order)
      .sortedUniqBy(item => item.itemName)
      .value();
    return [{ itemName: all, originalValue: all }, ...filterValues];
  }
}
