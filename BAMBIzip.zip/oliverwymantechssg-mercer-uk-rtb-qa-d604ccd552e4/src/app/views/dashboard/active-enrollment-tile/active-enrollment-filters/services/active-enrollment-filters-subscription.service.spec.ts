import { TestBed, inject } from '@angular/core/testing';

import { ActiveEnrollmentFiltersSubscriptionService } from './active-enrollment-filters-subscription.service';

describe('ActiveEnrollmentFiltersSubscriptionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActiveEnrollmentFiltersSubscriptionService]
    });
  });

  it('should be created', inject([ActiveEnrollmentFiltersSubscriptionService], (service: ActiveEnrollmentFiltersSubscriptionService) => {
    expect<any>(service).toBeTruthy();
  }));
});
