import { TestBed, inject } from '@angular/core/testing';

import { AgeBandActiveEnrollmentFilterStrategy } from './age-band-active-enrollment-filter-strategy.service';

describe('AgeBandActiveEnrollmentFilterStrategy', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgeBandActiveEnrollmentFilterStrategy]
    });
  });

  it('should be created', inject([AgeBandActiveEnrollmentFilterStrategy], (service: AgeBandActiveEnrollmentFilterStrategy) => {
    expect<any>(service).toBeTruthy();
  }));
});
