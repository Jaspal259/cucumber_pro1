import { TestBed, inject } from '@angular/core/testing';

import { UnionActiveEnrollmentFilterStrategy } from './union-active-enrollment-filter-strategy.service';

describe('UnionActiveEnrollmentFilterStrategy', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UnionActiveEnrollmentFilterStrategy]
    });
  });

  it('should be created', inject([UnionActiveEnrollmentFilterStrategy], (service: UnionActiveEnrollmentFilterStrategy) => {
    expect<any>(service).toBeTruthy();
  }));
});
