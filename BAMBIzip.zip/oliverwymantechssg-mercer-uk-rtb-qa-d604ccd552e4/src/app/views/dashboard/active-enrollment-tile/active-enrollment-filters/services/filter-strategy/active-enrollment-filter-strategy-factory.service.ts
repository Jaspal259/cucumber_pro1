import { Injectable } from '@angular/core';
import { ActiveEnrollment } from '../../../models/active-enrollment.model';
import { AgeBandActiveEnrollmentFilterStrategy } from './age-band-active-enrollment-filter-strategy.service';
import { UnionActiveEnrollmentFilterStrategy } from './union-active-enrollment-filter-strategy.service';
import { GenderActiveEnrollmentFilterStrategy } from './gender-active-enrollment-filter-strategy.service';
import { ActiveEnrollmentFilterStrategy } from './active-enrollment-filter-strategy.service';
import { ResourceProviderDictionary } from '../../../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';

@Injectable()
export class ActiveEnrollmentFilterStrategyFactory {
  readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
    this.resources.activeEnrollment = resourceRouteService.getResource(route, 'activeEnrollment');
  }

  createActiveEnrollmentFilterStrategy(key: keyof ActiveEnrollment): ActiveEnrollmentFilterStrategy {
    switch (key) {
      case 'ageBand':
        return new AgeBandActiveEnrollmentFilterStrategy(this.resources.activeEnrollment);

      case 'union':
        return new UnionActiveEnrollmentFilterStrategy(this.resources.activeEnrollment);

      case 'gender':
        return new GenderActiveEnrollmentFilterStrategy(this.resources.activeEnrollment);

      default:
        throw new Error('Key was not presented in the activeEnrollmentFilters');
    }
  }
}
