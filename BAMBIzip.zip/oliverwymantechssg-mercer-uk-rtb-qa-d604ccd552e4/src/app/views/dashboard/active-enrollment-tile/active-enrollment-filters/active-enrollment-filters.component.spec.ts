import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveEnrollmentFiltersComponent } from './active-enrollment-filters.component';

describe('ActiveEnrollmentFiltersComponent', () => {
  let component: ActiveEnrollmentFiltersComponent;
  let fixture: ComponentFixture<ActiveEnrollmentFiltersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActiveEnrollmentFiltersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActiveEnrollmentFiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
