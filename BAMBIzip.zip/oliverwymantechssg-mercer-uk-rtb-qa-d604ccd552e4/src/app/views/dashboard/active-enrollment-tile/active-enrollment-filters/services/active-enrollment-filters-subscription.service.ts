import { Injectable } from '@angular/core';
import { Subject ,  Subscription } from 'rxjs';

import { ActiveEnrollment } from '../../models/active-enrollment.model';

@Injectable()
export class ActiveEnrollmentFiltersSubscriptionService {
  private filtersSelectedSubject = new Subject<ActiveEnrollment[]>();
  private filtersSelected$ = this.filtersSelectedSubject.asObservable();

  subscribeToFilterSelection(subscriptionCallback: (filteredDetails: ActiveEnrollment[]) => void): Subscription {
    return this.filtersSelected$.subscribe((filteredDetails: ActiveEnrollment[]) => {
      subscriptionCallback(filteredDetails);
    });
  }

  triggerFilterSelection(filteredDetails: ActiveEnrollment[]) {
    this.filtersSelectedSubject.next(filteredDetails);
  }
}
