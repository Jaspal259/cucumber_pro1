import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ActiveEnrollmentFiltersComponent } from './active-enrollment-filters.component';
import { SimpleDropdownModule } from '../simple-dropdown/simple-dropdown.module';

@NgModule({
  imports: [
    CommonModule,
    SimpleDropdownModule
  ],
  declarations: [
    ActiveEnrollmentFiltersComponent
  ],
  exports: [ActiveEnrollmentFiltersComponent]
})
export class ActiveEnrollmentFiltersModule { }
