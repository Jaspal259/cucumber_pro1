import { TestBed, inject } from '@angular/core/testing';
import { ActiveEnrollmentFilterStrategyFactory } from './active-enrollment-filter-strategy-factory.service';


describe('ActiveEnrollmentFilterStrategyService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActiveEnrollmentFilterStrategyFactory]
    });
  });

  it('should be created', inject([ActiveEnrollmentFilterStrategyFactory], (service: ActiveEnrollmentFilterStrategyFactory) => {
    expect<any>(service).toBeTruthy();
  }));
});
