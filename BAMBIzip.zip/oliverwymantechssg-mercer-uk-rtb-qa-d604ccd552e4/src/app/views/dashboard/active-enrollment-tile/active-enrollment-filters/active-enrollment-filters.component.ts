import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ActiveEnrollment } from '../models/active-enrollment.model';
import { ActiveEnrollmentFiltersService } from './services/active-enrollment-filters.service';
import { ActiveEnrollmentFiltersSubscriptionService } from './services/active-enrollment-filters-subscription.service';
import { SimpleDropDown } from '../simple-dropdown/models/simple-drop-down.model';
import { ActiveEnrollmentFilterStrategyFactory } from './services/filter-strategy/active-enrollment-filter-strategy-factory.service';

@Component({
  selector: 'bam-active-enrollment-filters',
  templateUrl: './active-enrollment-filters.component.html',
  styleUrls: ['./active-enrollment-filters.component.scss'],
  providers: [ActiveEnrollmentFiltersService,
    ActiveEnrollmentFilterStrategyFactory],
  encapsulation: ViewEncapsulation.None
})
export class ActiveEnrollmentFiltersComponent implements OnInit {
  @Input() activeEnrollments: ActiveEnrollment[];
  readonly resources = new ResourceProviderDictionary();
  ageBandsDropDown: SimpleDropDown;
  gendersDropDown: SimpleDropDown;
  unionsDropDown: SimpleDropDown;

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private filtersService: ActiveEnrollmentFiltersService,
    private subscriptionService: ActiveEnrollmentFiltersSubscriptionService) {
    this.resources.activeEnrollment = resourceRouteService.getResource(route, 'activeEnrollment');
  }

  ngOnInit() {
    this.ageBandsDropDown = this.filtersService.createDropDownFilter('ageBand', this.activeEnrollments);
    this.unionsDropDown = this.filtersService.createDropDownFilter('union', this.activeEnrollments);
    this.gendersDropDown = this.filtersService.createDropDownFilter('gender', this.activeEnrollments);
  }

  onSelectFilterItem() {
    const dropDowns = [this.ageBandsDropDown, this.unionsDropDown, this.gendersDropDown];
    this.subscriptionService.triggerFilterSelection(this.filtersService.getFilteredDetails(this.activeEnrollments, dropDowns));
  }
}
