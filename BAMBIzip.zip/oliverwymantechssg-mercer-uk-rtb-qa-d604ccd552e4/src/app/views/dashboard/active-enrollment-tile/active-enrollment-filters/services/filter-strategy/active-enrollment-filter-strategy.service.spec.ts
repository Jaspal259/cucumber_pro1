import { TestBed, inject } from '@angular/core/testing';

import { ActiveEnrollmentFilterStrategy } from './active-enrollment-filter-strategy.service';

describe('ActiveEnrollmentFilterStrategy', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActiveEnrollmentFilterStrategy]
    });
  });

  it('should be created', inject([ActiveEnrollmentFilterStrategy], (service: ActiveEnrollmentFilterStrategy) => {
    expect<any>(service).toBeTruthy();
  }));
});
