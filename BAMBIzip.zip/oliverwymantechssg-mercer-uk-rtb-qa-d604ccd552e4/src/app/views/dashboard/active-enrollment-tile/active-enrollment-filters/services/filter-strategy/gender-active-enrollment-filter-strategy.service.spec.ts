import { TestBed, inject } from '@angular/core/testing';

import { GenderActiveEnrollmentFilterStrategy } from './gender-active-enrollment-filter-strategy.service';

describe('GenderActiveEnrollmentFilterStrategyService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GenderActiveEnrollmentFilterStrategy]
    });
  });

  it('should be created', inject([GenderActiveEnrollmentFilterStrategy], (service: GenderActiveEnrollmentFilterStrategy) => {
    expect<any>(service).toBeTruthy();
  }));
});
