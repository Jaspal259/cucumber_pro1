import { Injectable } from '@angular/core';
import { ActiveEnrollmentFilterStrategy } from './active-enrollment-filter-strategy.service';
import { SimpleDropDownItem } from '../../../simple-dropdown/models/simple-drop-down-item.model';
import { ResourceProvider } from '../../../../../../services/resources/resource-provider';
import { ActiveEnrollment } from '../../../models/active-enrollment.model';
import * as _ from 'lodash';

@Injectable()
export class UnionActiveEnrollmentFilterStrategy extends ActiveEnrollmentFilterStrategy {
  protected createFilter(items: SimpleDropDownItem[], resources: ResourceProvider): SimpleDropDownItem[] {
    return super.createFilter(items, resources);
  }

  constructor(private resources: ResourceProvider) {
    super();
  }

  getSimpleDropDownItems(enrollments: ActiveEnrollment[]): SimpleDropDownItem[] {
    const items = _.map(enrollments, (enrollment: ActiveEnrollment) => this.createDropDownItem(enrollment));

    return this.createFilter(items, this.resources);
  }

  private createDropDownItem(enrollment: ActiveEnrollment): SimpleDropDownItem {
    return {
      originalValue: enrollment.union,
      itemName: enrollment.union,
      order: enrollment.union
    };
  }
}
