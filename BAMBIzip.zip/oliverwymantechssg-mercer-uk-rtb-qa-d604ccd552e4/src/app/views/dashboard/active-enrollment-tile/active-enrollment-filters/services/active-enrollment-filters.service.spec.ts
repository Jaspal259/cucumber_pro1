import { TestBed, inject } from '@angular/core/testing';

import { ActiveEnrollmentFiltersService } from './active-enrollment-filters.service';

describe('ActiveEnrollmentFiltersService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActiveEnrollmentFiltersService]
    });
  });

  it('should be created', inject([ActiveEnrollmentFiltersService], (service: ActiveEnrollmentFiltersService) => {
    expect<any>(service).toBeTruthy();
  }));
});
