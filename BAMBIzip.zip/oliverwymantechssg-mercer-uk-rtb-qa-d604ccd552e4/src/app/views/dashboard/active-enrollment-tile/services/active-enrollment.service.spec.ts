import { TestBed, inject } from '@angular/core/testing';

import { ActiveEnrollmentService } from './active-enrollment.service';

describe('ActiveEnrollmentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActiveEnrollmentService]
    });
  });

  it('should be created', inject([ActiveEnrollmentService], (service: ActiveEnrollmentService) => {
    expect<any>(service).toBeTruthy();
  }));
});
