import { ActivatedRoute } from '@angular/router';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import * as Highcharts from 'highcharts';

import { PieChartModel } from '../../../../controls/charts/pie-chart/models/pie-chart-model.model';
import { ActiveEnrollment } from '../models/active-enrollment.model';
import { ArrayGroupService } from '../../../../services/array-group.service';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { DashboardApiService } from '../../services/dashboard-api.service';
import { ReportDetails } from '../../models/report-details.model';
import { KeyValueDictionary } from '../../../../models/key-value-dictionary.model';
import { PieChartSection } from '../../../../controls/charts/pie-chart/models/pie-chart-section.model';
import { PieChartSettings } from '../../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { PieChartColorSettings } from '../../models/pie-chart-color-settings.model';
import { PieChartSectionService } from '../../services/pie-chart-section.service';

@Injectable()
export class ActiveEnrollmentService {
  readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    private dashboardApiService: DashboardApiService,
    private arrayGroupService: ArrayGroupService,
    private pieChartSectionService: PieChartSectionService<ActiveEnrollment>,
      resourceRouteService: ResourceRouteService) {
      this.resources.activeEnrollment = resourceRouteService.getResource(route, 'activeEnrollment');
  }

  async getActiveEnrollmentTile(): Promise<ReportDetails<ActiveEnrollment[]>> {
    return await this.dashboardApiService.getActiveEnrollmentTile();
  }

  getSectionColors(activeEnrollment: ActiveEnrollment[]): KeyValueDictionary<string> {
    const colorSettings: PieChartColorSettings<ActiveEnrollment> = {
      details: activeEnrollment,
      sections: ['planType'],
      sectionColors: ['#0699D9', '#00933B', '#FF8700', '#FFB700', '#FF4A19', '#02628C', '#40B8EC', '#061991']
    };
    return this.pieChartSectionService.getSectionColors(colorSettings);
  }

  getPieChartSettings(activeEnrollment: ActiveEnrollment[], sectionColors: KeyValueDictionary<string>): PieChartSettings {
    return {
      chartModel: this.getActiveEnrollmentPieChartData(activeEnrollment, sectionColors)
    };
  }

  private getActiveEnrollmentPieChartData(activeEnrollment: ActiveEnrollment[], sectionColors: KeyValueDictionary<string>): PieChartModel {
    const pieChartData: PieChartModel = {
      parent: {
        name: '',
        id: '',
        data: this.getParentData(activeEnrollment, sectionColors)
      },
      dataLabelsFormat: '<span style="color:#fff">{point.name}:</span><br/><span style="color:#fff">{percentage:.1f}%</span>'
    };
    return pieChartData;
  }

  private sumEnrollments(activeEnrollment: ActiveEnrollment[]): number {
    return _.sumBy(activeEnrollment, e => e.enrollment);
  }

  private getParentData(activeEnrollment: ActiveEnrollment[], sectionColors: KeyValueDictionary<string>): PieChartSection[] {
    if (!activeEnrollment) {
      return null;
    }
    const groupedActiveEnrollment = this.arrayGroupService.groupBy<ActiveEnrollment>(activeEnrollment, 'planType');
    return _(groupedActiveEnrollment).map((groupedFields: ActiveEnrollment[], planType: string) => {
        const groupedFieldsSum = this.sumEnrollments(groupedFields);
        const section: PieChartSection = {
          name: planType,
          y: groupedFieldsSum,
          tooltipText: `${planType}: ${Highcharts.numberFormat(groupedFieldsSum, 0)} ${this.resources.activeEnrollment.get('subscribers')}`,
          color: sectionColors[planType]
        };
        return section;
    })
    .value();
  }
}
