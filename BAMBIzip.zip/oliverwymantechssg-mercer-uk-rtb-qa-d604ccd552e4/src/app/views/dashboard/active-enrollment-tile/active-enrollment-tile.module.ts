import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ActiveEnrollmentTileComponent } from './active-enrollment-tile.component';
import { DashboardTileModule } from '../dashboard-tile/dashboard-tile.module';
import { ChartsModule } from '../../../controls/charts/charts.module';
import { SpinnerModule } from '../../../controls/spinner/spinner.module';
import { ActiveEnrollmentResourceResolver } from '../resolvers/active-enrollment-resource-resolver';
import { DateTimeService } from '../../../services/date-time.service';
import { DashboardApiService } from '../services/dashboard-api.service';
import { ActiveEnrollmentFiltersModule } from './active-enrollment-filters/active-enrollment-filters.module';
// tslint:disable-next-line:max-line-length
import { ActiveEnrollmentFiltersSubscriptionService } from './active-enrollment-filters/services/active-enrollment-filters-subscription.service';

@NgModule({
  imports: [
    CommonModule,
    DashboardTileModule,
    ChartsModule,
    SpinnerModule,
    ActiveEnrollmentFiltersModule
  ],
  declarations: [ActiveEnrollmentTileComponent],
  providers: [
    DashboardApiService,
    ActiveEnrollmentResourceResolver,
    DateTimeService,
    ActiveEnrollmentFiltersSubscriptionService
  ],
  exports: [ActiveEnrollmentTileComponent]
})
export class ActiveEnrollmentTileModule { }
