import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { KeyValueDictionary } from '../../../models/key-value-dictionary.model';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { SpinnerService } from '../../../services/spinner.service';
import { ActiveEnrollmentService } from './services/active-enrollment.service';
import { PieChartSettings } from '../../../controls/charts/pie-chart/models/pie-chart-settings.model';
import { ActiveEnrollment } from './models/active-enrollment.model';
import { ReportDetails } from '../models/report-details.model';
// tslint:disable-next-line:max-line-length
import { ActiveEnrollmentFiltersSubscriptionService } from './active-enrollment-filters/services/active-enrollment-filters-subscription.service';
import { PieChartSectionService } from '../services/pie-chart-section.service';

@Component({
  selector: 'bam-active-enrollment-tile',
  templateUrl: './active-enrollment-tile.component.html',
  providers: [ActiveEnrollmentService]
})
export class ActiveEnrollmentTileComponent implements OnInit, OnDestroy {
  readonly resources = new ResourceProviderDictionary();
  loadingIndicatorKey: LoadingIndicatorSection;
  loadingSpinnerSettings: SpinnerSettings;
  pieChartSettings: PieChartSettings;
  activeEnrollmentsExist: boolean;
  activeEnrollmentTile: ReportDetails<ActiveEnrollment[]>;
  selectedFiltersSubscription: Subscription;
  sectionColors: KeyValueDictionary<string>;

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private spinnerService: SpinnerService,
    private activeEnrollmentService: ActiveEnrollmentService,
    private subscriptionService: ActiveEnrollmentFiltersSubscriptionService,
    private pieChartSectionService: PieChartSectionService<ActiveEnrollment>) {
      this.resources.activeEnrollment = resourceRouteService.getResource(route, 'activeEnrollment');
  }

  private updatePieChart(activeEnrollment: ActiveEnrollment[], sectionColors: KeyValueDictionary<string>) {
    this.pieChartSettings = this.activeEnrollmentService.getPieChartSettings(activeEnrollment, sectionColors);
    this.activeEnrollmentsExist = this.pieChartSettings.chartModel.parent && this.pieChartSettings.chartModel.parent.data ? true : false;
  }

  private subscribeToFilterSelection() {
    this.selectedFiltersSubscription = this.subscriptionService.subscribeToFilterSelection((activeEnrollment) => {
      this.updatePieChart(activeEnrollment, this.sectionColors);
    });
  }

  async ngOnInit() {
    this.loadingIndicatorKey = 'dashboard_active_enrollment';
    this.loadingSpinnerSettings = {
      fullPageLoader: false
    };

    await this.spinnerService.show(this.loadingIndicatorKey,
      async () => {
        this.activeEnrollmentTile = await this.activeEnrollmentService.getActiveEnrollmentTile();

        const activeEnrollment = this.activeEnrollmentTile.details;
        this.sectionColors = this.activeEnrollmentService.getSectionColors(activeEnrollment);
        this.updatePieChart(activeEnrollment, this.sectionColors);

        this.subscribeToFilterSelection();
    });
  }

  ngOnDestroy() {
    if (this.selectedFiltersSubscription) {
      this.selectedFiltersSubscription.unsubscribe();
    }
  }
}
