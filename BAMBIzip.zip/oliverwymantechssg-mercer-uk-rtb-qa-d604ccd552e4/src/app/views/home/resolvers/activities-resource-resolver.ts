import { Injectable } from '@angular/core';

import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable()
export class ActivitiesResourceResolver extends BaseResourceResolver<'home.activities'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'home.activities');
  }
}
