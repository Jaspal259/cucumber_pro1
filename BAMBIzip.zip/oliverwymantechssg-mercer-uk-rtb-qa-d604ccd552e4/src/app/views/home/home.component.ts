import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';

@Component({
  selector: 'bam-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
      this.resources.home = resourceRouteService.getResource(route, 'home.home');
  }

  ngOnInit() {
  }

}
