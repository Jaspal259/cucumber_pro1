import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';

import { HomeComponent } from './home.component';
import { PageHeaderModule } from '../../controls/page-header/page-header.module';
import { HomeResourceResolver } from './resolvers/home-resource-resolver';
import { HomeSubheaderModule } from './home-subheader/home-subheader.module';
import { OverviewTileModule } from './overview-tile/overview-tile.module';
import { OverviewResourceResolver } from './resolvers/overview-resource-resolver';
import { ActivitiesResourceResolver } from './resolvers/activities-resource-resolver';
import { ActivitiesTileModule } from './activities-tile/activities-tile.module';
import { HomeDisclaimerModule } from './home-disclaimer/home-disclaimer.module';
import { DisclaimerResourceResolver } from './resolvers/disclaimer-resource-resolver';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MercerOSModule,
    PageHeaderModule,
    HomeSubheaderModule,
    OverviewTileModule,
    ActivitiesTileModule,
    HomeDisclaimerModule
  ],
  declarations: [HomeComponent],
  providers: [
    HomeResourceResolver,
    OverviewResourceResolver,
    ActivitiesResourceResolver,
    DisclaimerResourceResolver
  ]
})
export class HomeModule { }
