export interface Overview {
  children?: Overview[];
  resourceKey: string;
}
