import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { Overview } from './models/overview.model';

@Component({
  selector: 'bam-overview-tile',
  templateUrl: './overview-tile.component.html',
})
export class OverviewTileComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();
  readonly overview: Overview;

  private createOverview(resourceKey: string, children?: Overview[]) {
    return { resourceKey, children };
  }

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
    this.resources.overview = resourceRouteService.getResource(route, 'home.overview');
    this.overview = this.createOverview(null, [
      this.createOverview('bambi_programs', [
        this.createOverview('census_and_enrollment'),
        this.createOverview('financial_information'),
        this.createOverview('benefit_plan_provisions')
      ]),
      this.createOverview('bambi_database'),
      this.createOverview('bambi_data')
    ]);
  }

  ngOnInit() {
  }

}
