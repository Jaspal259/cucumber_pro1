import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';
import { IconModule } from '../../../../controls/icon/icon.module';
import { OverviewItemComponent } from './overview-item.component';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    IconModule
  ],
  declarations: [OverviewItemComponent],
  exports: [OverviewItemComponent]
})
export class OverviewItemModule { }
