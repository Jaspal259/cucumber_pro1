import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import { Overview } from '../models/overview.model';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';

@Component({
  selector: 'bam-overview-item',
  templateUrl: './overview-item.component.html',
  styleUrls: ['./overview-item.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class OverviewItemComponent implements OnInit {
  @Input() overview: Overview;
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
      this.resources.overview = resourceRouteService.getResource(route, 'home.overview');
  }

  ngOnInit() {
  }

}
