import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';

import { OverviewTileComponent } from './overview-tile.component';
import { HomeTileModule } from '../home-tile/home-tile.module';
import { OverviewItemModule } from './overview-item/overview-item.module';

@NgModule({
  imports: [
    CommonModule,
    HomeTileModule,
    MercerOSModule,
    OverviewItemModule
  ],
  declarations: [OverviewTileComponent],
  exports: [OverviewTileComponent]
})
export class OverviewTileModule { }
