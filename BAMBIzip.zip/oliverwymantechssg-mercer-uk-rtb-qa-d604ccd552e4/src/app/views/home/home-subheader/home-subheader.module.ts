import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeSubheaderComponent } from './home-subheader.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [HomeSubheaderComponent],
  exports: [HomeSubheaderComponent]
})
export class HomeSubheaderModule { }
