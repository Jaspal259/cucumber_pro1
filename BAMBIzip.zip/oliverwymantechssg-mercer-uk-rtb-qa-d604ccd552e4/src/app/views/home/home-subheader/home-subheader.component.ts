import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';

@Component({
  selector: 'bam-home-subheader',
  templateUrl: './home-subheader.component.html',
})
export class HomeSubheaderComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
      this.resources.home = resourceRouteService.getResource(route, 'home.home');
  }

  ngOnInit() {
  }

}
