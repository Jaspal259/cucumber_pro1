import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';
import { IconModule } from '../../../controls/icon/icon.module';
import { ActivitiesTileComponent } from './activities-tile.component';
import { HomeTileModule } from '../home-tile/home-tile.module';

@NgModule({
  imports: [
    CommonModule,
    HomeTileModule,
    RouterModule,
    MercerOSModule,
    IconModule
  ],
  declarations: [ActivitiesTileComponent],
  exports: [ActivitiesTileComponent]
})
export class ActivitiesTileModule { }
