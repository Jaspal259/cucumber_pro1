export interface Activity {
  resourceKey: string;
  icon: string;
}
