import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesTileComponent } from './activities-tile.component';

describe('ActivitiesComponent', () => {
  let component: ActivitiesTileComponent;
  let fixture: ComponentFixture<ActivitiesTileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesTileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
