import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { Activity } from './models/activity.model';
import { UserGuideService } from '../../../services/user-guide.service';
import { SpinnerSettings } from '../../../controls/spinner/models/spinner-settings';
import { LoadingIndicatorSection } from '../../../controls/spinner/models/loading-indicator-section.type';
import { SpinnerService } from '../../../services/spinner.service';
import { DataConsiderationsService } from '../../../services/data-considerations.service';

@Component({
  selector: 'bam-activities-tile',
  templateUrl: './activities-tile.component.html',
  providers: [UserGuideService, DataConsiderationsService]
})
export class ActivitiesTileComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();
  readonly activities: Activity[];
  loadingSpinnerSettings: SpinnerSettings;
  loadingIndicatorKey: LoadingIndicatorSection;

  private createActivity(resourceKey: string, icon: string) {
    return {resourceKey, icon};
  }

  constructor(resourceRouteService: ResourceRouteService,
    private userGuideService: UserGuideService,
    private spinnerService: SpinnerService,
    route: ActivatedRoute) {
    this.resources.activities = resourceRouteService.getResource(route, 'home.activities');
    this.activities = [
      this.createActivity('explore_dashboards', 'pie_chart'),
      this.createActivity('look_up_counts', 'show_chart'),
      this.createActivity('research_plan_details', 'subject'),
      this.createActivity('save_query', 'done'),
      this.createActivity('share_queries', 'person_add'),
      this.createActivity('quickly_search', 'search'),
      this.createActivity('export_results', 'vertical_align_bottom'),
      this.createActivity('request_reports', 'supervisor_account')
    ];
    this.resources.siteResource = resourceRouteService.getResource(route, 'siteResource');
  }

  ngOnInit() {
  }

  async onGetUserGuide() {
    this.loadingIndicatorKey = 'full_page';

    this.loadingSpinnerSettings = {
      fullPageLoader: true
    };

    await this.spinnerService.show(this.loadingIndicatorKey, async () => {
      await this.userGuideService.downloadUserGuide();
    });
  }
}
