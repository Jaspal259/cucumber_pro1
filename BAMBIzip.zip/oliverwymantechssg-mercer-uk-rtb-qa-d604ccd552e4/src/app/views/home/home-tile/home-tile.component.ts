import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'bam-home-tile',
  templateUrl: './home-tile.component.html',
})
export class HomeTileComponent implements OnInit {
  @Input() title: string;

  constructor() { }

  ngOnInit() {
  }

}
