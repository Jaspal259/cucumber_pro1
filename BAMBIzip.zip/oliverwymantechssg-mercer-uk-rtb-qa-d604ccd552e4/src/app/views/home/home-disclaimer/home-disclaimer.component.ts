import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';

@Component({
  selector: 'bam-home-disclaimer',
  templateUrl: './home-disclaimer.component.html',
  styleUrls: ['./home-disclaimer.component.scss']
})
export class HomeDisclaimerComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();

  constructor(resourceRouteService: ResourceRouteService,
    route: ActivatedRoute) {
    this.resources.home = resourceRouteService.getResource(route, 'home.disclaimer');
  }

  ngOnInit() {
  }

}
