import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeDisclaimerComponent } from './home-disclaimer.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [HomeDisclaimerComponent],
  exports: [HomeDisclaimerComponent]
})
export class HomeDisclaimerModule { }
