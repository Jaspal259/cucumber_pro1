import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UserGuideSectionComponent } from './user-guide-section.component';

describe('UserGuideSectionComponent', () => {
  let component: UserGuideSectionComponent;
  let fixture: ComponentFixture<UserGuideSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UserGuideSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserGuideSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
