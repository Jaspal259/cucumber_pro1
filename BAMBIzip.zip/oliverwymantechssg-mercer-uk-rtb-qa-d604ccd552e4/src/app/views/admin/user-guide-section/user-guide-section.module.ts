import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserGuideSectionComponent } from './user-guide-section.component';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { RequestFileUploadModule } from '../../../controls/request-file-upload/request-file-upload.module';

@NgModule({
  imports: [
    CommonModule,
    RequestFileUploadModule
  ],
  declarations: [UserGuideSectionComponent],
  exports: [UserGuideSectionComponent],
  providers: [ResourceRouteService]
})
export class UserGuideSectionModule { }
