import { Injectable } from '@angular/core';
import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable({
  providedIn: 'root'
})
export class AdminResourceResolver extends BaseResourceResolver<'admin'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'admin');
  }
}
