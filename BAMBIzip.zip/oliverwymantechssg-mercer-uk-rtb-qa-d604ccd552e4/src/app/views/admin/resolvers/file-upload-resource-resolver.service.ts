import { Injectable } from '@angular/core';
import { BaseResourceResolver } from '../../../resolvers/base-resource-resolver';
import { ResourceService } from '../../../services/resources/resource.service';

@Injectable({
  providedIn: 'root'
})
export class FileUploadResourceResolver extends BaseResourceResolver<'fileUpload'> {
  constructor(protected resourceService: ResourceService) {
    super(resourceService, 'fileUpload');
  }
}
