import { AdminTab } from './admin-tab.model';

export interface AdminListTab {
  userGuide: AdminTab;
  dataConsiderations: AdminTab;
}
