import { FileUploadLimitations } from './file-upload-limitations.model';

export interface UploadSettings {
  limitations: FileUploadLimitations;
  label: string;
}
