export interface AdminTab {
  url: string;
  tabName: string;
}
