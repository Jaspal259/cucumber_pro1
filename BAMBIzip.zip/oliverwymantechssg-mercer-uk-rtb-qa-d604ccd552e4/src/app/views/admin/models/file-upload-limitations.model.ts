export interface FileUploadLimitations {
  maxSizeInBytes: number;
  formats: string[];
}
