import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminNavigationComponent } from './admin-navigation.component';
import { RouterModule } from '@angular/router';
import { UserGuideSectionModule } from '../user-guide-section/user-guide-section.module';
import { DataConsiderationsSectionModule } from '../data-considerations-section/data-considerations-section.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    UserGuideSectionModule,
    DataConsiderationsSectionModule
  ],
  declarations: [AdminNavigationComponent],
  exports: [AdminNavigationComponent]
})
export class AdminNavigationModule { }
