import { Component, OnInit, OnDestroy } from '@angular/core';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { Router } from '@angular/router';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { AdminTab } from '../models/admin-tab.model';
import { AdminTabNavigationService } from '../services/admin-tab-navigation.service';
import { AdminListTab } from '../models/admin-list-tab.model';

@Component({
  selector: 'bam-admin-navigation',
  templateUrl: './admin-navigation.component.html',
  styleUrls: ['./admin-navigation.component.scss']
})
export class AdminNavigationComponent implements OnInit, OnDestroy {
  activeTab: AdminTab;
  tabs: AdminListTab;
  readonly resources = new ResourceProviderDictionary();
  userGuideTab = true;
  dataConsiderationsTab = false;

  constructor(private router: Router,
    private resourceRouteService: ResourceRouteService,
    private adminNavigationService: AdminTabNavigationService) {
  }

  private async resetData() {
  }

  async ngOnInit() {
    this.tabs = this.adminNavigationService.getAdminTabs();
  }

  ngOnDestroy() {
  }
}
