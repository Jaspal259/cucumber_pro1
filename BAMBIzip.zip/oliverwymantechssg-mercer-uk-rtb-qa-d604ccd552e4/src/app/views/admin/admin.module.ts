import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminComponent } from './admin.component';
import { PageHeaderModule } from '../../controls/page-header/page-header.module';
import { MercerOSModule } from 'merceros-ui-components';
import { ButtonModule } from '../../controls/button/button.module';
import { IconModule } from '../../controls/icon/icon.module';
import { RouterModule } from '@angular/router';
import { AdminTabNavigationService } from './services/admin-tab-navigation.service';
import { AlertsModule } from '../../controls/alerts/alerts.module';
import { RequestFileUploadModule } from '../../controls/request-file-upload/request-file-upload.module';
import { AdminNavigationModule } from './admin-navigation/admin-navigation.module';
import { FileExtensionService } from '../../services/download-file/file-extension.service';

@NgModule({
  imports: [
    CommonModule,
    PageHeaderModule,
    MercerOSModule,
    ButtonModule,
    IconModule,
    RouterModule,
    RequestFileUploadModule,
    AlertsModule,
    AdminNavigationModule
  ],
  declarations: [
    AdminComponent
  ],
  exports: [
    AdminComponent
  ],
  providers: [
    AdminTabNavigationService,
    FileExtensionService
  ]
})
export class AdminModule { }
