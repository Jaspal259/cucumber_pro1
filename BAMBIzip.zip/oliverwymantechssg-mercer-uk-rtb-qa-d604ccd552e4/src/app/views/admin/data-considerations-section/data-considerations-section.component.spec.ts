import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataConsiderationsSectionComponent } from './data-considerations-section.component';

describe('DataConsiderationsSectionComponent', () => {
  let component: DataConsiderationsSectionComponent;
  let fixture: ComponentFixture<DataConsiderationsSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataConsiderationsSectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataConsiderationsSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
