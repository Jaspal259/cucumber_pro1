import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataConsiderationsSectionComponent } from './data-considerations-section.component';
import { RequestFileUploadModule } from '../../../controls/request-file-upload/request-file-upload.module';

@NgModule({
  imports: [
    CommonModule,
    RequestFileUploadModule
  ],
  declarations: [DataConsiderationsSectionComponent],
  exports: [DataConsiderationsSectionComponent]
})
export class DataConsiderationsSectionModule { }
