import { Component, OnInit, ViewChild, ChangeDetectionStrategy } from '@angular/core';
import { AdminApiService } from '../services/api/admin-api.service';
import { RequestFileUploadComponent } from '../../../controls/request-file-upload/request-file-upload.component';
import { FileUploadLimitations } from '../models/file-upload-limitations.model';
import { ResourceRouteService } from '../../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { ResourceProviderDictionary } from '../../../models/resources/resource-provider-dictionary';
import { UploadSettings } from '../models/upload-setting.model';

@Component({
  templateUrl: './data-considerations-section.component.html',
})
export class DataConsiderationsSectionComponent implements OnInit {
  @ViewChild(RequestFileUploadComponent) public fileUploadComponent: RequestFileUploadComponent;
  fileUploadLimitations: FileUploadLimitations;
  readonly resources = new ResourceProviderDictionary();
  uploadSettings: UploadSettings;


  constructor(private adminApiService: AdminApiService,
    private resourceRouteService: ResourceRouteService,
    private route: ActivatedRoute) {
  }

  async ngOnInit() {
    await this.initSettings();
  }

  async initSettings() {
    this.uploadSettings = {
      label: this.resourceRouteService.getResource(this.route, 'dataConsiderations').get('upload_file_label'),
      limitations: null
    };

    this.uploadSettings.limitations = await this.adminApiService.getDataConsiderationsLimitations();
  }

  upload(file) {
    this.adminApiService.uploadDataConsiderationsFile(file);
  }
}
