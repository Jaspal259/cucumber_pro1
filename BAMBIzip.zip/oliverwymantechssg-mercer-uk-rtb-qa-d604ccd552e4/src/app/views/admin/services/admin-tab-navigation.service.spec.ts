import { TestBed } from '@angular/core/testing';

import { AdminTabNavigationService } from './admin-tab-navigation.service';

describe('AdminTabNavigationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminTabNavigationService = TestBed.get(AdminTabNavigationService);
    expect(service).toBeTruthy();
  });
});
