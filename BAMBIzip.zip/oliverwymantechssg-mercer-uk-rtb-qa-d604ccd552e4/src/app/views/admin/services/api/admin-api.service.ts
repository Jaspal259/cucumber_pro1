import { Injectable } from '@angular/core';
import { ApiService } from '../../../../services/api.service';
import { FileUploadLimitations } from '../../models/file-upload-limitations.model';


@Injectable()
export class AdminApiService {
  private readonly path = 'admin';
  constructor(private apiService: ApiService) { }

  async getUserGuideLimitations(): Promise<FileUploadLimitations> {
    return await this.apiService.get<FileUploadLimitations>(`${this.path}/GetUserGuideLimitations`);
  }

  async uploadUserGuide(file): Promise<void> {
    return await this.apiService.postFile<void>(`${this.path}/UploadUserGuide`, file);
  }

  async uploadDataConsiderationsFile(file): Promise<void> {
    return await this.apiService.postFile<void>(`${this.path}/UploadDataConsiderations`, file);
  }

  async getDataConsiderationsLimitations(): Promise<FileUploadLimitations> {
    return await this.apiService.get<FileUploadLimitations>(`${this.path}/GetDataConsiderationsLimitations`);
  }
}
