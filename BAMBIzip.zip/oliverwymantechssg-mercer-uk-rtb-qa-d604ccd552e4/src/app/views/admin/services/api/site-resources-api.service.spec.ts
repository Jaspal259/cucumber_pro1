import { TestBed } from '@angular/core/testing';

import { SiteResourcesApiService } from './site-resources-api.service';

describe('SiteResourcesApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SiteResourcesApiService = TestBed.get(SiteResourcesApiService);
    expect(service).toBeTruthy();
  });
});
