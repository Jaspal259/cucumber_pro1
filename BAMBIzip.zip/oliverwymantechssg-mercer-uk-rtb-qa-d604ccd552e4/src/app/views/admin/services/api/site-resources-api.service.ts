import { ApiService } from '../../../../services/api.service';
import { Injectable } from '@angular/core';

@Injectable()
export class SiteResourcesApiService {
  private readonly path = 'siteResources';
  constructor(private apiService: ApiService) { }

  async getUserGuide(): Promise<Blob> {
    const responseType = 'blob';
    return await this.apiService.post<Blob>(`${this.path}/UserGuide`, { }, responseType);
  }

  async getDataConsiderations(): Promise<Blob> {
    const responseType = 'blob';
    return await this.apiService.post<Blob>(`${this.path}/DataConsiderations`, {}, responseType);
  }
}
