import { Injectable } from '@angular/core';
import { AdminTab } from '../models/admin-tab.model';
import { AdminListTab } from '../models/admin-list-tab.model';

@Injectable()
export class AdminTabNavigationService {

  private activeTab: AdminTab;

  public getAdminTabs(): AdminListTab {
    return {
      userGuide: {
        url: 'user-guide',
        tabName: 'User Guide'
      },
      dataConsiderations: {
        url: 'data-considerations',
        tabName: 'Data Considerations'
      }
    };
  }
}
