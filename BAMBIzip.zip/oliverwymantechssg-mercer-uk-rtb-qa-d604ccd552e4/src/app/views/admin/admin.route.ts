import { Routes } from '@angular/router';
import { UserGuideSectionComponent } from './user-guide-section/user-guide-section.component';
// tslint:disable-next-line: max-line-length
import { DataConsiderationsSectionComponent } from './data-considerations-section/data-considerations-section.component';


export const adminChildRoutes: Routes = [
  { path: '', redirectTo: 'user-guide', pathMatch: 'full' },
  { path: 'user-guide', component: UserGuideSectionComponent },
  // tslint:disable-next-line: max-line-length
  { path: 'data-considerations', component: DataConsiderationsSectionComponent }
];
