import { Component,  OnInit, ChangeDetectionStrategy, ViewEncapsulation } from '@angular/core';
import { ResourceProviderDictionary } from '../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../services/resources/resource-route.service';
import { ActivatedRoute } from '@angular/router';
import { SpinnerSettings } from '../../controls/spinner/models/spinner-settings';

import { SpinnerService } from '../../services/spinner.service';
import { LoadingIndicatorSection } from '../../controls/spinner/models/loading-indicator-section.type';

@Component({
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AdminComponent implements OnInit {
  readonly resources = new ResourceProviderDictionary();
  loadingSpinnerSettings: SpinnerSettings;
  loadingIndicatorKey: LoadingIndicatorSection;

  constructor(private resourceRouteService: ResourceRouteService,
    private route: ActivatedRoute,
    private spinnerService: SpinnerService) {
  }

  async ngOnInit() {
    this.loadingIndicatorKey = 'full_page';

    this.loadingSpinnerSettings = {
      fullPageLoader: true
    };

    await this.spinnerService.show(this.loadingIndicatorKey, async () => {
      this.resources.admin = this.resourceRouteService.getResource(this.route, 'admin');
    });
  }
}
