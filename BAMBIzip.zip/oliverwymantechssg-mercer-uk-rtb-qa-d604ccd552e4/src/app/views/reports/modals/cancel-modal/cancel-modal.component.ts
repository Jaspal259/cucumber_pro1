import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ModalComponent } from '../../../../controls/modal/modal.component';

@Component({
  selector: 'bam-cancel-modal',
  templateUrl: './cancel-modal.component.html',
})
export class CancelModalComponent implements OnInit {
  @ViewChild(ModalComponent) modal: ModalComponent;
  @Input() text: string;
  @Input() navigateUrl: string;

  readonly resources = new ResourceProviderDictionary();

  constructor(private router: Router, private resourceRouteService: ResourceRouteService, private route: ActivatedRoute) {
    this.resources.global = resourceRouteService.getResource(route, 'global');
  }

  ngOnInit() {
  }

  open() {
    this.modal.open();
  }

  onOk() {
    this.router.navigateByUrl(this.navigateUrl);
  }

  onCancel() {
    this.modal.close();
  }
}
