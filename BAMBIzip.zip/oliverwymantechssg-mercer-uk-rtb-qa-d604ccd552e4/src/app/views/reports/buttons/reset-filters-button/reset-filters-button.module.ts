import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';

import { ResetFiltersButtonComponent } from './reset-filters-button.component';
import { ButtonModule } from '../../../../controls/button/button.module';
import { ResetFiltersSubscriptionService } from '../../services/reset-filters-subscription.service';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    ButtonModule
  ],
  declarations: [ResetFiltersButtonComponent],
  exports: [ResetFiltersButtonComponent],
  providers: [ResetFiltersSubscriptionService]
})
export class ResetFiltersButtonModule { }
