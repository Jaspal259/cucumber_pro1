import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';
import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ResetFiltersSubscriptionService } from '../../services/reset-filters-subscription.service';

@Component({
  selector: 'bam-reset-filters-button',
  templateUrl: './reset-filters-button.component.html',
})
export class ResetFiltersButtonComponent implements OnInit {
 readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService,
    private subscriptionService: ResetFiltersSubscriptionService) {
      this.resources.adHocReportActions = resourceRouteService.getResource(route, 'adHocReportActions');
  }

  ngOnInit() {
  }

  onResetFilters() {
      this.subscriptionService.triggerResetFilters();
  }
}
