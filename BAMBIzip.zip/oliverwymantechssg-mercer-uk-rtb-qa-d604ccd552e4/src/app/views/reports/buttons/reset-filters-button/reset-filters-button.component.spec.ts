import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetFiltersButtonComponent } from './reset-filters-button.component';

describe('ResetFiltersButtonComponent', () => {
  let component: ResetFiltersButtonComponent;
  let fixture: ComponentFixture<ResetFiltersButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResetFiltersButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetFiltersButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
