import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';

import { ReportSaveButtonComponent } from './report-save-button.component';
import { ButtonModule } from '../../../../controls/button/button.module';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    ButtonModule
  ],
  declarations: [ReportSaveButtonComponent],
  exports: [ReportSaveButtonComponent]
})
export class ReportSaveButtonModule { }
