import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';
import { ReportSaveButtonSettings } from '../../models/report-save-button-settings.model';

@Component({
  selector: 'bam-report-save-button',
  templateUrl: './report-save-button.component.html',
})
export class ReportSaveButtonComponent implements OnInit {
  @Input() settings: ReportSaveButtonSettings;

  ngOnInit() {
  }
}
