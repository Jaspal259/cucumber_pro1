import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportSaveButtonComponent } from './report-save-button.component';

describe('ReportSaveButtonComponent', () => {
  let component: ReportSaveButtonComponent;
  let fixture: ComponentFixture<ReportSaveButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportSaveButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportSaveButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
