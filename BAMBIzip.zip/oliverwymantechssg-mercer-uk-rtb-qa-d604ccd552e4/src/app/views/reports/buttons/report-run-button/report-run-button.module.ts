import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MercerOSModule } from 'merceros-ui-components';

import { ReportRunButtonComponent } from './report-run-button.component';
import { ButtonModule } from '../../../../controls/button/button.module';

@NgModule({
  imports: [
    CommonModule,
    MercerOSModule,
    ButtonModule
  ],
  declarations: [ReportRunButtonComponent],
  exports: [ReportRunButtonComponent]
})
export class ReportRunButtonModule { }
