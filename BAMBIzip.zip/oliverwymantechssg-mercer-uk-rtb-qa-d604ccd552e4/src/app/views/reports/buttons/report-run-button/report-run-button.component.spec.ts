import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportRunButtonComponent } from './report-run-button.component';

describe('ReportRunButtonComponent', () => {
  let component: ReportRunButtonComponent;
  let fixture: ComponentFixture<ReportRunButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportRunButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportRunButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect<any>(component).toBeTruthy();
  });
});
