import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

import { ResourceRouteService } from '../../../../services/resources/resource-route.service';
import { ResourceProviderDictionary } from '../../../../models/resources/resource-provider-dictionary';

@Component({
  selector: 'bam-report-run-button',
  templateUrl: './report-run-button.component.html',
})
export class ReportRunButtonComponent implements OnInit {
  @Output() runClick = new EventEmitter();
  readonly resources = new ResourceProviderDictionary();

  constructor(route: ActivatedRoute,
    resourceRouteService: ResourceRouteService) {
      this.resources.adHocReportActions = resourceRouteService.getResource(route, 'adHocReportActions');
  }

  ngOnInit() {
  }

  onRun() {
    this.runClick.emit();
  }
}
